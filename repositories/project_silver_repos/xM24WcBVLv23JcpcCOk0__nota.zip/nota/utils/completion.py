"""Shell auto-completion helpers for nota.

Provides dynamic completions for note titles, tags, and commands
that can be wired into bash, zsh, and fish via Click's completion system.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, List

import click


# ---------------------------------------------------------------------------
# Dynamic completion callbacks

def complete_note_ref(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> List[click.shell_completion.CompletionItem]:
    """Complete a note reference (stem or title) from the active vault."""
    try:
        from ..core.store import Store
        from ..utils.config import get_config

        cfg = get_config()
        vault = cfg.vault or Path.cwd()
        nota_dir = vault / ".nota"
        if not nota_dir.exists():
            return []

        with Store(vault) as store:
            items = []
            for note in store.notes():
                if incomplete.lower() in note.stem.lower() or incomplete.lower() in note.title.lower():
                    items.append(
                        click.shell_completion.CompletionItem(
                            note.stem,
                            help=note.title,
                        )
                    )
            return items[:40]
    except Exception:
        return []


def complete_tag(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> List[click.shell_completion.CompletionItem]:
    """Complete a tag name from the active vault's tag index."""
    try:
        from ..core.store import Store
        from ..utils.config import get_config

        cfg = get_config()
        vault = cfg.vault or Path.cwd()
        nota_dir = vault / ".nota"
        if not nota_dir.exists():
            return []

        with Store(vault) as store:
            tag_counts = store.all_tags()
            return [
                click.shell_completion.CompletionItem(tag, help=f"{count} note(s)")
                for tag, count in tag_counts.items()
                if incomplete.lower() in tag.lower()
            ][:30]
    except Exception:
        return []


def complete_export_format(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> List[click.shell_completion.CompletionItem]:
    formats = [
        ("html", "Self-contained HTML file"),
        ("json", "JSON with graph data"),
        ("pdf",  "PDF via WeasyPrint"),
    ]
    return [
        click.shell_completion.CompletionItem(fmt, help=desc)
        for fmt, desc in formats
        if incomplete.lower() in fmt
    ]


# ---------------------------------------------------------------------------
# Install helpers

_BASH_COMPLETE_VAR  = "_NOTA_COMPLETE"
_BASH_SCRIPT = """\
# nota bash completion
_{name}_complete() {{
    local IFS=$'\\n'
    local response
    response=$(env {var}=bash_complete {name} "${{COMP_WORDS[@]}}" 2>/dev/null)
    for completion in $response; do
        IFS=',' read -r type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        else
            COMPREPLY+=($value)
        fi
    done
    return 0
}}
complete -o nosort -F _{name}_complete {name}
""".format(name="nota", var=_BASH_COMPLETE_VAR)

_ZSH_SCRIPT = """\
#compdef nota
_{name}_complete() {{
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[{name}] )) && return 1
    response=("${{(@f)$(env {var}=zsh_complete {name} "${{words[@]}}" 2>/dev/null)}}")
    for type key descr in "${{response[@]}}"; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done
    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi
    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}}
compdef _{name}_complete {name}
""".format(name="nota", var=_BASH_COMPLETE_VAR)

_FISH_SCRIPT = """\
function _nota_complete
    set -l response (env {var}=fish_complete nota (commandline -cp))
    for completion in $response
        set -l metadata (string split "," $completion)
        if test $metadata[1] = "dir"
            __fish_complete_directories
        else if test $metadata[1] = "file"
            __fish_complete_path
        else
            echo $metadata[2]
        end
    end
end
complete --no-files --command nota --arguments "(_nota_complete)"
""".format(var=_BASH_COMPLETE_VAR)


def install_completion(shell: str) -> str:
    """Return the shell completion script for *shell*."""
    shell = shell.lower()
    if shell == "bash":
        return _BASH_SCRIPT
    if shell == "zsh":
        return _ZSH_SCRIPT
    if shell == "fish":
        return _FISH_SCRIPT
    raise ValueError(f"Unsupported shell: {shell!r}. Choose bash, zsh, or fish.")


def detect_shell() -> str:
    """Best-effort detection of the user's current shell."""
    import os
    shell_env = os.environ.get("SHELL", "")
    if "zsh" in shell_env:
        return "zsh"
    if "fish" in shell_env:
        return "fish"
    return "bash"
