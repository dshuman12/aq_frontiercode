"""Vault backup and restore utilities for nota.

Provides:
  - create_backup()   — zip the vault to a timestamped archive
  - restore_backup()  — extract an archive back to a vault directory
  - list_backups()    — enumerate existing backup archives
  - prune_backups()   — delete old backups beyond a retention limit
  - BackupManifest    — metadata written inside every archive
  - verify_backup()   — check archive integrity
  - BackupRotator     — policy-based backup rotation
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import zipfile
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Constants

MANIFEST_NAME    = ".nota_backup_manifest.json"
DEFAULT_COMPRESS = zipfile.ZIP_DEFLATED
ARCHIVE_PREFIX   = "nota_backup_"
ARCHIVE_EXT      = ".zip"


# ---------------------------------------------------------------------------
# Manifest

@dataclass
class BackupManifest:
    """Metadata stored at the root of every backup archive."""
    created_at: str         # ISO-8601
    vault_name: str
    note_count: int
    file_count: int
    total_bytes: int
    nota_version: str = "unknown"
    hostname: str     = ""
    checksum: str     = ""   # sha256 of all file paths+sizes (lightweight)
    tags: List[str]   = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, text: str) -> "BackupManifest":
        data = json.loads(text)
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def summary(self) -> str:
        return (
            f"Vault    : {self.vault_name}\n"
            f"Created  : {self.created_at}\n"
            f"Notes    : {self.note_count}\n"
            f"Files    : {self.file_count}\n"
            f"Size     : {self.total_bytes:,} bytes\n"
            f"Checksum : {self.checksum[:12]}…"
        )


# ---------------------------------------------------------------------------
# Backup creation

def create_backup(
    vault_path: Path,
    dest_dir: Path,
    *,
    include_patterns: Optional[List[str]] = None,
    exclude_patterns: Optional[List[str]] = None,
    tags: Optional[List[str]] = None,
    nota_version: str = "unknown",
    compress_level: int = 6,
) -> Path:
    """Create a zip backup of *vault_path* inside *dest_dir*.

    Returns the path to the created archive.
    """
    vault_path = Path(vault_path)
    dest_dir   = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    include_patterns = include_patterns or ["**/*.md", "**/.nota/**/*"]
    exclude_patterns = exclude_patterns or []

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_path = dest_dir / f"{ARCHIVE_PREFIX}{vault_path.name}_{stamp}{ARCHIVE_EXT}"

    files = _collect_files(vault_path, include_patterns, exclude_patterns)
    total_bytes = sum(p.stat().st_size for p in files)
    note_count  = sum(1 for p in files if p.suffix == ".md")

    checksum = _compute_checksum(vault_path, files)

    try:
        hostname = os.uname().nodename  # type: ignore[attr-defined]
    except AttributeError:
        hostname = os.environ.get("COMPUTERNAME", "unknown")

    manifest = BackupManifest(
        created_at    = datetime.now().isoformat(timespec="seconds"),
        vault_name    = vault_path.name,
        note_count    = note_count,
        file_count    = len(files),
        total_bytes   = total_bytes,
        nota_version  = nota_version,
        hostname      = hostname,
        checksum      = checksum,
        tags          = list(tags or []),
    )

    compression = zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(
        archive_path, "w", compression=compression, compresslevel=compress_level
    ) as zf:
        zf.writestr(MANIFEST_NAME, manifest.to_json())
        for p in files:
            arcname = p.relative_to(vault_path)
            zf.write(p, arcname)

    return archive_path


def _collect_files(
    vault_path: Path,
    include_patterns: List[str],
    exclude_patterns: List[str],
) -> List[Path]:
    collected: set = set()
    for pattern in include_patterns:
        for p in vault_path.glob(pattern):
            if p.is_file():
                collected.add(p)
    if exclude_patterns:
        filtered: set = set()
        for p in collected:
            rel = str(p.relative_to(vault_path))
            if not any(_match_pattern(rel, ep) for ep in exclude_patterns):
                filtered.add(p)
        return sorted(filtered)
    return sorted(collected)


def _match_pattern(path_str: str, pattern: str) -> bool:
    import fnmatch
    return fnmatch.fnmatch(path_str, pattern)


def _compute_checksum(vault_path: Path, files: List[Path]) -> str:
    h = hashlib.sha256()
    for p in sorted(files):
        rel = str(p.relative_to(vault_path))
        size = p.stat().st_size
        h.update(f"{rel}:{size}\n".encode())
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Backup listing and querying

@dataclass
class BackupInfo:
    path: Path
    manifest: Optional[BackupManifest]
    size_bytes: int
    created_at: Optional[datetime]

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def age_days(self) -> float:
        if self.created_at is None:
            return float("inf")
        return (datetime.now() - self.created_at).total_seconds() / 86400

    def __str__(self) -> str:
        size_kb = self.size_bytes // 1024
        ca = self.created_at.strftime("%Y-%m-%d %H:%M") if self.created_at else "?"
        notes = self.manifest.note_count if self.manifest else "?"
        return f"{self.name}  ({size_kb} KB, {notes} notes, {ca})"


def list_backups(backup_dir: Path) -> List[BackupInfo]:
    """Return BackupInfo for every archive in *backup_dir*."""
    backup_dir = Path(backup_dir)
    if not backup_dir.is_dir():
        return []
    result: List[BackupInfo] = []
    for p in sorted(backup_dir.glob(f"{ARCHIVE_PREFIX}*{ARCHIVE_EXT}"), reverse=True):
        manifest = _read_manifest(p)
        created_at = _parse_created_at(manifest)
        result.append(
            BackupInfo(
                path       = p,
                manifest   = manifest,
                size_bytes = p.stat().st_size,
                created_at = created_at,
            )
        )
    return result


def _read_manifest(archive_path: Path) -> Optional[BackupManifest]:
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            if MANIFEST_NAME in zf.namelist():
                data = zf.read(MANIFEST_NAME).decode("utf-8")
                return BackupManifest.from_json(data)
    except Exception:
        pass
    return None


def _parse_created_at(manifest: Optional[BackupManifest]) -> Optional[datetime]:
    if manifest is None:
        return None
    try:
        return datetime.fromisoformat(manifest.created_at)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Backup verification

def verify_backup(archive_path: Path) -> Tuple[bool, str]:
    """Check that *archive_path* is a valid, readable backup.

    Returns (ok, message).
    """
    archive_path = Path(archive_path)
    if not archive_path.is_file():
        return False, f"File not found: {archive_path}"

    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            bad = zf.testzip()
            if bad:
                return False, f"Corrupt entry: {bad}"
            names = zf.namelist()
    except zipfile.BadZipFile as exc:
        return False, f"Bad zip file: {exc}"

    if MANIFEST_NAME not in names:
        return False, "Missing backup manifest (may not be a nota backup)"

    manifest = _read_manifest(archive_path)
    if manifest is None:
        return False, "Could not parse backup manifest"

    md_count = sum(1 for n in names if n.endswith(".md"))
    if md_count != manifest.note_count:
        return False, (
            f"Note count mismatch: manifest says {manifest.note_count}, "
            f"archive has {md_count}"
        )

    return True, f"OK — {manifest.note_count} notes, created {manifest.created_at}"


# ---------------------------------------------------------------------------
# Restore

def restore_backup(
    archive_path: Path,
    target_dir: Path,
    *,
    overwrite: bool = False,
    dry_run: bool = False,
) -> Tuple[int, List[str]]:
    """Extract *archive_path* into *target_dir*.

    Returns (files_restored, skipped_list).
    """
    archive_path = Path(archive_path)
    target_dir   = Path(target_dir)

    ok, msg = verify_backup(archive_path)
    if not ok:
        raise ValueError(f"Cannot restore invalid backup: {msg}")

    target_dir.mkdir(parents=True, exist_ok=True)
    restored = 0
    skipped: List[str] = []

    with zipfile.ZipFile(archive_path, "r") as zf:
        for member in zf.infolist():
            if member.filename == MANIFEST_NAME:
                continue
            dest = target_dir / member.filename
            if dest.exists() and not overwrite:
                skipped.append(member.filename)
                continue
            if not dry_run:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as src, open(dest, "wb") as out:
                    shutil.copyfileobj(src, out)
            restored += 1

    return restored, skipped


# ---------------------------------------------------------------------------
# Pruning

def prune_backups(
    backup_dir: Path,
    *,
    keep_last: int = 10,
    keep_days: Optional[int] = None,
    dry_run: bool = False,
) -> List[Path]:
    """Delete old backups according to retention policy.

    Returns list of deleted archive paths.
    """
    backups = list_backups(backup_dir)
    to_delete: List[BackupInfo] = []

    if keep_days is not None:
        cutoff = datetime.now() - timedelta(days=keep_days)
        for bi in backups:
            if bi.created_at and bi.created_at < cutoff:
                to_delete.append(bi)

    if len(backups) > keep_last:
        # Sort by date descending, oldest ones beyond keep_last are candidates
        by_date = sorted(
            [b for b in backups if b not in to_delete],
            key=lambda b: b.created_at or datetime.min,
            reverse=True,
        )
        to_delete.extend(by_date[keep_last:])

    deleted: List[Path] = []
    for bi in to_delete:
        if not dry_run:
            bi.path.unlink(missing_ok=True)
        deleted.append(bi.path)

    return deleted


# ---------------------------------------------------------------------------
# Policy-based rotation

class BackupRotator:
    """Applies a rolling backup policy: hourly/daily/weekly/monthly."""

    def __init__(
        self,
        backup_dir: Path,
        keep_hourly:  int = 24,
        keep_daily:   int = 7,
        keep_weekly:  int = 4,
        keep_monthly: int = 12,
    ) -> None:
        self.backup_dir   = Path(backup_dir)
        self.keep_hourly  = keep_hourly
        self.keep_daily   = keep_daily
        self.keep_weekly  = keep_weekly
        self.keep_monthly = keep_monthly

    def prune(self, dry_run: bool = False) -> Dict[str, List[Path]]:
        """Prune backups, keeping the most recent in each tier."""
        backups = list_backups(self.backup_dir)
        backups_by_time = sorted(
            backups, key=lambda b: b.created_at or datetime.min, reverse=True
        )

        now = datetime.now()

        def _keep_n(items: List[BackupInfo], n: int, period_fn) -> set:
            seen: set = set()
            kept: set = set()
            for b in items:
                if b.created_at is None:
                    continue
                key = period_fn(b.created_at)
                if key not in seen:
                    seen.add(key)
                    kept.add(b.path)
                if len(seen) >= n:
                    break
            return kept

        keep_hourly  = _keep_n(backups_by_time, self.keep_hourly,
                                lambda dt: (dt.year, dt.month, dt.day, dt.hour))
        keep_daily   = _keep_n(backups_by_time, self.keep_daily,
                                lambda dt: (dt.year, dt.month, dt.day))
        keep_weekly  = _keep_n(backups_by_time, self.keep_weekly,
                                lambda dt: (dt.isocalendar()[0], dt.isocalendar()[1]))
        keep_monthly = _keep_n(backups_by_time, self.keep_monthly,
                                lambda dt: (dt.year, dt.month))

        keep_all = keep_hourly | keep_daily | keep_weekly | keep_monthly
        deleted: Dict[str, List[Path]] = {"deleted": []}

        for b in backups:
            if b.path not in keep_all:
                if not dry_run:
                    b.path.unlink(missing_ok=True)
                deleted["deleted"].append(b.path)

        return deleted
