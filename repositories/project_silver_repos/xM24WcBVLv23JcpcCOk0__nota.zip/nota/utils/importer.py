"""Multi-format vault importer.

Supported sources:
  - Obsidian vault (directory of .md files)
  - jrnl export (JSON or plain text)
  - Bear (JSON export)
  - Roam Research (JSON export)
  - Plain directory (any .md files)
"""
from __future__ import annotations

import json
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import frontmatter

from ..core.note import Note
from ..core.store import Store


@dataclass
class ImportResult:
    imported: List[Path] = field(default_factory=list)
    skipped: List[Path]  = field(default_factory=list)
    errors: List[tuple[Path, str]] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.imported)

    def summary(self) -> str:
        parts = [f"{len(self.imported)} imported"]
        if self.skipped:
            parts.append(f"{len(self.skipped)} skipped (already exist)")
        if self.errors:
            parts.append(f"{len(self.errors)} error(s)")
        return ", ".join(parts)


# ---------------------------------------------------------------------------
# Obsidian

def from_obsidian(
    src: Path,
    store: Store,
    *,
    overwrite: bool = False,
    rewrite_links: bool = True,
) -> ImportResult:
    """Import an Obsidian vault directory into a nota vault."""
    result = ImportResult()

    for md_path in sorted(src.rglob("*.md")):
        if any(p.startswith(".") for p in md_path.relative_to(src).parts):
            result.skipped.append(md_path)
            continue

        rel = md_path.relative_to(src)
        dest = store.vault_root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)

        if dest.exists() and not overwrite:
            result.skipped.append(md_path)
            continue

        try:
            content = md_path.read_text(encoding="utf-8", errors="replace")
            if rewrite_links:
                content = _obsidian_to_nota_links(content)
            dest.write_text(content, encoding="utf-8")
            note = Note(dest, store.vault_root)
            store.index_note(note)
            result.imported.append(dest)
        except Exception as exc:
            result.errors.append((md_path, str(exc)))

    store.conn.commit()
    return result


def _obsidian_to_nota_links(text: str) -> str:
    """Obsidian and nota both use [[links]], so this is a passthrough.

    However, Obsidian uses ![[embeds]] for images/attachments which we strip.
    """
    # strip attachment embeds
    text = re.sub(r"!\[\[([^\]]+)\]\]", r"*(attachment: \1)*", text)
    return text


# ---------------------------------------------------------------------------
# jrnl

_JRNL_ENTRY_RE = re.compile(
    r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) (.+?)(?=\n\d{4}-\d{2}-\d{2}|\Z)",
    re.DOTALL,
)


def from_jrnl_text(src: Path, store: Store) -> ImportResult:
    """Import a jrnl plain-text export (one entry per timestamp header)."""
    result = ImportResult()
    raw = src.read_text(encoding="utf-8", errors="replace")

    for m in _JRNL_ENTRY_RE.finditer(raw):
        ts_str, body = m.group(1), m.group(2).strip()
        try:
            ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M")
        except ValueError:
            continue

        # first line of body becomes the title
        lines = body.splitlines()
        title = lines[0].strip() if lines else ts.strftime("%Y-%m-%d %H:%M")
        content = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""

        slug = ts.strftime("%Y-%m-%d") + "-" + _slugify(title)[:50]
        dest = store.vault_root / "jrnl" / f"{slug}.md"
        dest.parent.mkdir(parents=True, exist_ok=True)

        if dest.exists():
            result.skipped.append(dest)
            continue

        post = frontmatter.Post(
            content,
            title=title,
            created=ts.isoformat(),
            tags=["jrnl"],
        )
        dest.write_text(frontmatter.dumps(post), encoding="utf-8")
        note = Note(dest, store.vault_root)
        store.index_note(note)
        result.imported.append(dest)

    store.conn.commit()
    return result


def from_jrnl_json(src: Path, store: Store) -> ImportResult:
    """Import a jrnl JSON export."""
    result = ImportResult()
    data = json.loads(src.read_text(encoding="utf-8"))
    entries = data if isinstance(data, list) else data.get("entries", [])

    for entry in entries:
        title = entry.get("title", "Untitled")
        body  = entry.get("body", "")
        ts_str = entry.get("date", "")
        tags = entry.get("tags", [])

        try:
            ts = datetime.fromisoformat(ts_str)
        except (ValueError, TypeError):
            ts = datetime.now()

        slug = ts.strftime("%Y-%m-%d") + "-" + _slugify(title)[:50]
        dest = store.vault_root / "jrnl" / f"{slug}.md"
        dest.parent.mkdir(parents=True, exist_ok=True)

        if dest.exists():
            result.skipped.append(dest)
            continue

        try:
            post = frontmatter.Post(
                body,
                title=title,
                created=ts.isoformat(),
                tags=tags + ["jrnl"],
            )
            dest.write_text(frontmatter.dumps(post), encoding="utf-8")
            note = Note(dest, store.vault_root)
            store.index_note(note)
            result.imported.append(dest)
        except Exception as exc:
            result.errors.append((dest, str(exc)))

    store.conn.commit()
    return result


# ---------------------------------------------------------------------------
# Bear

def from_bear_json(src: Path, store: Store) -> ImportResult:
    """Import Bear app JSON export (backup format)."""
    result = ImportResult()
    data = json.loads(src.read_text(encoding="utf-8"))
    notes_data = data if isinstance(data, list) else [data]

    for item in notes_data:
        title   = item.get("title", "Untitled")
        content = item.get("text", item.get("content", ""))
        tags    = item.get("tags", [])
        created_str = item.get("creationDate", item.get("created", ""))

        try:
            created = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
        except (ValueError, TypeError, AttributeError):
            created = datetime.now()

        # Bear uses #tag syntax inline — already compatible with nota
        slug = _slugify(title)[:80]
        dest = store.vault_root / "bear" / f"{slug}.md"
        dest.parent.mkdir(parents=True, exist_ok=True)

        if dest.exists():
            result.skipped.append(dest)
            continue

        try:
            post = frontmatter.Post(
                content,
                title=title,
                created=created.isoformat(),
                tags=tags,
            )
            dest.write_text(frontmatter.dumps(post), encoding="utf-8")
            note = Note(dest, store.vault_root)
            store.index_note(note)
            result.imported.append(dest)
        except Exception as exc:
            result.errors.append((dest, str(exc)))

    store.conn.commit()
    return result


# ---------------------------------------------------------------------------
# Roam Research

def from_roam_json(src: Path, store: Store) -> ImportResult:
    """Import a Roam Research JSON export.

    Roam's nested block structure is flattened into a markdown bullet list.
    """
    result = ImportResult()
    pages = json.loads(src.read_text(encoding="utf-8"))

    def _flatten_blocks(blocks: list, depth: int = 0) -> str:
        lines = []
        for block in blocks:
            text = block.get("string", "").strip()
            if text:
                indent = "  " * depth
                lines.append(f"{indent}- {text}")
            children = block.get("children", [])
            if children:
                lines.append(_flatten_blocks(children, depth + 1))
        return "\n".join(lines)

    for page in pages:
        title    = page.get("title", "Untitled")
        children = page.get("children", [])
        content  = _flatten_blocks(children)
        created_ms = page.get("create-time", 0)

        created = datetime.fromtimestamp(created_ms / 1000) if created_ms else datetime.now()

        slug = _slugify(title)[:80]
        dest = store.vault_root / "roam" / f"{slug}.md"
        dest.parent.mkdir(parents=True, exist_ok=True)

        if dest.exists():
            result.skipped.append(dest)
            continue

        # rewrite Roam [[page links]] — they're already wiki-link syntax
        try:
            post = frontmatter.Post(
                content,
                title=title,
                created=created.isoformat(),
                tags=["roam"],
            )
            dest.write_text(frontmatter.dumps(post), encoding="utf-8")
            note = Note(dest, store.vault_root)
            store.index_note(note)
            result.imported.append(dest)
        except Exception as exc:
            result.errors.append((dest, str(exc)))

    store.conn.commit()
    return result


# ---------------------------------------------------------------------------
# Plain directory

def from_directory(src: Path, store: Store, *, glob: str = "*.md") -> ImportResult:
    """Import all markdown files from a plain directory (non-recursive)."""
    result = ImportResult()
    for md_path in sorted(src.glob(glob)):
        dest = store.vault_root / md_path.name
        if dest.exists():
            result.skipped.append(md_path)
            continue
        try:
            shutil.copy2(str(md_path), str(dest))
            note = Note(dest, store.vault_root)
            store.index_note(note)
            result.imported.append(dest)
        except Exception as exc:
            result.errors.append((md_path, str(exc)))
    store.conn.commit()
    return result


# ---------------------------------------------------------------------------
# Dispatcher

def import_vault(
    src: Path,
    store: Store,
    fmt: str = "auto",
    **kwargs,
) -> ImportResult:
    """Detect format and import from *src* into *store*.

    *fmt* may be: ``'auto'``, ``'obsidian'``, ``'jrnl'``, ``'jrnl-json'``,
    ``'bear'``, ``'roam'``, or ``'directory'``.
    """
    if fmt == "auto":
        fmt = _detect_format(src)

    if fmt == "obsidian":
        return from_obsidian(src, store, **kwargs)
    if fmt == "jrnl":
        return from_jrnl_text(src, store)
    if fmt == "jrnl-json":
        return from_jrnl_json(src, store)
    if fmt == "bear":
        return from_bear_json(src, store)
    if fmt == "roam":
        return from_roam_json(src, store)
    if fmt == "directory":
        return from_directory(src, store, **kwargs)

    raise ValueError(f"Unknown import format: {fmt!r}")


def _detect_format(src: Path) -> str:
    if src.is_dir():
        if (src / ".obsidian").exists():
            return "obsidian"
        return "directory"
    if src.suffix == ".json":
        try:
            data = json.loads(src.read_text(encoding="utf-8"))
            if isinstance(data, list) and data and "title" in data[0] and "children" in data[0]:
                return "roam"
            if isinstance(data, list) and data and "title" in data[0]:
                return "bear"
            if isinstance(data, dict) and "entries" in data:
                return "jrnl-json"
        except Exception:
            pass
        return "jrnl-json"
    return "jrnl"


# ---------------------------------------------------------------------------
# Helpers

def _slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = text.strip("-")
    return text
