"""Remote template fetching with local TTL cache.

Templates are fetched over HTTPS and cached in .nota/templates/
with a configurable time-to-live (default 24 hours).
"""
from __future__ import annotations

import hashlib
import json
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional


_DEFAULT_TTL = 86400  # 24 hours


class TemplateFetcher:
    """Fetch and cache Jinja2 templates from remote URLs."""

    def __init__(self, cache_dir: Path, ttl: int = _DEFAULT_TTL) -> None:
        self.cache_dir = cache_dir
        self.ttl = ttl
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._meta_path = cache_dir / "_meta.json"
        self._meta: dict[str, dict] = self._load_meta()

    # ------------------------------------------------------------------
    # meta persistence

    def _load_meta(self) -> dict[str, dict]:
        if self._meta_path.exists():
            try:
                return json.loads(self._meta_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}

    def _save_meta(self) -> None:
        self._meta_path.write_text(json.dumps(self._meta, indent=2), encoding="utf-8")

    # ------------------------------------------------------------------
    # cache helpers

    def _cache_key(self, url: str) -> str:
        return hashlib.sha256(url.encode()).hexdigest()[:20]

    def _is_fresh(self, url: str) -> bool:
        meta = self._meta.get(url)
        if not meta:
            return False
        return (time.time() - meta.get("fetched_at", 0)) < self.ttl

    def _cached_path(self, url: str) -> Path:
        return self.cache_dir / (self._cache_key(url) + ".md")

    def _store(self, url: str, content: str) -> None:
        self._cached_path(url).write_text(content, encoding="utf-8")
        self._meta[url] = {"fetched_at": time.time(), "key": self._cache_key(url)}
        self._save_meta()

    # ------------------------------------------------------------------
    # public API

    def fetch(self, url: str, *, force: bool = False) -> str:
        """Return template content for *url*, using cache when fresh.

        Args:
            url: HTTP/HTTPS URL pointing to a Jinja2 template file.
            force: Bypass cache and always re-fetch.

        Raises:
            urllib.error.URLError: if the URL cannot be reached and no cache exists.
        """
        cached = self._cached_path(url)

        if not force and self._is_fresh(url) and cached.exists():
            return cached.read_text(encoding="utf-8")

        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "nota-template-fetcher/1.0"},
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                content = resp.read().decode("utf-8", errors="replace")
            self._store(url, content)
            return content
        except urllib.error.URLError:
            # stale cache is better than nothing
            if cached.exists():
                return cached.read_text(encoding="utf-8")
            raise

    def invalidate(self, url: str) -> bool:
        """Remove cached entry for *url*. Returns True if it existed."""
        cached = self._cached_path(url)
        removed = False
        if cached.exists():
            cached.unlink()
            removed = True
        if url in self._meta:
            del self._meta[url]
            self._save_meta()
            removed = True
        return removed

    def clear(self) -> int:
        """Wipe the entire template cache. Returns number of entries removed."""
        count = 0
        for p in self.cache_dir.glob("*.md"):
            p.unlink()
            count += 1
        self._meta.clear()
        self._save_meta()
        return count

    def list_cached(self) -> list[dict]:
        """Return metadata for all cached templates."""
        entries = []
        for url, meta in self._meta.items():
            cached = self._cached_path(url)
            entries.append({
                "url": url,
                "cached": cached.exists(),
                "fetched_at": meta.get("fetched_at"),
                "age_hours": round((time.time() - meta.get("fetched_at", 0)) / 3600, 1),
                "fresh": self._is_fresh(url),
                "size": cached.stat().st_size if cached.exists() else 0,
            })
        return entries


def fetch_template(url: str, cache_dir: Path, *, ttl: int = _DEFAULT_TTL, force: bool = False) -> str:
    """Convenience wrapper — fetch a single remote template."""
    return TemplateFetcher(cache_dir, ttl=ttl).fetch(url, force=force)
