"""Database migration system for nota's SQLite index.

Migrations are numbered SQL scripts applied in order. Each migration
is recorded in a ``_migrations`` table so re-runs are idempotent.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Migration definitions

@dataclass
class Migration:
    version: int
    description: str
    sql: str


MIGRATIONS: List[Migration] = [
    Migration(
        version=1,
        description="Initial schema — notes, fts, meta",
        sql="""
        CREATE TABLE IF NOT EXISTS notes (
            id       TEXT PRIMARY KEY,
            path     TEXT NOT NULL,
            title    TEXT,
            tags     TEXT,
            links    TEXT,
            checksum TEXT,
            created  TEXT,
            modified TEXT
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS fts USING fts5(
            id, title, content, tokenize='unicode61'
        );
        CREATE TABLE IF NOT EXISTS meta (
            key TEXT PRIMARY KEY, value TEXT
        );
        """,
    ),
    Migration(
        version=2,
        description="Add words column to notes table",
        sql="""
        ALTER TABLE notes ADD COLUMN words INTEGER DEFAULT 0;
        """,
    ),
    Migration(
        version=3,
        description="Add modified index for recent() queries",
        sql="""
        CREATE INDEX IF NOT EXISTS idx_notes_modified ON notes(modified DESC);
        """,
    ),
    Migration(
        version=4,
        description="Add created index for date-range queries",
        sql="""
        CREATE INDEX IF NOT EXISTS idx_notes_created ON notes(created DESC);
        """,
    ),
    Migration(
        version=5,
        description="Rebuild FTS with porter tokenizer for stemming",
        sql="""
        DROP TABLE IF EXISTS fts;
        CREATE VIRTUAL TABLE fts USING fts5(
            id, title, content, tokenize='porter unicode61'
        );
        """,
    ),
    Migration(
        version=6,
        description="Add plugin key-value store table",
        sql="""
        CREATE TABLE IF NOT EXISTS plugin_store (
            plugin TEXT NOT NULL,
            key    TEXT NOT NULL,
            value  TEXT,
            PRIMARY KEY (plugin, key)
        );
        """,
    ),
    Migration(
        version=7,
        description="Add heading_count column",
        sql="""
        ALTER TABLE notes ADD COLUMN heading_count INTEGER DEFAULT 0;
        """,
    ),
    Migration(
        version=8,
        description="Add external_links column",
        sql="""
        ALTER TABLE notes ADD COLUMN external_links TEXT DEFAULT '[]';
        """,
    ),
]

_BOOTSTRAP = """
CREATE TABLE IF NOT EXISTS _migrations (
    version     INTEGER PRIMARY KEY,
    description TEXT,
    applied_at  TEXT NOT NULL
);
"""


# ---------------------------------------------------------------------------
# Migrator

class Migrator:
    """Applies pending migrations to a SQLite database."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _applied_versions(self, conn: sqlite3.Connection) -> set[int]:
        conn.executescript(_BOOTSTRAP)
        conn.commit()
        rows = conn.execute("SELECT version FROM _migrations").fetchall()
        return {r["version"] for r in rows}

    def _record(self, conn: sqlite3.Connection, m: Migration) -> None:
        conn.execute(
            "INSERT OR REPLACE INTO _migrations(version, description, applied_at) VALUES (?,?,?)",
            (m.version, m.description, datetime.utcnow().isoformat()),
        )

    def pending(self) -> List[Migration]:
        conn = self._connect()
        try:
            applied = self._applied_versions(conn)
            return [m for m in MIGRATIONS if m.version not in applied]
        finally:
            conn.close()

    def apply(self, *, target: Optional[int] = None) -> List[Migration]:
        """Apply all pending migrations up to *target* (default: latest).

        Returns the list of migrations that were actually applied.
        """
        conn = self._connect()
        applied_migrations: List[Migration] = []
        try:
            applied = self._applied_versions(conn)
            to_apply = [
                m for m in MIGRATIONS
                if m.version not in applied
                and (target is None or m.version <= target)
            ]
            for migration in to_apply:
                try:
                    conn.executescript(migration.sql)
                except sqlite3.OperationalError as exc:
                    # Some ALTER TABLE statements fail if column already exists;
                    # treat as already applied rather than crashing.
                    if "duplicate column" in str(exc).lower():
                        pass
                    else:
                        raise
                self._record(conn, migration)
                conn.commit()
                applied_migrations.append(migration)
        finally:
            conn.close()
        return applied_migrations

    def rollback(self, target: int) -> None:
        """Remove migration records for versions > *target*.

        Note: this does NOT reverse schema changes (SQLite has limited DDL
        rollback). Use with care — primarily for re-applying migrations.
        """
        conn = self._connect()
        try:
            conn.execute(
                "DELETE FROM _migrations WHERE version > ?", (target,)
            )
            conn.commit()
        finally:
            conn.close()

    def status(self) -> List[dict]:
        """Return a list of all known migrations with applied/pending status."""
        conn = self._connect()
        try:
            applied = self._applied_versions(conn)
            rows = {
                r["version"]: r["applied_at"]
                for r in conn.execute("SELECT version, applied_at FROM _migrations").fetchall()
            }
        finally:
            conn.close()

        return [
            {
                "version":     m.version,
                "description": m.description,
                "applied":     m.version in applied,
                "applied_at":  rows.get(m.version),
            }
            for m in MIGRATIONS
        ]

    def latest_version(self) -> int:
        return MIGRATIONS[-1].version if MIGRATIONS else 0

    def current_version(self) -> int:
        conn = self._connect()
        try:
            applied = self._applied_versions(conn)
            return max(applied, default=0)
        finally:
            conn.close()

    def is_up_to_date(self) -> bool:
        return self.current_version() == self.latest_version()


# ---------------------------------------------------------------------------
# Convenience

def ensure_migrated(db_path: Path) -> List[Migration]:
    """Apply all pending migrations to *db_path* and return applied list."""
    return Migrator(db_path).apply()
