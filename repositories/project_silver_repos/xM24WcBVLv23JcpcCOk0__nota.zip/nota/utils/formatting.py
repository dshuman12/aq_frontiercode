"""Terminal and output formatting utilities for nota.

Provides Rich-compatible helpers for rendering tables, trees, progress
bars, panels, and plain-text fallbacks when the terminal is not capable
of colour output.

All functions accept a ``console`` parameter (Rich Console).  When
omitted a module-level default console is used.  This makes every
function directly callable in tests without any setup.
"""
from __future__ import annotations

import os
import shutil
import textwrap
from datetime import datetime, date
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from rich.console import Console
    from rich.table import Table
    from rich.tree import Tree
    from rich.panel import Panel
    from rich.text import Text
    from rich.progress import (
        Progress, SpinnerColumn, BarColumn,
        TaskProgressColumn, TimeElapsedColumn, TextColumn,
    )
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    _HAS_RICH = True
except ImportError:  # pragma: no cover
    _HAS_RICH = False


# ---------------------------------------------------------------------------
# Default console

def _default_console() -> "Console":
    if not _HAS_RICH:
        raise RuntimeError("rich is required for terminal formatting")
    return Console()


_console: Optional["Console"] = None


def get_console() -> "Console":
    global _console
    if _console is None:
        _console = _default_console()
    return _console


def set_console(c: "Console") -> None:
    global _console
    _console = c


# ---------------------------------------------------------------------------
# Note list table

def note_table(
    notes: List[Any],
    columns: Sequence[str] = ("title", "tags", "modified", "words"),
    console: Optional["Console"] = None,
    title: str = "",
) -> None:
    """Print a Rich table of notes to the console."""
    c = console or get_console()
    tbl = Table(title=title or "Notes", show_header=True, header_style="bold cyan")
    col_map = {
        "title":    ("Title",    "bold"),
        "tags":     ("Tags",     "green"),
        "modified": ("Modified", "dim"),
        "words":    ("Words",    "right"),
        "id":       ("ID",       "dim"),
        "path":     ("Path",     "dim"),
    }
    for col in columns:
        label, style = col_map.get(col, (col.capitalize(), ""))
        justify = "right" if col == "words" else "left"
        tbl.add_column(label, style=style, justify=justify)

    for note in notes:
        row: List[str] = []
        for col in columns:
            if col == "title":
                row.append(note.title or note.id)
            elif col == "tags":
                row.append(", ".join(note.tags) if note.tags else "—")
            elif col == "modified":
                dt = note.modified
                row.append(format_relative(dt) if dt else "—")
            elif col == "words":
                row.append(str(getattr(note, "word_count", "?")))
            elif col == "id":
                row.append(note.id)
            elif col == "path":
                row.append(str(note.path))
            else:
                row.append(str(getattr(note, col, "—")))
        tbl.add_row(*row)

    c.print(tbl)


# ---------------------------------------------------------------------------
# Tag cloud / frequency table

def tag_table(
    tag_counts: Dict[str, int],
    console: Optional["Console"] = None,
    top_n: int = 50,
) -> None:
    """Print a two-column tag → count table."""
    c = console or get_console()
    tbl = Table(title="Tags", show_header=True, header_style="bold magenta")
    tbl.add_column("Tag",   style="green")
    tbl.add_column("Notes", justify="right")
    sorted_tags = sorted(tag_counts.items(), key=lambda x: -x[1])[:top_n]
    for tag, count in sorted_tags:
        tbl.add_row(f"#{tag}", str(count))
    c.print(tbl)


# ---------------------------------------------------------------------------
# Graph summary panel

def graph_panel(summary: Dict[str, Any], console: Optional["Console"] = None) -> None:
    """Print a panel summarising graph metrics."""
    c = console or get_console()
    lines = [
        f"Nodes : [bold]{summary.get('nodes', '?')}[/bold]",
        f"Edges : [bold]{summary.get('edges', '?')}[/bold]",
    ]
    if "density" in summary:
        lines.append(f"Density : {summary['density']:.4f}")
    if "avg_degree" in summary:
        lines.append(f"Avg degree : {summary['avg_degree']:.2f}")
    if "components" in summary:
        lines.append(f"Components : {summary['components']}")
    if "diameter" in summary:
        lines.append(f"Diameter : {summary['diameter']}")
    text = "\n".join(lines)
    c.print(Panel(text, title="Graph Summary", border_style="blue"))


# ---------------------------------------------------------------------------
# Stats panel

def stats_panel(stats: Dict[str, Any], console: Optional["Console"] = None) -> None:
    """Print a statistics summary panel."""
    c = console or get_console()
    lines: List[str] = []
    labels = [
        ("notes",      "Notes"),
        ("words",      "Words"),
        ("tags",       "Tags"),
        ("links",      "Links"),
        ("orphans",    "Orphans"),
        ("avg_words",  "Avg words/note"),
        ("oldest",     "Oldest"),
        ("newest",     "Newest"),
    ]
    for key, label in labels:
        val = stats.get(key)
        if val is None:
            continue
        if isinstance(val, float):
            val = f"{val:.1f}"
        lines.append(f"{label:20s}: [bold]{val}[/bold]")
    c.print(Panel("\n".join(lines), title="Vault Stats", border_style="green"))


# ---------------------------------------------------------------------------
# Tree view (directory / link graph)

def link_tree(
    root_id: str,
    adjacency: Dict[str, List[str]],
    console: Optional["Console"] = None,
    depth: int = 3,
) -> None:
    """Render an outbound link tree starting from *root_id*."""
    c = console or get_console()
    tree = Tree(f"[bold cyan]{root_id}[/bold cyan]")
    _build_tree(tree, root_id, adjacency, depth, visited=set())
    c.print(tree)


def _build_tree(
    node: "Tree",
    current: str,
    adj: Dict[str, List[str]],
    depth: int,
    visited: set,
) -> None:
    if depth == 0 or current in visited:
        return
    visited.add(current)
    for target in adj.get(current, []):
        child = node.add(f"[green]{target}[/green]")
        _build_tree(child, target, adj, depth - 1, visited)


# ---------------------------------------------------------------------------
# Progress helpers

def make_progress(description: str = "Processing") -> "Progress":
    """Create a Rich Progress bar for long-running tasks."""
    return Progress(
        SpinnerColumn(),
        TextColumn(f"[bold blue]{description}[/bold blue]"),
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        transient=True,
    )


# ---------------------------------------------------------------------------
# Syntax-highlighted code

def code_panel(
    code: str,
    language: str = "python",
    title: str = "",
    console: Optional["Console"] = None,
) -> None:
    """Print a syntax-highlighted code block."""
    c = console or get_console()
    syn = Syntax(code, language, theme="monokai", line_numbers=True)
    c.print(Panel(syn, title=title or language))


# ---------------------------------------------------------------------------
# Date/time formatting

def format_relative(dt: Optional[datetime], now: Optional[datetime] = None) -> str:
    """Return a human-readable relative time string."""
    if dt is None:
        return "—"
    now = now or datetime.now()
    if dt.tzinfo is not None:
        now = now.replace(tzinfo=dt.tzinfo)
    delta = now - dt
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        m = seconds // 60
        return f"{m}m ago"
    if seconds < 86400:
        h = seconds // 3600
        return f"{h}h ago"
    days = delta.days
    if days == 1:
        return "yesterday"
    if days < 7:
        return f"{days}d ago"
    if days < 30:
        w = days // 7
        return f"{w}w ago"
    if days < 365:
        mo = days // 30
        return f"{mo}mo ago"
    y = days // 365
    return f"{y}y ago"


def format_size(n_bytes: int) -> str:
    """Format a byte count as a human-readable string."""
    for unit in ("B", "KB", "MB", "GB"):
        if n_bytes < 1024:
            return f"{n_bytes:.1f} {unit}"
        n_bytes //= 1024
    return f"{n_bytes:.1f} TB"


# ---------------------------------------------------------------------------
# Word-wrap helpers

def wrap_text(text: str, width: Optional[int] = None) -> str:
    """Wrap *text* to terminal width (or *width* if specified)."""
    w = width or shutil.get_terminal_size(fallback=(80, 24)).columns
    return textwrap.fill(text, width=w)


def truncate(text: str, max_len: int = 80, suffix: str = "…") -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - len(suffix)] + suffix


# ---------------------------------------------------------------------------
# Colour helpers (fallback-safe)

_ANSI_RESET = "\033[0m"
_ANSI_COLORS = {
    "red":     "\033[31m",
    "green":   "\033[32m",
    "yellow":  "\033[33m",
    "blue":    "\033[34m",
    "magenta": "\033[35m",
    "cyan":    "\033[36m",
    "bold":    "\033[1m",
    "dim":     "\033[2m",
}


def colorize(text: str, color: str, force: bool = False) -> str:
    """Wrap *text* in ANSI colour if stdout is a TTY (or *force* is True)."""
    if not force and not os.isatty(1):
        return text
    code = _ANSI_COLORS.get(color, "")
    if not code:
        return text
    return f"{code}{text}{_ANSI_RESET}"


# ---------------------------------------------------------------------------
# Plain-text fallback table

def plain_table(rows: List[List[str]], headers: List[str]) -> str:
    """Render a plain-text ASCII table (no Rich dependency)."""
    all_rows = [headers] + rows
    col_widths = [max(len(str(r[i])) for r in all_rows) for i in range(len(headers))]
    sep = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"

    def fmt_row(row: List[str]) -> str:
        cells = " | ".join(str(row[i]).ljust(col_widths[i]) for i in range(len(headers)))
        return "| " + cells + " |"

    lines = [sep, fmt_row(headers), sep]
    for row in rows:
        lines.append(fmt_row(row))
    lines.append(sep)
    return "\n".join(lines)
