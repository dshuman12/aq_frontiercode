"""Shell integration helpers for nota.

Provides utilities for:
  - Opening notes in the user's configured editor
  - Launching a browser to a local URL
  - Running external commands with timeout and output capture
  - Shell completion script generation (bash/zsh/fish)
  - Environment detection (terminal, CI, platform)
  - Rich / plain-text output switching based on terminal capability
  - XDG / Windows / macOS data-directory resolution
"""
from __future__ import annotations

import os
import platform
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Editor integration

_FALLBACK_EDITORS = ["nano", "notepad", "vi", "vim"]


def find_editor() -> str:
    """Return the editor to use, in priority order."""
    for env_var in ("VISUAL", "EDITOR"):
        val = os.environ.get(env_var, "").strip()
        if val:
            return val
    for candidate in _FALLBACK_EDITORS:
        if shutil.which(candidate):
            return candidate
    return "notepad" if platform.system() == "Windows" else "vi"


def open_in_editor(path: Path, editor: Optional[str] = None, wait: bool = True) -> int:
    """Open *path* in the user's editor.

    Returns the editor process exit code, or -1 if the editor could not
    be launched.
    """
    editor = editor or find_editor()
    try:
        parts = shlex.split(editor) + [str(path)]
        proc = subprocess.run(parts, check=False)
        return proc.returncode
    except (FileNotFoundError, OSError):
        return -1


def open_in_browser(url: str) -> bool:
    """Open *url* in the default web browser.  Returns True on success."""
    try:
        import webbrowser
        return webbrowser.open(url)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# External commands

class CommandResult:
    def __init__(self, returncode: int, stdout: str, stderr: str) -> None:
        self.returncode = returncode
        self.stdout     = stdout
        self.stderr     = stderr

    @property
    def ok(self) -> bool:
        return self.returncode == 0

    def __repr__(self) -> str:
        return f"CommandResult(rc={self.returncode}, stdout={self.stdout[:50]!r})"


def run_command(
    cmd: List[str],
    cwd: Optional[Path] = None,
    timeout: Optional[float] = 30.0,
    env: Optional[Dict[str, str]] = None,
    input_text: Optional[str] = None,
) -> CommandResult:
    """Run *cmd* and capture stdout/stderr."""
    merged_env = dict(os.environ)
    if env:
        merged_env.update(env)
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=timeout,
            env=merged_env,
            input=input_text,
        )
        return CommandResult(proc.returncode, proc.stdout, proc.stderr)
    except subprocess.TimeoutExpired:
        return CommandResult(-1, "", f"Command timed out after {timeout}s")
    except FileNotFoundError:
        return CommandResult(-1, "", f"Command not found: {cmd[0]}")
    except OSError as exc:
        return CommandResult(-1, "", str(exc))


def check_command_available(name: str) -> bool:
    """Return True if *name* is findable on PATH."""
    return shutil.which(name) is not None


# ---------------------------------------------------------------------------
# Shell completion scripts

_BASH_COMPLETION = """\
# nota bash completion
_{name}_completion() {{
    local IFS=$'\\n'
    local response
    response=$(nota --shell-complete bash "${{COMP_WORDS[*]}}" "$COMP_CWORD")
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ "$type" == 'dir' ]]; then
            COMPREPLY+=( "$value" )
        elif [[ "$type" == 'file' ]]; then
            COMPREPLY+=( "$value" )
        elif [[ "$type" == 'plain' ]]; then
            COMPREPLY+=( "$value" )
        fi
    done
}}
complete -o nosort -F _{name}_completion nota
"""

_ZSH_COMPLETION = """\
#compdef nota
_{name}_completion() {{
    local -a completions
    local -a completions_with_descriptions
    local -a response
    response=("${{(@f)$(nota --shell-complete zsh "${{words[@]}}" "$CURRENT")}}")
    for type_and_value in ${{response[@]}}; do
        IFS=',' read -r type value description <<< "$type_and_value"
        if [[ "$type" == 'plain' ]]; then
            if [[ "$description" != '' ]]; then
                completions_with_descriptions+=("$value:$description")
            else
                completions+=("$value")
            fi
        fi
    done
    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi
    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}}
compdef _{name}_completion nota
"""

_FISH_COMPLETION = """\
# nota fish completion
function __nota_complete
    set -l response (nota --shell-complete fish (commandline -cp) (commandline -t))
    for completion in $response
        set -l metadata (string split ',' -- $completion)
        if test $metadata[1] = 'dir'
            __fish_complete_directories $metadata[2]
        else if test $metadata[1] = 'file'
            __fish_complete_path $metadata[2]
        else if test $metadata[1] = 'plain'
            echo $metadata[2]\\t$metadata[3]
        end
    end
end
complete --no-files --command nota --arguments '(__nota_complete)'
"""


def completion_script(shell: str) -> str:
    """Return the shell completion script for *shell* (bash/zsh/fish)."""
    shell = shell.lower()
    if shell == "bash":
        return _BASH_COMPLETION.format(name="nota")
    elif shell == "zsh":
        return _ZSH_COMPLETION.format(name="nota")
    elif shell == "fish":
        return _FISH_COMPLETION.format(name="nota")
    raise ValueError(f"Unsupported shell: {shell!r}. Choose from bash, zsh, fish.")


def install_completion(shell: str) -> Path:
    """Write the completion script to the appropriate location and return its path."""
    script = completion_script(shell)
    shell = shell.lower()

    if shell == "bash":
        dest = Path.home() / ".local" / "share" / "bash-completion" / "completions" / "nota"
    elif shell == "zsh":
        dest = Path.home() / ".zfunc" / "_nota"
    elif shell == "fish":
        dest = Path.home() / ".config" / "fish" / "completions" / "nota.fish"
    else:
        raise ValueError(f"Unsupported shell: {shell!r}")

    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(script, encoding="utf-8")
    return dest


# ---------------------------------------------------------------------------
# Environment detection

def is_ci() -> bool:
    """Return True if running in a CI environment."""
    ci_vars = {"CI", "GITHUB_ACTIONS", "GITLAB_CI", "TRAVIS", "CIRCLECI",
               "BUILDKITE", "JENKINS_URL", "TF_BUILD"}
    return any(os.environ.get(v) for v in ci_vars)


def is_interactive() -> bool:
    """Return True if running interactively (TTY attached)."""
    return sys.stdout.isatty() and sys.stdin.isatty()


def terminal_width() -> int:
    """Return the current terminal width (fallback: 80)."""
    try:
        return shutil.get_terminal_size(fallback=(80, 24)).columns
    except Exception:
        return 80


def supports_color() -> bool:
    """Return True if the terminal likely supports ANSI colour."""
    if not is_interactive():
        return False
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    term = os.environ.get("TERM", "")
    return "color" in term or "256" in term or term in ("xterm", "screen", "tmux")


def get_system_info() -> Dict[str, str]:
    """Return a dict of environment diagnostics."""
    return {
        "platform":    platform.system(),
        "python":      sys.version.split()[0],
        "interactive": str(is_interactive()),
        "ci":          str(is_ci()),
        "color":       str(supports_color()),
        "term_width":  str(terminal_width()),
        "editor":      find_editor(),
    }


# ---------------------------------------------------------------------------
# XDG / platform data dirs

def data_dir() -> Path:
    """Return the platform-appropriate app data directory for nota."""
    system = platform.system()
    if system == "Windows":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif system == "Darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "nota"


def config_dir() -> Path:
    """Return the platform-appropriate config directory for nota."""
    system = platform.system()
    if system == "Windows":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif system == "Darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "nota"


def cache_dir() -> Path:
    """Return the platform-appropriate cache directory for nota."""
    system = platform.system()
    if system == "Windows":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif system == "Darwin":
        base = Path.home() / "Library" / "Caches"
    else:
        base = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    return base / "nota"
