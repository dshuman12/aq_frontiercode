"""Webhook delivery for nota vault events.

Delivers HTTP POST payloads to configured endpoints whenever notes
are created, modified, or deleted. Retries with exponential back-off.
Uses a background thread pool so watcher latency is not affected.
"""
from __future__ import annotations

import json
import logging
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Callable, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger("nota.webhook")


# ---------------------------------------------------------------------------
# Event model

class EventKind(str, Enum):
    CREATED  = "created"
    MODIFIED = "modified"
    DELETED  = "deleted"
    INDEXED  = "indexed"


@dataclass
class WebhookEvent:
    kind:     EventKind
    note_id:  str
    title:    Optional[str]     = None
    tags:     List[str]         = field(default_factory=list)
    vault:    Optional[str]     = None
    ts:       str               = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")

    def to_payload(self) -> dict:
        return {
            "event":   self.kind.value,
            "note_id": self.note_id,
            "title":   self.title,
            "tags":    self.tags,
            "vault":   self.vault,
            "ts":      self.ts,
        }


# ---------------------------------------------------------------------------
# Delivery

@dataclass
class DeliveryResult:
    url:      str
    status:   Optional[int]
    ok:       bool
    attempts: int
    error:    Optional[str] = None


def _deliver_once(url: str, payload: dict, timeout: int = 10) -> int:
    """POST *payload* to *url*. Returns HTTP status code."""
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "User-Agent":   "nota-webhook/1.0",
            "X-Nota-Event": payload.get("event", ""),
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status


def deliver(
    url:        str,
    event:      WebhookEvent,
    *,
    max_retries: int   = 3,
    backoff_base: float = 1.0,
    timeout:     int   = 10,
) -> DeliveryResult:
    """Deliver *event* to *url* with exponential back-off retry.

    Back-off sequence: 1s, 2s, 4s (base * 2^attempt).
    """
    payload  = event.to_payload()
    attempts = 0
    last_err: Optional[str] = None

    for attempt in range(max_retries):
        attempts += 1
        try:
            status = _deliver_once(url, payload, timeout=timeout)
            if 200 <= status < 300:
                return DeliveryResult(url=url, status=status, ok=True, attempts=attempts)
            last_err = f"HTTP {status}"
        except urllib.error.HTTPError as exc:
            last_err = f"HTTP {exc.code}: {exc.reason}"
        except urllib.error.URLError as exc:
            last_err = f"URLError: {exc.reason}"
        except Exception as exc:
            last_err = str(exc)

        if attempt < max_retries - 1:
            sleep_s = backoff_base * (2 ** attempt)
            log.debug("Webhook %s attempt %d failed (%s), retrying in %.1fs",
                      url, attempt + 1, last_err, sleep_s)
            time.sleep(sleep_s)

    log.warning("Webhook %s failed after %d attempts: %s", url, attempts, last_err)
    return DeliveryResult(url=url, status=None, ok=False, attempts=attempts, error=last_err)


# ---------------------------------------------------------------------------
# Dispatcher

class WebhookDispatcher:
    """Dispatches vault events to a list of endpoint URLs asynchronously."""

    def __init__(
        self,
        urls:         List[str],
        *,
        max_workers:  int   = 4,
        max_retries:  int   = 3,
        backoff_base: float = 1.0,
        on_result:    Optional[Callable[[DeliveryResult], None]] = None,
    ) -> None:
        self.urls         = list(urls)
        self._max_retries = max_retries
        self._backoff     = backoff_base
        self._on_result   = on_result
        self._executor    = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="nota-wh")
        self._lock        = threading.Lock()
        self._results:    List[DeliveryResult] = []

    def dispatch(self, event: WebhookEvent) -> None:
        """Fire-and-forget dispatch to all configured URLs."""
        for url in self.urls:
            self._executor.submit(self._dispatch_one, url, event)

    def _dispatch_one(self, url: str, event: WebhookEvent) -> None:
        result = deliver(url, event, max_retries=self._max_retries, backoff_base=self._backoff)
        with self._lock:
            self._results.append(result)
        if self._on_result:
            try:
                self._on_result(result)
            except Exception:
                pass

    def dispatch_sync(self, event: WebhookEvent) -> List[DeliveryResult]:
        """Dispatch synchronously and return all results."""
        futures = [
            self._executor.submit(deliver, url, event,
                                  max_retries=self._max_retries,
                                  backoff_base=self._backoff)
            for url in self.urls
        ]
        return [f.result() for f in futures]

    def flush(self, timeout: float = 10.0) -> None:
        """Wait for all pending deliveries to complete."""
        self._executor.shutdown(wait=True, cancel_futures=False)

    def recent_results(self, n: int = 50) -> List[DeliveryResult]:
        with self._lock:
            return list(self._results[-n:])

    def success_rate(self) -> float:
        with self._lock:
            if not self._results:
                return 1.0
            ok = sum(1 for r in self._results if r.ok)
            return ok / len(self._results)

    # context manager
    def __enter__(self) -> "WebhookDispatcher":
        return self

    def __exit__(self, *_: object) -> None:
        self.flush()


# ---------------------------------------------------------------------------
# Convenience factory

def make_dispatcher(config) -> Optional[WebhookDispatcher]:
    """Build a dispatcher from a Config object; returns None if no webhooks."""
    urls = getattr(config, "webhooks", [])
    if not urls:
        return None
    return WebhookDispatcher(urls)


# ---------------------------------------------------------------------------
# HMAC signing (optional — for verified webhooks)

def sign_payload(payload: dict, secret: str) -> str:
    """Return an HMAC-SHA256 hex digest of the JSON payload."""
    import hashlib
    import hmac
    body = json.dumps(payload, sort_keys=True).encode()
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def verify_signature(payload: dict, secret: str, signature: str) -> bool:
    """Verify a webhook signature (constant-time comparison)."""
    import hmac
    expected = sign_payload(payload, secret)
    return hmac.compare_digest(expected, signature)
