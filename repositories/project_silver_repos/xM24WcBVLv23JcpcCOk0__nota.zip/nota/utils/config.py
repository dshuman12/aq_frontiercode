from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

import platformdirs

_APP = "nota"
_APP_AUTHOR = "pramodhkrishna42"

_DEFAULT_TEMPLATE = """\
---
title: {{ title }}
created: {{ created }}
tags: []
---

# {{ title }}

"""

_DEFAULT_DAILY_TEMPLATE = """\
---
title: {{ date }}
created: {{ created }}
tags: [daily]
---

# {{ date }}

## Tasks

- [ ]

## Notes

"""


@dataclass
class Config:
    vault: Optional[Path] = None
    editor: str = field(default_factory=lambda: os.environ.get("EDITOR", "vim"))
    default_template: str = _DEFAULT_TEMPLATE
    daily_template: str = _DEFAULT_DAILY_TEMPLATE
    date_format: str = "%Y-%m-%d"
    datetime_format: str = "%Y-%m-%dT%H:%M:%S"
    extensions: list[str] = field(default_factory=lambda: [".md", ".markdown"])
    exclude_dirs: list[str] = field(default_factory=lambda: [".git", ".nota", "node_modules"])
    semantic_model: str = "all-MiniLM-L6-v2"
    sync_bucket: Optional[str] = None
    sync_prefix: str = "nota/"
    webhooks: list[str] = field(default_factory=list)
    plugins: list[str] = field(default_factory=list)
    encrypt_keys: Dict[str, str] = field(default_factory=dict)

    # derived
    _path: Optional[Path] = field(default=None, repr=False)

    def save(self, path: Optional[Path] = None) -> None:
        target = path or self._path or _default_config_path()
        target.parent.mkdir(parents=True, exist_ok=True)
        data: Dict[str, Any] = {}
        if self.vault:
            data["vault"] = str(self.vault)
        data["editor"] = self.editor
        data["date_format"] = self.date_format
        data["datetime_format"] = self.datetime_format
        data["extensions"] = self.extensions
        data["exclude_dirs"] = self.exclude_dirs
        data["semantic_model"] = self.semantic_model
        if self.sync_bucket:
            data["sync_bucket"] = self.sync_bucket
            data["sync_prefix"] = self.sync_prefix
        if self.webhooks:
            data["webhooks"] = self.webhooks
        if self.plugins:
            data["plugins"] = self.plugins
        target.write_text(json.dumps(data, indent=2), encoding="utf-8")
        self._path = target

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "Config":
        candidates = [path] if path else _config_candidates()
        for candidate in candidates:
            if candidate and candidate.exists():
                try:
                    data = json.loads(candidate.read_text(encoding="utf-8"))
                    cfg = cls._from_dict(data)
                    cfg._path = candidate
                    return cfg
                except Exception:
                    pass
        return cls()

    @classmethod
    def _from_dict(cls, data: Dict[str, Any]) -> "Config":
        cfg = cls()
        if "vault" in data:
            cfg.vault = Path(data["vault"]).expanduser()
        if "editor" in data:
            cfg.editor = data["editor"]
        if "date_format" in data:
            cfg.date_format = data["date_format"]
        if "datetime_format" in data:
            cfg.datetime_format = data["datetime_format"]
        if "extensions" in data:
            cfg.extensions = data["extensions"]
        if "exclude_dirs" in data:
            cfg.exclude_dirs = data["exclude_dirs"]
        if "semantic_model" in data:
            cfg.semantic_model = data["semantic_model"]
        if "sync_bucket" in data:
            cfg.sync_bucket = data["sync_bucket"]
        if "sync_prefix" in data:
            cfg.sync_prefix = data["sync_prefix"]
        if "webhooks" in data:
            cfg.webhooks = data["webhooks"]
        if "plugins" in data:
            cfg.plugins = data["plugins"]
        return cfg


def _default_config_path() -> Path:
    return Path(platformdirs.user_config_dir(_APP, _APP_AUTHOR)) / "config.json"


def _config_candidates() -> list[Path]:
    cwd = Path.cwd()
    candidates = [
        cwd / ".notarc",
        cwd / ".nota" / "config.json",
        Path.home() / ".notarc",
        _default_config_path(),
    ]
    return candidates


_cache: Optional[Config] = None


def get_config(path: Optional[Path] = None, *, reload: bool = False) -> Config:
    global _cache
    if _cache is None or reload:
        _cache = Config.load(path)
    return _cache
