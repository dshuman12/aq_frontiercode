"""AES-256-GCM note encryption (requires `cryptography` package)."""
from __future__ import annotations

import base64
import os
from pathlib import Path
from typing import Optional

_MAGIC = b"nota\x00enc\x01"


def _derive_key(password: str, salt: bytes) -> bytes:
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    from cryptography.hazmat.backends import default_backend

    kdf = Scrypt(salt=salt, length=32, n=2**14, r=8, p=1, backend=default_backend())
    return kdf.derive(password.encode())


def encrypt_file(path: Path, password: str) -> None:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    data = path.read_bytes()
    if data.startswith(_MAGIC):
        return  # already encrypted

    salt = os.urandom(16)
    key = _derive_key(password, salt)
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, data, None)
    path.write_bytes(_MAGIC + salt + nonce + ciphertext)


def decrypt_file(path: Path, password: str) -> bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    raw = path.read_bytes()
    if not raw.startswith(_MAGIC):
        return raw  # not encrypted

    offset = len(_MAGIC)
    salt = raw[offset:offset + 16]
    nonce = raw[offset + 16:offset + 28]
    ciphertext = raw[offset + 28:]
    key = _derive_key(password, salt)
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ciphertext, None)


def is_encrypted(path: Path) -> bool:
    try:
        return path.read_bytes().startswith(_MAGIC)
    except OSError:
        return False
