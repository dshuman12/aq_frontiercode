"""nota CLI — entry point for all user-facing commands."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import click
from rich.console import Console
from rich.table import Table
from rich import box

from .core.note import Note
from .core.store import Store
from .core.search import ranked_search
from .core.links import link_graph, ascii_graph, orphans
from .core.watcher import Watcher
from .export.html import export_html, export_vault_html
from .export.json_export import export_json
from .utils.config import Config, get_config
from . import __version__

console = Console()


# ---------------------------------------------------------------------------
# helpers

def _resolve_vault(cfg: Config) -> Path:
    vault = cfg.vault or Path.cwd()
    nota_dir = vault / ".nota"
    if not nota_dir.exists():
        raise click.ClickException(
            f"No vault found at {vault}. Run `nota init` first."
        )
    return vault


def _open_editor(path: Path, editor: str) -> None:
    subprocess.call([editor, str(path)])


def _render_template(template: str, **ctx: str) -> str:
    from jinja2 import Environment

    env = Environment()
    tmpl = env.from_string(template)
    return tmpl.render(**ctx)


def _create_note(
    vault_root: Path,
    title: str,
    content: str = "",
    tags: Optional[List[str]] = None,
    subdir: str = "",
) -> Note:
    cfg = get_config()
    now = datetime.now()
    slug = title.lower().replace(" ", "-")
    slug = "".join(c if c.isalnum() or c == "-" else "" for c in slug)
    slug = slug[:80]

    target_dir = vault_root / subdir if subdir else vault_root
    target_dir.mkdir(parents=True, exist_ok=True)
    path = target_dir / f"{slug}.md"

    # handle collisions
    counter = 1
    while path.exists():
        path = target_dir / f"{slug}-{counter}.md"
        counter += 1

    fm_tags = tags or []
    tag_line = ", ".join(fm_tags) if fm_tags else "[]"
    body = f"---\ntitle: {title}\ncreated: {now.strftime(cfg.datetime_format)}\ntags: [{tag_line}]\n---\n\n# {title}\n\n{content}"
    path.write_text(body, encoding="utf-8")
    return Note(path, vault_root)


# ---------------------------------------------------------------------------
# CLI group

@click.group()
@click.version_option(__version__, "-V", "--version")
@click.pass_context
def main(ctx: click.Context) -> None:
    """nota — a local-first, markdown-powered knowledge base."""
    ctx.ensure_object(dict)


# ---------------------------------------------------------------------------
# init

@main.command()
@click.argument("directory", default=".", type=click.Path())
def init(directory: str) -> None:
    """Initialize a new nota vault in DIRECTORY."""
    vault = Path(directory).resolve()
    nota_dir = vault / ".nota"
    if nota_dir.exists():
        console.print(f"[yellow]Vault already initialised at {vault}[/]")
        return

    nota_dir.mkdir(parents=True)
    cfg = Config(vault=vault)
    cfg.save(vault / ".nota" / "config.json")

    # welcome note
    welcome = _create_note(vault, "Welcome to nota", content=(
        "This is your first note. Start writing!\n\n"
        "## Quick tips\n\n"
        "- Link to other notes with `[[Note Title]]`\n"
        "- Add tags with `#tag` inline or in frontmatter\n"
        "- Run `nota new 'My Note'` to create more notes\n"
    ))

    with Store(vault) as store:
        store.index_note(welcome)

    console.print(f"[green]✓[/] Vault initialised at [bold]{vault}[/]")


# ---------------------------------------------------------------------------
# new

@main.command()
@click.argument("title")
@click.option("-t", "--tag", "tags", multiple=True, help="Tags to apply")
@click.option("--edit", is_flag=True, help="Open in editor after creating")
@click.option("--template", default="", help="Path to a Jinja2 template file")
@click.pass_context
def new(ctx: click.Context, title: str, tags: tuple, edit: bool, template: str) -> None:
    """Create a new note with TITLE."""
    cfg = get_config()
    vault = _resolve_vault(cfg)

    content = ""
    if template:
        tmpl_path = Path(template)
        if not tmpl_path.exists():
            raise click.ClickException(f"Template not found: {template}")
        raw = tmpl_path.read_text(encoding="utf-8")
        content = _render_template(raw, title=title, created=datetime.now().isoformat())

    note = _create_note(vault, title, content=content, tags=list(tags))
    with Store(vault) as store:
        store.index_note(note)

    console.print(f"[green]✓[/] Created [bold]{note.path.name}[/]")
    if edit:
        _open_editor(note.path, cfg.editor)


# ---------------------------------------------------------------------------
# list

@main.command("ls")
@click.option("-t", "--tag", default="", help="Filter by tag")
@click.option("-n", "--limit", default=30, show_default=True)
@click.option("--sort", type=click.Choice(["modified", "created", "title"]), default="modified")
def ls(tag: str, limit: int, sort: str) -> None:
    """List notes in the vault."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        notes = list(store.by_tag(tag) if tag else store.notes())

    if sort == "modified":
        notes.sort(key=lambda n: n.modified, reverse=True)
    elif sort == "created":
        notes.sort(key=lambda n: n.created or datetime.min, reverse=True)
    elif sort == "title":
        notes.sort(key=lambda n: n.title.lower())

    notes = notes[:limit]

    table = Table(box=box.SIMPLE, show_header=True, header_style="bold")
    table.add_column("Title", style="cyan", no_wrap=True)
    table.add_column("Tags", style="dim")
    table.add_column("Modified", style="dim", justify="right")

    for note in notes:
        tags_str = " ".join(f"#{t}" for t in note.tags[:3])
        mod = note.modified.strftime("%Y-%m-%d")
        table.add_row(note.title, tags_str, mod)

    console.print(table)


# ---------------------------------------------------------------------------
# find / search

@main.command()
@click.argument("query")
@click.option("-n", "--limit", default=10, show_default=True)
@click.option("--semantic", is_flag=True, help="Use semantic (embedding) search")
def find(query: str, limit: int, semantic: bool) -> None:
    """Search notes by full-text or semantic similarity."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        store.index_all()
        if semantic:
            from .core.search import SemanticSearch
            ss = SemanticSearch(store)
            results = [n for n, _ in ss.query(query, top_k=limit)]
        else:
            results = ranked_search(store, query, limit=limit)

    if not results:
        console.print("[yellow]No results.[/]")
        return

    for i, note in enumerate(results, 1):
        console.print(f"[bold cyan]{i}.[/] {note.title}  [dim]{note.id}[/]")


# ---------------------------------------------------------------------------
# edit

@main.command()
@click.argument("ref")
def edit(ref: str) -> None:
    """Open a note in $EDITOR. REF can be a title, stem, or path."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        note = store.get(ref)
    if note is None:
        raise click.ClickException(f"Note not found: {ref!r}")
    _open_editor(note.path, cfg.editor)


# ---------------------------------------------------------------------------
# show

@main.command()
@click.argument("ref")
@click.option("--raw", is_flag=True, help="Print raw markdown")
def show(ref: str, raw: bool) -> None:
    """Display a note in the terminal."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        note = store.get(ref)
    if note is None:
        raise click.ClickException(f"Note not found: {ref!r}")

    if raw:
        click.echo(note.raw)
        return

    from rich.markdown import Markdown
    from rich.panel import Panel

    meta_parts = [f"[bold]{note.title}[/]"]
    if note.tags:
        meta_parts.append(" ".join(f"[dim]#{t}[/]" for t in note.tags))
    console.print("  ".join(meta_parts))
    console.print(Markdown(note.content))


# ---------------------------------------------------------------------------
# links / backlinks

@main.command()
@click.argument("ref")
def links(ref: str) -> None:
    """Show outbound links for a note."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        note = store.get(ref)
        if note is None:
            raise click.ClickException(f"Note not found: {ref!r}")
        for target in note.links:
            resolved = store.get(target)
            suffix = f"  → [cyan]{resolved.title}[/]" if resolved else "  [dim](unresolved)[/]"
            console.print(f"  [[{target}]]{suffix}")


@main.command()
@click.argument("ref")
def backlinks(ref: str) -> None:
    """Show notes that link to REF."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        note = store.get(ref)
        if note is None:
            raise click.ClickException(f"Note not found: {ref!r}")
        bls = store.backlinks(note)
    if not bls:
        console.print("[dim]No backlinks.[/]")
        return
    for n in bls:
        console.print(f"  [cyan]{n.title}[/]  [dim]{n.id}[/]")


# ---------------------------------------------------------------------------
# tags

@main.command()
def tags() -> None:
    """List all tags and their note counts."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        tag_counts = store.all_tags()
    table = Table(box=box.SIMPLE, show_header=True)
    table.add_column("Tag", style="cyan")
    table.add_column("Count", justify="right")
    for tag, count in tag_counts.items():
        table.add_row(f"#{tag}", str(count))
    console.print(table)


# ---------------------------------------------------------------------------
# daily

@main.command()
@click.option("--edit", is_flag=True, default=True, help="Open in editor")
def daily(edit: bool) -> None:
    """Open or create today's daily note."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    today = datetime.now().strftime(cfg.date_format)
    with Store(vault) as store:
        existing = store.get(today)
        if existing:
            if edit:
                _open_editor(existing.path, cfg.editor)
            return

        content = _render_template(
            cfg.daily_template,
            date=today,
            created=datetime.now().isoformat(),
        )
        note = _create_note(vault, today, content=content, subdir="daily")
        store.index_note(note)

    console.print(f"[green]✓[/] Daily note: [bold]{note.path.name}[/]")
    if edit:
        _open_editor(note.path, cfg.editor)


# ---------------------------------------------------------------------------
# graph

@main.command()
@click.option("--json", "as_json", is_flag=True, help="Output adjacency list as JSON")
def graph(as_json: bool) -> None:
    """Visualise the note link graph."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        adj = store.graph()

    if as_json:
        click.echo(json.dumps(adj, indent=2))
        return

    console.print(ascii_graph(adj))


# ---------------------------------------------------------------------------
# stats

@main.command()
def stats() -> None:
    """Show vault statistics."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        s = store.stats()
        orph = len(orphans(store))

    table = Table(box=box.SIMPLE, show_header=False)
    table.add_column("Metric", style="dim")
    table.add_column("Value", style="bold cyan", justify="right")
    table.add_row("Notes", str(s["notes"]))
    table.add_row("Words", f"{s['words']:,}")
    table.add_row("Links", str(s["links"]))
    table.add_row("Tags", str(s["tags"]))
    table.add_row("Orphans", str(orph))
    console.print(table)


# ---------------------------------------------------------------------------
# export

@main.command("export")
@click.argument("fmt", type=click.Choice(["html", "json", "pdf"]))
@click.option("--note", default="", help="Export a single note (stem or title)")
@click.option("-o", "--output", default="", help="Output path")
def export_cmd(fmt: str, note: str, output: str) -> None:
    """Export notes to HTML, JSON, or PDF."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    out_path = Path(output) if output else None

    with Store(vault) as store:
        store.index_all()
        if note:
            n = store.get(note)
            if n is None:
                raise click.ClickException(f"Note not found: {note!r}")
            if fmt == "html":
                result = export_html(n, out_path)
                console.print(f"[green]✓[/] {result}")
            elif fmt == "pdf":
                from .export.pdf import export_pdf
                result = export_pdf(n, out_path)
                console.print(f"[green]✓[/] {result}")
            elif fmt == "json":
                d = n.to_dict()
                click.echo(json.dumps(d, indent=2, default=str))
        else:
            if fmt == "html":
                results = export_vault_html(vault, out_path)
                console.print(f"[green]✓[/] Exported {len(results)} notes")
            elif fmt == "json":
                payload = export_json(store, out_path)
                if not out_path:
                    click.echo(json.dumps(payload, indent=2, default=str))
                else:
                    console.print(f"[green]✓[/] {out_path}")
            elif fmt == "pdf":
                raise click.ClickException("PDF export for full vault not supported yet; use --note")


# ---------------------------------------------------------------------------
# index

@main.command()
@click.option("--force", is_flag=True, help="Re-index all notes regardless of checksum")
@click.option("--watch", is_flag=True, help="Keep running and watch for changes")
def index(force: bool, watch: bool) -> None:
    """Rebuild the search index."""
    cfg = get_config()
    vault = _resolve_vault(cfg)

    with Store(vault) as store:
        count = store.index_all(force=force)
        console.print(f"[green]✓[/] Indexed {count} notes")

        if watch:
            console.print("[dim]Watching for changes… Ctrl-C to stop[/]")

            def on_change(path: str) -> None:
                console.print(f"  [dim]updated[/] {Path(path).name}")

            w = Watcher(store, on_change=on_change)
            w.run_forever()


# ---------------------------------------------------------------------------
# encrypt / decrypt

@main.command()
@click.argument("ref")
@click.option("--password", prompt=True, hide_input=True)
def encrypt(ref: str, password: str) -> None:
    """Encrypt a note with AES-256-GCM."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        note = store.get(ref)
    if note is None:
        raise click.ClickException(f"Note not found: {ref!r}")
    from .utils.encrypt import encrypt_file
    encrypt_file(note.path, password)
    console.print(f"[green]✓[/] Encrypted {note.path.name}")


@main.command()
@click.argument("ref")
@click.option("--password", prompt=True, hide_input=True)
def decrypt(ref: str, password: str) -> None:
    """Decrypt a note (print to stdout)."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    with Store(vault) as store:
        note = store.get(ref)
    if note is None:
        raise click.ClickException(f"Note not found: {ref!r}")
    from .utils.encrypt import decrypt_file
    try:
        click.echo(decrypt_file(note.path, password).decode("utf-8", errors="replace"))
    except Exception as exc:
        raise click.ClickException(f"Decryption failed: {exc}") from exc


# ---------------------------------------------------------------------------
# mcp-serve

@main.command("mcp-serve")
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", default=5173, show_default=True)
def mcp_serve(host: str, port: int) -> None:
    """Start an MCP server exposing the vault to AI assistants."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    console.print(f"[green]✓[/] Starting MCP server for vault [bold]{vault}[/]")
    from .mcp_server import serve
    serve(vault, host=host, port=port)


# ---------------------------------------------------------------------------
# import

@main.command("import")
@click.argument("source", type=click.Path(exists=True))
@click.option("--format", "fmt", type=click.Choice(["obsidian", "jrnl"]), default="obsidian")
def import_cmd(source: str, fmt: str) -> None:
    """Import notes from another app (Obsidian vault, jrnl export)."""
    cfg = get_config()
    vault = _resolve_vault(cfg)
    src = Path(source)
    count = 0

    with Store(vault) as store:
        if fmt == "obsidian":
            for md_file in src.rglob("*.md"):
                if any(part.startswith(".") for part in md_file.parts):
                    continue
                rel = md_file.relative_to(src)
                dest = vault / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                if not dest.exists():
                    dest.write_bytes(md_file.read_bytes())
                    count += 1
                    note = Note(dest, vault)
                    store.index_note(note)
        store.conn.commit()

    console.print(f"[green]✓[/] Imported {count} notes from {src.name}")


if __name__ == "__main__":
    main()
