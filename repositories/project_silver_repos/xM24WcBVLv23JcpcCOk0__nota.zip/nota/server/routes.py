"""Lightweight routing layer for the nota local web server.

Provides Router, Request, and Response abstractions over stdlib
http.server without introducing any external framework dependency.
"""
from __future__ import annotations

import json
import re
import urllib.parse
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler
from typing import Any, Callable, Dict, List, Optional, Pattern, Tuple


# ---------------------------------------------------------------------------
# Data classes

@dataclass
class Request:
    """Parsed HTTP request."""
    method: str
    path: str
    query: Dict[str, str]
    headers: Dict[str, str]
    body: bytes
    path_params: Dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_handler(cls, handler: BaseHTTPRequestHandler) -> "Request":
        parsed = urllib.parse.urlparse(handler.path)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        query = {k: v[0] for k, v in qs.items()}
        headers = {k.lower(): v for k, v in handler.headers.items()}
        body = b""
        if "content-length" in headers:
            try:
                length = int(headers["content-length"])
                body = handler.rfile.read(length)
            except (ValueError, OSError):
                pass
        return cls(
            method=handler.command,
            path=parsed.path,
            query=query,
            headers=headers,
            body=body,
        )

    def get_param(self, key: str, default: str = "") -> str:
        return self.query.get(key, default)

    def json_body(self) -> Any:
        try:
            return json.loads(self.body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None


@dataclass
class Response:
    """HTTP response to send back to client."""
    status: int = 200
    content_type: str = "text/html; charset=utf-8"
    body: bytes = b""
    headers: Dict[str, str] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Factory helpers

    @classmethod
    def html(cls, content: str, status: int = 200) -> "Response":
        return cls(
            status=status,
            content_type="text/html; charset=utf-8",
            body=content.encode("utf-8"),
        )

    @classmethod
    def json(cls, data: Any, status: int = 200) -> "Response":
        body = json.dumps(data, default=str, ensure_ascii=False).encode("utf-8")
        return cls(
            status=status,
            content_type="application/json; charset=utf-8",
            body=body,
        )

    @classmethod
    def text(cls, content: str, status: int = 200) -> "Response":
        return cls(
            status=status,
            content_type="text/plain; charset=utf-8",
            body=content.encode("utf-8"),
        )

    @classmethod
    def redirect(cls, location: str, permanent: bool = False) -> "Response":
        status = 301 if permanent else 302
        r = cls(status=status, body=b"")
        r.headers["Location"] = location
        return r

    @classmethod
    def not_found(cls, message: str = "Not found") -> "Response":
        return cls.html(
            f"<html><body><h1>404 Not Found</h1><p>{message}</p></body></html>",
            status=404,
        )

    @classmethod
    def error(cls, message: str = "Internal Server Error", status: int = 500) -> "Response":
        return cls.html(
            f"<html><body><h1>{status} Error</h1><p>{message}</p></body></html>",
            status=status,
        )

    # ------------------------------------------------------------------
    # Sending

    def send(self, handler: BaseHTTPRequestHandler) -> None:
        handler.send_response(self.status)
        handler.send_header("Content-Type", self.content_type)
        handler.send_header("Content-Length", str(len(self.body)))
        handler.send_header("X-Content-Type-Options", "nosniff")
        for k, v in self.headers.items():
            handler.send_header(k, v)
        handler.end_headers()
        if self.body:
            handler.wfile.write(self.body)


# ---------------------------------------------------------------------------
# Router

_RouteHandler = Callable[["Request"], "Response"]
_CompiledRoute = Tuple[str, Pattern[str], List[str], _RouteHandler]


class Router:
    """Simple pattern-based HTTP router.

    Routes are registered with ``add(method, pattern, handler)`` where
    *pattern* is a URL template with ``{param}`` placeholders.  The first
    matching route wins.

    Example::

        router = Router()

        @router.get("/notes/{stem}")
        def note_view(req: Request) -> Response:
            stem = req.path_params["stem"]
            ...
    """

    def __init__(self) -> None:
        self._routes: List[_CompiledRoute] = []

    # ------------------------------------------------------------------
    # Registration

    def add(self, method: str, pattern: str, handler: _RouteHandler) -> None:
        regex, param_names = self._compile(pattern)
        self._routes.append((method.upper(), regex, param_names, handler))

    def get(self, pattern: str) -> Callable[[_RouteHandler], _RouteHandler]:
        def decorator(fn: _RouteHandler) -> _RouteHandler:
            self.add("GET", pattern, fn)
            return fn
        return decorator

    def post(self, pattern: str) -> Callable[[_RouteHandler], _RouteHandler]:
        def decorator(fn: _RouteHandler) -> _RouteHandler:
            self.add("POST", pattern, fn)
            return fn
        return decorator

    def put(self, pattern: str) -> Callable[[_RouteHandler], _RouteHandler]:
        def decorator(fn: _RouteHandler) -> _RouteHandler:
            self.add("PUT", pattern, fn)
            return fn
        return decorator

    def delete(self, pattern: str) -> Callable[[_RouteHandler], _RouteHandler]:
        def decorator(fn: _RouteHandler) -> _RouteHandler:
            self.add("DELETE", pattern, fn)
            return fn
        return decorator

    # ------------------------------------------------------------------
    # Dispatch

    def dispatch(self, req: Request) -> Response:
        for method, regex, param_names, handler in self._routes:
            if method != req.method:
                continue
            m = regex.fullmatch(req.path)
            if m is None:
                continue
            req.path_params = dict(zip(param_names, m.groups()))
            try:
                return handler(req)
            except Exception as exc:  # noqa: BLE001
                return Response.error(f"Handler error: {exc}")
        return Response.not_found(f"No route matched: {req.method} {req.path}")

    # ------------------------------------------------------------------
    # Internal

    @staticmethod
    def _compile(pattern: str) -> Tuple[Pattern[str], List[str]]:
        """Convert ``/note/{stem}`` to a compiled regex + param name list."""
        param_re = re.compile(r"\{(\w+)\}")
        param_names: List[str] = []
        parts = []
        last = 0
        for m in param_re.finditer(pattern):
            parts.append(re.escape(pattern[last: m.start()]))
            param_names.append(m.group(1))
            parts.append(r"([^/]+)")
            last = m.end()
        parts.append(re.escape(pattern[last:]))
        return re.compile("".join(parts)), param_names

    def __repr__(self) -> str:  # pragma: no cover
        n = len(self._routes)
        return f"Router(routes={n})"


# ---------------------------------------------------------------------------
# Middleware helpers

def require_json(handler: _RouteHandler) -> _RouteHandler:
    """Middleware: reject requests whose Content-Type is not application/json."""
    def wrapper(req: Request) -> Response:
        ct = req.headers.get("content-type", "")
        if "application/json" not in ct:
            return Response.error("Content-Type must be application/json", status=415)
        return handler(req)
    return wrapper


def cors_headers(response: Response, allow_origins: str = "*") -> Response:
    """Add CORS headers to *response* in-place, then return it."""
    response.headers["Access-Control-Allow-Origin"] = allow_origins
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    return response


def with_cors(handler: _RouteHandler) -> _RouteHandler:
    """Middleware: add CORS headers to every response."""
    def wrapper(req: Request) -> Response:
        resp = handler(req)
        return cors_headers(resp)
    return wrapper


# ---------------------------------------------------------------------------
# Static file helpers

_MIME_MAP: Dict[str, str] = {
    ".html": "text/html; charset=utf-8",
    ".css":  "text/css; charset=utf-8",
    ".js":   "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png":  "image/png",
    ".jpg":  "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg":  "image/svg+xml",
    ".ico":  "image/x-icon",
    ".txt":  "text/plain; charset=utf-8",
    ".woff2": "font/woff2",
    ".woff":  "font/woff",
}


def mime_type(suffix: str) -> str:
    return _MIME_MAP.get(suffix.lower(), "application/octet-stream")


def static_response(path_obj: "Any") -> Response:
    """Return a Response for a static file.  path_obj is a pathlib.Path."""
    from pathlib import Path
    p = Path(path_obj)
    if not p.is_file():
        return Response.not_found(f"Static file not found: {p.name}")
    ct = mime_type(p.suffix)
    data = p.read_bytes()
    return Response(status=200, content_type=ct, body=data)
