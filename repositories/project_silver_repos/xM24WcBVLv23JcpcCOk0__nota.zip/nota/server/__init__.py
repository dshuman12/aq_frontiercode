"""nota local web server — browse your vault in a browser."""
from .app import NotaServer, run

__all__ = ["NotaServer", "run"]
