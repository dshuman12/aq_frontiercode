"""nota local HTTP server.

Serves the vault as a live-updating web app.
No external web framework required — uses stdlib http.server.

Usage::

    nota serve --host 127.0.0.1 --port 5000
    nota serve --open          # also opens the browser
"""
from __future__ import annotations

import json
import mimetypes
import os
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, unquote, urlparse

from ..core.store import Store
from ..core.search import ranked_search
from ..core.query import search as dsl_search
from ..core.graph import graph_summary, pagerank
from ..core.calendar import activity_by_day, heatmap
from ..core.links import orphans
from ..export.html import _md_to_html
from .routes import Router, Response, Request


# ---------------------------------------------------------------------------
# Static assets (inline so the server is self-contained)

_FAVICON = (
    "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'>"
    "<text y='.9em' font-size='90'>📝</text></svg>"
)

_CSS = """
:root { --bg:#fff; --text:#1a1a2e; --link:#2563eb; --dim:#6b7280;
        --border:#e5e7eb; --code:#f3f4f6; --tag:#dbeafe;
        --sidebar-w:280px; --accent:#3b82f6; }
@media(prefers-color-scheme:dark){
  :root { --bg:#0f172a; --text:#e2e8f0; --link:#60a5fa; --dim:#94a3b8;
          --border:#1e293b; --code:#1e293b; --tag:#1e3a5f; }
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font:16px/1.7 system-ui,sans-serif;display:flex;min-height:100vh}
a{color:var(--link);text-decoration:none}a:hover{text-decoration:underline}
.sidebar{width:var(--sidebar-w);min-width:var(--sidebar-w);border-right:1px solid var(--border);
         padding:1.2rem 0.8rem;height:100vh;position:sticky;top:0;overflow-y:auto;font-size:.88rem}
.sidebar-logo{font-weight:700;font-size:1.1rem;padding:.4rem .6rem;margin-bottom:1rem;display:block;color:var(--text)}
.sidebar-section{font-size:.75rem;text-transform:uppercase;letter-spacing:.08em;
                 color:var(--dim);padding:.6rem .6rem .2rem;margin-top:.5rem}
.sidebar-link{display:block;padding:.25rem .6rem;border-radius:4px;color:var(--text);
              white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sidebar-link:hover,.sidebar-link.active{background:var(--code);text-decoration:none}
.sidebar-link.active{color:var(--accent);font-weight:600}
.search-input{width:100%;padding:.4rem .6rem;border:1px solid var(--border);border-radius:6px;
              background:var(--bg);color:var(--text);font-size:.88rem;margin-bottom:.6rem}
.main{flex:1;padding:2rem 2.5rem;max-width:900px;min-width:0}
h1{font-size:1.8rem;margin-bottom:.4rem}
h2{font-size:1.3rem;margin:1.8rem 0 .4rem}
h3{font-size:1.05rem;margin:1.4rem 0 .3rem}
p{margin:.6rem 0}.meta{color:var(--dim);font-size:.85rem;margin-bottom:1.2rem}
.tag{background:var(--tag);color:var(--link);border-radius:20px;padding:1px 10px;
     font-size:.8rem;margin-right:4px;display:inline-block}
.card{border:1px solid var(--border);border-radius:8px;padding:1rem 1.2rem;margin-bottom:.8rem}
.card-title{font-weight:600;font-size:1rem}
.card-meta{color:var(--dim);font-size:.82rem;margin:.2rem 0}
.card-excerpt{color:var(--dim);font-size:.88rem;margin-top:.3rem}
.stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:.8rem;margin:1rem 0}
.stat-card{background:var(--code);border-radius:8px;padding:1rem;text-align:center}
.stat-val{font-size:1.8rem;font-weight:700;color:var(--accent)}
.stat-lbl{font-size:.82rem;color:var(--dim);margin-top:.2rem}
code{background:var(--code);padding:2px 5px;border-radius:3px;font-size:.9em;font-family:monospace}
pre{background:var(--code);padding:1rem;border-radius:6px;overflow-x:auto;margin:.8rem 0}
pre code{background:none;padding:0}
blockquote{border-left:3px solid var(--border);padding-left:1rem;color:var(--dim);margin:.8rem 0}
table{border-collapse:collapse;width:100%;margin:.8rem 0}
th,td{border:1px solid var(--border);padding:.4rem .7rem;text-align:left}
th{background:var(--code)}
.backlinks{margin-top:2.5rem;padding-top:1.5rem;border-top:1px solid var(--border)}
.flash{background:#fef3c7;border:1px solid #fbbf24;border-radius:6px;padding:.6rem 1rem;margin-bottom:1rem}
footer{color:var(--dim);font-size:.8rem;margin-top:2.5rem;padding-top:1rem;border-top:1px solid var(--border)}
.graph-canvas{border:1px solid var(--border);border-radius:8px;width:100%;height:520px}
"""

_JS = """
// Live search
const searchForm = document.getElementById('search-form');
if (searchForm) {
  const inp = searchForm.querySelector('input');
  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); window.location.href = '/search?q=' + encodeURIComponent(inp.value); }
  });
}
// Keyboard shortcut: / to focus search
document.addEventListener('keydown', e => {
  if (e.key === '/' && document.activeElement.tagName !== 'INPUT') {
    e.preventDefault();
    const inp = document.querySelector('.search-input');
    if (inp) inp.focus();
  }
});
"""


def _html_page(title: str, body: str, *, active: str = "", sidebar_extra: str = "") -> str:
    return f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title} — nota</title>
<link rel="icon" href="{_FAVICON}">
<style>{_CSS}</style>
</head><body>
<nav class="sidebar">
  <a class="sidebar-logo" href="/">📝 nota</a>
  <form id="search-form" action="/search" method="get">
    <input class="search-input" name="q" placeholder="Search… (/)" autocomplete="off">
  </form>
  <div class="sidebar-section">Pages</div>
  <a class="sidebar-link {'active' if active=='home' else ''}" href="/">Home</a>
  <a class="sidebar-link {'active' if active=='tags' else ''}" href="/tags">Tags</a>
  <a class="sidebar-link {'active' if active=='graph' else ''}" href="/graph">Graph</a>
  <a class="sidebar-link {'active' if active=='calendar' else ''}" href="/calendar">Calendar</a>
  <a class="sidebar-link {'active' if active=='orphans' else ''}" href="/orphans">Orphans</a>
  <a class="sidebar-link {'active' if active=='stats' else ''}" href="/stats">Stats</a>
  {sidebar_extra}
</nav>
<main class="main">
{body}
<footer>nota local server &nbsp;·&nbsp; <a href="/api/stats">API</a></footer>
</main>
<script>{_JS}</script>
</body></html>"""


# ---------------------------------------------------------------------------
# Router and handlers

def _make_router(store: Store) -> Router:
    router = Router()

    @router.get("/")
    def index(req: Request) -> Response:
        notes = sorted(store.notes(), key=lambda n: n.modified, reverse=True)
        cards = ""
        for note in notes[:40]:
            tags_html = " ".join(f'<span class="tag">{t}</span>' for t in note.tags[:4])
            words = note.word_count
            mod = note.modified.strftime("%Y-%m-%d")
            excerpt = " ".join(note.content.split()[:25]) + "…"
            cards += f"""
            <div class="card">
              <div class="card-title"><a href="/note/{note.stem}">{note.title}</a></div>
              <div class="card-meta">{tags_html} &nbsp;{words:,} words &nbsp;·&nbsp; {mod}</div>
              <div class="card-excerpt">{excerpt}</div>
            </div>"""
        body = f"<h1>Notes <span style='color:var(--dim);font-size:1rem'>({len(notes)})</span></h1>{cards}"
        return Response(200, _html_page("Home", body, active="home"))

    @router.get("/note/{stem}")
    def view_note(req: Request, stem: str) -> Response:
        note = store.get(stem)
        if note is None:
            return Response(404, _html_page("Not Found", "<h1>Note not found</h1>"))
        backlinks = store.backlinks(note)
        tags_html = " ".join(f'<a class="tag" href="/tags/{t}">{t}</a>' for t in note.tags)
        created = note.created.strftime("%Y-%m-%d") if note.created else ""
        mod = note.modified.strftime("%Y-%m-%d")
        meta_parts = [p for p in [tags_html, f"Created {created}" if created else "", f"Modified {mod}", f"{note.word_count:,} words"] if p]
        content_html = _md_to_html(note.content)
        bl_html = ""
        if backlinks:
            items = "".join(f'<li><a href="/note/{b.stem}">{b.title}</a></li>' for b in backlinks)
            bl_html = f'<div class="backlinks"><h2>Backlinks ({len(backlinks)})</h2><ul>{items}</ul></div>'
        body = f"""
        <h1>{note.title}</h1>
        <div class="meta">{' &nbsp;·&nbsp; '.join(meta_parts)}</div>
        {content_html}
        {bl_html}"""
        sidebar_extra = f"""
        <div class="sidebar-section">Actions</div>
        <a class="sidebar-link" href="/api/note/{note.stem}">JSON</a>
        <a class="sidebar-link" href="/note/{note.stem}/links">Links</a>"""
        return Response(200, _html_page(note.title, body, sidebar_extra=sidebar_extra))

    @router.get("/note/{stem}/links")
    def note_links(req: Request, stem: str) -> Response:
        note = store.get(stem)
        if note is None:
            return Response(404, _html_page("Not Found", "<h1>Note not found</h1>"))
        out_items = "".join(
            f'<li><a href="/note/{t}">{t}</a></li>' for t in note.unique_links
        ) or "<li><em>No outbound links</em></li>"
        backlinks = store.backlinks(note)
        bl_items = "".join(
            f'<li><a href="/note/{b.stem}">{b.title}</a></li>' for b in backlinks
        ) or "<li><em>No backlinks</em></li>"
        body = f"""
        <h1>Links — {note.title}</h1>
        <h2>Outbound ({len(note.unique_links)})</h2><ul>{out_items}</ul>
        <h2>Backlinks ({len(backlinks)})</h2><ul>{bl_items}</ul>"""
        return Response(200, _html_page(f"Links — {note.title}", body))

    @router.get("/search")
    def search_page(req: Request) -> Response:
        q = req.params.get("q", [""])[0].strip()
        if not q:
            return Response(200, _html_page("Search", "<h1>Search</h1><p>Enter a query above.</p>", active="search"))
        results = ranked_search(store, q, limit=30)
        cards = ""
        for note in results:
            tags_html = " ".join(f'<span class="tag">{t}</span>' for t in note.tags[:3])
            cards += f"""
            <div class="card">
              <div class="card-title"><a href="/note/{note.stem}">{note.title}</a></div>
              <div class="card-meta">{tags_html}</div>
            </div>"""
        body = f"""
        <h1>Search: <em>{q}</em></h1>
        <p style="color:var(--dim);margin-bottom:1rem">{len(results)} result(s)</p>
        {cards or '<p>No results.</p>'}"""
        return Response(200, _html_page(f"Search: {q}", body))

    @router.get("/search/query")
    def query_page(req: Request) -> Response:
        q = req.params.get("q", [""])[0].strip()
        results = dsl_search(store, q) if q else []
        cards = "".join(
            f'<div class="card"><div class="card-title"><a href="/note/{n.stem}">{n.title}</a></div></div>'
            for n in results
        )
        body = f"""
        <h1>Query Search</h1>
        <form action="/search/query" method="get">
          <input name="q" value="{q}" placeholder="tag:python AND words:&gt;500"
                 style="width:100%;padding:.5rem;border:1px solid var(--border);border-radius:6px;
                        background:var(--bg);color:var(--text);font-size:.95rem;margin-bottom:1rem">
        </form>
        {f'<p style="color:var(--dim)">{len(results)} result(s)</p>' if q else ''}
        {cards or ('<p>No results.</p>' if q else '')}"""
        return Response(200, _html_page("Query Search", body))

    @router.get("/tags")
    def tags_page(req: Request) -> Response:
        tag_counts = store.all_tags()
        rows = "".join(
            f'<div class="card"><div class="card-title"><a href="/tags/{t}">#{t}</a>'
            f'<span style="color:var(--dim);font-size:.85rem;margin-left:.5rem">{c} note(s)</span></div></div>'
            for t, c in tag_counts.items()
        )
        body = f"<h1>Tags ({len(tag_counts)})</h1>{rows}"
        return Response(200, _html_page("Tags", body, active="tags"))

    @router.get("/tags/{tag}")
    def tag_notes(req: Request, tag: str) -> Response:
        notes = store.by_tag(tag)
        cards = "".join(
            f'<div class="card"><div class="card-title"><a href="/note/{n.stem}">{n.title}</a></div>'
            f'<div class="card-meta">{n.modified.strftime("%Y-%m-%d")} &nbsp;·&nbsp; {n.word_count:,} words</div></div>'
            for n in sorted(notes, key=lambda n: n.modified, reverse=True)
        )
        body = f"<h1>Tag: #{tag} ({len(notes)})</h1>{cards or '<p>No notes with this tag.</p>'}"
        return Response(200, _html_page(f"#{tag}", body, active="tags"))

    @router.get("/graph")
    def graph_page(req: Request) -> Response:
        adj = store.graph()
        summary = graph_summary(adj)
        pr = pagerank(adj)
        top = sorted(pr.items(), key=lambda x: -x[1])[:10]
        top_html = "".join(
            f'<li><a href="/note/{nid.replace(".md","")}">{nid.replace(".md","")}</a> '
            f'<span style="color:var(--dim)">{score:.4f}</span></li>'
            for nid, score in top
        )
        stats_html = f"""
        <div class="stat-grid">
          <div class="stat-card"><div class="stat-val">{summary['nodes']}</div><div class="stat-lbl">Nodes</div></div>
          <div class="stat-card"><div class="stat-val">{summary['edges']}</div><div class="stat-lbl">Edges</div></div>
          <div class="stat-card"><div class="stat-val">{summary['components']}</div><div class="stat-lbl">Components</div></div>
          <div class="stat-card"><div class="stat-val">{summary['density']}</div><div class="stat-lbl">Density</div></div>
        </div>"""
        body = f"""
        <h1>Knowledge Graph</h1>
        {stats_html}
        <canvas id="gc" class="graph-canvas"></canvas>
        <h2>Top by PageRank</h2><ol>{top_html}</ol>
        <script>
        const ADJ={json.dumps(adj)};
        const C=document.getElementById('gc'),ctx=C.getContext('2d');
        C.width=C.offsetWidth;C.height=520;
        const W=C.width,H=C.height;
        const nodes=Object.keys(ADJ);
        let pos={{}};
        nodes.forEach((n,i)=>{{const a=2*Math.PI*i/nodes.length;
          pos[n]={{x:W/2+Math.min(W,H)*.38*Math.cos(a),y:H/2+Math.min(W,H)*.38*Math.sin(a),vx:0,vy:0}}}});
        function tick(){{
          nodes.forEach(a=>nodes.forEach(b=>{{if(a===b)return;
            const dx=pos[a].x-pos[b].x,dy=pos[a].y-pos[b].y,d=Math.sqrt(dx*dx+dy*dy)||1,f=3000/(d*d);
            pos[a].vx+=dx/d*f;pos[a].vy+=dy/d*f}}));
          nodes.forEach(s=>(ADJ[s]||[]).forEach(t=>{{if(!pos[t])return;
            const dx=pos[t].x-pos[s].x,dy=pos[t].y-pos[s].y,d=Math.sqrt(dx*dx+dy*dy)||1,f=d/50;
            pos[s].vx+=dx/d*f;pos[s].vy+=dy/d*f;pos[t].vx-=dx/d*f;pos[t].vy-=dy/d*f}}));
          nodes.forEach(n=>{{pos[n].vx*=.85;pos[n].vy*=.85;
            pos[n].x=Math.max(15,Math.min(W-15,pos[n].x+pos[n].vx));
            pos[n].y=Math.max(15,Math.min(H-15,pos[n].y+pos[n].vy))}})}}
        function draw(){{
          ctx.clearRect(0,0,W,H);
          ctx.strokeStyle='#555';ctx.lineWidth=1;
          nodes.forEach(s=>(ADJ[s]||[]).forEach(t=>{{if(!pos[t])return;
            ctx.beginPath();ctx.moveTo(pos[s].x,pos[s].y);ctx.lineTo(pos[t].x,pos[t].y);ctx.stroke()}}));
          ctx.fillStyle='#3b82f6';
          nodes.forEach(n=>{{ctx.beginPath();ctx.arc(pos[n].x,pos[n].y,5,0,Math.PI*2);ctx.fill()}});
          ctx.fillStyle=getComputedStyle(document.body).getPropertyValue('--text').trim()||'#222';
          ctx.font='10px system-ui';
          nodes.forEach(n=>{{const lbl=n.split('/').pop().replace('.md','');
            ctx.fillText(lbl,pos[n].x+7,pos[n].y+4)}})}};
        let i=0;function loop(){{if(i++<120)tick();draw();requestAnimationFrame(loop)}}loop();
        </script>"""
        return Response(200, _html_page("Graph", body, active="graph"))

    @router.get("/calendar")
    def calendar_page(req: Request) -> Response:
        import datetime as dt
        year = int(req.params.get("year", [str(dt.date.today().year)])[0])
        activity = activity_by_day(store)
        hm = heatmap(activity, year)
        prev_year = f'<a href="/calendar?year={year-1}">← {year-1}</a>'
        next_year = f'<a href="/calendar?year={year+1}">{year+1} →</a>'
        total = sum(v for d, v in activity.items() if d.year == year)
        body = f"""
        <h1>Calendar {year}</h1>
        <div style="display:flex;justify-content:space-between;margin-bottom:1rem">
          {prev_year}<span style="color:var(--dim)">{total} notes in {year}</span>{next_year}
        </div>
        <pre style="font-family:monospace;font-size:.8rem;line-height:1.4">{hm}</pre>"""
        return Response(200, _html_page(f"Calendar {year}", body, active="calendar"))

    @router.get("/orphans")
    def orphans_page(req: Request) -> Response:
        orph = orphans(store)
        cards = "".join(
            f'<div class="card"><div class="card-title"><a href="/note/{n.stem}">{n.title}</a></div>'
            f'<div class="card-meta">{n.word_count:,} words</div></div>'
            for n in orph
        )
        body = f"<h1>Orphaned Notes ({len(orph)})</h1><p style='color:var(--dim);margin-bottom:1rem'>Notes with no inbound or outbound links.</p>{cards or '<p>No orphans — great connectivity!</p>'}"
        return Response(200, _html_page("Orphans", body, active="orphans"))

    @router.get("/stats")
    def stats_page(req: Request) -> Response:
        s = store.stats()
        longest = store.longest_notes(5)
        top_tags = list(store.all_tags().items())[:10]
        tag_rows = "".join(
            f'<tr><td><a href="/tags/{t}">#{t}</a></td><td>{c}</td></tr>' for t, c in top_tags
        )
        longest_rows = "".join(
            f'<tr><td><a href="/note/{n.stem}">{n.title}</a></td><td>{w:,}</td></tr>'
            for n, w in longest
        )
        body = f"""
        <h1>Vault Statistics</h1>
        <div class="stat-grid">
          <div class="stat-card"><div class="stat-val">{s['notes']}</div><div class="stat-lbl">Notes</div></div>
          <div class="stat-card"><div class="stat-val">{s['words']:,}</div><div class="stat-lbl">Words</div></div>
          <div class="stat-card"><div class="stat-val">{s['links']}</div><div class="stat-lbl">Links</div></div>
          <div class="stat-card"><div class="stat-val">{s['tags']}</div><div class="stat-lbl">Tags</div></div>
        </div>
        <h2>Top Tags</h2>
        <table><tr><th>Tag</th><th>Notes</th></tr>{tag_rows}</table>
        <h2>Longest Notes</h2>
        <table><tr><th>Title</th><th>Words</th></tr>{longest_rows}</table>"""
        return Response(200, _html_page("Stats", body, active="stats"))

    # ------------------------------------------------------------------
    # JSON API

    @router.get("/api/stats")
    def api_stats(req: Request) -> Response:
        data = store.stats()
        return Response(200, json.dumps(data), content_type="application/json")

    @router.get("/api/notes")
    def api_notes(req: Request) -> Response:
        limit = int(req.params.get("limit", ["50"])[0])
        notes = [n.to_dict() for n in list(store.notes())[:limit]]
        return Response(200, json.dumps(notes, default=str), content_type="application/json")

    @router.get("/api/note/{stem}")
    def api_note(req: Request, stem: str) -> Response:
        note = store.get(stem)
        if note is None:
            return Response(404, json.dumps({"error": "not found"}), content_type="application/json")
        return Response(200, json.dumps(note.to_dict(), default=str), content_type="application/json")

    @router.get("/api/search")
    def api_search(req: Request) -> Response:
        q = req.params.get("q", [""])[0]
        limit = int(req.params.get("limit", ["20"])[0])
        results = ranked_search(store, q, limit=limit) if q else []
        return Response(200, json.dumps([n.to_dict() for n in results], default=str),
                        content_type="application/json")

    @router.get("/api/graph")
    def api_graph(req: Request) -> Response:
        return Response(200, json.dumps(store.graph()), content_type="application/json")

    @router.get("/api/tags")
    def api_tags(req: Request) -> Response:
        return Response(200, json.dumps(store.all_tags()), content_type="application/json")

    return router


# ---------------------------------------------------------------------------
# HTTP server

class NotaHandler(BaseHTTPRequestHandler):
    router: Router
    store: Store

    def log_message(self, fmt: str, *args: object) -> None:
        pass  # suppress default access log

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        params = parse_qs(parsed.query)
        req = Request(method="GET", path=path, params=params, headers=dict(self.headers))
        resp = self.router.dispatch(req)
        self.send_response(resp.status)
        self.send_header("Content-Type", resp.content_type)
        self.end_headers()
        self.wfile.write(resp.body.encode() if isinstance(resp.body, str) else resp.body)

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8", errors="replace")
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        req = Request(method="POST", path=unquote(parsed.path), params=params,
                      headers=dict(self.headers), body=body)
        resp = self.router.dispatch(req)
        self.send_response(resp.status)
        self.send_header("Content-Type", resp.content_type)
        self.end_headers()
        self.wfile.write(resp.body.encode() if isinstance(resp.body, str) else resp.body)


class NotaServer:
    """Wrapper around the stdlib HTTPServer."""

    def __init__(self, store: Store, host: str = "127.0.0.1", port: int = 5000) -> None:
        self.store  = store
        self.host   = host
        self.port   = port
        self._router = _make_router(store)
        self._httpd: Optional[HTTPServer] = None

    def start(self, *, open_browser: bool = False, daemon: bool = False) -> None:
        handler = type(
            "Handler",
            (NotaHandler,),
            {"router": self._router, "store": self.store},
        )
        self._httpd = HTTPServer((self.host, self.port), handler)
        url = f"http://{self.host}:{self.port}"
        if open_browser:
            threading.Thread(target=lambda: webbrowser.open(url), daemon=True).start()
        if daemon:
            t = threading.Thread(target=self._httpd.serve_forever, daemon=True)
            t.start()
        else:
            self._httpd.serve_forever()

    def stop(self) -> None:
        if self._httpd:
            self._httpd.shutdown()

    def url(self) -> str:
        return f"http://{self.host}:{self.port}"


def run(
    store: Store,
    *,
    host: str = "127.0.0.1",
    port: int = 5000,
    open_browser: bool = False,
) -> None:
    """Start the nota web server (blocking)."""
    server = NotaServer(store, host=host, port=port)
    server.start(open_browser=open_browser)
