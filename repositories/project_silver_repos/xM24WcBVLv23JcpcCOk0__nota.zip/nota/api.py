"""High-level programmatic API for nota.

Provides a single ``Vault`` class that wraps Store, search, batch
operations, and export behind a clean, stable interface suitable for
use in scripts, plugins, and the MCP server.

Example::

    from nota.api import Vault

    v = Vault("/path/to/my-notes")
    note = v.create("Design decisions", tags=["architecture"])
    results = v.search("async python")
    v.export_html(output_dir="/tmp/site")
    v.close()

Context manager usage::

    with Vault("/path/to/my-notes") as v:
        for note in v.recent(10):
            print(note.title, note.word_count)
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .core.note import Note
from .core.store import Store
from .core.search import ranked_search
from .core.query import search as query_search, compile_query, explain as explain_query
from .core.batch import (
    add_tag, remove_tag, rename_tag,
    batch_add_tag, batch_remove_tag, batch_rename_tag,
    set_field, batch_replace,
)
from .core.graph import pagerank, graph_summary, shortest_path
from .core.links import orphans, link_graph
from .core.calendar import activity_by_day, streak, heatmap
from .core.summarizer import summarize, extractive_summary
from .utils.config import Config


class Vault:
    """High-level interface to a nota vault.

    All mutating methods automatically re-index affected notes.
    """

    def __init__(
        self,
        path: Union[str, Path],
        *,
        config: Optional[Config] = None,
        auto_index: bool = True,
    ) -> None:
        self._root   = Path(path).resolve()
        self._config = config or Config(vault=self._root)
        self._store  = Store(self._root)
        if auto_index:
            self._store.index_all()

    # ------------------------------------------------------------------
    # context manager

    def __enter__(self) -> "Vault":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        self._store.close()

    # ------------------------------------------------------------------
    # properties

    @property
    def root(self) -> Path:
        return self._root

    @property
    def store(self) -> Store:
        return self._store

    # ------------------------------------------------------------------
    # CRUD

    def create(
        self,
        title: str,
        *,
        content: str = "",
        tags: Optional[List[str]] = None,
        subdir: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Note:
        """Create a new note and index it.

        Args:
            title: Note title (used to generate the filename slug).
            content: Markdown body (without frontmatter).
            tags: List of tag strings.
            subdir: Optional subdirectory within the vault.
            metadata: Extra frontmatter fields.

        Returns:
            The created Note object.
        """
        import re
        now = datetime.now()
        slug = re.sub(r"[^\w-]", "", title.lower().replace(" ", "-"))[:80]

        target_dir = self._root / subdir if subdir else self._root
        target_dir.mkdir(parents=True, exist_ok=True)
        path = target_dir / f"{slug}.md"

        counter = 1
        while path.exists():
            path = target_dir / f"{slug}-{counter}.md"
            counter += 1

        fm_tags  = tags or []
        tag_line = ", ".join(fm_tags) if fm_tags else "[]"
        extra = ""
        if metadata:
            for k, v in metadata.items():
                extra += f"\n{k}: {v}"

        body = (
            f"---\ntitle: {title}\ncreated: {now.isoformat()}\n"
            f"tags: [{tag_line}]{extra}\n---\n\n# {title}\n\n{content}"
        )
        path.write_text(body, encoding="utf-8")
        note = Note(path, self._root)
        self._store.index_note(note)
        self._store.conn.commit()
        return note

    def get(self, ref: str) -> Optional[Note]:
        """Resolve a note by id, stem, or title."""
        return self._store.get(ref)

    def delete(self, ref: str) -> bool:
        """Delete a note and remove it from the index. Returns True if found."""
        note = self._store.get(ref)
        if note is None:
            return False
        note_id = note.id
        note.path.unlink()
        self._store.remove_note(note_id)
        return True

    def update_content(self, ref: str, new_content: str) -> Optional[Note]:
        """Replace the body of a note (preserves frontmatter)."""
        import frontmatter
        note = self._store.get(ref)
        if note is None:
            return None
        post = frontmatter.load(str(note.path))
        post.content = new_content
        note.path.write_text(frontmatter.dumps(post), encoding="utf-8")
        note._post = None
        self._store.index_note(note)
        self._store.conn.commit()
        return note

    # ------------------------------------------------------------------
    # search

    def search(self, query: str, limit: int = 20) -> List[Note]:
        """Ranked full-text + fuzzy search."""
        return ranked_search(self._store, query, limit=limit)

    def query(self, dsl: str, limit: int = 0) -> List[Note]:
        """Filter notes with the nota query DSL.

        Examples::

            v.query("tag:python AND words:>500")
            v.query("created:>2025-06-01 NOT tag:archived")
        """
        return query_search(self._store, dsl, limit=limit)

    def explain(self, dsl: str) -> str:
        """Return a human-readable explanation of a DSL query."""
        return explain_query(dsl)

    # ------------------------------------------------------------------
    # listing

    def all_notes(self, *, sort: str = "modified") -> List[Note]:
        notes = list(self._store.notes())
        if sort == "modified":
            notes.sort(key=lambda n: n.modified, reverse=True)
        elif sort == "created":
            notes.sort(key=lambda n: n.created or datetime.min, reverse=True)
        elif sort == "title":
            notes.sort(key=lambda n: n.title.lower())
        elif sort == "words":
            notes.sort(key=lambda n: n.word_count, reverse=True)
        return notes

    def recent(self, n: int = 10) -> List[Note]:
        return self._store.recent(n)

    def by_tag(self, tag: str) -> List[Note]:
        return self._store.by_tag(tag)

    def by_tags(self, tags: List[str], *, require_all: bool = False) -> List[Note]:
        return self._store.by_tags(tags, require_all=require_all)

    def orphans(self) -> List[Note]:
        return orphans(self._store)

    def backlinks(self, ref: str) -> List[Note]:
        note = self._store.get(ref)
        if note is None:
            return []
        return self._store.backlinks(note)

    # ------------------------------------------------------------------
    # tags

    def all_tags(self) -> Dict[str, int]:
        return self._store.all_tags()

    def add_tag(self, ref: str, tag: str) -> bool:
        note = self._store.get(ref)
        if not note:
            return False
        result = add_tag(note, tag)
        if result:
            note._post = None
            self._store.index_note(note)
            self._store.conn.commit()
        return result

    def remove_tag(self, ref: str, tag: str) -> bool:
        note = self._store.get(ref)
        if not note:
            return False
        result = remove_tag(note, tag)
        if result:
            note._post = None
            self._store.index_note(note)
            self._store.conn.commit()
        return result

    def rename_tag_vault(self, old: str, new: str) -> int:
        paths = batch_rename_tag(self._store, old, new)
        self._store.index_all(force=True)
        return len(paths)

    # ------------------------------------------------------------------
    # graph

    def graph(self) -> Dict[str, List[str]]:
        return self._store.graph()

    def pagerank(self) -> Dict[str, float]:
        return pagerank(self.graph())

    def graph_summary(self) -> Dict[str, object]:
        return graph_summary(self.graph())

    def path_between(self, src: str, dst: str) -> Optional[List[str]]:
        adj = self.graph()
        return shortest_path(adj, src + ".md", dst + ".md")

    # ------------------------------------------------------------------
    # stats

    def stats(self) -> Dict[str, object]:
        return self._store.stats()

    def full_stats(self) -> Dict[str, object]:
        return self._store.full_stats()

    # ------------------------------------------------------------------
    # calendar / activity

    def activity(self, year: Optional[int] = None) -> Dict:
        act = activity_by_day(self._store)
        current_streak, longest_streak = streak(act)
        return {
            "activity":       {str(d): c for d, c in act.items()},
            "current_streak": current_streak,
            "longest_streak": longest_streak,
            "heatmap":        heatmap(act, year),
        }

    # ------------------------------------------------------------------
    # summarisation

    def summarize(self, ref: str, *, model: str = "llama3.1") -> str:
        note = self._store.get(ref)
        if note is None:
            return ""
        return summarize(note, model=model)

    def extractive_summary(self, ref: str, sentences: int = 3) -> str:
        note = self._store.get(ref)
        if note is None:
            return ""
        return extractive_summary(note, sentences=sentences)

    # ------------------------------------------------------------------
    # export

    def export_html(
        self,
        output_dir: Optional[Union[str, Path]] = None,
        *,
        ref: Optional[str] = None,
    ) -> List[Path]:
        from .export.html import export_html, export_vault_html
        out = Path(output_dir) if output_dir else None
        if ref:
            note = self._store.get(ref)
            if note is None:
                return []
            return [export_html(note, out)]
        return export_vault_html(self._root, out)

    def export_site(
        self,
        output_dir: Union[str, Path],
        *,
        theme: str = "light",
        clean: bool = False,
    ) -> int:
        from .export.site import build_site
        return build_site(self._store, Path(output_dir), theme=theme, clean=clean)

    def export_json(self, output: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
        from .export.json_export import export_json
        return export_json(self._store, Path(output) if output else None)

    def export_markdown(self, output: Optional[Union[str, Path]] = None) -> str:
        from .export.markdown import export_consolidated
        return export_consolidated(self._store, Path(output) if output else None)

    # ------------------------------------------------------------------
    # index management

    def reindex(self, *, force: bool = False) -> int:
        return self._store.index_all(force=force)

    # ------------------------------------------------------------------
    # repr

    def __repr__(self) -> str:
        count = self._store.note_count()
        return f"Vault({str(self._root)!r}, notes={count})"
