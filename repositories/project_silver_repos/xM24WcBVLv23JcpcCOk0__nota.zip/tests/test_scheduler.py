"""Tests for the nota task scheduler."""
from __future__ import annotations

import time
import threading
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from nota.core.scheduler import (
    Scheduler,
    ScheduledTask,
    make_reindex_task,
    make_stats_log_task,
    make_backup_task,
    default_scheduler,
)


# ---------------------------------------------------------------------------
# ScheduledTask

class TestScheduledTask:
    def test_is_due_immediately_when_run_immediately(self) -> None:
        counter = [0]
        task = ScheduledTask(
            name="t", fn=lambda: counter.__setitem__(0, counter[0]+1),
            interval_seconds=9999, run_immediately=True,
        )
        assert task.is_due

    def test_not_due_initially(self) -> None:
        task = ScheduledTask(
            name="t", fn=lambda: None,
            interval_seconds=9999, run_immediately=False,
        )
        assert not task.is_due

    def test_is_due_after_interval(self) -> None:
        task = ScheduledTask(name="t", fn=lambda: None, interval_seconds=0.01)
        task.last_run = datetime.now() - timedelta(seconds=1)
        assert task.is_due

    def test_execute_increments_run_count(self) -> None:
        task = ScheduledTask(name="t", fn=lambda: None, interval_seconds=1)
        task.execute()
        assert task.run_count == 1

    def test_execute_sets_last_run(self) -> None:
        task = ScheduledTask(name="t", fn=lambda: None, interval_seconds=1)
        before = datetime.now()
        task.execute()
        assert task.last_run >= before

    def test_execute_captures_error(self) -> None:
        def bad(): raise RuntimeError("boom")
        task = ScheduledTask(name="t", fn=bad, interval_seconds=1)
        result = task.execute()
        assert not result
        assert task.last_error == "boom"
        assert task.error_count == 1

    def test_status_dict_has_keys(self) -> None:
        task = ScheduledTask(name="mytask", fn=lambda: None, interval_seconds=60)
        d = task.status_dict()
        assert d["name"] == "mytask"
        assert "run_count" in d
        assert "enabled" in d


# ---------------------------------------------------------------------------
# Scheduler lifecycle

class TestSchedulerLifecycle:
    def test_start_stop(self) -> None:
        s = Scheduler(tick=60)
        s.start()
        assert s.is_running
        s.stop()
        assert not s.is_running

    def test_double_start_safe(self) -> None:
        s = Scheduler(tick=60)
        s.start()
        s.start()  # should not raise
        s.stop()

    def test_repr(self) -> None:
        s = Scheduler(tick=30)
        r = repr(s)
        assert "Scheduler" in r
        assert "30" in r


# ---------------------------------------------------------------------------
# Task registration

class TestTaskRegistration:
    def test_add_task(self) -> None:
        s = Scheduler(tick=60)
        s.add("mytest", lambda: None, interval=120)
        status = s.status()
        assert any(t["name"] == "mytest" for t in status)

    def test_remove_task(self) -> None:
        s = Scheduler(tick=60)
        s.add("removeme", lambda: None, interval=60)
        assert s.remove("removeme")
        assert not any(t["name"] == "removeme" for t in s.status())

    def test_remove_nonexistent(self) -> None:
        s = Scheduler(tick=60)
        assert not s.remove("ghost")

    def test_enable_disable(self) -> None:
        s = Scheduler(tick=60)
        s.add("toggle", lambda: None, interval=60)
        s.disable("toggle")
        assert not s.get_task("toggle").enabled
        s.enable("toggle")
        assert s.get_task("toggle").enabled

    def test_chaining(self) -> None:
        s = (
            Scheduler(tick=60)
            .add("a", lambda: None, interval=60)
            .add("b", lambda: None, interval=120)
        )
        assert len(s.status()) == 2


# ---------------------------------------------------------------------------
# Task execution

class TestTaskExecution:
    def test_run_now_executes(self) -> None:
        results = []
        s = Scheduler(tick=60)
        s.add("immediate", lambda: results.append(1), interval=9999)
        s.run_now("immediate")
        time.sleep(0.2)
        assert results

    def test_run_now_nonexistent_returns_false(self) -> None:
        s = Scheduler(tick=60)
        assert not s.run_now("ghost")

    def test_tasks_run_on_schedule(self) -> None:
        counter = []
        s = Scheduler(tick=0.05)
        s.add("frequent", lambda: counter.append(1), interval=0.05, run_immediately=True)
        s.start()
        time.sleep(0.4)
        s.stop()
        assert len(counter) >= 2

    def test_disabled_task_not_run(self) -> None:
        counter = []
        s = Scheduler(tick=0.05)
        s.add("disabled", lambda: counter.append(1), interval=0.01, run_immediately=True, enabled=False)
        s.start()
        time.sleep(0.2)
        s.stop()
        assert len(counter) == 0


# ---------------------------------------------------------------------------
# Factory functions

class TestFactoryFunctions:
    def test_reindex_task_callable(self) -> None:
        class FakeStore:
            def index_all(self, force=False): return 0
        fn = make_reindex_task(FakeStore())
        fn()  # should not raise

    def test_stats_log_task_callable(self) -> None:
        class FakeStore:
            def note_count(self): return 5
        fn = make_stats_log_task(FakeStore())
        fn()

    def test_backup_task_creates_zip(self, tmp_path: Path) -> None:
        vault = tmp_path / "vault"
        vault.mkdir()
        (vault / "note.md").write_text("# Hello", encoding="utf-8")
        backup_dir = tmp_path / "backups"
        fn = make_backup_task(vault, backup_dir)
        fn()
        zips = list(backup_dir.glob("*.zip"))
        assert len(zips) == 1


# ---------------------------------------------------------------------------
# Default scheduler

class TestDefaultScheduler:
    def test_creates_scheduler_with_tasks(self) -> None:
        class FakeStore:
            def index_all(self, force=False): return 0
            def note_count(self): return 0

        s = default_scheduler(FakeStore(), Path("/tmp"))
        status = s.status()
        names = [t["name"] for t in status]
        assert "reindex" in names
        assert "stats-log" in names
