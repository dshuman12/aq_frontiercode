"""Tests for the SQLite migration system."""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from nota.utils.migrate import (
    MigrationRunner,
    Migration,
    get_schema_version,
    set_schema_version,
    run_migrations,
)


@pytest.fixture()
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "test.db"


@pytest.fixture()
def conn(db_path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(str(db_path))
    yield c
    c.close()


# ---------------------------------------------------------------------------
# Schema version helpers

class TestSchemaVersion:
    def test_initial_version_is_zero(self, conn: sqlite3.Connection) -> None:
        assert get_schema_version(conn) == 0

    def test_set_and_get_version(self, conn: sqlite3.Connection) -> None:
        set_schema_version(conn, 5)
        assert get_schema_version(conn) == 5

    def test_overwrite_version(self, conn: sqlite3.Connection) -> None:
        set_schema_version(conn, 3)
        set_schema_version(conn, 7)
        assert get_schema_version(conn) == 7


# ---------------------------------------------------------------------------
# Migration data class

class TestMigration:
    def test_migration_repr(self) -> None:
        m = Migration(version=1, description="initial", sql="CREATE TABLE t (id INT);")
        assert "1" in repr(m)
        assert "initial" in repr(m)

    def test_apply_creates_table(self, conn: sqlite3.Connection) -> None:
        m = Migration(
            version=1,
            description="create foo",
            sql="CREATE TABLE foo (id INTEGER PRIMARY KEY);",
        )
        m.apply(conn)
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        assert "foo" in tables

    def test_apply_updates_version(self, conn: sqlite3.Connection) -> None:
        m = Migration(version=2, description="v2", sql="CREATE TABLE bar (x TEXT);")
        m.apply(conn)
        assert get_schema_version(conn) == 2


# ---------------------------------------------------------------------------
# MigrationRunner

class TestMigrationRunner:
    def _make_migrations(self) -> list:
        return [
            Migration(1, "create alpha", "CREATE TABLE alpha (id INTEGER PRIMARY KEY);"),
            Migration(2, "create beta",  "CREATE TABLE beta (val TEXT);"),
            Migration(3, "add column",   "ALTER TABLE alpha ADD COLUMN name TEXT;"),
        ]

    def test_runs_all_from_zero(self, conn: sqlite3.Connection) -> None:
        runner = MigrationRunner(self._make_migrations())
        applied = runner.run(conn)
        assert applied == 3
        assert get_schema_version(conn) == 3

    def test_skips_already_applied(self, conn: sqlite3.Connection) -> None:
        migs = self._make_migrations()
        runner = MigrationRunner(migs)
        runner.run(conn)
        # Run again — should apply 0 more
        applied = runner.run(conn)
        assert applied == 0

    def test_applies_incremental(self, conn: sqlite3.Connection) -> None:
        migs = self._make_migrations()
        runner1 = MigrationRunner(migs[:1])
        runner1.run(conn)
        assert get_schema_version(conn) == 1

        runner2 = MigrationRunner(migs)
        applied = runner2.run(conn)
        assert applied == 2
        assert get_schema_version(conn) == 3

    def test_pending_returns_correct_count(self, conn: sqlite3.Connection) -> None:
        runner = MigrationRunner(self._make_migrations())
        assert runner.pending_count(conn) == 3
        runner.run(conn)
        assert runner.pending_count(conn) == 0

    def test_migration_table_created(self, conn: sqlite3.Connection) -> None:
        runner = MigrationRunner(self._make_migrations())
        runner.run(conn)
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        assert any("migrat" in t.lower() or "schema" in t.lower() for t in tables)

    def test_empty_migrations(self, conn: sqlite3.Connection) -> None:
        runner = MigrationRunner([])
        applied = runner.run(conn)
        assert applied == 0


# ---------------------------------------------------------------------------
# run_migrations convenience function

class TestRunMigrations:
    def test_run_migrations_returns_count(self, db_path: Path) -> None:
        count = run_migrations(db_path)
        assert isinstance(count, int)
        assert count >= 0

    def test_idempotent(self, db_path: Path) -> None:
        run_migrations(db_path)
        count = run_migrations(db_path)
        assert count == 0  # all already applied
