"""Shared pytest fixtures."""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from nota.core.note import Note
from nota.core.store import Store


@pytest.fixture()
def vault(tmp_path: Path) -> Path:
    """Return a temporary vault directory with a few seed notes."""
    (tmp_path / ".nota").mkdir()

    def write_note(name: str, body: str) -> Path:
        p = tmp_path / name
        p.write_text(textwrap.dedent(body), encoding="utf-8")
        return p

    write_note("alpha.md", """\
        ---
        title: Alpha Note
        created: 2025-03-01
        tags: [research, ai]
        ---
        # Alpha Note
        This is the alpha note. It links to [[Beta Note]].
        #research
    """)

    write_note("beta.md", """\
        ---
        title: Beta Note
        created: 2025-03-15
        tags: [project]
        ---
        # Beta Note
        The beta note references [[Alpha Note]] and [[Gamma]].
    """)

    write_note("gamma.md", """\
        ---
        title: Gamma
        created: 2025-04-01
        ---
        # Gamma
        No outbound links here.
    """)

    return tmp_path


@pytest.fixture()
def store(vault: Path) -> Store:
    s = Store(vault)
    s.index_all(force=True)
    return s
