"""Tests for the nota query DSL."""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from nota.core.query import compile_query, search, explain, QuerySyntaxError, tokenise
from nota.core.note import Note
from nota.core.store import Store


def make_note(root: Path, name: str, body: str) -> None:
    (root / name).write_text(textwrap.dedent(body), encoding="utf-8")


@pytest.fixture()
def rich_vault(tmp_path: Path) -> Path:
    (tmp_path / ".nota").mkdir()
    make_note(tmp_path, "python-async.md", """\
        ---
        title: Python Async Guide
        created: 2025-03-01
        tags: [python, async, tutorial]
        ---
        # Python Async Guide
        asyncio is the foundation of async Python.
        Coroutines are defined with async def.
        Tasks wrap coroutines and run concurrently.
        This guide covers event loops and awaitable objects extensively.
        """)
    make_note(tmp_path, "rust-memory.md", """\
        ---
        title: Rust Memory Model
        created: 2025-06-15
        tags: [rust, systems]
        ---
        # Rust Memory Model
        Ownership is the central concept. The borrow checker enforces it.
        No garbage collector means predictable performance always.
        Stack allocation is preferred over heap when possible.
        """)
    make_note(tmp_path, "archived-notes.md", """\
        ---
        title: Old Notes
        created: 2024-11-01
        tags: [archived]
        ---
        # Old Notes
        These notes are archived and no longer relevant.
        """)
    make_note(tmp_path, "daily-2025-07-01.md", """\
        ---
        title: 2025-07-01
        created: 2025-07-01
        tags: [daily]
        ---
        # 2025-07-01
        ## Tasks
        - [ ] Review PR
        ## Notes
        Worked on [[Python Async Guide]] today.
        """)
    return tmp_path


@pytest.fixture()
def rich_store(rich_vault: Path) -> Store:
    s = Store(rich_vault)
    s.index_all(force=True)
    return s


# ---------------------------------------------------------------------------
# Tokeniser

class TestTokenise:
    def test_field_token(self) -> None:
        tokens = tokenise("tag:python")
        assert tokens[0].kind == "field"
        assert tokens[0].value == "tag:python"

    def test_operators(self) -> None:
        tokens = tokenise("AND OR NOT")
        assert [t.kind for t in tokens] == ["AND", "OR", "NOT"]

    def test_parens(self) -> None:
        tokens = tokenise("(tag:a OR tag:b)")
        assert tokens[0].kind == "lparen"
        assert tokens[-1].kind == "rparen"

    def test_quoted(self) -> None:
        tokens = tokenise('"async python"')
        assert tokens[0].kind == "quoted"


# ---------------------------------------------------------------------------
# Compile and match

class TestCompileQuery:
    def test_empty_matches_all(self, rich_store) -> None:
        pred = compile_query("")
        notes = list(rich_store.notes())
        assert all(pred(n) for n in notes)

    def test_tag_filter(self, rich_store) -> None:
        pred = compile_query("tag:python")
        results = [n for n in rich_store.notes() if pred(n)]
        assert all("python" in n.tags for n in results)

    def test_and_filter(self, rich_store) -> None:
        pred = compile_query("tag:python AND tag:async")
        results = [n for n in rich_store.notes() if pred(n)]
        for n in results:
            assert "python" in n.tags
            assert "async" in n.tags

    def test_or_filter(self, rich_store) -> None:
        pred = compile_query("tag:rust OR tag:python")
        results = [n for n in rich_store.notes() if pred(n)]
        assert len(results) >= 2

    def test_not_filter(self, rich_store) -> None:
        pred = compile_query("NOT tag:archived")
        results = [n for n in rich_store.notes() if pred(n)]
        assert all("archived" not in n.tags for n in results)

    def test_title_filter(self, rich_store) -> None:
        pred = compile_query("title:rust")
        results = [n for n in rich_store.notes() if pred(n)]
        assert all("rust" in n.title.lower() for n in results)

    def test_path_filter(self, rich_store) -> None:
        pred = compile_query("path:daily")
        results = [n for n in rich_store.notes() if pred(n)]
        assert all("daily" in n.id for n in results)

    def test_words_gt(self, rich_store) -> None:
        pred = compile_query("words:>20")
        results = [n for n in rich_store.notes() if pred(n)]
        assert all(n.word_count > 20 for n in results)

    def test_words_range(self, rich_store) -> None:
        pred = compile_query("words:1..500")
        results = [n for n in rich_store.notes() if pred(n)]
        assert all(1 <= n.word_count <= 500 for n in results)

    def test_created_gt(self, rich_store) -> None:
        from datetime import datetime
        pred = compile_query("created:>2025-01-01")
        results = [n for n in rich_store.notes() if pred(n)]
        for n in results:
            assert n.created is not None
            assert n.created > datetime(2025, 1, 1)

    def test_has_daily(self, rich_store) -> None:
        pred = compile_query("has:daily")
        results = [n for n in rich_store.notes() if pred(n)]
        assert any("daily" in n.id for n in results)

    def test_has_links(self, rich_store) -> None:
        pred = compile_query("has:links")
        results = [n for n in rich_store.notes() if pred(n)]
        assert all(len(n.links) > 0 for n in results)

    def test_text_search(self, rich_store) -> None:
        pred = compile_query("asyncio")
        results = [n for n in rich_store.notes() if pred(n)]
        assert len(results) >= 1

    def test_complex_parentheses(self, rich_store) -> None:
        pred = compile_query("(tag:python OR tag:rust) AND NOT tag:archived")
        results = [n for n in rich_store.notes() if pred(n)]
        for n in results:
            assert "python" in n.tags or "rust" in n.tags
            assert "archived" not in n.tags

    def test_implicit_and(self, rich_store) -> None:
        pred = compile_query("tag:python tag:async")
        results = [n for n in rich_store.notes() if pred(n)]
        for n in results:
            assert "python" in n.tags and "async" in n.tags


# ---------------------------------------------------------------------------
# Search function

class TestSearch:
    def test_returns_list(self, rich_store) -> None:
        results = search(rich_store, "tag:python")
        assert isinstance(results, list)

    def test_sorted_by_modified(self, rich_store) -> None:
        results = search(rich_store, "")
        dates = [n.modified for n in results]
        assert dates == sorted(dates, reverse=True)

    def test_limit(self, rich_store) -> None:
        results = search(rich_store, "", limit=2)
        assert len(results) <= 2

    def test_no_results(self, rich_store) -> None:
        results = search(rich_store, "tag:nonexistent_xyz")
        assert results == []


# ---------------------------------------------------------------------------
# Explain

class TestExplain:
    def test_returns_string(self) -> None:
        result = explain("tag:python AND words:>500")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_contains_field_info(self) -> None:
        result = explain("tag:python")
        assert "python" in result

    def test_operators_preserved(self) -> None:
        result = explain("tag:a AND NOT tag:b")
        assert "AND" in result
        assert "NOT" in result
