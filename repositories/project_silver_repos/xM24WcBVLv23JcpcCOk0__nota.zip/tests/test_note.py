"""Tests for the Note model."""
from __future__ import annotations

import textwrap
from datetime import datetime
from pathlib import Path

import pytest

from nota.core.note import Note


def make_note(tmp_path: Path, name: str, body: str) -> Note:
    p = tmp_path / name
    p.write_text(textwrap.dedent(body), encoding="utf-8")
    return Note(p, tmp_path)


class TestNoteTitle:
    def test_frontmatter_title(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "foo.md", """\
            ---
            title: Frontmatter Title
            ---
            # Ignored H1
        """)
        assert n.title == "Frontmatter Title"

    def test_h1_fallback(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "foo.md", """\
            # H1 Title
            Some content.
        """)
        assert n.title == "H1 Title"

    def test_filename_fallback(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "my-note.md", "No title here.")
        assert n.title == "My Note"


class TestNoteTags:
    def test_frontmatter_tags_list(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", """\
            ---
            tags: [alpha, beta]
            ---
        """)
        assert "alpha" in n.tags
        assert "beta" in n.tags

    def test_frontmatter_tags_string(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", """\
            ---
            tags: alpha, beta
            ---
        """)
        assert "alpha" in n.tags

    def test_inline_tags(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", "Hello #world and #python/dev.")
        assert "world" in n.tags
        assert "python/dev" in n.tags

    def test_deduplication(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", """\
            ---
            tags: [dup]
            ---
            Content #dup
        """)
        assert n.tags.count("dup") == 1


class TestNoteLinks:
    def test_basic_wikilink(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", "See [[Other Note]] for details.")
        assert "Other Note" in n.links

    def test_aliased_wikilink(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", "See [[Other Note|click here]].")
        assert "Other Note" in n.links

    def test_heading_wikilink(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", "See [[Other Note#Section]].")
        assert "Other Note" in n.links

    def test_multiple_links(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", "[[A]] and [[B]] and [[A]] again.")
        assert n.links.count("A") == 2  # raw extraction, dedup is caller's job


class TestNoteCreated:
    def test_iso_date(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", """\
            ---
            created: 2025-06-01
            ---
        """)
        assert n.created is not None
        assert n.created.year == 2025

    def test_invalid_date_returns_none(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", """\
            ---
            created: not-a-date
            ---
        """)
        assert n.created is None


class TestNoteChecksum:
    def test_checksum_length(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "t.md", "content")
        assert len(n.checksum) == 16

    def test_checksum_changes_on_edit(self, tmp_path: Path) -> None:
        p = tmp_path / "t.md"
        p.write_text("original", encoding="utf-8")
        n = Note(p, tmp_path)
        cs1 = n.checksum
        p.write_text("modified", encoding="utf-8")
        n._post = None  # force reload
        cs2 = n.checksum
        assert cs1 != cs2
