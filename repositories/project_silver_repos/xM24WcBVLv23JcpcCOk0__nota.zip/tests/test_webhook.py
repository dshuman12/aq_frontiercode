"""Tests for the webhook delivery system."""
from __future__ import annotations

import hashlib
import hmac
import http.server
import json
import threading
import time
from pathlib import Path
from typing import List
from unittest.mock import MagicMock, patch

import pytest

from nota.utils.webhook import (
    WebhookConfig,
    WebhookDelivery,
    WebhookEvent,
    WebhookManager,
    sign_payload,
    verify_signature,
)


# ---------------------------------------------------------------------------
# Test HTTP server to capture webhook deliveries

class _CaptureHandler(http.server.BaseHTTPRequestHandler):
    captured: List[dict] = []

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        self._CaptureHandler__class__.captured.append({
            "path": self.path,
            "headers": dict(self.headers),
            "body": body,
        })
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *_: object) -> None:  # noqa: D102
        pass


@pytest.fixture(scope="module")
def capture_server():
    _CaptureHandler.captured = []
    server = http.server.HTTPServer(("127.0.0.1", 0), _CaptureHandler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}", _CaptureHandler.captured
    server.shutdown()


# ---------------------------------------------------------------------------
# Signing helpers

class TestSigning:
    def test_sign_payload(self) -> None:
        sig = sign_payload(b'{"event":"test"}', secret="mysecret")
        assert sig.startswith("sha256=")
        assert len(sig) > 10

    def test_verify_correct_signature(self) -> None:
        payload = b'{"event":"ping"}'
        sig = sign_payload(payload, secret="s3cr3t")
        assert verify_signature(payload, sig, secret="s3cr3t")

    def test_verify_wrong_signature(self) -> None:
        payload = b'{"event":"ping"}'
        sig = sign_payload(payload, secret="right_secret")
        assert not verify_signature(payload, sig, secret="wrong_secret")

    def test_verify_tampered_payload(self) -> None:
        payload = b'{"event":"ping"}'
        sig = sign_payload(payload, secret="s3cr3t")
        assert not verify_signature(b'{"event":"tampered"}', sig, secret="s3cr3t")


# ---------------------------------------------------------------------------
# WebhookConfig

class TestWebhookConfig:
    def test_defaults(self) -> None:
        cfg = WebhookConfig(url="http://example.com/hook")
        assert cfg.max_retries >= 1
        assert cfg.timeout > 0

    def test_events_filter(self) -> None:
        cfg = WebhookConfig(
            url="http://example.com/hook",
            events=["note.created", "note.deleted"],
        )
        assert "note.created" in cfg.events
        assert "note.updated" not in cfg.events


# ---------------------------------------------------------------------------
# WebhookEvent

class TestWebhookEvent:
    def test_serialises_to_json(self) -> None:
        evt = WebhookEvent(
            event="note.created",
            payload={"id": "alpha", "title": "Alpha"},
        )
        d = evt.to_dict()
        assert d["event"] == "note.created"
        assert "timestamp" in d
        assert d["payload"]["id"] == "alpha"

    def test_json_bytes(self) -> None:
        evt = WebhookEvent(event="note.deleted", payload={"id": "beta"})
        b = evt.to_json_bytes()
        assert isinstance(b, bytes)
        parsed = json.loads(b)
        assert parsed["event"] == "note.deleted"


# ---------------------------------------------------------------------------
# WebhookDelivery

class TestWebhookDelivery:
    def test_delivery_to_live_server(self, capture_server) -> None:
        url, captured = capture_server
        before = len(captured)
        cfg = WebhookConfig(url=url, secret="test-secret")
        evt = WebhookEvent(event="note.created", payload={"id": "test-note"})
        delivery = WebhookDelivery(cfg)
        result = delivery.send(evt)
        assert result.success
        assert len(captured) > before

    def test_signature_header_sent(self, capture_server) -> None:
        url, captured = capture_server
        captured.clear()
        cfg = WebhookConfig(url=url, secret="my-secret")
        evt = WebhookEvent(event="ping", payload={})
        WebhookDelivery(cfg).send(evt)
        assert captured
        last = captured[-1]
        sig_header = last["headers"].get("x-nota-signature", "")
        assert sig_header.startswith("sha256=")

    def test_delivery_to_bad_url_fails_gracefully(self) -> None:
        cfg = WebhookConfig(url="http://127.0.0.1:1/nonexistent", max_retries=1, timeout=1)
        evt = WebhookEvent(event="ping", payload={})
        delivery = WebhookDelivery(cfg)
        result = delivery.send(evt)
        assert not result.success
        assert result.error is not None


# ---------------------------------------------------------------------------
# WebhookManager

class TestWebhookManager:
    def test_register_and_fire(self, capture_server) -> None:
        url, captured = capture_server
        captured.clear()
        manager = WebhookManager()
        cfg = WebhookConfig(url=url, events=["note.created"])
        manager.register(cfg)
        evt = WebhookEvent(event="note.created", payload={"id": "x"})
        manager.fire(evt)
        time.sleep(0.5)  # async delivery
        assert any(b"note.created" in r["body"] for r in captured)

    def test_event_filter_respected(self, capture_server) -> None:
        url, captured = capture_server
        captured.clear()
        manager = WebhookManager()
        cfg = WebhookConfig(url=url, events=["note.deleted"])
        manager.register(cfg)
        evt = WebhookEvent(event="note.created", payload={"id": "x"})
        manager.fire(evt)
        time.sleep(0.3)
        # note.created should NOT be delivered to a hook that only wants note.deleted
        assert not any(b"note.created" in r["body"] for r in captured)

    def test_deregister(self, capture_server) -> None:
        url, _ = capture_server
        manager = WebhookManager()
        cfg = WebhookConfig(url=url)
        hook_id = manager.register(cfg)
        assert manager.deregister(hook_id)
        assert not manager.deregister(hook_id)  # already removed

    def test_list_hooks(self, capture_server) -> None:
        url, _ = capture_server
        manager = WebhookManager()
        manager.register(WebhookConfig(url=url))
        manager.register(WebhookConfig(url=url + "/other"))
        hooks = manager.list_hooks()
        assert len(hooks) >= 2
