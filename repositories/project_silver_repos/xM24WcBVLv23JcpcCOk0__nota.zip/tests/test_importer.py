"""Tests for multi-format vault importer."""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from nota.core.note import Note
from nota.core.store import Store
from nota.utils.importer import (
    from_obsidian,
    from_jrnl_text,
    from_jrnl_json,
    from_bear_json,
    from_roam_json,
    from_directory,
    import_vault,
    _detect_format,
    _slugify,
)


@pytest.fixture()
def target_store(tmp_path: Path) -> Store:
    vault = tmp_path / "target"
    vault.mkdir()
    (vault / ".nota").mkdir()
    s = Store(vault)
    return s


# ---------------------------------------------------------------------------
# Helpers

class TestSlugify:
    def test_basic(self) -> None:
        assert _slugify("Hello World") == "hello-world"

    def test_strips_special_chars(self) -> None:
        assert _slugify("Hello, World!") == "hello-world"

    def test_strips_leading_trailing_hyphens(self) -> None:
        slug = _slugify("  spaces  ")
        assert not slug.startswith("-")
        assert not slug.endswith("-")


# ---------------------------------------------------------------------------
# Obsidian

class TestFromObsidian:
    def test_imports_md_files(self, tmp_path: Path, target_store: Store) -> None:
        src = tmp_path / "obsidian_vault"
        src.mkdir()
        (src / "note1.md").write_text("# Note 1\nContent here.", encoding="utf-8")
        (src / "note2.md").write_text("# Note 2\nMore content.", encoding="utf-8")

        result = from_obsidian(src, target_store)
        assert result.total == 2

    def test_preserves_directory_structure(self, tmp_path: Path, target_store: Store) -> None:
        src = tmp_path / "obs"
        (src / "sub").mkdir(parents=True)
        (src / "sub" / "nested.md").write_text("# Nested", encoding="utf-8")

        result = from_obsidian(src, target_store)
        assert result.total == 1
        dest = target_store.vault_root / "sub" / "nested.md"
        assert dest.exists()

    def test_skips_hidden_dirs(self, tmp_path: Path, target_store: Store) -> None:
        src = tmp_path / "obs"
        (src / ".obsidian").mkdir(parents=True)
        (src / ".obsidian" / "hidden.md").write_text("# Hidden", encoding="utf-8")
        (src / "visible.md").write_text("# Visible", encoding="utf-8")

        result = from_obsidian(src, target_store)
        assert result.total == 1

    def test_skips_existing_without_overwrite(self, tmp_path: Path, target_store: Store) -> None:
        src = tmp_path / "obs"
        src.mkdir()
        (src / "note.md").write_text("# Note\nOriginal", encoding="utf-8")
        # pre-create dest
        dest = target_store.vault_root / "note.md"
        dest.write_text("# Note\nExisting", encoding="utf-8")

        result = from_obsidian(src, target_store)
        assert len(result.skipped) == 1
        # content should not be overwritten
        assert "Existing" in dest.read_text()

    def test_rewrites_attachment_embeds(self, tmp_path: Path, target_store: Store) -> None:
        src = tmp_path / "obs"
        src.mkdir()
        (src / "note.md").write_text("![[image.png]]\nText", encoding="utf-8")

        from_obsidian(src, target_store)
        dest = target_store.vault_root / "note.md"
        content = dest.read_text()
        assert "![[image.png]]" not in content
        assert "attachment" in content


# ---------------------------------------------------------------------------
# jrnl

class TestFromJrnlText:
    def test_parses_entries(self, tmp_path: Path, target_store: Store) -> None:
        jrnl_file = tmp_path / "journal.txt"
        jrnl_file.write_text(textwrap.dedent("""\
            2025-03-01 09:00 Morning thoughts
            Woke up early and worked on the project.

            2025-03-02 08:30 Second entry
            Another good morning with coffee.
        """), encoding="utf-8")

        result = from_jrnl_text(jrnl_file, target_store)
        assert result.total == 2

    def test_tags_applied(self, tmp_path: Path, target_store: Store) -> None:
        jrnl_file = tmp_path / "journal.txt"
        jrnl_file.write_text("2025-01-01 10:00 Entry\nSome text.\n", encoding="utf-8")
        from_jrnl_text(jrnl_file, target_store)
        notes = list(target_store.notes())
        assert any("jrnl" in n.tags for n in notes)


class TestFromJrnlJSON:
    def test_parses_entries(self, tmp_path: Path, target_store: Store) -> None:
        data = {"entries": [
            {"title": "First", "body": "Body one.", "date": "2025-04-01", "tags": ["work"]},
            {"title": "Second", "body": "Body two.", "date": "2025-04-02", "tags": []},
        ]}
        f = tmp_path / "export.json"
        f.write_text(json.dumps(data), encoding="utf-8")

        result = from_jrnl_json(f, target_store)
        assert result.total == 2

    def test_tags_included(self, tmp_path: Path, target_store: Store) -> None:
        data = [{"title": "T", "body": "B", "date": "2025-01-01", "tags": ["mytag"]}]
        f = tmp_path / "e.json"
        f.write_text(json.dumps(data), encoding="utf-8")
        from_jrnl_json(f, target_store)
        notes = list(target_store.notes())
        assert any("mytag" in n.tags for n in notes)


# ---------------------------------------------------------------------------
# Bear

class TestFromBearJSON:
    def test_imports_notes(self, tmp_path: Path, target_store: Store) -> None:
        data = [
            {"title": "Bear Note 1", "text": "Content A.", "tags": ["bear"],
             "creationDate": "2025-05-01T10:00:00"},
            {"title": "Bear Note 2", "text": "Content B.", "tags": [],
             "creationDate": "2025-05-02T10:00:00"},
        ]
        f = tmp_path / "bear.json"
        f.write_text(json.dumps(data), encoding="utf-8")
        result = from_bear_json(f, target_store)
        assert result.total == 2

    def test_metadata_set(self, tmp_path: Path, target_store: Store) -> None:
        data = [{"title": "Meta Test", "text": "Body.",
                 "tags": ["a"], "creationDate": "2025-01-01T00:00:00"}]
        f = tmp_path / "b.json"
        f.write_text(json.dumps(data), encoding="utf-8")
        from_bear_json(f, target_store)
        notes = list(target_store.notes())
        assert any(n.title == "Meta Test" for n in notes)


# ---------------------------------------------------------------------------
# Roam

class TestFromRoamJSON:
    def test_imports_pages(self, tmp_path: Path, target_store: Store) -> None:
        data = [
            {
                "title": "Roam Page",
                "create-time": 1700000000000,
                "children": [
                    {"string": "First block", "children": []},
                    {"string": "Second block", "children": [
                        {"string": "Nested block", "children": []}
                    ]},
                ],
            }
        ]
        f = tmp_path / "roam.json"
        f.write_text(json.dumps(data), encoding="utf-8")
        result = from_roam_json(f, target_store)
        assert result.total == 1

    def test_nested_blocks_indented(self, tmp_path: Path, target_store: Store) -> None:
        data = [{"title": "T", "create-time": 0,
                 "children": [{"string": "Parent", "children": [
                     {"string": "Child", "children": []}
                 ]}]}]
        f = tmp_path / "r.json"
        f.write_text(json.dumps(data), encoding="utf-8")
        from_roam_json(f, target_store)
        notes = list(target_store.notes())
        assert len(notes) == 1
        content = notes[0].content
        assert "Child" in content


# ---------------------------------------------------------------------------
# Directory

class TestFromDirectory:
    def test_copies_md_files(self, tmp_path: Path, target_store: Store) -> None:
        src = tmp_path / "src"
        src.mkdir()
        (src / "a.md").write_text("# A", encoding="utf-8")
        (src / "b.md").write_text("# B", encoding="utf-8")
        (src / "image.png").write_bytes(b"\x89PNG")

        result = from_directory(src, target_store)
        assert result.total == 2


# ---------------------------------------------------------------------------
# Auto-detect

class TestDetectFormat:
    def test_obsidian_dir(self, tmp_path: Path) -> None:
        vault = tmp_path / "obs"
        (vault / ".obsidian").mkdir(parents=True)
        assert _detect_format(vault) == "obsidian"

    def test_plain_dir(self, tmp_path: Path) -> None:
        d = tmp_path / "plain"
        d.mkdir()
        assert _detect_format(d) == "directory"

    def test_text_file(self, tmp_path: Path) -> None:
        f = tmp_path / "journal.txt"
        f.write_text("2025-01-01 10:00 Entry\nBody.", encoding="utf-8")
        assert _detect_format(f) == "jrnl"


class TestImportVault:
    def test_dispatches_to_obsidian(self, tmp_path: Path, target_store: Store) -> None:
        src = tmp_path / "obs"
        (src / ".obsidian").mkdir(parents=True)
        (src / "note.md").write_text("# N\nContent.", encoding="utf-8")
        result = import_vault(src, target_store, fmt="obsidian")
        assert result.total >= 1

    def test_unknown_format_raises(self, tmp_path: Path, target_store: Store) -> None:
        with pytest.raises(ValueError):
            import_vault(tmp_path, target_store, fmt="unknown_xyz")
