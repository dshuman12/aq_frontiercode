"""Tests for batch vault operations."""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from nota.core.note import Note
from nota.core.batch import (
    add_tag, remove_tag, rename_tag,
    batch_add_tag, batch_remove_tag, batch_rename_tag,
    set_field, delete_field,
    batch_replace,
    deduplicate_tags,
    tag_co_occurrence,
    rename_note,
)


def write_note(root: Path, name: str, body: str) -> Note:
    p = root / name
    p.write_text(textwrap.dedent(body), encoding="utf-8")
    return Note(p, root)


class TestAddTag:
    def test_adds_new_tag(self, vault, store) -> None:
        note = store.get("alpha")
        assert note is not None
        changed = add_tag(note, "new-tag")
        assert changed
        note._post = None
        assert "new-tag" in note.tags

    def test_idempotent(self, vault, store) -> None:
        note = store.get("alpha")
        assert note is not None
        add_tag(note, "idempotent")
        changed = add_tag(note, "idempotent")
        assert not changed


class TestRemoveTag:
    def test_removes_existing_tag(self, vault, store) -> None:
        note = store.get("alpha")
        assert note is not None
        add_tag(note, "to-remove")
        note._post = None
        changed = remove_tag(note, "to-remove")
        assert changed
        note._post = None
        assert "to-remove" not in note.tags

    def test_noop_for_absent_tag(self, vault, store) -> None:
        note = store.get("gamma")
        assert note is not None
        assert not remove_tag(note, "nonexistent")


class TestRenameTag:
    def test_renames_in_frontmatter(self, vault, store) -> None:
        note = store.get("alpha")
        assert note is not None
        add_tag(note, "old-name")
        note._post = None
        changed = rename_tag(note, "old-name", "new-name")
        assert changed
        note._post = None
        assert "new-name" in note.tags
        assert "old-name" not in note.tags

    def test_renames_inline_tags(self, tmp_path) -> None:
        note = write_note(tmp_path, "t.md", "Content #old-tag here.")
        changed = rename_tag(note, "old-tag", "new-tag")
        assert changed
        note._post = None
        content = note.path.read_text()
        assert "#new-tag" in content
        assert "#old-tag" not in content


class TestBatchOps:
    def test_batch_add_tag(self, store) -> None:
        paths = batch_add_tag(store, "batch-test")
        assert len(paths) == store.note_count()

    def test_batch_remove_tag(self, store) -> None:
        batch_add_tag(store, "to-batch-remove")
        paths = batch_remove_tag(store, "to-batch-remove")
        assert len(paths) > 0

    def test_batch_rename_tag(self, vault, store) -> None:
        # add a known tag to at least one note
        note = store.get("beta")
        assert note is not None
        add_tag(note, "old-batch")
        paths = batch_rename_tag(store, "old-batch", "new-batch")
        assert len(paths) >= 1


class TestFieldOps:
    def test_set_field(self, store) -> None:
        note = store.get("gamma")
        assert note is not None
        set_field(note, "status", "published")
        note._post = None
        assert note.metadata.get("status") == "published"

    def test_delete_field(self, store) -> None:
        note = store.get("gamma")
        assert note is not None
        set_field(note, "to-delete", "value")
        note._post = None
        deleted = delete_field(note, "to-delete")
        assert deleted
        note._post = None
        assert "to-delete" not in note.metadata

    def test_delete_absent_field(self, store) -> None:
        note = store.get("gamma")
        assert note is not None
        assert not delete_field(note, "never-existed")


class TestBatchReplace:
    def test_replaces_text(self, vault, store) -> None:
        # write a known string into a note
        note = store.get("gamma")
        assert note is not None
        original = note.path.read_text(encoding="utf-8")
        note.path.write_text(original + "\nFIND_THIS", encoding="utf-8")
        results = batch_replace(store, "FIND_THIS", "REPLACED")
        assert any("gamma" in str(p) for p, _ in results)

    def test_regex_replace(self, vault, store) -> None:
        note = store.get("gamma")
        assert note is not None
        note.path.write_text(note.path.read_text() + "\n2025-01-01", encoding="utf-8")
        results = batch_replace(store, r"\d{4}-\d{2}-\d{2}", "DATE", regex=True)
        assert len(results) >= 1


class TestDeduplicateTags:
    def test_removes_duplicates(self, tmp_path) -> None:
        from nota.core.store import Store
        (tmp_path / ".nota").mkdir()
        note = write_note(tmp_path, "dup.md", """\
            ---
            tags: [alpha, alpha, beta]
            ---
            Content
        """)
        with Store(tmp_path) as s:
            s.index_note(note)
            paths = deduplicate_tags(s)
        assert note.path in paths
        note._post = None
        assert note.tags.count("alpha") == 1


class TestTagCoOccurrence:
    def test_returns_dict(self, store) -> None:
        result = tag_co_occurrence(store)
        assert isinstance(result, dict)
        for (a, b), count in result.items():
            assert isinstance(a, str)
            assert isinstance(b, str)
            assert count >= 1


class TestRenameNote:
    def test_renames_file(self, tmp_path) -> None:
        note = write_note(tmp_path, "old-title.md", "---\ntitle: Old Title\n---\n# Old")
        new_path = rename_note(note, "New Title")
        assert new_path.exists()
        assert not (tmp_path / "old-title.md").exists()
        assert new_path.stem == "new-title"

    def test_updates_frontmatter_title(self, tmp_path) -> None:
        note = write_note(tmp_path, "orig.md", "---\ntitle: Original\n---\nBody")
        new_path = rename_note(note, "Updated Title", update_links=False)
        new_note = Note(new_path, tmp_path)
        assert new_note.title == "Updated Title"

    def test_collision_raises(self, tmp_path) -> None:
        write_note(tmp_path, "target.md", "---\ntitle: Target\n---\nBody")
        note = write_note(tmp_path, "source.md", "---\ntitle: Source\n---\nBody")
        with pytest.raises(FileExistsError):
            rename_note(note, "Target", update_links=False)
