"""Tests for the Markdown renderer."""
from __future__ import annotations

import pytest

from nota.core.renderer import MarkdownRenderer, RenderConfig, render_note, render_preview


@pytest.fixture()
def renderer() -> MarkdownRenderer:
    return MarkdownRenderer()


# ---------------------------------------------------------------------------
# Headings

class TestHeadings:
    def test_h1(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("# Hello World")
        assert "<h1" in html
        assert "Hello World" in html

    def test_h3(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("### Section")
        assert "<h3" in html

    def test_heading_anchor(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("## My Section")
        assert 'id="my-section"' in html

    def test_heading_anchor_link(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("# Title")
        assert 'href="#title"' in html


# ---------------------------------------------------------------------------
# Inline formatting

class TestInlineFormatting:
    def test_bold_asterisks(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("**bold text**")
        assert "<strong>bold text</strong>" in html

    def test_italic_asterisk(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("*italic*")
        assert "<em>italic</em>" in html

    def test_inline_code(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("`code here`")
        assert "<code>code here</code>" in html

    def test_strikethrough(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("~~struck~~")
        assert "<del>struck</del>" in html

    def test_external_link(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("[Anthropic](https://anthropic.com)")
        assert 'href="https://anthropic.com"' in html
        assert 'target="_blank"' in html


# ---------------------------------------------------------------------------
# Wiki links

class TestWikiLinks:
    def test_basic_wiki_link(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("[[Alpha Note]]")
        assert 'class="wiki-link"' in html
        assert "alpha-note" in html

    def test_wiki_link_with_label(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("[[Alpha Note|My Label]]")
        assert "My Label" in html

    def test_wiki_link_custom_prefix(self) -> None:
        cfg = RenderConfig(link_prefix="/notes/")
        r = MarkdownRenderer(cfg)
        html = r.render("[[Beta]]")
        assert "/notes/beta" in html


# ---------------------------------------------------------------------------
# Hashtags

class TestHashtags:
    def test_hashtag_converted_to_link(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("tagged with #python today")
        assert 'class="tag-link"' in html
        assert "#python" in html

    def test_hashtag_prefix(self) -> None:
        cfg = RenderConfig(tag_prefix="/mytags/")
        r = MarkdownRenderer(cfg)
        html = r.render("see #rust")
        assert "/mytags/rust" in html


# ---------------------------------------------------------------------------
# Code blocks

class TestCodeBlocks:
    def test_fenced_code_block(self, renderer: MarkdownRenderer) -> None:
        md = "```python\nprint('hello')\n```"
        html = renderer.render(md)
        assert "<pre>" in html
        assert "print" in html

    def test_language_class(self, renderer: MarkdownRenderer) -> None:
        md = "```javascript\nconsole.log('hi');\n```"
        html = renderer.render(md)
        assert "language-javascript" in html

    def test_mermaid_block(self, renderer: MarkdownRenderer) -> None:
        md = "```mermaid\ngraph TD\n  A --> B\n```"
        html = renderer.render(md)
        assert "mermaid" in html


# ---------------------------------------------------------------------------
# Lists

class TestLists:
    def test_unordered_list(self, renderer: MarkdownRenderer) -> None:
        md = "- item one\n- item two\n- item three"
        html = renderer.render(md)
        assert "<ul>" in html
        assert "<li>" in html

    def test_ordered_list(self, renderer: MarkdownRenderer) -> None:
        md = "1. first\n2. second\n3. third"
        html = renderer.render(md)
        assert "<ol>" in html

    def test_task_list_unchecked(self, renderer: MarkdownRenderer) -> None:
        md = "- [ ] do something"
        html = renderer.render(md)
        assert 'type="checkbox"' in html
        assert "checked" not in html or 'checked=""' not in html

    def test_task_list_checked(self, renderer: MarkdownRenderer) -> None:
        md = "- [x] done already"
        html = renderer.render(md)
        assert 'checked=""' in html


# ---------------------------------------------------------------------------
# Tables

class TestTables:
    def test_basic_table(self, renderer: MarkdownRenderer) -> None:
        md = "| Col A | Col B |\n|-------|-------|\n| val1  | val2  |"
        html = renderer.render(md)
        assert "<table>" in html
        assert "<th" in html
        assert "val1" in html

    def test_table_alignment(self, renderer: MarkdownRenderer) -> None:
        md = "| Left | Center | Right |\n|:-----|:------:|------:|\n| a | b | c |"
        html = renderer.render(md)
        assert "text-align:center" in html
        assert "text-align:right" in html


# ---------------------------------------------------------------------------
# Blockquotes and callouts

class TestBlockquotes:
    def test_blockquote(self, renderer: MarkdownRenderer) -> None:
        md = "> This is a quote."
        html = renderer.render(md)
        assert "<blockquote>" in html

    def test_callout_note(self, renderer: MarkdownRenderer) -> None:
        md = "> [!NOTE] Important\nSome information."
        html = renderer.render(md)
        assert "callout" in html
        assert "callout-note" in html

    def test_callout_warning(self, renderer: MarkdownRenderer) -> None:
        md = "> [!WARNING] Watch out\nDanger ahead."
        html = renderer.render(md)
        assert "callout-warning" in html


# ---------------------------------------------------------------------------
# Footnotes

class TestFootnotes:
    def test_footnote_ref(self) -> None:
        cfg = RenderConfig()
        r = MarkdownRenderer(cfg)
        md = "See note[^1] here.\n\n[^1]: The footnote text."
        html = r.render(md)
        assert "fnref-1" in html or "fn-1" in html

    def test_footnote_definition_rendered(self) -> None:
        r = MarkdownRenderer()
        md = "Text[^a].\n\n[^a]: Explanation here."
        html = r.render(md)
        assert "Explanation here" in html


# ---------------------------------------------------------------------------
# Table of contents

class TestTOC:
    def test_toc_generated_with_marker(self) -> None:
        md = (
            "<!-- toc -->\n\n"
            "# H1\n\n## H2 A\n\n## H2 B\n\n### H3\n\n## H2 C\n"
        )
        cfg = RenderConfig(inject_toc=True, toc_min_headings=3)
        r = MarkdownRenderer(cfg)
        html = r.render(md)
        assert 'class="toc"' in html

    def test_toc_not_injected_for_short_notes(self) -> None:
        md = "# Title\n\n## Section\n\nJust two headings."
        cfg = RenderConfig(inject_toc=True, toc_min_headings=5)
        r = MarkdownRenderer(cfg)
        html = r.render(md)
        assert 'class="toc"' not in html


# ---------------------------------------------------------------------------
# Horizontal rules

class TestHR:
    def test_hr_rendered(self, renderer: MarkdownRenderer) -> None:
        html = renderer.render("---")
        assert "<hr" in html


# ---------------------------------------------------------------------------
# Safe mode

class TestSafeMode:
    def test_raw_html_stripped(self) -> None:
        cfg = RenderConfig(safe_mode=True)
        r = MarkdownRenderer(cfg)
        html = r.render("<script>alert(1)</script>")
        assert "<script>" not in html


# ---------------------------------------------------------------------------
# Convenience functions

class TestConvenienceFunctions:
    def test_render_note(self) -> None:
        html = render_note("# Hello\n\nWorld.")
        assert "<h1" in html

    def test_render_preview_strips_markdown(self) -> None:
        preview = render_preview("# Title\n\nThis is a **long** note about stuff.")
        assert "#" not in preview
        assert "**" not in preview
        assert "Title" in preview or "long" in preview

    def test_render_preview_truncates(self) -> None:
        long_text = "word " * 200
        preview = render_preview(long_text, max_chars=50)
        assert len(preview) <= 60  # some slack for ellipsis
