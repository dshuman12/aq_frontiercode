"""Tests for the note template system."""
from __future__ import annotations

from pathlib import Path

import pytest

from nota.core.templates import (
    TemplateManager,
    TemplateRenderer,
    VaultTemplateLoader,
    parse_extra_vars,
    _built_in_vars,
)


@pytest.fixture()
def vault_path(tmp_path: Path) -> Path:
    (tmp_path / ".nota" / "templates").mkdir(parents=True)
    return tmp_path


@pytest.fixture()
def mgr(vault_path: Path) -> TemplateManager:
    return TemplateManager(vault_path)


# ---------------------------------------------------------------------------
# Built-in variables

class TestBuiltInVars:
    def test_title_present(self, vault_path: Path) -> None:
        v = _built_in_vars("My Note", vault_path)
        assert v["title"] == "My Note"

    def test_date_format(self, vault_path: Path) -> None:
        v = _built_in_vars("T", vault_path)
        assert len(v["date"]) == 10  # YYYY-MM-DD
        assert "-" in v["date"]

    def test_id_slugified(self, vault_path: Path) -> None:
        v = _built_in_vars("Hello World", vault_path)
        assert v["id"] == "hello-world"

    def test_vault_name(self, tmp_path: Path) -> None:
        vp = tmp_path / "my-vault"
        vp.mkdir()
        v = _built_in_vars("T", vp)
        assert v["vault"] == "my-vault"


# ---------------------------------------------------------------------------
# TemplateRenderer

class TestTemplateRenderer:
    def test_renders_variable(self) -> None:
        r = TemplateRenderer(use_jinja=False)
        result = r.render("Hello {{ name }}!", {"name": "World"})
        assert result == "Hello World!"

    def test_missing_variable_left_as_is(self) -> None:
        r = TemplateRenderer(use_jinja=False)
        result = r.render("{{ missing }}", {})
        assert "{{ missing }}" in result

    def test_multiple_variables(self) -> None:
        r = TemplateRenderer(use_jinja=False)
        result = r.render("{{ a }} and {{ b }}", {"a": "alpha", "b": "beta"})
        assert "alpha and beta" == result


# ---------------------------------------------------------------------------
# VaultTemplateLoader

class TestVaultTemplateLoader:
    def test_resolves_md_file(self, vault_path: Path) -> None:
        tmpl_dir = vault_path / ".nota" / "templates"
        (tmpl_dir / "custom.md").write_text("# {{ title }}", encoding="utf-8")
        loader = VaultTemplateLoader([tmpl_dir])
        path = loader.resolve("custom")
        assert path is not None
        assert path.name == "custom.md"

    def test_returns_none_for_missing(self, vault_path: Path) -> None:
        tmpl_dir = vault_path / ".nota" / "templates"
        loader = VaultTemplateLoader([tmpl_dir])
        assert loader.resolve("nonexistent") is None

    def test_list_templates(self, vault_path: Path) -> None:
        tmpl_dir = vault_path / ".nota" / "templates"
        (tmpl_dir / "alpha.md").write_text("", encoding="utf-8")
        (tmpl_dir / "beta.md").write_text("", encoding="utf-8")
        loader = VaultTemplateLoader([tmpl_dir])
        templates = loader.list_templates()
        assert "alpha" in templates
        assert "beta" in templates

    def test_multiple_search_dirs(self, tmp_path: Path) -> None:
        d1 = tmp_path / "dir1"
        d2 = tmp_path / "dir2"
        d1.mkdir(); d2.mkdir()
        (d2 / "remote.md").write_text("# Remote", encoding="utf-8")
        loader = VaultTemplateLoader([d1, d2])
        path = loader.resolve("remote")
        assert path is not None


# ---------------------------------------------------------------------------
# TemplateManager

class TestTemplateManager:
    def test_list_templates_includes_builtins(self, mgr: TemplateManager) -> None:
        templates = mgr.list_templates()
        assert "default" in templates
        assert "daily" in templates
        assert "meeting" in templates

    def test_render_default(self, mgr: TemplateManager) -> None:
        result = mgr.render("default", "My Title")
        assert "My Title" in result

    def test_render_daily(self, mgr: TemplateManager) -> None:
        result = mgr.render("daily", "2025-06-01")
        assert "daily" in result
        assert "Tasks" in result

    def test_render_meeting(self, mgr: TemplateManager) -> None:
        result = mgr.render("meeting", "Team Sync")
        assert "Team Sync" in result
        assert "Agenda" in result

    def test_render_with_extra_vars(self, mgr: TemplateManager) -> None:
        custom = "---\ntitle: {{ title }}\ncustom: {{ custom_var }}\n---\n"
        tmpl_dir = mgr.vault_path / ".nota" / "templates"
        (tmpl_dir / "custom.md").write_text(custom, encoding="utf-8")
        result = mgr.render("custom", "T", extra_vars={"custom_var": "hello"})
        assert "hello" in result

    def test_unknown_template_raises(self, mgr: TemplateManager) -> None:
        with pytest.raises(KeyError):
            mgr.render("no-such-template-xyz", "Title")

    def test_save_builtin(self, mgr: TemplateManager) -> None:
        path = mgr.save_builtin("daily")
        assert path.exists()
        assert "daily" in path.read_text()

    def test_save_all_builtins(self, mgr: TemplateManager) -> None:
        paths = mgr.save_all_builtins()
        assert len(paths) >= 4
        assert all(p.exists() for p in paths)

    def test_user_template_overrides_builtin(self, vault_path: Path) -> None:
        tmpl_dir = vault_path / ".nota" / "templates"
        (tmpl_dir / "daily.md").write_text("# Custom Daily\n{{ title }}\n", encoding="utf-8")
        mgr = TemplateManager(vault_path)
        result = mgr.render("daily", "Override Test")
        assert "Custom Daily" in result

    def test_repr(self, mgr: TemplateManager) -> None:
        r = repr(mgr)
        assert "TemplateManager" in r


# ---------------------------------------------------------------------------
# parse_extra_vars

class TestParseExtraVars:
    def test_single_pair(self) -> None:
        result = parse_extra_vars(["key=value"])
        assert result == {"key": "value"}

    def test_multiple_pairs(self) -> None:
        result = parse_extra_vars(["a=1", "b=2", "c=hello world"])
        assert result["a"] == "1"
        assert result["c"] == "hello world"

    def test_value_with_equals(self) -> None:
        result = parse_extra_vars(["url=http://example.com?a=1"])
        assert "http://example.com?a=1" in result["url"]

    def test_invalid_raises(self) -> None:
        with pytest.raises(ValueError):
            parse_extra_vars(["no-equals-sign"])
