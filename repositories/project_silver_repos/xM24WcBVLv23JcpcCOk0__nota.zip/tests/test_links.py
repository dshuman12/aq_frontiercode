"""Tests for link extraction and graph building."""
from __future__ import annotations

import textwrap
from pathlib import Path

from nota.core.note import Note
from nota.core.links import extract_links, link_graph, orphans


def make_note(root: Path, name: str, body: str) -> Note:
    p = root / name
    p.write_text(textwrap.dedent(body), encoding="utf-8")
    return Note(p, root)


class TestExtractLinks:
    def test_basic(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "a.md", "See [[Target]].")
        edges = extract_links(n)
        assert len(edges) == 1
        assert edges[0].target == "Target"
        assert not edges[0].resolved

    def test_alias(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "a.md", "[[Target|click here]]")
        edges = extract_links(n)
        assert edges[0].alias == "click here"

    def test_heading(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "a.md", "[[Target#Section]]")
        edges = extract_links(n)
        assert edges[0].heading == "Section"
        assert edges[0].target == "Target"

    def test_multiple(self, tmp_path: Path) -> None:
        n = make_note(tmp_path, "a.md", "[[A]] and [[B]]")
        assert len(extract_links(n)) == 2


class TestLinkGraph:
    def test_graph_structure(self, store, vault: Path) -> None:
        adj = link_graph(store)
        assert isinstance(adj, dict)
        for _src, targets in adj.items():
            assert isinstance(targets, list)

    def test_alpha_links_to_beta(self, store, vault: Path) -> None:
        adj = link_graph(store)
        alpha_id = "alpha.md"
        assert any("beta" in t for t in adj.get(alpha_id, []))


class TestOrphans:
    def test_returns_list(self, store, vault: Path) -> None:
        result = orphans(store)
        assert isinstance(result, list)
