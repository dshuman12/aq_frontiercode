"""Tests for calendar / activity heatmap."""
from __future__ import annotations

from datetime import date, timedelta

import pytest

from nota.core.calendar import (
    activity_by_day,
    heatmap,
    monthly_summary,
    streak,
    most_active_hours,
    most_active_weekdays,
)


class TestActivityByDay:
    def test_returns_dict(self, store) -> None:
        result = activity_by_day(store)
        assert isinstance(result, dict)
        for key in result:
            assert isinstance(key, date)

    def test_all_values_positive(self, store) -> None:
        result = activity_by_day(store)
        for count in result.values():
            assert count >= 1

    def test_date_range_filter(self, store) -> None:
        yesterday = date.today() - timedelta(days=1)
        future    = date.today() + timedelta(days=1)
        result = activity_by_day(store, start=yesterday, end=future)
        for d in result:
            assert yesterday <= d <= future


class TestStreak:
    def test_no_activity(self) -> None:
        current, longest = streak({})
        assert current == 0
        assert longest == 0

    def test_consecutive_days(self) -> None:
        today = date.today()
        activity = {today - timedelta(days=i): 1 for i in range(5)}
        current, longest = streak(activity)
        assert current == 5
        assert longest >= 5

    def test_broken_streak(self) -> None:
        today = date.today()
        activity = {
            today: 1,
            # gap: yesterday missing
            today - timedelta(days=2): 1,
            today - timedelta(days=3): 1,
        }
        current, longest = streak(activity)
        assert current == 1
        assert longest == 2


class TestHeatmap:
    def test_returns_string(self, store) -> None:
        activity = activity_by_day(store)
        result = heatmap(activity, year=2025)
        assert isinstance(result, str)

    def test_contains_month_labels(self, store) -> None:
        activity = activity_by_day(store)
        result = heatmap(activity, year=2025)
        assert "Jan" in result or "Feb" in result

    def test_contains_day_labels(self, store) -> None:
        activity = activity_by_day(store)
        result = heatmap(activity, year=2025)
        assert "Mo" in result

    def test_empty_activity(self) -> None:
        result = heatmap({}, year=2025)
        assert isinstance(result, str)
        assert len(result) > 0


class TestMonthlySummary:
    def test_returns_string(self, store) -> None:
        activity = activity_by_day(store)
        result = monthly_summary(activity, year=2025)
        assert isinstance(result, str)

    def test_contains_streak_info(self, store) -> None:
        activity = activity_by_day(store)
        result = monthly_summary(activity)
        assert "streak" in result.lower()

    def test_twelve_months_present(self, store) -> None:
        import calendar
        activity = activity_by_day(store)
        result = monthly_summary(activity, year=2025)
        for name in calendar.month_name[1:]:
            assert name in result


class TestMostActive:
    def test_hours_returns_dict(self, store) -> None:
        result = most_active_hours(store)
        assert isinstance(result, dict)
        for hour in result:
            assert 0 <= hour <= 23

    def test_weekdays_returns_dict(self, store) -> None:
        result = most_active_weekdays(store)
        assert isinstance(result, dict)
        for name in result:
            assert name in ["Monday", "Tuesday", "Wednesday", "Thursday",
                            "Friday", "Saturday", "Sunday"]
