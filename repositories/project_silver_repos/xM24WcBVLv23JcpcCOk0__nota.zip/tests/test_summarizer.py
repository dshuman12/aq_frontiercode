"""Tests for the summariser module."""
from __future__ import annotations

import textwrap
from pathlib import Path
from unittest.mock import patch

import pytest

from nota.core.note import Note
from nota.core.summarizer import (
    extractive_summary,
    ollama_is_running,
    suggest_title,
    _score_sentences,
)


def make_note(root: Path, name: str, body: str) -> Note:
    p = root / name
    p.write_text(textwrap.dedent(body), encoding="utf-8")
    return Note(p, root)


class TestExtractorSummary:
    def test_returns_string(self, tmp_path) -> None:
        note = make_note(tmp_path, "t.md", """\
            # Topic
            The quick brown fox jumps over the lazy dog.
            Machine learning is a subset of artificial intelligence.
            Neural networks are inspired by the human brain.
            Deep learning uses multiple layers of neurons.
            Transformers changed NLP in 2017 with attention mechanisms.
        """)
        result = extractive_summary(note, sentences=2)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_sentence_count(self, tmp_path) -> None:
        note = make_note(tmp_path, "t.md", """\
            # Topic
            First sentence with good content here.
            Second sentence adds more relevant information.
            Third sentence completes the picture perfectly.
            Fourth sentence is also quite informative to read.
        """)
        result = extractive_summary(note, sentences=2)
        # rough check: 2 sentences means roughly 2 periods
        assert result.count(".") >= 1

    def test_empty_note(self, tmp_path) -> None:
        note = make_note(tmp_path, "t.md", "# Empty\n")
        result = extractive_summary(note, sentences=3)
        assert isinstance(result, str)

    def test_short_note_no_crash(self, tmp_path) -> None:
        note = make_note(tmp_path, "t.md", "Short.")
        result = extractive_summary(note)
        assert isinstance(result, str)


class TestScoreSentences:
    def test_returns_list(self) -> None:
        scored = _score_sentences("Hello world. This is a test sentence. Another one here.")
        assert isinstance(scored, list)

    def test_scores_are_non_negative(self) -> None:
        scored = _score_sentences("A good sentence. Another good sentence.")
        for score, _, _ in scored:
            assert score >= 0.0

    def test_index_order(self) -> None:
        scored = _score_sentences("First. Second. Third.")
        indices = [i for _, i, _ in scored]
        # indices should be 0, 1, 2 in some order
        assert set(indices) == {0, 1, 2} or len(indices) <= 3

    def test_too_short_sentences_skipped(self) -> None:
        scored = _score_sentences("Hi. Hello. A longer sentence here to include.")
        # very short sentences should be filtered
        texts = [s for _, _, s in scored]
        assert not any(len(s.split()) <= 4 and s in ("Hi.", "Hello.") for s in texts)


class TestOllamaCheck:
    def test_returns_bool(self) -> None:
        result = ollama_is_running()
        assert isinstance(result, bool)

    def test_false_when_not_running(self) -> None:
        with patch("urllib.request.urlopen", side_effect=Exception("refused")):
            assert not ollama_is_running()


class TestSuggestTitle:
    def test_falls_back_to_first_line(self, tmp_path) -> None:
        note = make_note(tmp_path, "t.md", """\
            This is actually the real topic of this note.
            More context follows here.
        """)
        with patch("nota.core.summarizer.ollama_is_running", return_value=False):
            title = suggest_title(note)
        assert isinstance(title, str)
        assert len(title) > 0

    def test_respects_max_length(self, tmp_path) -> None:
        note = make_note(tmp_path, "t.md", "A " * 50 + "\nBody text.")
        with patch("nota.core.summarizer.ollama_is_running", return_value=False):
            title = suggest_title(note)
        assert len(title) <= 60
