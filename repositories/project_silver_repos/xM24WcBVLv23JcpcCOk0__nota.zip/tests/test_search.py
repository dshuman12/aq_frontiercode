"""Tests for fuzzy and ranked search."""
from __future__ import annotations

from nota.core.search import fuzzy_search, ranked_search


class TestFuzzySearch:
    def test_finds_close_match(self, store) -> None:
        results = fuzzy_search(store, "Alpha", limit=5)
        titles = [n.title for n, _ in results]
        assert any("Alpha" in t for t in titles)

    def test_score_in_range(self, store) -> None:
        results = fuzzy_search(store, "Beta Note", limit=5)
        for _n, score in results:
            assert 0.0 <= score <= 100.0

    def test_empty_vault_returns_nothing(self, tmp_path) -> None:
        from nota.core.store import Store
        (tmp_path / ".nota").mkdir()
        s = Store(tmp_path)
        assert fuzzy_search(s, "anything") == []


class TestRankedSearch:
    def test_returns_notes(self, store) -> None:
        results = ranked_search(store, "alpha")
        assert len(results) >= 1

    def test_no_duplicates(self, store) -> None:
        results = ranked_search(store, "note", limit=20)
        ids = [n.id for n in results]
        assert len(ids) == len(set(ids))
