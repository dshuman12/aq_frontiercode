"""Tests for vault metrics and analytics."""
from __future__ import annotations

import textwrap
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from nota.core.store import Store
from nota.core.metrics import (
    compute_metrics,
    activity_trend,
    score_notes,
    top_notes,
    tag_cooccurrence,
    link_density,
    vocabulary_size,
    freshness_score,
    NoteScore,
    TrendBucket,
    TagCooccurrence,
    VaultMetrics,
)


def make_note(root: Path, name: str, body: str) -> None:
    (root / name).write_text(textwrap.dedent(body), encoding="utf-8")


@pytest.fixture()
def vault(tmp_path: Path) -> Path:
    (tmp_path / ".nota").mkdir()
    make_note(tmp_path, "python-guide.md", """\
        ---
        title: Python Guide
        tags: [python, tutorial]
        ---
        # Python Guide
        asyncio is the foundation. Coroutines and tasks.
        The event loop drives everything in async Python.
        """)
    make_note(tmp_path, "rust-memory.md", """\
        ---
        title: Rust Memory
        tags: [rust, systems]
        ---
        # Rust Memory
        Ownership and borrowing. Stack vs heap. No GC.
        [[Python Guide]] discusses async patterns too.
        """)
    make_note(tmp_path, "untagged.md", """\
        ---
        title: Untagged Note
        tags: []
        ---
        # Untagged Note
        No tags here, standing alone.
        """)
    make_note(tmp_path, "python-async.md", """\
        ---
        title: Python Async
        tags: [python, async]
        ---
        # Python Async
        Building on the [[Python Guide]]. Deep dive into asyncio.
        """)
    return tmp_path


@pytest.fixture()
def store(vault: Path) -> Store:
    s = Store(vault)
    s.index_all(force=True)
    return s


@pytest.fixture()
def notes(store: Store):
    return list(store.notes())


# ---------------------------------------------------------------------------
# VaultMetrics

class TestComputeMetrics:
    def test_returns_metrics_object(self, store: Store) -> None:
        m = compute_metrics(store)
        assert isinstance(m, VaultMetrics)

    def test_note_count(self, store: Store) -> None:
        m = compute_metrics(store)
        assert m.note_count == 4

    def test_tag_count_positive(self, store: Store) -> None:
        m = compute_metrics(store)
        assert m.tag_count >= 4

    def test_notes_without_tags(self, store: Store) -> None:
        m = compute_metrics(store)
        assert m.notes_without_tags >= 1

    def test_top_tags_present(self, store: Store) -> None:
        m = compute_metrics(store)
        tag_names = [t for t, _ in m.top_tags]
        assert "python" in tag_names

    def test_to_dict_keys(self, store: Store) -> None:
        d = compute_metrics(store).to_dict()
        assert "note_count" in d
        assert "tag_count" in d
        assert "generated_at" in d

    def test_link_count_detected(self, store: Store) -> None:
        m = compute_metrics(store)
        assert m.link_count >= 1  # rust-memory and python-async link to python-guide

    def test_stale_notes_empty_for_fresh(self, store: Store) -> None:
        m = compute_metrics(store, stale_days=365 * 10)
        assert m.stale_notes == []

    def test_empty_store(self, tmp_path: Path) -> None:
        (tmp_path / ".nota").mkdir()
        s = Store(tmp_path)
        m = compute_metrics(s)
        assert m.note_count == 0


# ---------------------------------------------------------------------------
# Activity trend

class TestActivityTrend:
    def test_returns_list(self, notes: list) -> None:
        buckets = activity_trend(notes, period="month", n_periods=6)
        assert isinstance(buckets, list)
        assert len(buckets) == 6

    def test_bucket_has_label(self, notes: list) -> None:
        buckets = activity_trend(notes, period="month")
        for b in buckets:
            assert isinstance(b.label, str)
            assert len(b.label) > 0

    def test_week_period(self, notes: list) -> None:
        buckets = activity_trend(notes, period="week", n_periods=4)
        assert len(buckets) == 4
        for b in buckets:
            assert "W" in b.label

    def test_day_period(self, notes: list) -> None:
        buckets = activity_trend(notes, period="day", n_periods=7)
        assert len(buckets) == 7

    def test_total_modified_positive(self, notes: list) -> None:
        buckets = activity_trend(notes, period="month", n_periods=12)
        total_modified = sum(b.modified for b in buckets)
        assert total_modified >= 0  # could be 0 if all notes are in same bucket


# ---------------------------------------------------------------------------
# Note scoring

class TestScoreNotes:
    def test_returns_list(self, notes: list) -> None:
        scores = score_notes(notes)
        assert isinstance(scores, list)
        assert len(scores) == len(notes)

    def test_all_scores_are_note_scores(self, notes: list) -> None:
        scores = score_notes(notes)
        assert all(isinstance(s, NoteScore) for s in scores)

    def test_sorted_descending(self, notes: list) -> None:
        scores = score_notes(notes)
        totals = [s.total for s in scores]
        assert totals == sorted(totals, reverse=True)

    def test_ranks_assigned(self, notes: list) -> None:
        scores = score_notes(notes)
        ranks = [s.rank for s in scores]
        assert ranks == list(range(1, len(scores) + 1))

    def test_backlinks_boost_score(self, notes: list) -> None:
        backlinks = {"python-guide": 10, "rust-memory": 0}
        scores = score_notes(notes, backlink_counts=backlinks)
        python_score = next((s for s in scores if s.note_id == "python-guide"), None)
        rust_score   = next((s for s in scores if s.note_id == "rust-memory"),   None)
        if python_score and rust_score:
            assert python_score.link_score > rust_score.link_score

    def test_to_dict(self, notes: list) -> None:
        scores = score_notes(notes)
        d = scores[0].to_dict()
        assert "total" in d
        assert "rank" in d


# ---------------------------------------------------------------------------
# Top notes

class TestTopNotes:
    def test_returns_at_most_n(self, notes: list) -> None:
        top = top_notes(notes, n=2)
        assert len(top) <= 2

    def test_empty_notes(self) -> None:
        assert top_notes([], n=5) == []


# ---------------------------------------------------------------------------
# Tag co-occurrence

class TestTagCooccurrence:
    def test_finds_python_pairs(self, notes: list) -> None:
        cooc = tag_cooccurrence(notes, min_count=1)
        assert isinstance(cooc, list)
        # python+tutorial and python+async should appear
        pairs = {(c.tag_a, c.tag_b) for c in cooc}
        assert any("python" in a or "python" in b for a, b in pairs)

    def test_min_count_filter(self, notes: list) -> None:
        cooc = tag_cooccurrence(notes, min_count=999)
        assert cooc == []

    def test_empty_notes(self) -> None:
        assert tag_cooccurrence([]) == []

    def test_str_representation(self, notes: list) -> None:
        cooc = tag_cooccurrence(notes, min_count=1)
        if cooc:
            s = str(cooc[0])
            assert "+" in s


# ---------------------------------------------------------------------------
# Link density

class TestLinkDensity:
    def test_returns_dict(self, notes: list) -> None:
        result = link_density(notes)
        assert isinstance(result, dict)
        assert "histogram" in result
        assert "avg" in result

    def test_notes_with_links_count(self, notes: list) -> None:
        result = link_density(notes)
        # python-async and rust-memory have links
        assert result["notes_with_links"] >= 0

    def test_empty_notes(self) -> None:
        result = link_density([])
        assert result["avg"] == 0.0


# ---------------------------------------------------------------------------
# Vocabulary size

class TestVocabularySize:
    def test_returns_int(self, notes: list) -> None:
        size = vocabulary_size(notes)
        assert isinstance(size, int)
        assert size >= 0

    def test_empty_notes(self) -> None:
        assert vocabulary_size([]) == 0


# ---------------------------------------------------------------------------
# Freshness score

class TestFreshnessScore:
    def test_very_recent_note_score_near_one(self, notes: list) -> None:
        note = notes[0]
        note.modified = datetime.now()
        score = freshness_score(note)
        assert score > 0.9

    def test_old_note_score_near_zero(self, notes: list) -> None:
        note = notes[0]
        note.modified = datetime.now() - timedelta(days=365)
        score = freshness_score(note)
        assert score < 0.1

    def test_none_modified_returns_zero(self, notes: list) -> None:
        note = notes[0]
        note.modified = None
        score = freshness_score(note)
        assert score == 0.0

    def test_custom_half_life(self, notes: list) -> None:
        note = notes[0]
        note.modified = datetime.now() - timedelta(days=7)
        score7  = freshness_score(note, half_life_days=7)
        score30 = freshness_score(note, half_life_days=30)
        assert score7 < score30
