"""Tests for the Store / index layer."""
from __future__ import annotations

from pathlib import Path

import pytest

from nota.core.store import Store
from nota.core.note import Note


class TestStoreIndex:
    def test_index_all_finds_notes(self, store: Store, vault: Path) -> None:
        notes = list(store.notes())
        assert len(notes) == 3

    def test_get_by_stem(self, store: Store) -> None:
        n = store.get("alpha")
        assert n is not None
        assert n.stem == "alpha"

    def test_get_by_title(self, store: Store) -> None:
        n = store.get("Alpha Note")
        assert n is not None

    def test_get_missing_returns_none(self, store: Store) -> None:
        assert store.get("does-not-exist") is None

    def test_index_note_updates_on_change(self, store: Store, vault: Path) -> None:
        p = vault / "alpha.md"
        original = p.read_text(encoding="utf-8")
        p.write_text(original + "\nExtra content.", encoding="utf-8")
        note = Note(p, vault)
        store.index_note(note)
        store.conn.commit()
        updated = store.get("alpha")
        assert updated is not None
        assert "Extra content" in updated.content


class TestStoreSearch:
    def test_basic_search(self, store: Store) -> None:
        results = store.search("alpha")
        ids = [n.id for n in results]
        assert any("alpha" in i for i in ids)

    def test_search_no_results(self, store: Store) -> None:
        results = store.search("xyzzy_nonexistent_term")
        assert results == []


class TestStoreBacklinks:
    def test_backlinks_to_beta(self, store: Store) -> None:
        beta = store.get("beta")
        assert beta is not None
        bls = store.backlinks(beta)
        stems = [n.stem for n in bls]
        assert "alpha" in stems

    def test_no_backlinks_for_orphan(self, store: Store) -> None:
        gamma = store.get("gamma")
        assert gamma is not None
        bls = store.backlinks(gamma)
        stems = [n.stem for n in bls]
        assert "beta" in stems


class TestStoreTags:
    def test_all_tags_returns_counts(self, store: Store) -> None:
        tag_counts = store.all_tags()
        assert "research" in tag_counts or "ai" in tag_counts

    def test_by_tag_filters(self, store: Store) -> None:
        results = store.by_tag("project")
        assert any(n.stem == "beta" for n in results)


class TestStoreStats:
    def test_stats_keys(self, store: Store) -> None:
        s = store.stats()
        assert "notes" in s
        assert "words" in s
        assert "links" in s
        assert "tags" in s

    def test_note_count(self, store: Store) -> None:
        assert store.stats()["notes"] == 3
