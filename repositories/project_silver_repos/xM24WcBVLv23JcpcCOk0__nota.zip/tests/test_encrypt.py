"""Tests for the AES-256-GCM encryption utilities."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from nota.utils.encrypt import (
    encrypt_file,
    decrypt_file,
    encrypt_bytes,
    decrypt_bytes,
    is_encrypted,
    MAGIC_HEADER,
)


@pytest.fixture()
def plaintext() -> bytes:
    return b"This is sensitive vault content.\nSecond line.\n"


@pytest.fixture()
def password() -> str:
    return "hunter2"


@pytest.fixture()
def encrypted_bytes(plaintext: bytes, password: str) -> bytes:
    return encrypt_bytes(plaintext, password)


# ---------------------------------------------------------------------------
# Round-trip bytes

class TestBytesRoundtrip:
    def test_encrypt_decrypt(self, plaintext: bytes, password: str) -> None:
        ct = encrypt_bytes(plaintext, password)
        pt = decrypt_bytes(ct, password)
        assert pt == plaintext

    def test_encrypted_differs_from_plaintext(self, plaintext: bytes, password: str) -> None:
        ct = encrypt_bytes(plaintext, password)
        assert ct != plaintext

    def test_magic_header_present(self, encrypted_bytes: bytes) -> None:
        assert encrypted_bytes.startswith(MAGIC_HEADER)

    def test_is_encrypted_true(self, encrypted_bytes: bytes) -> None:
        assert is_encrypted(encrypted_bytes)

    def test_is_encrypted_false_for_plain(self, plaintext: bytes) -> None:
        assert not is_encrypted(plaintext)

    def test_wrong_password_raises(self, plaintext: bytes, password: str) -> None:
        ct = encrypt_bytes(plaintext, password)
        with pytest.raises(Exception):
            decrypt_bytes(ct, "wrong-password")

    def test_different_ciphertexts_each_call(self, plaintext: bytes, password: str) -> None:
        ct1 = encrypt_bytes(plaintext, password)
        ct2 = encrypt_bytes(plaintext, password)
        assert ct1 != ct2  # different nonces → different ciphertexts

    def test_empty_plaintext(self, password: str) -> None:
        ct = encrypt_bytes(b"", password)
        pt = decrypt_bytes(ct, password)
        assert pt == b""

    def test_large_payload(self, password: str) -> None:
        big = os.urandom(64 * 1024)
        ct = encrypt_bytes(big, password)
        pt = decrypt_bytes(ct, password)
        assert pt == big


# ---------------------------------------------------------------------------
# File encryption

class TestFileEncryption:
    def test_encrypt_file_creates_output(self, tmp_path: Path, password: str) -> None:
        src = tmp_path / "note.md"
        src.write_bytes(b"# Secret\nContent here.")
        out = tmp_path / "note.md.enc"
        encrypt_file(src, out, password)
        assert out.exists()

    def test_encrypt_file_is_encrypted(self, tmp_path: Path, password: str) -> None:
        src = tmp_path / "note.md"
        src.write_bytes(b"Secret content.")
        out = tmp_path / "note.md.enc"
        encrypt_file(src, out, password)
        assert is_encrypted(out.read_bytes())

    def test_decrypt_file_restores_content(self, tmp_path: Path, password: str) -> None:
        original = b"# My private note\nVery secret content here.\n"
        src = tmp_path / "note.md"
        src.write_bytes(original)
        enc = tmp_path / "note.md.enc"
        dec = tmp_path / "note.md.dec"
        encrypt_file(src, enc, password)
        decrypt_file(enc, dec, password)
        assert dec.read_bytes() == original

    def test_encrypt_file_in_place(self, tmp_path: Path, password: str) -> None:
        src = tmp_path / "note.md"
        original = b"Private note content."
        src.write_bytes(original)
        encrypt_file(src, src, password)  # overwrite in-place
        assert is_encrypted(src.read_bytes())

    def test_decrypt_wrong_password_raises(self, tmp_path: Path, password: str) -> None:
        src = tmp_path / "note.md"
        src.write_bytes(b"Secret.")
        enc = tmp_path / "note.md.enc"
        dec = tmp_path / "note.md.dec"
        encrypt_file(src, enc, password)
        with pytest.raises(Exception):
            decrypt_file(enc, dec, "badpass")

    def test_decrypt_non_encrypted_file_raises(self, tmp_path: Path, password: str) -> None:
        plain = tmp_path / "plain.md"
        plain.write_bytes(b"Not encrypted.")
        out = tmp_path / "out.md"
        with pytest.raises(Exception):
            decrypt_file(plain, out, password)
