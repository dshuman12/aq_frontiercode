"""Tests for HTML, JSON, and Markdown export."""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from nota.core.note import Note
from nota.core.store import Store
from nota.export.html import export_html, export_vault_html
from nota.export.json_export import export_json
from nota.export.markdown import (
    make_toc,
    inject_toc,
    rewrite_wiki_links,
    rewrite_links_for_html,
    export_consolidated,
    extract_section,
    split_by_headings,
)


# ---------------------------------------------------------------------------
# HTML export

class TestExportHTML:
    def test_creates_file(self, vault, store) -> None:
        note = store.get("alpha")
        assert note is not None
        out = export_html(note, vault / ".nota" / "export")
        assert out.exists()
        assert out.suffix == ".html"

    def test_contains_title(self, vault, store) -> None:
        note = store.get("alpha")
        assert note is not None
        out = export_html(note)
        content = out.read_text(encoding="utf-8")
        assert note.title in content

    def test_contains_tags(self, vault, store) -> None:
        note = store.get("alpha")
        assert note is not None
        out = export_html(note)
        content = out.read_text(encoding="utf-8")
        for tag in note.tags[:2]:
            assert tag in content

    def test_creates_output_dir(self, tmp_path) -> None:
        root = tmp_path / "vault"
        root.mkdir()
        p = root / "note.md"
        p.write_text("---\ntitle: Test\n---\n# Test\nHello", encoding="utf-8")
        note = Note(p, root)
        out_dir = tmp_path / "nonexistent" / "subdir"
        out = export_html(note, out_dir)
        assert out.exists()

    def test_html_structure(self, vault, store) -> None:
        note = store.get("gamma")
        assert note is not None
        out = export_html(note)
        html = out.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in html
        assert "<body>" in html
        assert "</html>" in html


class TestExportVaultHTML:
    def test_exports_all_notes(self, vault, store) -> None:
        outputs = export_vault_html(vault)
        assert len(outputs) == store.note_count()

    def test_all_files_exist(self, vault) -> None:
        outputs = export_vault_html(vault)
        for p in outputs:
            assert p.exists()


# ---------------------------------------------------------------------------
# JSON export

class TestExportJSON:
    def test_returns_dict(self, vault, store) -> None:
        data = export_json(store)
        assert isinstance(data, dict)

    def test_has_required_keys(self, vault, store) -> None:
        data = export_json(store)
        for key in ("version", "vault", "notes", "graph", "stats"):
            assert key in data

    def test_notes_list(self, vault, store) -> None:
        data = export_json(store)
        assert isinstance(data["notes"], list)
        assert len(data["notes"]) == store.note_count()

    def test_writes_file(self, vault, store, tmp_path) -> None:
        out = tmp_path / "export.json"
        export_json(store, out)
        assert out.exists()
        loaded = json.loads(out.read_text())
        assert "notes" in loaded


# ---------------------------------------------------------------------------
# Markdown export

class TestMakeTOC:
    def test_basic(self) -> None:
        content = "# H1\n## H2\n### H3"
        toc = make_toc(content)
        assert "H2" in toc
        assert "H3" in toc

    def test_min_level_filter(self) -> None:
        content = "# Ignored\n## Included"
        toc = make_toc(content, min_level=2)
        assert "Ignored" not in toc
        assert "Included" in toc

    def test_max_level_filter(self) -> None:
        content = "## H2\n#### H4"
        toc = make_toc(content, max_level=3)
        assert "H4" not in toc

    def test_duplicate_headings(self) -> None:
        content = "## Same\n## Same"
        toc = make_toc(content)
        assert "same-1" in toc or "same" in toc

    def test_empty_content(self) -> None:
        assert make_toc("No headings here.") == ""


class TestInjectTOC:
    def test_injects_at_placeholder(self) -> None:
        note_content = "# Title\n<!-- toc -->\n## Section A\n## Section B"
        # wrap in a Note-like object
        from unittest.mock import MagicMock
        note = MagicMock()
        note.content = note_content
        result = inject_toc(note)
        assert "Section A" in result
        assert "<!-- toc -->" not in result

    def test_injects_after_h1_when_no_placeholder(self) -> None:
        from unittest.mock import MagicMock
        note = MagicMock()
        note.content = "# Title\n## A\n## B"
        result = inject_toc(note)
        assert "A" in result


class TestRewriteLinks:
    def test_wiki_to_md(self) -> None:
        content = "See [[Other Note]] for more."
        result = rewrite_wiki_links(content)
        assert "[[Other Note]]" not in result
        assert "[Other Note](other-note.md)" in result

    def test_alias_preserved(self) -> None:
        content = "See [[Other Note|click here]]."
        result = rewrite_wiki_links(content)
        assert "[click here]" in result

    def test_html_extension(self) -> None:
        content = "[[Target]]"
        result = rewrite_links_for_html(content)
        assert "target.html" in result

    def test_no_wiki_links(self) -> None:
        content = "Plain text without links."
        assert rewrite_wiki_links(content) == content


class TestExportConsolidated:
    def test_returns_string(self, vault, store) -> None:
        result = export_consolidated(store)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_contains_all_titles(self, vault, store) -> None:
        result = export_consolidated(store)
        for note in store.notes():
            assert note.title in result

    def test_writes_file(self, vault, store, tmp_path) -> None:
        out = tmp_path / "all-notes.md"
        export_consolidated(store, out)
        assert out.exists()

    def test_toc_present(self, vault, store) -> None:
        result = export_consolidated(store, include_toc=True)
        assert "Table of Contents" in result


class TestExtractSection:
    def test_extracts_body(self) -> None:
        content = "## Intro\nSome text.\n## Next\nOther."
        body = extract_section(content, "Intro")
        assert "Some text" in body
        assert "Other" not in body

    def test_missing_heading(self) -> None:
        assert extract_section("## Only\nText", "Missing") is None

    def test_case_insensitive(self) -> None:
        content = "## INTRO\nText here."
        assert extract_section(content, "intro") is not None


class TestSplitByHeadings:
    def test_splits_correctly(self) -> None:
        content = "## A\nText A.\n## B\nText B."
        sections = split_by_headings(content)
        assert len(sections) == 2
        assert sections[0][0] == "A"
        assert "Text A" in sections[0][1]

    def test_empty_content(self) -> None:
        assert split_by_headings("No headings") == []
