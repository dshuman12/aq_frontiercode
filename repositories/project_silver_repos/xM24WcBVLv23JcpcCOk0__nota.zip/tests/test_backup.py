"""Tests for the backup/restore utilities."""
from __future__ import annotations

import json
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from nota.utils.backup import (
    create_backup,
    list_backups,
    verify_backup,
    restore_backup,
    prune_backups,
    BackupManifest,
    BackupRotator,
    MANIFEST_NAME,
    ARCHIVE_PREFIX,
)


@pytest.fixture()
def vault_path(tmp_path: Path) -> Path:
    vault = tmp_path / "my_vault"
    vault.mkdir()
    (vault / ".nota").mkdir()
    (vault / "note1.md").write_text("# Note 1\nContent.", encoding="utf-8")
    (vault / "note2.md").write_text("# Note 2\nMore content.", encoding="utf-8")
    sub = vault / "sub"
    sub.mkdir()
    (sub / "note3.md").write_text("# Note 3\nNested.", encoding="utf-8")
    return vault


@pytest.fixture()
def backup_dir(tmp_path: Path) -> Path:
    d = tmp_path / "backups"
    d.mkdir()
    return d


# ---------------------------------------------------------------------------
# BackupManifest

class TestBackupManifest:
    def test_to_json_roundtrip(self) -> None:
        m = BackupManifest(
            created_at="2025-06-01T10:00:00",
            vault_name="test",
            note_count=5,
            file_count=7,
            total_bytes=1234,
        )
        j = m.to_json()
        m2 = BackupManifest.from_json(j)
        assert m2.vault_name == "test"
        assert m2.note_count == 5

    def test_summary_contains_vault_name(self) -> None:
        m = BackupManifest(
            created_at="2025-01-01T00:00:00",
            vault_name="my-vault",
            note_count=3,
            file_count=3,
            total_bytes=500,
            checksum="abc123",
        )
        s = m.summary()
        assert "my-vault" in s
        assert "3" in s


# ---------------------------------------------------------------------------
# create_backup

class TestCreateBackup:
    def test_creates_zip(self, vault_path: Path, backup_dir: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        assert path.exists()
        assert path.suffix == ".zip"

    def test_archive_contains_notes(self, vault_path: Path, backup_dir: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
        assert any("note1.md" in n for n in names)

    def test_archive_contains_manifest(self, vault_path: Path, backup_dir: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        with zipfile.ZipFile(path) as zf:
            assert MANIFEST_NAME in zf.namelist()

    def test_manifest_has_correct_note_count(self, vault_path: Path, backup_dir: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        with zipfile.ZipFile(path) as zf:
            data = json.loads(zf.read(MANIFEST_NAME))
        assert data["note_count"] == 3  # note1, note2, note3

    def test_manifest_vault_name(self, vault_path: Path, backup_dir: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        with zipfile.ZipFile(path) as zf:
            data = json.loads(zf.read(MANIFEST_NAME))
        assert data["vault_name"] == "my_vault"

    def test_creates_backup_dir_if_missing(self, vault_path: Path, tmp_path: Path) -> None:
        new_dir = tmp_path / "new" / "backup" / "dir"
        path = create_backup(vault_path, new_dir)
        assert path.exists()

    def test_archive_name_contains_timestamp(self, vault_path: Path, backup_dir: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        assert ARCHIVE_PREFIX in path.name


# ---------------------------------------------------------------------------
# list_backups

class TestListBackups:
    def test_lists_backups(self, vault_path: Path, backup_dir: Path) -> None:
        create_backup(vault_path, backup_dir)
        create_backup(vault_path, backup_dir)
        infos = list_backups(backup_dir)
        assert len(infos) == 2

    def test_empty_dir(self, tmp_path: Path) -> None:
        assert list_backups(tmp_path / "empty") == []

    def test_backup_info_has_manifest(self, vault_path: Path, backup_dir: Path) -> None:
        create_backup(vault_path, backup_dir)
        infos = list_backups(backup_dir)
        assert infos[0].manifest is not None

    def test_backup_info_size(self, vault_path: Path, backup_dir: Path) -> None:
        create_backup(vault_path, backup_dir)
        infos = list_backups(backup_dir)
        assert infos[0].size_bytes > 0

    def test_sorted_newest_first(self, vault_path: Path, backup_dir: Path) -> None:
        create_backup(vault_path, backup_dir)
        create_backup(vault_path, backup_dir)
        infos = list_backups(backup_dir)
        if len(infos) >= 2 and infos[0].created_at and infos[1].created_at:
            assert infos[0].created_at >= infos[1].created_at


# ---------------------------------------------------------------------------
# verify_backup

class TestVerifyBackup:
    def test_valid_backup(self, vault_path: Path, backup_dir: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        ok, msg = verify_backup(path)
        assert ok
        assert "OK" in msg

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        ok, msg = verify_backup(tmp_path / "ghost.zip")
        assert not ok
        assert "not found" in msg.lower()

    def test_corrupt_archive(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.zip"
        bad.write_bytes(b"this is not a zip file")
        ok, msg = verify_backup(bad)
        assert not ok

    def test_missing_manifest(self, tmp_path: Path) -> None:
        fake = tmp_path / "nota_backup_fake.zip"
        with zipfile.ZipFile(fake, "w") as zf:
            zf.writestr("note.md", "# Note")
        ok, msg = verify_backup(fake)
        assert not ok
        assert "manifest" in msg.lower()


# ---------------------------------------------------------------------------
# restore_backup

class TestRestoreBackup:
    def test_restores_files(self, vault_path: Path, backup_dir: Path, tmp_path: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        target = tmp_path / "restored"
        count, skipped = restore_backup(path, target)
        assert count >= 3  # 3 markdown notes
        assert (target / "note1.md").exists()

    def test_skip_existing_without_overwrite(self, vault_path: Path, backup_dir: Path, tmp_path: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        target = tmp_path / "restored"
        target.mkdir()
        (target / "note1.md").write_text("existing", encoding="utf-8")
        count, skipped = restore_backup(path, target, overwrite=False)
        assert "note1.md" in skipped
        assert (target / "note1.md").read_text() == "existing"

    def test_overwrite_replaces_content(self, vault_path: Path, backup_dir: Path, tmp_path: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        target = tmp_path / "restored"
        target.mkdir()
        (target / "note1.md").write_text("old content", encoding="utf-8")
        restore_backup(path, target, overwrite=True)
        assert "old content" not in (target / "note1.md").read_text()

    def test_dry_run_creates_no_files(self, vault_path: Path, backup_dir: Path, tmp_path: Path) -> None:
        path = create_backup(vault_path, backup_dir)
        target = tmp_path / "dry"
        count, _ = restore_backup(path, target, dry_run=True)
        assert count > 0
        assert not target.exists() or not any(target.iterdir())

    def test_invalid_archive_raises(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.zip"
        bad.write_bytes(b"not a zip")
        with pytest.raises(Exception):
            restore_backup(bad, tmp_path / "target")


# ---------------------------------------------------------------------------
# prune_backups

class TestPruneBackups:
    def test_keeps_last_n(self, vault_path: Path, backup_dir: Path) -> None:
        for _ in range(5):
            create_backup(vault_path, backup_dir)
        deleted = prune_backups(backup_dir, keep_last=3)
        remaining = list_backups(backup_dir)
        assert len(remaining) == 3
        assert len(deleted) == 2

    def test_dry_run_does_not_delete(self, vault_path: Path, backup_dir: Path) -> None:
        for _ in range(4):
            create_backup(vault_path, backup_dir)
        prune_backups(backup_dir, keep_last=2, dry_run=True)
        remaining = list_backups(backup_dir)
        assert len(remaining) == 4

    def test_no_deletion_when_within_limit(self, vault_path: Path, backup_dir: Path) -> None:
        create_backup(vault_path, backup_dir)
        deleted = prune_backups(backup_dir, keep_last=10)
        assert deleted == []


# ---------------------------------------------------------------------------
# BackupRotator

class TestBackupRotator:
    def test_prune_returns_deleted(self, vault_path: Path, backup_dir: Path) -> None:
        for _ in range(3):
            create_backup(vault_path, backup_dir)
        rotator = BackupRotator(backup_dir, keep_hourly=2, keep_daily=1)
        result = rotator.prune(dry_run=True)
        assert "deleted" in result

    def test_dry_run_preserves_files(self, vault_path: Path, backup_dir: Path) -> None:
        for _ in range(4):
            create_backup(vault_path, backup_dir)
        rotator = BackupRotator(backup_dir, keep_hourly=1, keep_daily=1, keep_weekly=1, keep_monthly=1)
        before = len(list_backups(backup_dir))
        rotator.prune(dry_run=True)
        after = len(list_backups(backup_dir))
        assert before == after
