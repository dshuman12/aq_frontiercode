"""Tests for graph algorithms."""
from __future__ import annotations

import math
import pytest

from nota.core.graph import (
    pagerank,
    betweenness_centrality,
    hits,
    connected_components,
    shortest_path,
    bfs,
    reverse_graph,
    all_nodes,
    graph_summary,
    ego_graph,
    top_n,
)


@pytest.fixture()
def linear() -> dict:
    """A -> B -> C (linear chain)."""
    return {"A": ["B"], "B": ["C"], "C": []}


@pytest.fixture()
def triangle() -> dict:
    """A <-> B <-> C <-> A (directed cycle)."""
    return {"A": ["B"], "B": ["C"], "C": ["A"]}


@pytest.fixture()
def star() -> dict:
    """Hub H points to leaves L1..L4, nothing points back."""
    return {
        "H":  ["L1", "L2", "L3", "L4"],
        "L1": [], "L2": [], "L3": [], "L4": [],
    }


@pytest.fixture()
def disconnected() -> dict:
    """Two isolated pairs."""
    return {"A": ["B"], "B": [], "C": ["D"], "D": []}


class TestAllNodes:
    def test_includes_targets(self, linear) -> None:
        nodes = all_nodes(linear)
        assert nodes == {"A", "B", "C"}

    def test_empty(self) -> None:
        assert all_nodes({}) == set()


class TestReverseGraph:
    def test_reversal(self, linear) -> None:
        rev = reverse_graph(linear)
        assert "A" in rev["B"]
        assert "B" in rev["C"]

    def test_triangle_reversal(self, triangle) -> None:
        rev = reverse_graph(triangle)
        assert "C" in rev["A"]


class TestBFS:
    def test_distances(self, linear) -> None:
        dist = bfs(linear, "A")
        assert dist["A"] == 0
        assert dist["B"] == 1
        assert dist["C"] == 2

    def test_unreachable_excluded(self, disconnected) -> None:
        dist = bfs(disconnected, "A")
        assert "C" not in dist
        assert "D" not in dist


class TestShortestPath:
    def test_direct(self, linear) -> None:
        path = shortest_path(linear, "A", "B")
        assert path == ["A", "B"]

    def test_two_hop(self, linear) -> None:
        path = shortest_path(linear, "A", "C")
        assert path == ["A", "B", "C"]

    def test_self(self, linear) -> None:
        assert shortest_path(linear, "A", "A") == ["A"]

    def test_unreachable(self, disconnected) -> None:
        assert shortest_path(disconnected, "A", "C") is None

    def test_cycle(self, triangle) -> None:
        path = shortest_path(triangle, "A", "C")
        assert path is not None
        assert path[0] == "A"
        assert path[-1] == "C"


class TestConnectedComponents:
    def test_linear_is_one_component(self, linear) -> None:
        comps = connected_components(linear)
        assert len(comps) == 1
        assert len(comps[0]) == 3

    def test_disconnected_two_components(self, disconnected) -> None:
        comps = connected_components(disconnected)
        assert len(comps) == 2

    def test_sorted_by_size_descending(self) -> None:
        adj = {"A": ["B"], "B": ["C"], "C": ["A"], "X": []}
        comps = connected_components(adj)
        assert len(comps[0]) >= len(comps[-1])


class TestPageRank:
    def test_values_sum_to_one(self, triangle) -> None:
        pr = pagerank(triangle)
        assert abs(sum(pr.values()) - 1.0) < 1e-4

    def test_all_nodes_present(self, linear) -> None:
        pr = pagerank(linear)
        assert set(pr) == all_nodes(linear)

    def test_star_hub_has_low_rank(self, star) -> None:
        # Hub points out to leaves; leaves point to nothing
        # so hub has no inbound links — leaves should have higher rank
        pr = pagerank(star)
        assert pr["H"] < pr["L1"] + pr["L2"] + pr["L3"] + pr["L4"]

    def test_uniform_in_cycle(self, triangle) -> None:
        pr = pagerank(triangle)
        scores = list(pr.values())
        assert max(scores) - min(scores) < 0.01

    def test_empty_graph(self) -> None:
        assert pagerank({}) == {}

    def test_convergence_parameter(self, linear) -> None:
        pr1 = pagerank(linear, iterations=5)
        pr100 = pagerank(linear, iterations=100)
        for node in pr1:
            assert abs(pr1[node] - pr100[node]) < 0.05


class TestBetweennessCentrality:
    def test_middle_node_highest(self, linear) -> None:
        cb = betweenness_centrality(linear)
        # B is the only path between A and C
        assert cb["B"] >= cb["A"]
        assert cb["B"] >= cb["C"]

    def test_non_negative(self, triangle) -> None:
        cb = betweenness_centrality(triangle)
        for v in cb.values():
            assert v >= 0.0

    def test_all_nodes_present(self, star) -> None:
        cb = betweenness_centrality(star)
        assert set(cb) == all_nodes(star)


class TestHITS:
    def test_returns_two_dicts(self, linear) -> None:
        hubs, auths = hits(linear)
        assert isinstance(hubs, dict)
        assert isinstance(auths, dict)

    def test_empty(self) -> None:
        h, a = hits({})
        assert h == {}
        assert a == {}

    def test_star_hub_score(self, star) -> None:
        hubs, auths = hits(star)
        # H points to many things, so it should have the highest hub score
        assert hubs["H"] == max(hubs.values())


class TestGraphSummary:
    def test_keys_present(self, linear) -> None:
        s = graph_summary(linear)
        for key in ("nodes", "edges", "components", "density", "top_pagerank"):
            assert key in s

    def test_node_count(self, linear) -> None:
        s = graph_summary(linear)
        assert s["nodes"] == 3

    def test_edge_count(self, linear) -> None:
        assert graph_summary(linear)["edges"] == 2


class TestEgoGraph:
    def test_radius_1(self, star) -> None:
        ego = ego_graph(star, "H", radius=1)
        assert "H" in ego

    def test_includes_direct_neighbours(self, linear) -> None:
        ego = ego_graph(linear, "A", radius=1)
        assert "A" in ego
        assert "B" in ego

    def test_radius_2_includes_two_hop(self, linear) -> None:
        ego = ego_graph(linear, "A", radius=2)
        assert "C" in ego


class TestTopN:
    def test_returns_sorted(self) -> None:
        scores = {"a": 0.3, "b": 0.8, "c": 0.1}
        top = top_n(scores, 2)
        assert top[0][0] == "b"
        assert top[1][0] == "a"

    def test_limit_respected(self) -> None:
        scores = {str(i): float(i) for i in range(20)}
        assert len(top_n(scores, 5)) == 5
