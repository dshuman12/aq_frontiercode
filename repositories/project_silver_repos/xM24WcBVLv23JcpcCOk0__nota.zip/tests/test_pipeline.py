"""Tests for the note processing pipeline."""
from __future__ import annotations

import pytest

from nota.core.pipeline import (
    Pipeline,
    PipelineContext,
    StripFrontmatter,
    NormalizeWhitespace,
    InjectTitle,
    ResolveWikiLinks,
    RewriteHashtags,
    ExtractTasks,
    WordCountAnnotator,
    ReadingTimeAnnotator,
    SlugifyLinks,
    SanitizeHTML,
    LintHeadings,
    ExpandAbbreviations,
    default_pipeline,
    export_pipeline,
    safe_pipeline,
)


def make_ctx(text: str, metadata: dict = None) -> PipelineContext:
    return PipelineContext(text=text, raw=text, metadata=dict(metadata or {}))


# ---------------------------------------------------------------------------
# StripFrontmatter

class TestStripFrontmatter:
    def test_strips_yaml(self) -> None:
        text = "---\ntitle: Hello\ntags: [a, b]\n---\nBody text here."
        ctx = StripFrontmatter().process(make_ctx(text))
        assert "---" not in ctx.text
        assert "Body text here" in ctx.text

    def test_populates_metadata(self) -> None:
        text = "---\ntitle: My Note\n---\nContent."
        ctx = StripFrontmatter().process(make_ctx(text))
        assert ctx.metadata.get("title") == "My Note"

    def test_populates_tags(self) -> None:
        text = "---\ntags: [python, async]\n---\nContent."
        ctx = StripFrontmatter().process(make_ctx(text))
        assert "python" in ctx.tags
        assert "async" in ctx.tags

    def test_no_frontmatter_unchanged(self) -> None:
        text = "Just plain text, no front matter."
        ctx = StripFrontmatter().process(make_ctx(text))
        assert ctx.text == text


# ---------------------------------------------------------------------------
# NormalizeWhitespace

class TestNormalizeWhitespace:
    def test_collapses_blank_lines(self) -> None:
        text = "line1\n\n\n\nline2"
        ctx = NormalizeWhitespace().process(make_ctx(text))
        assert "\n\n\n" not in ctx.text

    def test_strips_trailing_spaces(self) -> None:
        text = "hello   \nworld   "
        ctx = NormalizeWhitespace().process(make_ctx(text))
        for line in ctx.text.splitlines():
            assert not line.endswith(" ")


# ---------------------------------------------------------------------------
# InjectTitle

class TestInjectTitle:
    def test_injects_when_no_h1(self) -> None:
        ctx = make_ctx("Some body.", {"title": "My Title"})
        ctx = InjectTitle().process(ctx)
        assert ctx.text.startswith("# My Title")

    def test_no_injection_when_h1_exists(self) -> None:
        ctx = make_ctx("# Existing Title\n\nBody.", {"title": "Ignored"})
        ctx = InjectTitle().process(ctx)
        assert ctx.text.count("# ") == 1

    def test_no_title_no_injection(self) -> None:
        ctx = make_ctx("Body only, no title.", {})
        ctx = InjectTitle().process(ctx)
        assert "#" not in ctx.text


# ---------------------------------------------------------------------------
# ResolveWikiLinks

class TestResolveWikiLinks:
    def test_basic_link(self) -> None:
        ctx = make_ctx("See [[Alpha Note]] for details.")
        ctx = ResolveWikiLinks().process(ctx)
        assert "[[Alpha Note]]" not in ctx.text
        assert "[Alpha Note](/note/alpha-note)" in ctx.text

    def test_link_with_label(self) -> None:
        ctx = make_ctx("See [[Alpha Note|custom label]].")
        ctx = ResolveWikiLinks().process(ctx)
        assert "custom label" in ctx.text
        assert "[[" not in ctx.text

    def test_links_collected(self) -> None:
        ctx = make_ctx("[[Alpha]] and [[Beta]]")
        ctx = ResolveWikiLinks().process(ctx)
        assert "alpha" in ctx.links
        assert "beta" in ctx.links

    def test_custom_prefix(self) -> None:
        proc = ResolveWikiLinks(link_prefix="/notes/")
        ctx = proc.process(make_ctx("[[Gamma]]"))
        assert "/notes/gamma" in ctx.text


# ---------------------------------------------------------------------------
# RewriteHashtags

class TestRewriteHashtags:
    def test_hashtag_rewritten(self) -> None:
        ctx = make_ctx("This is #python content.")
        ctx = RewriteHashtags().process(ctx)
        assert "#python" not in ctx.text or "[#python]" in ctx.text

    def test_tags_collected(self) -> None:
        ctx = make_ctx("Tags: #python #rust #go")
        ctx = RewriteHashtags().process(ctx)
        assert "python" in ctx.tags
        assert "rust" in ctx.tags


# ---------------------------------------------------------------------------
# ExtractTasks

class TestExtractTasks:
    def test_unchecked_task(self) -> None:
        ctx = make_ctx("- [ ] Buy groceries")
        ctx = ExtractTasks().process(ctx)
        assert len(ctx.tasks) == 1
        assert not ctx.tasks[0]["done"]
        assert "Buy groceries" in ctx.tasks[0]["label"]

    def test_checked_task(self) -> None:
        ctx = make_ctx("- [x] Done task")
        ctx = ExtractTasks().process(ctx)
        assert ctx.tasks[0]["done"]

    def test_multiple_tasks(self) -> None:
        ctx = make_ctx("- [ ] One\n- [x] Two\n- [ ] Three")
        ctx = ExtractTasks().process(ctx)
        assert len(ctx.tasks) == 3


# ---------------------------------------------------------------------------
# WordCountAnnotator

class TestWordCountAnnotator:
    def test_word_count_set(self) -> None:
        ctx = make_ctx("one two three four five")
        ctx = WordCountAnnotator().process(ctx)
        assert ctx.metadata["word_count"] == 5

    def test_empty_text(self) -> None:
        ctx = make_ctx("")
        ctx = WordCountAnnotator().process(ctx)
        assert ctx.metadata["word_count"] == 0


# ---------------------------------------------------------------------------
# ReadingTimeAnnotator

class TestReadingTimeAnnotator:
    def test_minimum_one_minute(self) -> None:
        ctx = make_ctx("short")
        ctx = WordCountAnnotator().process(ctx)
        ctx = ReadingTimeAnnotator().process(ctx)
        assert ctx.metadata["reading_time_min"] >= 1

    def test_scales_with_word_count(self) -> None:
        ctx = make_ctx(" ".join(["word"] * 400))
        ctx = WordCountAnnotator().process(ctx)
        ctx = ReadingTimeAnnotator().process(ctx)
        assert ctx.metadata["reading_time_min"] == 2


# ---------------------------------------------------------------------------
# SlugifyLinks

class TestSlugifyLinks:
    def test_slugifies_spaces(self) -> None:
        ctx = make_ctx("[[My Big Note]]")
        ctx = SlugifyLinks().process(ctx)
        assert "[[my-big-note|My Big Note]]" in ctx.text

    def test_lowercase(self) -> None:
        ctx = make_ctx("[[UPPER CASE]]")
        ctx = SlugifyLinks().process(ctx)
        assert "upper-case" in ctx.text


# ---------------------------------------------------------------------------
# SanitizeHTML

class TestSanitizeHTML:
    def test_strips_script_tag(self) -> None:
        ctx = make_ctx("<script>alert('xss')</script>Normal text.")
        ctx = SanitizeHTML().process(ctx)
        assert "<script>" not in ctx.text
        assert "Normal text" in ctx.text

    def test_strips_style_tag(self) -> None:
        ctx = make_ctx("<style>body{color:red}</style>Content.")
        ctx = SanitizeHTML().process(ctx)
        assert "<style>" not in ctx.text


# ---------------------------------------------------------------------------
# LintHeadings

class TestLintHeadings:
    def test_no_warnings_for_sequential(self) -> None:
        ctx = make_ctx("# H1\n\n## H2\n\n### H3")
        ctx = LintHeadings().process(ctx)
        assert not ctx.warnings

    def test_warns_on_skip(self) -> None:
        ctx = make_ctx("# H1\n\n### H3 (skipped H2)")
        ctx = LintHeadings().process(ctx)
        assert len(ctx.warnings) >= 1


# ---------------------------------------------------------------------------
# ExpandAbbreviations

class TestExpandAbbreviations:
    def test_expands_known_abbreviation(self) -> None:
        proc = ExpandAbbreviations({"API": "Application Programming Interface"})
        ctx = proc.process(make_ctx("The API is stable."))
        assert "Application Programming Interface" in ctx.text

    def test_no_expansion_for_unknown(self) -> None:
        proc = ExpandAbbreviations({"XYZ": "Something"})
        ctx = proc.process(make_ctx("This is ABC."))
        assert "ABC" in ctx.text


# ---------------------------------------------------------------------------
# Pipeline composition

class TestPipeline:
    def test_add_and_run(self) -> None:
        pipe = Pipeline()
        pipe.add(NormalizeWhitespace())
        pipe.add(WordCountAnnotator())
        ctx = pipe.run_text("hello world\n\n\nfoo bar")
        assert "word_count" in ctx.metadata

    def test_len(self) -> None:
        pipe = Pipeline([NormalizeWhitespace(), WordCountAnnotator()])
        assert len(pipe) == 2

    def test_remove(self) -> None:
        pipe = Pipeline([NormalizeWhitespace(), WordCountAnnotator()])
        removed = pipe.remove("word-count")
        assert removed
        assert len(pipe) == 1

    def test_remove_nonexistent(self) -> None:
        pipe = Pipeline([NormalizeWhitespace()])
        assert not pipe.remove("nonexistent")

    def test_warnings_collected_on_optional_failure(self) -> None:
        class BadProc(WordCountAnnotator):
            name = "bad"
            optional = True
            def process(self, ctx):
                raise RuntimeError("simulated failure")
        pipe = Pipeline([BadProc()])
        ctx = pipe.run_text("some text")
        assert any("bad" in w for w in ctx.warnings)

    def test_non_optional_failure_raises(self) -> None:
        class CrashProc(WordCountAnnotator):
            name = "crash"
            optional = False
            def process(self, ctx):
                raise RuntimeError("boom")
        pipe = Pipeline([CrashProc()])
        with pytest.raises(RuntimeError):
            pipe.run_text("text")


# ---------------------------------------------------------------------------
# Preset pipelines

class TestPresets:
    def test_default_pipeline_runs(self) -> None:
        pipe = default_pipeline()
        ctx = pipe.run_text("# Title\n\nSome body text here.")
        assert "word_count" in ctx.metadata

    def test_export_pipeline_resolves_links(self) -> None:
        pipe = export_pipeline()
        ctx = pipe.run_text("---\ntitle: T\n---\n[[Other Note]]")
        assert "[[Other Note]]" not in ctx.text

    def test_safe_pipeline_strips_html(self) -> None:
        pipe = safe_pipeline()
        ctx = pipe.run_text("<script>bad()</script>Normal content.")
        assert "<script>" not in ctx.text
