"""Tests for the high-level Vault API."""
from __future__ import annotations

from pathlib import Path

import pytest

from nota.api import Vault


@pytest.fixture()
def vault_path(tmp_path: Path) -> Path:
    """An initialised vault with a few notes."""
    v = Vault(tmp_path)
    v.create("Alpha", content="Alpha body content for testing.", tags=["test", "alpha"])
    v.create("Beta",  content="Beta body with different content.", tags=["test", "beta"])
    v.create("Gamma", content="Gamma is untagged and standalone.", tags=[])
    return tmp_path


@pytest.fixture()
def v(vault_path: Path) -> Vault:
    vault = Vault(vault_path)
    yield vault
    vault.close()


# ---------------------------------------------------------------------------
# Context manager

class TestContextManager:
    def test_enters_and_exits(self, vault_path: Path) -> None:
        with Vault(vault_path) as vault:
            assert vault is not None

    def test_repr(self, vault_path: Path) -> None:
        with Vault(vault_path) as vault:
            r = repr(vault)
            assert "Vault" in r
            assert "notes=" in r


# ---------------------------------------------------------------------------
# CRUD

class TestCreate:
    def test_creates_file(self, v: Vault) -> None:
        note = v.create("New Note", content="Content.")
        assert note.path.exists()

    def test_title_in_frontmatter(self, v: Vault) -> None:
        note = v.create("Titled Note")
        assert note.title == "Titled Note"

    def test_tags_applied(self, v: Vault) -> None:
        note = v.create("Tagged", tags=["x", "y"])
        assert "x" in note.tags
        assert "y" in note.tags

    def test_creates_in_subdir(self, v: Vault) -> None:
        note = v.create("Sub Note", subdir="sub")
        assert "sub" in note.id

    def test_collision_handled(self, v: Vault) -> None:
        n1 = v.create("Collision")
        n2 = v.create("Collision")
        assert n1.path != n2.path

    def test_extra_metadata(self, v: Vault) -> None:
        note = v.create("Meta Note", metadata={"status": "draft"})
        assert note.metadata.get("status") == "draft"


class TestGet:
    def test_by_stem(self, v: Vault) -> None:
        assert v.get("alpha") is not None

    def test_by_title(self, v: Vault) -> None:
        assert v.get("Alpha") is not None

    def test_missing_returns_none(self, v: Vault) -> None:
        assert v.get("nonexistent_xyz") is None


class TestDelete:
    def test_deletes_note(self, v: Vault) -> None:
        note = v.create("To Delete")
        path = note.path
        assert v.delete("to-delete")
        assert not path.exists()

    def test_missing_returns_false(self, v: Vault) -> None:
        assert not v.delete("never-existed")


class TestUpdateContent:
    def test_updates_body(self, v: Vault) -> None:
        v.create("Updatable", content="Original body.")
        updated = v.update_content("updatable", "New body content.")
        assert updated is not None
        updated._post = None
        assert "New body content" in updated.content

    def test_missing_returns_none(self, v: Vault) -> None:
        assert v.update_content("nope", "content") is None


# ---------------------------------------------------------------------------
# Search

class TestSearch:
    def test_finds_by_text(self, v: Vault) -> None:
        results = v.search("alpha")
        assert len(results) >= 1

    def test_returns_list(self, v: Vault) -> None:
        assert isinstance(v.search("test"), list)

    def test_limit_respected(self, v: Vault) -> None:
        results = v.search("body", limit=1)
        assert len(results) <= 1


class TestQuery:
    def test_tag_filter(self, v: Vault) -> None:
        results = v.query("tag:alpha")
        assert all("alpha" in n.tags for n in results)

    def test_not_filter(self, v: Vault) -> None:
        results = v.query("NOT tag:test")
        assert all("test" not in n.tags for n in results)

    def test_empty_query(self, v: Vault) -> None:
        results = v.query("")
        assert len(results) == v.store.note_count()

    def test_explain(self, v: Vault) -> None:
        explanation = v.explain("tag:python AND words:>100")
        assert isinstance(explanation, str)
        assert "python" in explanation


# ---------------------------------------------------------------------------
# Listing

class TestListing:
    def test_all_notes_count(self, v: Vault) -> None:
        notes = v.all_notes()
        assert len(notes) == v.store.note_count()

    def test_all_notes_sorted_modified(self, v: Vault) -> None:
        notes = v.all_notes(sort="modified")
        dates = [n.modified for n in notes]
        assert dates == sorted(dates, reverse=True)

    def test_recent(self, v: Vault) -> None:
        notes = v.recent(2)
        assert len(notes) <= 2

    def test_by_tag(self, v: Vault) -> None:
        notes = v.by_tag("test")
        assert all("test" in n.tags for n in notes)

    def test_orphans_returns_list(self, v: Vault) -> None:
        assert isinstance(v.orphans(), list)

    def test_backlinks(self, v: Vault) -> None:
        assert isinstance(v.backlinks("alpha"), list)


# ---------------------------------------------------------------------------
# Tags

class TestTagOps:
    def test_all_tags(self, v: Vault) -> None:
        tags = v.all_tags()
        assert "test" in tags

    def test_add_tag(self, v: Vault) -> None:
        assert v.add_tag("alpha", "new-tag")
        note = v.get("alpha")
        assert note is not None
        note._post = None
        assert "new-tag" in note.tags

    def test_remove_tag(self, v: Vault) -> None:
        v.add_tag("beta", "removable")
        assert v.remove_tag("beta", "removable")

    def test_add_tag_missing_note(self, v: Vault) -> None:
        assert not v.add_tag("nonexistent", "tag")


# ---------------------------------------------------------------------------
# Graph

class TestGraph:
    def test_graph_returns_dict(self, v: Vault) -> None:
        assert isinstance(v.graph(), dict)

    def test_pagerank_sums_to_one(self, v: Vault) -> None:
        pr = v.pagerank()
        if pr:
            assert abs(sum(pr.values()) - 1.0) < 0.01

    def test_graph_summary_keys(self, v: Vault) -> None:
        s = v.graph_summary()
        assert "nodes" in s
        assert "edges" in s


# ---------------------------------------------------------------------------
# Stats

class TestStats:
    def test_stats_keys(self, v: Vault) -> None:
        s = v.stats()
        assert "notes" in s and "words" in s

    def test_note_count(self, v: Vault) -> None:
        assert v.stats()["notes"] == v.store.note_count()


# ---------------------------------------------------------------------------
# Export

class TestExport:
    def test_export_html(self, v: Vault, tmp_path: Path) -> None:
        out = tmp_path / "html_out"
        files = v.export_html(out)
        assert len(files) > 0
        assert all(f.exists() for f in files)

    def test_export_json(self, v: Vault) -> None:
        data = v.export_json()
        assert "notes" in data

    def test_export_markdown(self, v: Vault) -> None:
        md = v.export_markdown()
        assert isinstance(md, str)
        assert len(md) > 0

    def test_export_site(self, v: Vault, tmp_path: Path) -> None:
        count = v.export_site(tmp_path / "site", theme="dark")
        assert count >= 4  # notes + index + tags + graph

    def test_reindex(self, v: Vault) -> None:
        count = v.reindex()
        assert isinstance(count, int)
