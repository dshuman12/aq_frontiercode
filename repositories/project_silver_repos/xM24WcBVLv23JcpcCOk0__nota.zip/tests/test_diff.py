"""Tests for the note diffing utilities."""
from __future__ import annotations

from pathlib import Path

import pytest

from nota.core.diff import (
    LineDiff,
    WordDiff,
    MetaDiff,
    NoteChange,
    Op,
    DiffLine,
    DiffWord,
    FieldChange,
    Hunk,
    compare_notes,
    diff_html,
    changelog,
)


# ---------------------------------------------------------------------------
# LineDiff

class TestLineDiff:
    OLD = "line one\nline two\nline three\n"
    NEW = "line one\nline TWO\nline three\nline four\n"

    def test_detects_change(self) -> None:
        d = LineDiff(self.OLD, self.NEW)
        assert not d.is_empty

    def test_identical_is_empty(self) -> None:
        d = LineDiff("same\n", "same\n")
        assert d.is_empty

    def test_stats_added(self) -> None:
        old = "a\nb\nc\n"
        new = "a\nb\nc\nd\n"
        d = LineDiff(old, new)
        s = d.stats()
        assert s["added"] >= 1
        assert s["deleted"] == 0

    def test_stats_deleted(self) -> None:
        old = "a\nb\nc\n"
        new = "a\nc\n"
        d = LineDiff(old, new)
        s = d.stats()
        assert s["deleted"] >= 1

    def test_unified_text_format(self) -> None:
        d = LineDiff("a\nb\n", "a\nc\n")
        ut = d.unified_text()
        assert "@@" in ut

    def test_hunks_returned(self) -> None:
        d = LineDiff("a\nb\nc\n", "a\nX\nc\n")
        assert len(d.hunks) >= 1

    def test_hunk_header(self) -> None:
        d = LineDiff("a\nb\n", "a\nc\n")
        header = d.hunks[0].header()
        assert header.startswith("@@")

    def test_empty_inputs(self) -> None:
        d = LineDiff("", "")
        assert d.is_empty

    def test_from_empty_to_content(self) -> None:
        d = LineDiff("", "new content\n")
        assert not d.is_empty
        s = d.stats()
        assert s["added"] >= 1


# ---------------------------------------------------------------------------
# WordDiff

class TestWordDiff:
    def test_detects_insertion(self) -> None:
        wd = WordDiff("hello world", "hello beautiful world")
        diffs = wd.diff()
        inserts = [d for d in diffs if d.op == Op.INSERT]
        assert inserts

    def test_detects_deletion(self) -> None:
        wd = WordDiff("hello beautiful world", "hello world")
        diffs = wd.diff()
        deletes = [d for d in diffs if d.op == Op.DELETE]
        assert deletes

    def test_identical(self) -> None:
        wd = WordDiff("same text here", "same text here")
        diffs = wd.diff()
        assert all(d.op == Op.EQUAL for d in diffs)

    def test_html_output_has_ins(self) -> None:
        wd = WordDiff("old text", "new text")
        h = wd.html()
        assert "<ins" in h or "<del" in h

    def test_html_output_escaped(self) -> None:
        wd = WordDiff("a", "a & <b>")
        h = wd.html()
        assert "<b>" not in h or "&amp;" in h or "&lt;" in h


# ---------------------------------------------------------------------------
# MetaDiff

class TestMetaDiff:
    def test_detects_changed_field(self) -> None:
        old = {"title": "Old", "tags": ["a"]}
        new = {"title": "New", "tags": ["a"]}
        md = MetaDiff(old, new)
        changes = md.changes()
        assert any(c.field == "title" for c in changes)

    def test_detects_added_field(self) -> None:
        old = {"title": "T"}
        new = {"title": "T", "status": "draft"}
        md = MetaDiff(old, new)
        changes = md.changes()
        assert any(c.field == "status" for c in changes)

    def test_detects_removed_field(self) -> None:
        old = {"title": "T", "old_key": "v"}
        new = {"title": "T"}
        md = MetaDiff(old, new)
        changes = md.changes()
        assert any(c.field == "old_key" for c in changes)

    def test_identical_is_empty(self) -> None:
        meta = {"title": "T", "tags": ["x"]}
        md = MetaDiff(meta, meta.copy())
        assert md.is_empty()

    def test_summary_format(self) -> None:
        old = {"title": "Old"}
        new = {"title": "New"}
        md = MetaDiff(old, new)
        s = md.summary()
        assert "title" in s

    def test_field_change_op_insert(self) -> None:
        fc = FieldChange(field="f", old_value=None, new_value="v")
        assert fc.op == Op.INSERT

    def test_field_change_op_delete(self) -> None:
        fc = FieldChange(field="f", old_value="v", new_value=None)
        assert fc.op == Op.DELETE

    def test_field_change_op_replace(self) -> None:
        fc = FieldChange(field="f", old_value="a", new_value="b")
        assert fc.op == Op.REPLACE


# ---------------------------------------------------------------------------
# compare_notes / NoteChange

class TestCompareNotes:
    def test_basic_comparison(self, tmp_path: Path) -> None:
        path = tmp_path / "note.md"
        nc = compare_notes("old content\n", "new content\n", path=path)
        assert not nc.is_empty

    def test_identical_is_empty(self, tmp_path: Path) -> None:
        path = tmp_path / "note.md"
        nc = compare_notes("same\n", "same\n", path=path)
        assert nc.is_empty

    def test_word_delta_positive(self, tmp_path: Path) -> None:
        path = tmp_path / "note.md"
        nc = compare_notes("one two", "one two three four", path=path)
        assert nc.word_delta > 0

    def test_word_delta_negative(self, tmp_path: Path) -> None:
        path = tmp_path / "note.md"
        nc = compare_notes("one two three four", "one two", path=path)
        assert nc.word_delta < 0

    def test_link_added_detected(self, tmp_path: Path) -> None:
        path = tmp_path / "note.md"
        nc = compare_notes(
            "no links", "some links",
            path=path,
            old_links=[],
            new_links=["alpha"],
        )
        assert "alpha" in nc.link_added

    def test_link_removed_detected(self, tmp_path: Path) -> None:
        path = tmp_path / "note.md"
        nc = compare_notes(
            "", "",
            path=path,
            old_links=["beta"],
            new_links=[],
        )
        assert "beta" in nc.link_removed

    def test_summary_line_format(self, tmp_path: Path) -> None:
        path = tmp_path / "test.md"
        nc = compare_notes("old\n", "new line\nadded\n", path=path)
        s = nc.summary_line()
        assert "test.md" in s


# ---------------------------------------------------------------------------
# diff_html

class TestDiffHTML:
    def test_returns_table(self) -> None:
        d = LineDiff("a\nb\n", "a\nc\n")
        h = diff_html(d)
        assert "<table" in h

    def test_insertion_highlighted(self) -> None:
        d = LineDiff("a\n", "a\nnew line\n")
        h = diff_html(d)
        assert "diff-ins" in h

    def test_deletion_highlighted(self) -> None:
        d = LineDiff("a\nremoved\n", "a\n")
        h = diff_html(d)
        assert "diff-del" in h


# ---------------------------------------------------------------------------
# changelog

class TestChangelog:
    def test_empty_list(self) -> None:
        result = changelog([])
        assert "No changes" in result

    def test_generates_markdown(self, tmp_path: Path) -> None:
        path = tmp_path / "note.md"
        nc = compare_notes("old text here\n", "new text added here\n", path=path)
        md = changelog([nc])
        assert "note.md" in md

    def test_multiple_changes(self, tmp_path: Path) -> None:
        paths = [tmp_path / f"n{i}.md" for i in range(3)]
        ncs = [
            compare_notes("old", "new content added", path=p)
            for p in paths
        ]
        md = changelog(ncs)
        assert "## Changes" in md
