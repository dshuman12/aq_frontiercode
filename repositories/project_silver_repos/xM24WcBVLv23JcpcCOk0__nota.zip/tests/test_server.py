"""Tests for the nota local web server."""
from __future__ import annotations

import json
import threading
import time
import urllib.request
from pathlib import Path

import pytest

from nota.api import Vault
from nota.server import NotaServer, run


@pytest.fixture()
def vault_path(tmp_path: Path) -> Path:
    v = Vault(tmp_path)
    v.create("Alpha Note", content="Alpha content here for testing.", tags=["test", "alpha"])
    v.create("Beta Note",  content="Beta content is different.", tags=["test", "beta"])
    v.create("Gamma Note", content="Gamma is standalone.", tags=[])
    return tmp_path


@pytest.fixture()
def server(vault_path: Path):
    from nota.core.store import Store
    store = Store(vault_path)
    store.index_all(force=True)
    srv = NotaServer(vault_path, host="127.0.0.1", port=0)
    srv.start()
    yield srv
    srv.stop()


# ---------------------------------------------------------------------------
# Server lifecycle

class TestServerLifecycle:
    def test_starts_and_stops(self, vault_path: Path) -> None:
        from nota.core.store import Store
        store = Store(vault_path)
        store.index_all(force=True)
        srv = NotaServer(vault_path, host="127.0.0.1", port=0)
        srv.start()
        assert srv.is_running
        srv.stop()
        assert not srv.is_running

    def test_url_contains_host(self, server: NotaServer) -> None:
        url = server.url
        assert "127.0.0.1" in url

    def test_port_assigned(self, server: NotaServer) -> None:
        assert server.port > 0


# ---------------------------------------------------------------------------
# Routes (HTTP requests)

def _get(url: str, timeout: float = 5.0) -> tuple:
    """Return (status_code, body_str)."""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")


class TestHTTPRoutes:
    def test_home_returns_200(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/")
        assert status == 200
        assert "<html" in body.lower()

    def test_search_returns_200(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/search?q=alpha")
        assert status == 200

    def test_tags_returns_200(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/tags")
        assert status == 200

    def test_graph_returns_200(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/graph")
        assert status == 200

    def test_stats_returns_200(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/stats")
        assert status == 200

    def test_missing_note_returns_404(self, server: NotaServer) -> None:
        status, _ = _get(server.url + "/note/nonexistent-xyz")
        assert status == 404

    def test_orphans_returns_200(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/orphans")
        assert status == 200

    def test_calendar_returns_200(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/calendar")
        assert status == 200


class TestAPIRoutes:
    def test_api_stats_json(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/api/stats")
        assert status == 200
        data = json.loads(body)
        assert "notes" in data

    def test_api_notes_json(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/api/notes")
        assert status == 200
        data = json.loads(body)
        assert "notes" in data
        assert len(data["notes"]) >= 1

    def test_api_tags_json(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/api/tags")
        assert status == 200
        data = json.loads(body)
        assert "tags" in data

    def test_api_search_json(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/api/search?q=alpha")
        assert status == 200
        data = json.loads(body)
        assert "results" in data

    def test_api_graph_json(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/api/graph")
        assert status == 200
        data = json.loads(body)
        assert "nodes" in data or isinstance(data, dict)

    def test_api_note_missing_returns_404(self, server: NotaServer) -> None:
        status, body = _get(server.url + "/api/note/nonexistent-xyz")
        assert status == 404


# ---------------------------------------------------------------------------
# Router and Response unit tests

class TestRouter:
    def test_simple_route_match(self) -> None:
        from nota.server.routes import Router, Request, Response

        router = Router()

        @router.get("/hello")
        def hello(req: Request) -> Response:
            return Response.text("hi")

        req = Request(
            method="GET", path="/hello", query={},
            headers={}, body=b"", path_params={}
        )
        resp = router.dispatch(req)
        assert resp.status == 200
        assert b"hi" in resp.body

    def test_path_params_extracted(self) -> None:
        from nota.server.routes import Router, Request, Response

        router = Router()

        @router.get("/note/{stem}")
        def note(req: Request) -> Response:
            return Response.text(req.path_params["stem"])

        req = Request(
            method="GET", path="/note/alpha-note", query={},
            headers={}, body=b"", path_params={}
        )
        resp = router.dispatch(req)
        assert b"alpha-note" in resp.body

    def test_not_found_on_unmatched(self) -> None:
        from nota.server.routes import Router, Request, Response

        router = Router()
        req = Request(
            method="GET", path="/nonexistent", query={},
            headers={}, body=b"", path_params={}
        )
        resp = router.dispatch(req)
        assert resp.status == 404

    def test_method_not_matched(self) -> None:
        from nota.server.routes import Router, Request, Response

        router = Router()

        @router.get("/only-get")
        def only_get(req: Request) -> Response:
            return Response.text("ok")

        req = Request(
            method="POST", path="/only-get", query={},
            headers={}, body=b"", path_params={}
        )
        resp = router.dispatch(req)
        assert resp.status == 404


class TestResponse:
    def test_html_factory(self) -> None:
        from nota.server.routes import Response
        r = Response.html("<p>hello</p>")
        assert r.status == 200
        assert b"hello" in r.body

    def test_json_factory(self) -> None:
        from nota.server.routes import Response
        r = Response.json({"key": "value"})
        assert r.status == 200
        data = json.loads(r.body)
        assert data["key"] == "value"

    def test_not_found_factory(self) -> None:
        from nota.server.routes import Response
        r = Response.not_found("missing")
        assert r.status == 404

    def test_redirect_factory(self) -> None:
        from nota.server.routes import Response
        r = Response.redirect("/new-path")
        assert r.status == 302
        assert r.headers["Location"] == "/new-path"
