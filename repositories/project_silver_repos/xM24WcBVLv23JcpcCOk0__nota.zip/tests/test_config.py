"""Tests for the nota configuration system."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from nota.utils.config import Config, DEFAULT_CONFIG, load_config, save_config


@pytest.fixture()
def cfg_path(tmp_path: Path) -> Path:
    return tmp_path / "config.json"


@pytest.fixture()
def cfg(cfg_path: Path) -> Config:
    return Config(path=cfg_path)


# ---------------------------------------------------------------------------
# Defaults

class TestDefaults:
    def test_default_editor(self, cfg: Config) -> None:
        assert isinstance(cfg.editor, str)

    def test_default_theme(self, cfg: Config) -> None:
        assert cfg.theme in ("light", "dark", "sepia")

    def test_default_date_format(self, cfg: Config) -> None:
        assert "%Y" in cfg.date_format or cfg.date_format  # non-empty

    def test_tags_are_list(self, cfg: Config) -> None:
        assert isinstance(cfg.default_tags, list)


# ---------------------------------------------------------------------------
# Persistence

class TestPersistence:
    def test_save_and_reload(self, cfg_path: Path) -> None:
        cfg = Config(path=cfg_path)
        cfg.theme = "dark"
        save_config(cfg)
        loaded = load_config(cfg_path)
        assert loaded.theme == "dark"

    def test_file_is_json(self, cfg_path: Path) -> None:
        cfg = Config(path=cfg_path)
        save_config(cfg)
        data = json.loads(cfg_path.read_text())
        assert isinstance(data, dict)

    def test_missing_file_returns_defaults(self, tmp_path: Path) -> None:
        path = tmp_path / "nonexistent.json"
        cfg = load_config(path)
        assert isinstance(cfg, Config)

    def test_partial_file_merges_defaults(self, cfg_path: Path) -> None:
        cfg_path.write_text(json.dumps({"theme": "sepia"}), encoding="utf-8")
        cfg = load_config(cfg_path)
        assert cfg.theme == "sepia"
        assert isinstance(cfg.editor, str)  # default preserved

    def test_save_creates_parent_dirs(self, tmp_path: Path) -> None:
        deep = tmp_path / "a" / "b" / "config.json"
        cfg = Config(path=deep)
        save_config(cfg)
        assert deep.exists()


# ---------------------------------------------------------------------------
# Fields

class TestFields:
    def test_set_theme(self, cfg: Config) -> None:
        cfg.theme = "sepia"
        assert cfg.theme == "sepia"

    def test_set_editor(self, cfg: Config) -> None:
        cfg.editor = "vim"
        assert cfg.editor == "vim"

    def test_vault_path_none_by_default(self, cfg: Config) -> None:
        assert cfg.default_vault is None or isinstance(cfg.default_vault, (str, Path))

    def test_webhooks_list(self, cfg: Config) -> None:
        assert isinstance(cfg.webhooks, list)

    def test_plugins_list(self, cfg: Config) -> None:
        assert isinstance(cfg.plugins, list)


# ---------------------------------------------------------------------------
# to_dict / from_dict

class TestSerialization:
    def test_to_dict_is_dict(self, cfg: Config) -> None:
        d = cfg.to_dict()
        assert isinstance(d, dict)

    def test_from_dict_roundtrip(self, cfg: Config) -> None:
        cfg.theme = "dark"
        cfg.editor = "nano"
        d = cfg.to_dict()
        cfg2 = Config.from_dict(d, path=cfg.path)
        assert cfg2.theme == "dark"
        assert cfg2.editor == "nano"

    def test_repr_contains_theme(self, cfg: Config) -> None:
        r = repr(cfg)
        assert "Config" in r


# ---------------------------------------------------------------------------
# DEFAULT_CONFIG sentinel

class TestDefaultConfig:
    def test_default_config_is_dict(self) -> None:
        assert isinstance(DEFAULT_CONFIG, dict)

    def test_has_required_keys(self) -> None:
        for key in ("theme", "editor", "date_format"):
            assert key in DEFAULT_CONFIG
