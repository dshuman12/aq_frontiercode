# Changelog

All notable changes to nota are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

---

## [0.5.2] – 2026-05-05

### Added
- Shell auto-complete for note titles via `nota --install-completion`

### Fixed
- Batch SQLite writes now use WAL mode correctly on Windows

---

## [0.5.1] – 2026-04-28

### Fixed
- Race condition in concurrent file watcher when two editors save simultaneously

### Added
- Webhook notifications on note change (`webhooks` config key)

---

## [0.5.0] – 2026-03-28

### Added
- `nota mcp-serve` — expose vault as an MCP server for AI assistants
- Note-level AES-256-GCM encryption (`nota encrypt` / `nota decrypt`)
- Obsidian vault import (`nota import --format obsidian`)

### Changed
- Export pipeline decoupled from CLI; usable as a library

---

## [0.4.0] – 2025-12-22

### Added
- Plugin system via `nota.plugins` entry-point group
- Fetch note templates from remote URLs (`nota new --template https://...`)
- Calendar heatmap view (`nota calendar`)

### Changed
- Improved BM25 search ranking via FTS5 porter tokenizer

### Fixed
- Multi-byte Unicode handling in note titles on Windows

---

## [0.3.0] – 2025-09-29

### Added
- Semantic search via sentence-transformers (`nota find --semantic`)
- Vector embeddings persisted in SQLite (`nota[semantic]` extra)
- `nota stats` command

### Fixed
- Reduced memory footprint in `--watch` mode by limiting concurrent indexers

---

## [0.2.0] – 2025-04-22

### Added
- HTML export (`nota export html`)
- JSON graph export (`nota graph --json`)
- Daily notes (`nota daily`)
- Note templates (Jinja2)
- GitHub Actions CI workflow

### Fixed
- Wiki-link resolution for notes in nested subdirectories
- Invalid date formats in frontmatter no longer crash indexing

---

## [0.1.0] – 2025-01-21

### Added
- Initial release
- `nota init`, `nota new`, `nota ls`, `nota find`
- Full-text search via FTS5
- Tag extraction from frontmatter and inline `#tag`
- Backlinks tracking
- SQLite-backed note index
