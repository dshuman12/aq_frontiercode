# CateringOps

Catering inquiry, quote, order, production, delivery, and invoicing platform
for restaurants. CateringOps takes a customer from "first email asking
about a wedding" to "deposit collected, kitchen prepped, driver dispatched,
final invoice paid" — without spreadsheets and sticky notes.

## What it handles

- Catering inquiries (public form + manager inbox)
- Quote builder with packages, custom items, fees, taxes, revisions
- Customer approval via signed link (no signup required)
- Catering orders with full lifecycle
- Kitchen production board + batch tracking
- Delivery scheduling, driver assignment, proof of delivery
- Deposits (Stripe) + final invoicing + refunds
- Reports: revenue, quote conversion, deposit, outstanding balance,
  menu performance, package performance, delivery success, repeat customers

## What it does NOT handle

POS, table reservations, ingredient inventory, employee scheduling. Those
are solved elsewhere. CateringOps focuses on catering as a revenue stream.

## Stack

- Backend: Python 3.11, Django 4.2, DRF, PostgreSQL 15, Redis, Celery,
  Django Channels, Stripe, drf-spectacular.
- Frontends: React 18 + Vite + Tailwind, four apps (staff, customer portal,
  kitchen board, delivery board).
- Tests: Pytest + factory-boy.

## Quick start

```bash
docker compose -f docker/compose.dev.yml up -d
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements/dev.txt
./manage.py migrate
./manage.py seed_demo
./manage.py runserver
```

Open http://localhost:5173, sign in as `chef@aurora-catering.test` / `demo-pass-123`.
