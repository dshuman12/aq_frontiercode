import { useEffect, useState } from "react";

export function Board() {
  const [items, setItems] = useState([]);
  useEffect(() => {
    const proto = window.location.protocol === "https:" ? "wss" : "ws";
    const tenant = new URLSearchParams(window.location.search).get("t") || "";
    const ws = new WebSocket(`${proto}://${window.location.host}/ws/kitchen/${tenant}/`);
    ws.onmessage = (e) => {
      const msg = JSON.parse(e.data);
      setItems((prev) => [msg, ...prev.filter(p => p.id !== msg.id)].slice(0, 100));
    };
    return () => ws.close();
  }, []);
  return (
    <div style={{ background: "#0c0c0c", color: "#fff", padding: 24, minHeight: "100vh", fontSize: 18 }}>
      <h1 style={{ fontSize: 32, marginTop: 0 }}>Kitchen production</h1>
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 16 }}>
        <thead><tr style={{ textAlign: "left" }}><th>Time</th><th>Station</th><th>Item</th><th>Qty</th><th>Status</th></tr></thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.id} style={{ borderTop: "1px solid #2c2c2c" }}>
              <td>{i.event_time}</td><td>{i.station}</td><td>{i.label}</td><td>{i.qty}</td><td>{i.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
