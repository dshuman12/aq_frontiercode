#!/usr/bin/env python
"""Print today + tomorrow's event schedule."""
import os
import sys
from datetime import date, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")

import django
django.setup()

from apps.orders.models import Order
from apps.tenants.models import Tenant


def main(slug):
    t = Tenant.objects.get(slug=slug)
    today = date.today()
    qs = Order.objects.filter(tenant=t, event_date__gte=today,
                              event_date__lt=today + timedelta(days=2),
                              archived_at__isnull=True
                              ).select_related("customer").order_by("event_date", "event_time")
    for o in qs:
        c = o.customer
        name = c.company_name or c.primary_email
        print(f"{o.event_date} {o.event_time}  {o.order_number}  {name}  {o.guest_count}p  {o.status}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "aurora-catering")
