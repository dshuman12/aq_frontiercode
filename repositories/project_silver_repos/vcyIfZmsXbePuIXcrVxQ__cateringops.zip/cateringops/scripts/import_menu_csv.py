#!/usr/bin/env python
"""Import menu items from CSV (slug,name,price,serves,sku,category_slug)."""
import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")

import django
django.setup()

from decimal import Decimal
from apps.menu.models import MenuCategory
from apps.menu.services import create_item
from apps.tenants.models import Tenant


def main(slug, csv_path):
    t = Tenant.objects.get(slug=slug)
    with open(csv_path) as f:
        for row in csv.DictReader(f):
            try:
                cat = MenuCategory.objects.get(tenant=t, slug=row["category_slug"])
            except MenuCategory.DoesNotExist:
                print(f"skip {row['slug']}: unknown category")
                continue
            create_item(tenant=t, category=cat, name=row["name"],
                       price=Decimal(row["price"]), serves=int(row["serves"]),
                       sku=row.get("sku", ""))
            print(f"created {row['name']}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: import_menu_csv.py <tenant_slug> <csv>")
    main(sys.argv[1], sys.argv[2])
