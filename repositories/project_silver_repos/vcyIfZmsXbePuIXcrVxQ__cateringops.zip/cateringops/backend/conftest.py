"""Project-wide pytest fixtures."""
import pytest
from rest_framework.test import APIClient


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def user(db):
    from django.contrib.auth import get_user_model
    U = get_user_model()
    return U.objects.create_user(email="user@example.test", password="pw-correct-horse-1",
                                first_name="Test", last_name="User")


@pytest.fixture
def another_user(db):
    from django.contrib.auth import get_user_model
    return get_user_model().objects.create_user(email="other@example.test", password="pw-correct-horse-2")


@pytest.fixture
def tenant(db, user):
    from apps.tenants.services import onboard_tenant
    return onboard_tenant(owner=user, slug="aurora-catering", name="Aurora Catering")


@pytest.fixture
def location(db, tenant):
    from apps.locations.services import create_location
    return create_location(
        tenant=tenant, slug="main", name="Main Kitchen", is_main=True,
        address_line1="1 Aurora Way", city="Seattle", state="WA", postal_code="98101",
        delivery_enabled=True,
    )


@pytest.fixture
def auth_client(api_client, user):
    api_client.force_authenticate(user)
    return api_client
