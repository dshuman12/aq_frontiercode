"""Celery factory."""
from __future__ import annotations

import os

from celery import Celery
from celery.schedules import crontab

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")

app = Celery("cateringops")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

app.conf.beat_schedule = {
    "expire-quotes-nightly": {
        "task": "apps.quotes.tasks.expire_stale_quotes",
        "schedule": crontab(hour=2, minute=0),
    },
    "send-deposit-reminders-daily": {
        "task": "apps.billing.tasks.send_deposit_reminders",
        "schedule": crontab(hour=9, minute=0),
    },
    "send-production-reminders": {
        "task": "apps.production.tasks.send_production_reminders",
        "schedule": crontab(hour=6, minute=30),
    },
    "daily-catering-digest": {
        "task": "apps.notifications.tasks.daily_digest",
        "schedule": crontab(hour=17, minute=0),
    },
    "cleanup-old-notifications": {
        "task": "apps.notifications.tasks.cleanup_notifications",
        "schedule": crontab(hour=3, minute=30),
    },
}
