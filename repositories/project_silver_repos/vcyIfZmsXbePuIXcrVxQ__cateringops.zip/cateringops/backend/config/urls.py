from django.contrib import admin
from django.urls import include, path

from apps.core.health import live, ready

urlpatterns = [
    path("admin/", admin.site.urls),
    path("health/live/", live, name="live"),
    path("health/ready/", ready, name="ready"),
    path("api/auth/", include("apps.users.urls")),
    path("api/tenants/", include("apps.tenants.urls")),
    path("api/", include("apps.locations.urls")),
    path("api/", include("apps.staff.urls")),
    path("api/", include("apps.roles.urls")),
    path("api/t/<uuid:tenant_id>/customers/", include("apps.customers.urls")),
    path("api/t/<uuid:tenant_id>/menu/", include("apps.menu.urls")),
    path("api/t/<uuid:tenant_id>/packages/", include("apps.packages.urls")),
    path("api/t/<uuid:tenant_id>/inquiries/", include("apps.inquiries.urls")),
    path("api/t/<uuid:tenant_id>/quotes/", include("apps.quotes.urls")),
    path("api/t/<uuid:tenant_id>/orders/", include("apps.orders.urls")),
    path("api/t/<uuid:tenant_id>/production/", include("apps.production.urls")),
    path("api/t/<uuid:tenant_id>/kitchen/", include("apps.kitchen.urls")),
    path("api/t/<uuid:tenant_id>/delivery/", include("apps.delivery.urls")),
    path("api/t/<uuid:tenant_id>/billing/", include("apps.billing.urls")),
    path("api/t/<uuid:tenant_id>/payments/", include("apps.payments.urls")),
    path("api/t/<uuid:tenant_id>/documents/", include("apps.documents.urls")),
    path("api/t/<uuid:tenant_id>/notifications/", include("apps.notifications.urls")),
    path("api/t/<uuid:tenant_id>/reports/", include("apps.reports.urls")),
    path("api/t/<uuid:tenant_id>/audit/", include("apps.audit.urls")),
    path("api/t/<uuid:tenant_id>/files/", include("apps.files.urls")),
    path("api/schema/", include("drf_spectacular.urls")),
]
