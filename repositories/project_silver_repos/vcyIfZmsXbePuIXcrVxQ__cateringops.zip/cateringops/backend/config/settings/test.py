from .base import *  # noqa: F401,F403

DEBUG = False
SECRET_KEY = "test-only"
CELERY_TASK_ALWAYS_EAGER = False
PASSWORD_HASHERS = ("django.contrib.auth.hashers.MD5PasswordHasher",)
DATABASES["default"]["NAME"] = "cateringops_test"  # noqa: F405
CHANNEL_LAYERS = {"default": {"BACKEND": "channels.layers.InMemoryChannelLayer"}}
