from __future__ import annotations
from django.utils import timezone

from apps.notifications.models import EmailLog, Notification, NotificationPreference


TEMPLATES = {
    "inquiry.new": ("New catering inquiry", "A new catering inquiry has arrived."),
    "quote.sent": ("Your catering quote", "Click the link to view your quote."),
    "quote.viewed": ("Quote viewed", "Customer has opened the quote."),
    "quote.approved": ("Quote approved", "The customer has approved the quote."),
    "deposit.reminder": ("Deposit due", "Your deposit is due."),
    "order.confirmed": ("Order confirmed", "Your catering order is confirmed."),
    "production.reminder": ("Production reminder", "Tomorrow's events."),
    "delivery.reminder": ("Delivery reminder", "Today's deliveries."),
    "payment.received": ("Payment received", "Your payment is recorded."),
    "payment.reminder": ("Balance due", "Your remaining balance is due."),
    "order.completed": ("Order completed", "Your catering order is completed."),
    "digest.daily": ("Daily digest", "Today's catering activity."),
}


def create(*, tenant, kind: str, subject=None, body=None, user=None,
          customer_email: str = "", metadata=None) -> Notification:
    default_subject, default_body = TEMPLATES.get(kind, ("Notification", ""))
    return Notification.objects.create(
        tenant=tenant, user=user, customer_email=customer_email, kind=kind,
        subject=subject or default_subject, body=body or default_body,
        metadata=metadata or {},
    )


def get_or_create_prefs(user, tenant) -> NotificationPreference:
    obj, _ = NotificationPreference.objects.get_or_create(tenant=tenant, user=user)
    return obj


def mark_read(n: Notification) -> Notification:
    n.read_at = timezone.now()
    n.save(update_fields=["read_at"])
    return n


def unread_count(*, user, tenant) -> int:
    return Notification.objects.filter(
        tenant=tenant, user=user, read_at__isnull=True, archived_at__isnull=True,
    ).count()


def _send_email(*, to_email: str, subject: str, body: str, template: str = "",
               tenant=None) -> EmailLog:
    from django.core.mail import EmailMessage
    log = EmailLog.objects.create(
        tenant=tenant, to_email=to_email, subject=subject, body=body, template=template,
    )
    try:
        EmailMessage(subject=subject, body=body, to=[to_email]).send()
        log.sent_at = timezone.now()
        log.save(update_fields=["sent_at"])
    except Exception as exc:
        log.error = str(exc)
        log.save(update_fields=["error"])
    return log
