import pytest

from apps.notifications.tasks import dispatch_template


@pytest.mark.django_db
def test_dispatch_runs():
    r = dispatch_template("deposit.reminder", {"id": "x"})
    assert "template" in r
