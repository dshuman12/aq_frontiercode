import pytest

from apps.notifications.services import (
    create, get_or_create_prefs, mark_read, unread_count,
)


@pytest.mark.django_db
def test_create_default_subject(tenant, user):
    n = create(tenant=tenant, kind="inquiry.new", user=user)
    assert n.subject == "New catering inquiry"


@pytest.mark.django_db
def test_explicit_subject(tenant, user):
    n = create(tenant=tenant, kind="inquiry.new", user=user, subject="X")
    assert n.subject == "X"


@pytest.mark.django_db
def test_mark_read(tenant, user):
    n = create(tenant=tenant, kind="inquiry.new", user=user)
    mark_read(n)
    n.refresh_from_db()
    assert n.read_at is not None


@pytest.mark.django_db
def test_unread_count(tenant, user):
    create(tenant=tenant, kind="inquiry.new", user=user)
    create(tenant=tenant, kind="quote.viewed", user=user)
    assert unread_count(user=user, tenant=tenant) == 2


@pytest.mark.django_db
def test_prefs_idempotent(tenant, user):
    a = get_or_create_prefs(user, tenant)
    b = get_or_create_prefs(user, tenant)
    assert a.id == b.id
