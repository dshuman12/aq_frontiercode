"""Notifications + preferences + email log."""
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class Notification(TenantScoped):
    KIND_CHOICES = [
        ("inquiry.new", "New inquiry"),
        ("quote.sent", "Quote sent"), ("quote.viewed", "Quote viewed"),
        ("quote.approved", "Quote approved"),
        ("deposit.reminder", "Deposit reminder"),
        ("order.confirmed", "Order confirmed"),
        ("production.reminder", "Production reminder"),
        ("delivery.reminder", "Delivery reminder"),
        ("payment.received", "Payment received"),
        ("payment.reminder", "Payment reminder"),
        ("order.completed", "Order completed"),
        ("digest.daily", "Daily digest"),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                            related_name="notifications", null=True, blank=True)
    customer_email = models.EmailField(blank=True, default="")
    kind = models.CharField(max_length=48, choices=KIND_CHOICES, db_index=True)
    subject = models.CharField(max_length=200)
    body = models.TextField()
    metadata = models.JSONField(default=dict, blank=True)
    read_at = models.DateTimeField(null=True, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]


class NotificationPreference(TenantScoped):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                               related_name="notification_prefs")
    email_inquiries = models.BooleanField(default=True)
    email_quote_events = models.BooleanField(default=True)
    email_deposit_reminders = models.BooleanField(default=True)
    email_production_reminders = models.BooleanField(default=True)
    email_delivery_reminders = models.BooleanField(default=True)
    email_payment_events = models.BooleanField(default=True)
    daily_digest = models.BooleanField(default=False)


class EmailLog(TenantScoped):
    to_email = models.EmailField()
    subject = models.CharField(max_length=200)
    body = models.TextField()
    template = models.CharField(max_length=80, blank=True, default="")
    sent_at = models.DateTimeField(null=True, blank=True)
    error = models.TextField(blank=True, default="")
