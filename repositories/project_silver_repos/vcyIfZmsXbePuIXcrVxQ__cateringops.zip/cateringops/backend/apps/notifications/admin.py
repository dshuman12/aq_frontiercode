from django.contrib import admin
from apps.notifications.models import EmailLog, Notification, NotificationPreference


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("kind", "user", "subject", "read_at")
    list_filter = ("kind",)


admin.site.register(EmailLog)
admin.site.register(NotificationPreference)
