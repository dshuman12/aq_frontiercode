from rest_framework import serializers
from apps.notifications.models import Notification, NotificationPreference


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ["id", "kind", "subject", "body", "metadata", "read_at", "created_at"]


class PrefSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationPreference
        fields = ["email_inquiries", "email_quote_events", "email_deposit_reminders",
                  "email_production_reminders", "email_delivery_reminders",
                  "email_payment_events", "daily_digest"]
