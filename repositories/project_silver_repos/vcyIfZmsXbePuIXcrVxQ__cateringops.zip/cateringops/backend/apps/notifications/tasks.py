from celery import shared_task


@shared_task
def notify_new_inquiry(inquiry_id: str):
    from apps.inquiries.models import Inquiry
    from apps.notifications.services import _send_email, create
    try:
        inq = Inquiry.objects.select_related("tenant").get(pk=inquiry_id)
    except Inquiry.DoesNotExist:
        return {"missing": inquiry_id}
    n = create(tenant=inq.tenant, kind="inquiry.new",
              metadata={"inquiry_id": str(inq.id), "event_date": inq.event_date.isoformat()})
    if inq.tenant.contact_email:
        _send_email(to_email=inq.tenant.contact_email, subject=n.subject, body=n.body,
                   template="inquiry.new", tenant=inq.tenant)
    return {"notification_id": str(n.id)}


@shared_task
def dispatch_template(template: str, context: dict):
    return {"template": template, "context_keys": list(context.keys())}


@shared_task
def daily_digest():
    from apps.orders.selectors import upcoming
    from apps.notifications.services import create
    from apps.tenants.models import Tenant
    n = 0
    for t in Tenant.objects.filter(archived_at__isnull=True):
        cnt = upcoming(t, days=3).count()
        create(tenant=t, kind="digest.daily", metadata={"upcoming_count": cnt})
        n += 1
    return {"digests": n}


@shared_task
def cleanup_notifications(days: int = 90):
    from datetime import timedelta
    from django.utils import timezone
    from apps.notifications.models import Notification
    cutoff = timezone.now() - timedelta(days=days)
    return Notification.objects.filter(read_at__lt=cutoff, archived_at__isnull=True
                                       ).update(archived_at=timezone.now())
