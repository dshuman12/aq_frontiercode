from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.notifications import services
from apps.notifications.models import Notification
from apps.notifications.serializers import NotificationSerializer, PrefSerializer
from apps.tenants.models import Tenant


class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = NotificationSerializer

    def get_queryset(self):
        return Notification.objects.filter(
            tenant_id=self.kwargs["tenant_id"], user=self.request.user,
            archived_at__isnull=True,
        )

    @action(detail=False, methods=["get"])
    def unread_count(self, request, tenant_id=None):
        t = Tenant.objects.get(pk=tenant_id)
        return Response({"count": services.unread_count(user=request.user, tenant=t)})

    @action(detail=True, methods=["post"])
    def read(self, request, tenant_id=None, pk=None):
        services.mark_read(self.get_object())
        return Response(NotificationSerializer(self.get_object()).data)

    @action(detail=False, methods=["get", "put"])
    def preferences(self, request, tenant_id=None):
        t = Tenant.objects.get(pk=tenant_id)
        pref = services.get_or_create_prefs(request.user, t)
        if request.method == "PUT":
            s = PrefSerializer(pref, data=request.data, partial=True)
            s.is_valid(raise_exception=True)
            s.save()
        return Response(PrefSerializer(pref).data)
