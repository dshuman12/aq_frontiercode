from django.core.management.base import BaseCommand

from apps.orders.tasks import archive_old_completed


class Command(BaseCommand):
    help = "Archive completed orders older than --days (default 365)."

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=365)

    def handle(self, *args, days=365, **options):
        r = archive_old_completed(days=days)
        self.stdout.write(self.style.SUCCESS(f"Archived {r['archived']}"))
