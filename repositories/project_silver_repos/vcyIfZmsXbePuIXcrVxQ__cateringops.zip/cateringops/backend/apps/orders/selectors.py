from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Sum
from django.utils import timezone

from apps.orders.models import Order


def orders_for(tenant, *, status=None, location=None):
    qs = Order.objects.filter(tenant=tenant, archived_at__isnull=True)
    if status:
        qs = qs.filter(status=status)
    if location is not None:
        qs = qs.filter(location=location)
    return qs.select_related("customer", "location").order_by("event_date", "event_time")


def todays(tenant):
    return orders_for(tenant).filter(event_date=timezone.now().date())


def upcoming(tenant, days: int = 14):
    today = timezone.now().date()
    return orders_for(tenant).filter(event_date__gte=today,
                                     event_date__lte=today + timedelta(days=days))


def revenue_in_range(tenant, *, since: date, until: date) -> Decimal:
    total = (Order.objects.filter(
        tenant=tenant, event_date__gte=since, event_date__lte=until,
        status="completed", archived_at__isnull=True,
    ).aggregate(s=Sum("total"))["s"])
    return total or Decimal("0.00")
