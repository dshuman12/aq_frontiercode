"""When an order is confirmed, generate the production plan."""
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.orders.models import OrderStatusHistory


@receiver(post_save, sender=OrderStatusHistory)
def on_status(sender, instance, created, **kwargs):
    if not created:
        return
    if instance.to_status == "confirmed":
        from apps.production.tasks import generate_production_plan
        generate_production_plan.delay(str(instance.order_id))
