from datetime import timedelta

from celery import shared_task
from django.utils import timezone


@shared_task
def archive_old_completed(days: int = 365):
    from apps.orders.models import Order
    cutoff = timezone.now() - timedelta(days=days)
    n = Order.objects.filter(
        status="completed", completed_at__lt=cutoff, archived_at__isnull=True,
    ).update(archived_at=timezone.now())
    return {"archived": n}
