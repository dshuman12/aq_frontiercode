from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.orders.views import OrderViewSet, public_order

router = DefaultRouter()
router.register("", OrderViewSet, basename="order")

urlpatterns = [
    path("public/<str:token>/", public_order),
    path("", include(router.urls)),
]
