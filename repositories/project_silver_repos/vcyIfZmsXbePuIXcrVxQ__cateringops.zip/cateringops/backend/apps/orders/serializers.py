from rest_framework import serializers
from apps.orders.models import (
    Order, OrderAttachment, OrderItem, OrderNote, OrderStatusHistory,
)


class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = ["id", "kind", "label", "quantity", "unit_price", "line_total",
                  "package_id", "menu_item_id", "note", "sort_order"]


class NoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderNote
        fields = ["id", "intent", "body", "author_id", "created_at"]


class HistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderStatusHistory
        fields = ["id", "from_status", "to_status", "actor_id", "note", "at"]


class AttachmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderAttachment
        fields = ["id", "file_url", "filename", "content_type", "size_bytes",
                  "is_signed_agreement"]


class OrderListSerializer(serializers.ModelSerializer):
    customer_name = serializers.SerializerMethodField()
    location_name = serializers.CharField(source="location.name", read_only=True)

    class Meta:
        model = Order
        fields = ["id", "order_number", "customer_id", "customer_name",
                  "location_id", "location_name", "event_date", "event_time",
                  "guest_count", "fulfillment", "total", "deposit_paid_amount",
                  "remaining_balance", "status"]

    def get_customer_name(self, o):
        return o.customer.company_name or o.customer.primary_contact_name or o.customer.primary_email


class OrderDetailSerializer(OrderListSerializer):
    items = ItemSerializer(many=True, read_only=True)
    status_history = HistorySerializer(many=True, read_only=True)
    notes = NoteSerializer(many=True, source="notes_list", read_only=True)
    attachments = AttachmentSerializer(many=True, read_only=True)

    class Meta(OrderListSerializer.Meta):
        fields = OrderListSerializer.Meta.fields + [
            "subtotal", "discount_total", "tax_total", "service_charge_total",
            "delivery_fee", "deposit_required_amount", "delivery_address",
            "delivery_postal_code", "internal_note", "customer_note", "dietary_notes",
            "confirmed_at", "in_production_at", "ready_at", "completed_at",
            "cancelled_at", "cancelled_reason",
            "items", "status_history", "notes", "attachments",
        ]


class OrderPublicSerializer(serializers.ModelSerializer):
    tenant_name = serializers.CharField(source="tenant.name", read_only=True)

    class Meta:
        model = Order
        fields = ["id", "order_number", "event_date", "event_time", "guest_count",
                  "fulfillment", "delivery_address", "status", "total",
                  "deposit_paid_amount", "remaining_balance", "tenant_name"]
