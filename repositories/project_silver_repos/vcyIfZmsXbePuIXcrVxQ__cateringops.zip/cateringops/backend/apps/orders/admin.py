from django.contrib import admin
from apps.orders.models import Order, OrderAttachment, OrderItem, OrderNote, OrderStatusHistory


class ItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("order_number", "customer", "event_date", "total", "status", "tenant")
    list_filter = ("status",)
    inlines = [ItemInline]


admin.site.register(OrderNote)
admin.site.register(OrderAttachment)
admin.site.register(OrderStatusHistory)
