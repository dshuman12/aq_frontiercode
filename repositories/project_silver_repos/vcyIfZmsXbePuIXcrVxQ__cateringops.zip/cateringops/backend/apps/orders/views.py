from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from apps.orders import serializers as ser, services
from apps.orders.models import Order
from apps.tenants.models import Tenant


class OrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        return ser.OrderDetailSerializer if self.action != "list" else ser.OrderListSerializer

    def get_queryset(self):
        return Order.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("items", "status_history", "notes_list", "attachments")

    @action(detail=False, methods=["post"], url_path="from-quote")
    def from_quote(self, request, tenant_id=None):
        from apps.quotes.models import Quote
        t = Tenant.objects.get(pk=tenant_id)
        q = Quote.objects.get(pk=request.data["quote"], tenant=t)
        o = services.create_from_quote(quote=q, actor=request.user)
        return Response(ser.OrderDetailSerializer(o).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def confirm(self, request, tenant_id=None, pk=None):
        services.confirm(self.get_object(), actor=request.user)
        return Response(ser.OrderDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def start_production(self, request, tenant_id=None, pk=None):
        services.start_production(self.get_object(), actor=request.user)
        return Response(ser.OrderDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def mark_ready(self, request, tenant_id=None, pk=None):
        services.mark_ready(self.get_object(), actor=request.user)
        return Response(ser.OrderDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def complete(self, request, tenant_id=None, pk=None):
        services.complete(self.get_object(), actor=request.user)
        return Response(ser.OrderDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def cancel(self, request, tenant_id=None, pk=None):
        services.cancel(self.get_object(), reason=request.data.get("reason", ""),
                       actor=request.user)
        return Response(ser.OrderDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def note(self, request, tenant_id=None, pk=None):
        n = services.add_note(self.get_object(), body=request.data["body"],
                             intent=request.data.get("intent", "internal"),
                             author=request.user)
        return Response(ser.NoteSerializer(n).data, status=status.HTTP_201_CREATED)


@api_view(["GET"])
@permission_classes([AllowAny])
def public_order(request, token):
    o = services.find_by_public_token(token)
    return Response(ser.OrderPublicSerializer(o).data)
