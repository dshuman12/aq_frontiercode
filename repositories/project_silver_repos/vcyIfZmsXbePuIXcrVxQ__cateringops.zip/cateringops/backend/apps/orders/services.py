from __future__ import annotations
import secrets
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import Conflict, NotFound, StateError, ValidationError
from apps.orders.models import Order, OrderItem, OrderNote, OrderStatusHistory

ALLOWED = {
    "pending_deposit": {"confirmed", "cancelled"},
    "confirmed": {"in_production", "cancelled"},
    "in_production": {"ready_for_pickup", "out_for_delivery", "cancelled"},
    "ready_for_pickup": {"completed", "cancelled"},
    "out_for_delivery": {"completed", "cancelled"},
    "completed": {"refunded"},
    "cancelled": {"refunded"},
    "refunded": set(),
}


def _number(tenant) -> str:
    seq = Order.objects.filter(tenant=tenant).count() + 1
    return f"O-{timezone.now().year}-{seq:05d}"


@transaction.atomic
def create_from_quote(*, quote, actor=None) -> Order:
    if hasattr(quote, "order"):
        raise Conflict("order already exists")
    if quote.status not in ("approved", "viewed"):
        raise StateError("quote must be approved")
    o = Order.objects.create(
        tenant=quote.tenant, order_number=_number(quote.tenant),
        quote=quote, customer=quote.customer, location=quote.location,
        event_date=quote.event_date, event_time=quote.event_time,
        guest_count=quote.guest_count, fulfillment=quote.fulfillment,
        delivery_address=quote.delivery_address,
        subtotal=quote.subtotal, discount_total=quote.discount_total,
        tax_total=quote.tax_total, service_charge_total=quote.service_charge_total,
        delivery_fee=quote.delivery_fee, total=quote.total,
        deposit_required_amount=quote.deposit_required_amount,
        remaining_balance=quote.total,
        public_token=secrets.token_urlsafe(40),
        created_by=actor,
    )
    for ql in quote.lines.all():
        OrderItem.objects.create(
            tenant=quote.tenant, order=o, kind=ql.kind,
            package=ql.package, menu_item=ql.menu_item,
            label=ql.label, quantity=ql.quantity,
            unit_price=ql.unit_price, line_total=ql.line_total,
            note=ql.note, sort_order=ql.sort_order,
        )
    OrderStatusHistory.objects.create(
        tenant=o.tenant, order=o, from_status="", to_status="pending_deposit",
        actor=actor, note=f"from quote {quote.quote_number}",
    )
    if o.deposit_required_amount <= 0:
        _transition(o, "confirmed", actor=actor, note="no deposit required")
    return o


@transaction.atomic
def create_direct(*, tenant, customer, location, event_date, event_time, guest_count,
                 items: list, fulfillment="delivery", delivery_address="", actor=None) -> Order:
    if not items:
        raise ValidationError("at least one item required")
    o = Order.objects.create(
        tenant=tenant, order_number=_number(tenant), customer=customer, location=location,
        event_date=event_date, event_time=event_time, guest_count=guest_count,
        fulfillment=fulfillment, delivery_address=delivery_address,
        public_token=secrets.token_urlsafe(40), created_by=actor,
    )
    subtotal = Decimal("0.00")
    for i, it in enumerate(items):
        line_total = Decimal(str(it["unit_price"])) * Decimal(it["quantity"])
        subtotal += line_total
        OrderItem.objects.create(
            tenant=tenant, order=o, kind=it.get("kind", "custom"),
            label=it["label"], quantity=it["quantity"],
            unit_price=Decimal(str(it["unit_price"])), line_total=line_total,
            note=it.get("note", ""), sort_order=i,
        )
    o.subtotal = subtotal
    o.total = subtotal
    o.remaining_balance = subtotal
    o.save(update_fields=["subtotal", "total", "remaining_balance"])
    OrderStatusHistory.objects.create(
        tenant=tenant, order=o, from_status="", to_status="pending_deposit",
        actor=actor, note="manually created",
    )
    return o


@transaction.atomic
def _transition(o: Order, to_status: str, actor=None, note: str = "") -> Order:
    if to_status not in ALLOWED.get(o.status, set()):
        raise Conflict(f"cannot transition {o.status} → {to_status}")
    fr = o.status
    o.status = to_status
    if to_status == "confirmed":
        o.confirmed_at = timezone.now()
    elif to_status == "in_production":
        o.in_production_at = timezone.now()
    elif to_status in ("ready_for_pickup", "out_for_delivery"):
        o.ready_at = timezone.now()
    elif to_status == "completed":
        o.completed_at = timezone.now()
    elif to_status == "cancelled":
        o.cancelled_at = timezone.now()
        o.cancelled_reason = note
    o.save()
    OrderStatusHistory.objects.create(
        tenant=o.tenant, order=o, from_status=fr, to_status=to_status,
        actor=actor, note=note,
    )
    return o


def confirm(order: Order, *, actor=None) -> Order:
    if order.deposit_required_amount > 0 and order.deposit_paid_amount < order.deposit_required_amount:
        raise StateError("deposit not fully paid")
    return _transition(order, "confirmed", actor=actor, note="deposit received")


def start_production(order: Order, *, actor=None) -> Order:
    return _transition(order, "in_production", actor=actor)


def mark_ready(order: Order, *, actor=None) -> Order:
    target = "out_for_delivery" if order.fulfillment == "delivery" else "ready_for_pickup"
    return _transition(order, target, actor=actor)


def complete(order: Order, *, actor=None) -> Order:
    return _transition(order, "completed", actor=actor)


def cancel(order: Order, *, reason: str, actor=None) -> Order:
    return _transition(order, "cancelled", actor=actor, note=reason)


def apply_deposit_payment(order: Order, amount) -> Order:
    amount = Decimal(amount)
    if amount <= 0:
        raise ValidationError("amount > 0")
    order.deposit_paid_amount = (order.deposit_paid_amount + amount).quantize(Decimal("0.01"))
    order.remaining_balance = max(order.total - order.deposit_paid_amount, Decimal("0"))
    order.save(update_fields=["deposit_paid_amount", "remaining_balance"])
    return order


def add_note(order: Order, *, body: str, intent: str = "internal", author=None) -> OrderNote:
    return OrderNote.objects.create(
        tenant=order.tenant, order=order, body=body, intent=intent, author=author,
    )


def find_by_public_token(token: str) -> Order:
    try:
        return Order.objects.get(public_token=token, archived_at__isnull=True)
    except Order.DoesNotExist as exc:
        raise NotFound("order not found") from exc
