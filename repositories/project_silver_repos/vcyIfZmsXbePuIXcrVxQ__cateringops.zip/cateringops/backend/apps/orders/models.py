"""Order: a confirmed catering job."""
import secrets
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class Order(TenantScoped):
    STATUS_CHOICES = [
        ("pending_deposit", "Pending deposit"), ("confirmed", "Confirmed"),
        ("in_production", "In production"), ("ready_for_pickup", "Ready for pickup"),
        ("out_for_delivery", "Out for delivery"), ("completed", "Completed"),
        ("cancelled", "Cancelled"), ("refunded", "Refunded"),
    ]
    order_number = models.CharField(max_length=32, unique=True)
    quote = models.OneToOneField("quotes.Quote", on_delete=models.PROTECT,
                                related_name="order", null=True, blank=True)
    customer = models.ForeignKey("customers.Customer", on_delete=models.PROTECT, related_name="orders")
    location = models.ForeignKey("locations.Location", on_delete=models.PROTECT, related_name="+")

    event_date = models.DateField()
    event_time = models.TimeField()
    guest_count = models.PositiveIntegerField()
    fulfillment = models.CharField(max_length=16, default="delivery")
    delivery_address = models.CharField(max_length=400, blank=True, default="")
    delivery_postal_code = models.CharField(max_length=24, blank=True, default="")

    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    discount_total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    tax_total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    service_charge_total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    delivery_fee = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    deposit_required_amount = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    deposit_paid_amount = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    remaining_balance = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")

    status = models.CharField(max_length=24, choices=STATUS_CHOICES, default="pending_deposit",
                              db_index=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    in_production_at = models.DateTimeField(null=True, blank=True)
    ready_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancelled_reason = models.TextField(blank=True, default="")

    internal_note = models.TextField(blank=True, default="")
    customer_note = models.TextField(blank=True, default="")
    dietary_notes = models.TextField(blank=True, default="")

    public_token = models.CharField(max_length=80, unique=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, related_name="+")

    class Meta:
        indexes = [
            models.Index(fields=["tenant", "status", "event_date"]),
            models.Index(fields=["customer"]),
        ]


class OrderItem(TenantScoped):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    kind = models.CharField(max_length=16,
        choices=[("package", "Package"), ("menu_item", "Menu item"), ("custom", "Custom")])
    package = models.ForeignKey("packages.Package", on_delete=models.SET_NULL,
                               null=True, blank=True, related_name="+")
    menu_item = models.ForeignKey("menu.MenuItem", on_delete=models.SET_NULL,
                                 null=True, blank=True, related_name="+")
    label = models.CharField(max_length=200)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=12, decimal_places=2)
    note = models.CharField(max_length=300, blank=True, default="")
    sort_order = models.IntegerField(default=0)

    class Meta:
        ordering = ["sort_order"]


class OrderStatusHistory(TenantScoped):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="status_history")
    from_status = models.CharField(max_length=24)
    to_status = models.CharField(max_length=24)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                             null=True, related_name="+")
    note = models.CharField(max_length=400, blank=True, default="")
    at = models.DateTimeField(auto_now_add=True)


class OrderNote(TenantScoped):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="notes_list")
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                              null=True, related_name="+")
    intent = models.CharField(max_length=16,
        choices=[("internal", "Internal"), ("customer", "Customer-visible")], default="internal")
    body = models.TextField()


class OrderAttachment(TenantScoped):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="attachments")
    file_url = models.URLField()
    filename = models.CharField(max_length=200)
    content_type = models.CharField(max_length=80, blank=True, default="")
    size_bytes = models.PositiveBigIntegerField(default=0)
    is_signed_agreement = models.BooleanField(default=False)
