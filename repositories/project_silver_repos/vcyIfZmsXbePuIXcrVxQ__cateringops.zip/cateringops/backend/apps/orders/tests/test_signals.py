"""Confirming an order should fire a Celery task to generate production plan."""
import pytest
from unittest.mock import patch


@pytest.mark.django_db
def test_confirm_triggers_plan(approved_quote, user):
    from apps.orders.services import apply_deposit_payment, confirm, create_from_quote
    with patch("apps.production.tasks.generate_production_plan.delay") as mock_delay:
        o = create_from_quote(quote=approved_quote, actor=user)
        apply_deposit_payment(o, o.deposit_required_amount)
        confirm(o, actor=user)
        assert mock_delay.called
