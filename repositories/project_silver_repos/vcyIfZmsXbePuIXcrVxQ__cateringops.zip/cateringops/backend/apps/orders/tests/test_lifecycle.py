import pytest
from decimal import Decimal

from apps.core.exceptions import Conflict, StateError, ValidationError
from apps.orders.services import (
    apply_deposit_payment, cancel, complete, confirm,
    create_from_quote, mark_ready, start_production,
)


@pytest.mark.django_db
def test_no_full_deposit_blocks_confirm(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    apply_deposit_payment(o, Decimal("10"))
    with pytest.raises(StateError):
        confirm(o, actor=user)


@pytest.mark.django_db
def test_full_deposit_confirms(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    apply_deposit_payment(o, o.deposit_required_amount)
    confirm(o, actor=user)
    o.refresh_from_db()
    assert o.status == "confirmed"


@pytest.mark.django_db
def test_happy_path_delivery(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    apply_deposit_payment(o, o.deposit_required_amount)
    confirm(o, actor=user)
    start_production(o, actor=user)
    mark_ready(o, actor=user)
    o.refresh_from_db()
    assert o.status == "out_for_delivery"
    complete(o, actor=user)
    o.refresh_from_db()
    assert o.status == "completed"


@pytest.mark.django_db
def test_pickup_branch(approved_quote, user):
    approved_quote.fulfillment = "pickup"
    approved_quote.save(update_fields=["fulfillment"])
    o = create_from_quote(quote=approved_quote, actor=user)
    apply_deposit_payment(o, o.deposit_required_amount)
    confirm(o, actor=user)
    start_production(o, actor=user)
    mark_ready(o, actor=user)
    o.refresh_from_db()
    assert o.status == "ready_for_pickup"


@pytest.mark.django_db
def test_cancel_records_reason(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    cancel(o, reason="event cancelled", actor=user)
    o.refresh_from_db()
    assert o.status == "cancelled"
    assert o.cancelled_reason == "event cancelled"


@pytest.mark.django_db
def test_amount_positive(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    with pytest.raises(ValidationError):
        apply_deposit_payment(o, Decimal("0"))


@pytest.mark.django_db
def test_overpay_clamps(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    apply_deposit_payment(o, o.total + Decimal("100"))
    o.refresh_from_db()
    assert o.remaining_balance == Decimal("0.00")


@pytest.mark.django_db
def test_skip_states_blocked(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    apply_deposit_payment(o, o.deposit_required_amount)
    confirm(o, actor=user)
    with pytest.raises(Conflict):
        complete(o, actor=user)
