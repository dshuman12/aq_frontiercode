import pytest
from datetime import date, time, timedelta
from decimal import Decimal


@pytest.mark.django_db
def test_todays(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    from apps.orders.selectors import todays
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today(), event_time=time(12), guest_count=10,
                     items=[{"label": "X", "quantity": 1, "unit_price": "100"}], actor=user)
    assert o in todays(tenant)


@pytest.mark.django_db
def test_upcoming(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    from apps.orders.selectors import upcoming
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    create_direct(tenant=tenant, customer=c, location=location,
                 event_date=date.today() + timedelta(days=7), event_time=time(12),
                 guest_count=10, items=[{"label": "X", "quantity": 1, "unit_price": "100"}], actor=user)
    create_direct(tenant=tenant, customer=c, location=location,
                 event_date=date.today() + timedelta(days=30), event_time=time(12),
                 guest_count=10, items=[{"label": "Y", "quantity": 1, "unit_price": "200"}], actor=user)
    assert upcoming(tenant, days=14).count() == 1


@pytest.mark.django_db
def test_revenue_in_range(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import (
        apply_deposit_payment, complete, confirm, create_direct,
        mark_ready, start_production,
    )
    from apps.orders.selectors import revenue_in_range
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today(), event_time=time(12), guest_count=10,
                     items=[{"label": "X", "quantity": 1, "unit_price": "150"}], actor=user)
    apply_deposit_payment(o, o.total); confirm(o, actor=user)
    start_production(o, actor=user); mark_ready(o, actor=user); complete(o, actor=user)
    rev = revenue_in_range(tenant, since=date.today() - timedelta(days=1),
                          until=date.today() + timedelta(days=1))
    assert rev == Decimal("150.00")
