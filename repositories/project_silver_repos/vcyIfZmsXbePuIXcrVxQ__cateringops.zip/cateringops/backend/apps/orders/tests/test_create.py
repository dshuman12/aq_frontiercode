import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.core.exceptions import Conflict, StateError, ValidationError
from apps.orders.services import create_direct, create_from_quote


@pytest.mark.django_db
def test_from_quote_copies_lines(approved_quote, user):
    o = create_from_quote(quote=approved_quote, actor=user)
    assert o.items.count() == approved_quote.lines.count()
    assert o.total == approved_quote.total
    assert o.status == "pending_deposit"


@pytest.mark.django_db
def test_cannot_create_twice(approved_quote, user):
    create_from_quote(quote=approved_quote, actor=user)
    with pytest.raises(Conflict):
        create_from_quote(quote=approved_quote, actor=user)


@pytest.fixture
def draft_q(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.quotes.services import create_draft
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    return create_draft(tenant=tenant, customer=c, location=location,
                       event_date=date.today() + timedelta(days=5),
                       event_time=time(12), guest_count=10, created_by=user)


@pytest.mark.django_db
def test_unapproved_blocks(draft_q, user):
    with pytest.raises(StateError):
        create_from_quote(quote=draft_q, actor=user)


@pytest.mark.django_db
def test_direct_with_items(tenant, location, user):
    from apps.customers.services import create_customer
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(
        tenant=tenant, customer=c, location=location,
        event_date=date.today() + timedelta(days=5), event_time=time(12),
        guest_count=10,
        items=[{"label": "Box A", "quantity": 10, "unit_price": "12.00", "kind": "menu_item"}],
        actor=user,
    )
    assert o.total == Decimal("120.00")
    assert o.items.count() == 1


@pytest.mark.django_db
def test_direct_requires_items(tenant, location, user):
    from apps.customers.services import create_customer
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    with pytest.raises(ValidationError):
        create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today() + timedelta(days=5), event_time=time(12),
                     guest_count=10, items=[], actor=user)
