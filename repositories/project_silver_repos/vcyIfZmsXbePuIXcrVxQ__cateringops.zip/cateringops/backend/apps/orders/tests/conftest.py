import pytest


@pytest.fixture
def approved_quote(tenant, location, user):
    from datetime import date, time, timedelta
    from apps.customers.services import create_customer
    from apps.menu.services import create_category, create_item
    from apps.quotes.services import add_menu_line, approve, create_draft, send_quote

    c = create_customer(tenant=tenant, kind="business", company_name="Acme",
                       primary_email="ops@acme.test")
    cat = create_category(tenant=tenant, slug="x", name="X", kind="boxed_lunch")
    item = create_item(tenant=tenant, category=cat, name="Box", price="15", serves=1)
    q = create_draft(tenant=tenant, customer=c, location=location,
                    event_date=date.today() + timedelta(days=14),
                    event_time=time(12), guest_count=40, created_by=user)
    add_menu_line(quote=q, menu_item=item, quantity=40)
    send_quote(quote=q)
    approve(quote=q)
    return q
