"""Cross-tenant orders 404."""
import pytest


@pytest.mark.django_db
def test_cross_tenant_404(api_client, another_user, tenant, approved_quote):
    from apps.tenants.services import onboard_tenant
    from apps.orders.services import create_from_quote
    other = onboard_tenant(owner=another_user, slug="other", name="Other")
    o = create_from_quote(quote=approved_quote, actor=approved_quote.created_by)

    api_client.force_authenticate(another_user)
    r = api_client.get(f"/api/t/{other.id}/orders/{o.id}/")
    assert r.status_code == 404
