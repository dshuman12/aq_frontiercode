from __future__ import annotations
from decimal import Decimal

from django.db import transaction

from apps.core.exceptions import Conflict, ValidationError
from apps.menu.models import MenuAvailability, MenuCategory, MenuItem, MenuItemPhoto


@transaction.atomic
def create_category(*, tenant, slug: str, name: str, kind: str, sort_order: int = 0) -> MenuCategory:
    if MenuCategory.objects.filter(tenant=tenant, slug=slug).exists():
        raise Conflict(f"category {slug!r} exists")
    return MenuCategory.objects.create(
        tenant=tenant, slug=slug, name=name, kind=kind, sort_order=sort_order,
    )


@transaction.atomic
def create_item(*, tenant, category: MenuCategory, name: str, price,
               serves: int = 1, **fields) -> MenuItem:
    if Decimal(price) <= 0:
        raise ValidationError("price must be positive")
    if serves < 1:
        raise ValidationError("serves >= 1")
    return MenuItem.objects.create(
        tenant=tenant, category=category, name=name, price=Decimal(price),
        serves=serves, **fields,
    )


def add_photo(*, item: MenuItem, url: str, alt: str = "", sort_order: int = 0) -> MenuItemPhoto:
    return MenuItemPhoto.objects.create(
        tenant=item.tenant, item=item, url=url, alt=alt, sort_order=sort_order,
    )


def set_availability(*, item: MenuItem, weekday: int, available: bool = True,
                    cutoff_time=None) -> MenuAvailability:
    obj, _ = MenuAvailability.objects.update_or_create(
        tenant=item.tenant, item=item, weekday=weekday,
        defaults={"available": available, "cutoff_time": cutoff_time},
    )
    return obj


def update_price(*, item: MenuItem, new_price) -> MenuItem:
    new_price = Decimal(new_price)
    if new_price <= 0:
        raise ValidationError("price must be positive")
    item.price = new_price
    item.save(update_fields=["price"])
    return item


def margin_percent(item: MenuItem) -> Decimal:
    if not item.price:
        return Decimal("0")
    return ((item.price - item.cost) / item.price * Decimal("100")).quantize(Decimal("0.01"))


def serves_total(item: MenuItem, quantity: int) -> int:
    return item.serves * quantity
