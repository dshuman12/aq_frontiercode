from django.contrib import admin
from apps.menu.models import MenuAvailability, MenuCategory, MenuItem, MenuItemPhoto


@admin.register(MenuCategory)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "tenant")


class PhotoInline(admin.TabularInline):
    model = MenuItemPhoto
    extra = 0


@admin.register(MenuItem)
class ItemAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "price", "serves", "is_available")
    inlines = [PhotoInline]


admin.site.register(MenuAvailability)
