"""Catering menu: categories → items, with availability + photos."""
from django.db import models
from apps.core.models import TenantScoped


class MenuCategory(TenantScoped):
    KIND_CHOICES = [
        ("breakfast", "Breakfast"), ("boxed_lunch", "Boxed lunches"),
        ("sandwich_platter", "Sandwich platters"), ("hot_entree", "Hot entrees"),
        ("salad", "Salads"), ("side", "Sides"), ("dessert", "Desserts"),
        ("beverage", "Beverages"), ("extras", "Utensils/extras"),
        ("staffed", "Staffed events"),
    ]
    slug = models.SlugField(max_length=80)
    name = models.CharField(max_length=200)
    kind = models.CharField(max_length=32, choices=KIND_CHOICES)
    sort_order = models.IntegerField(default=0)
    description = models.TextField(blank=True, default="")

    class Meta:
        unique_together = [("tenant", "slug")]
        ordering = ["sort_order", "name"]


class MenuItem(TenantScoped):
    PACKAGING_CHOICES = [
        ("tray", "Tray"), ("box", "Box"), ("platter", "Platter"),
        ("buffet_pan", "Buffet pan"), ("individual", "Individual"),
        ("beverage_set", "Beverage set"),
    ]
    category = models.ForeignKey(MenuCategory, on_delete=models.PROTECT, related_name="items")
    sku = models.CharField(max_length=80, blank=True, default="")
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True, default="")
    packaging = models.CharField(max_length=24, choices=PACKAGING_CHOICES, default="tray")
    serves = models.PositiveIntegerField(default=1)
    serves_unit = models.CharField(max_length=24, default="people")
    minimum_quantity = models.PositiveIntegerField(default=1)
    lead_time_hours = models.PositiveIntegerField(default=24)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    cost = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    is_available = models.BooleanField(default=True)
    is_vegetarian = models.BooleanField(default=False)
    is_vegan = models.BooleanField(default=False)
    is_gluten_free = models.BooleanField(default=False)
    is_dairy_free = models.BooleanField(default=False)
    contains_nuts = models.BooleanField(default=False)
    tags = models.JSONField(default=list, blank=True)
    allergen_notes = models.TextField(blank=True, default="")

    class Meta:
        indexes = [
            models.Index(fields=["tenant", "category"]),
            models.Index(fields=["tenant", "is_available"]),
        ]
        ordering = ["category", "name"]


class MenuItemPhoto(TenantScoped):
    item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name="photos")
    url = models.URLField()
    alt = models.CharField(max_length=200, blank=True, default="")
    sort_order = models.IntegerField(default=0)


class MenuAvailability(TenantScoped):
    DAY_CHOICES = [(i, n) for i, n in enumerate(
        ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])]
    item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name="availability")
    weekday = models.IntegerField(choices=DAY_CHOICES)
    available = models.BooleanField(default=True)
    cutoff_time = models.TimeField(null=True, blank=True)

    class Meta:
        unique_together = [("item", "weekday")]
