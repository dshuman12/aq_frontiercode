import pytest


@pytest.mark.django_db
def test_auth_required(api_client, tenant):
    r = api_client.get(f"/api/t/{tenant.id}/menu/categories/")
    assert r.status_code in (401, 403)


@pytest.mark.django_db
def test_authed_lists(auth_client, tenant):
    from apps.menu.services import create_category
    create_category(tenant=tenant, slug="x", name="X", kind="breakfast")
    r = auth_client.get(f"/api/t/{tenant.id}/menu/categories/")
    assert r.status_code == 200
