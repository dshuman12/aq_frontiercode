import pytest
from datetime import date

from apps.menu.selectors import available_items, items_for_date
from apps.menu.services import create_category, create_item, set_availability


@pytest.mark.django_db
def test_unavailable_excluded(tenant):
    c = create_category(tenant=tenant, slug="x", name="X", kind="hot_entree")
    create_item(tenant=tenant, category=c, name="On", price="10")
    create_item(tenant=tenant, category=c, name="Off", price="10", is_available=False)
    names = [i.name for i in available_items(tenant)]
    assert "On" in names
    assert "Off" not in names


@pytest.mark.django_db
def test_items_for_date_filters_by_weekday(tenant):
    c = create_category(tenant=tenant, slug="x", name="X", kind="hot_entree")
    item = create_item(tenant=tenant, category=c, name="Weekday only", price="10")
    for d in range(5):
        set_availability(item=item, weekday=d, available=True)
    for d in (5, 6):
        set_availability(item=item, weekday=d, available=False)
    monday = date(2025, 6, 2)
    saturday = date(2025, 6, 7)
    assert item in items_for_date(tenant, monday)
    assert item not in items_for_date(tenant, saturday)


@pytest.mark.django_db
def test_set_availability_upserts(tenant):
    from datetime import time
    c = create_category(tenant=tenant, slug="x", name="X", kind="hot_entree")
    item = create_item(tenant=tenant, category=c, name="A", price="10")
    a = set_availability(item=item, weekday=2, available=True, cutoff_time=time(15))
    b = set_availability(item=item, weekday=2, available=False)
    assert a.id == b.id
    b.refresh_from_db()
    assert b.available is False
