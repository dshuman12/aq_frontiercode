import pytest
from decimal import Decimal

from apps.core.exceptions import Conflict, ValidationError
from apps.menu.services import (
    create_category, create_item, margin_percent, serves_total, update_price,
)


@pytest.mark.django_db
def test_duplicate_category_slug_rejected(tenant):
    create_category(tenant=tenant, slug="x", name="X", kind="breakfast")
    with pytest.raises(Conflict):
        create_category(tenant=tenant, slug="x", name="Y", kind="breakfast")


@pytest.fixture
def category(db, tenant):
    return create_category(tenant=tenant, slug="lunch", name="Lunch", kind="boxed_lunch")


@pytest.mark.django_db
def test_zero_price_rejected(tenant, category):
    with pytest.raises(ValidationError):
        create_item(tenant=tenant, category=category, name="bad", price="0")


@pytest.mark.django_db
def test_zero_serves_rejected(tenant, category):
    with pytest.raises(ValidationError):
        create_item(tenant=tenant, category=category, name="bad", price="10", serves=0)


@pytest.mark.django_db
def test_update_price_validates(tenant, category):
    i = create_item(tenant=tenant, category=category, name="X", price="10")
    with pytest.raises(ValidationError):
        update_price(item=i, new_price="-1")


@pytest.mark.django_db
def test_margin(tenant, category):
    i = create_item(tenant=tenant, category=category, name="X", price="20", cost="8")
    assert margin_percent(i) == Decimal("60.00")


@pytest.mark.django_db
def test_serves_total(tenant, category):
    i = create_item(tenant=tenant, category=category, name="X", price="10", serves=10)
    assert serves_total(i, 3) == 30
