from rest_framework import serializers
from apps.menu.models import MenuAvailability, MenuCategory, MenuItem, MenuItemPhoto


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuCategory
        fields = ["id", "slug", "name", "kind", "sort_order", "description"]


class PhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItemPhoto
        fields = ["id", "url", "alt", "sort_order"]


class AvailabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuAvailability
        fields = ["id", "weekday", "available", "cutoff_time"]


class ItemListSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)

    class Meta:
        model = MenuItem
        fields = ["id", "sku", "name", "category_id", "category_name",
                  "packaging", "serves", "minimum_quantity", "price", "is_available"]


class ItemDetailSerializer(ItemListSerializer):
    photos = PhotoSerializer(many=True, read_only=True)
    availability = AvailabilitySerializer(many=True, read_only=True)

    class Meta(ItemListSerializer.Meta):
        fields = ItemListSerializer.Meta.fields + [
            "description", "cost", "lead_time_hours",
            "is_vegetarian", "is_vegan", "is_gluten_free", "is_dairy_free",
            "contains_nuts", "tags", "allergen_notes", "photos", "availability",
        ]
