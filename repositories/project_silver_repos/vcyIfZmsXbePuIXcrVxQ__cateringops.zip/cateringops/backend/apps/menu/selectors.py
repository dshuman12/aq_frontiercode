from datetime import date

from apps.menu.models import MenuCategory, MenuItem


def available_items(tenant):
    return MenuItem.objects.filter(
        tenant=tenant, is_available=True, archived_at__isnull=True,
    ).select_related("category").order_by("category__sort_order", "name")


def items_for_date(tenant, dt: date):
    wd = dt.weekday()
    return [
        i for i in available_items(tenant)
        if not i.availability.filter(weekday=wd, available=False).exists()
    ]


def categories_with_counts(tenant):
    cats = MenuCategory.objects.filter(tenant=tenant, archived_at__isnull=True).order_by("sort_order")
    return [
        {"id": str(c.id), "slug": c.slug, "name": c.name, "kind": c.kind,
         "item_count": c.items.filter(is_available=True, archived_at__isnull=True).count()}
        for c in cats
    ]
