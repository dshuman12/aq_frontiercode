from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.menu import selectors, serializers as ser
from apps.menu.models import MenuCategory, MenuItem
from apps.tenants.models import Tenant


class CategoryViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ser.CategorySerializer

    def get_queryset(self):
        return MenuCategory.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).order_by("sort_order")

    def perform_create(self, serializer):
        serializer.save(tenant=Tenant.objects.get(pk=self.kwargs["tenant_id"]))


class ItemViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        return ser.ItemDetailSerializer if self.action != "list" else ser.ItemListSerializer

    def get_queryset(self):
        return MenuItem.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).select_related("category")

    def perform_create(self, serializer):
        serializer.save(tenant=Tenant.objects.get(pk=self.kwargs["tenant_id"]))

    @action(detail=False, methods=["get"])
    def category_overview(self, request, tenant_id=None):
        return Response(selectors.categories_with_counts(Tenant.objects.get(pk=tenant_id)))
