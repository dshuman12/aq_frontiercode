from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.menu.views import CategoryViewSet, ItemViewSet

router = DefaultRouter()
router.register("categories", CategoryViewSet, basename="menu-category")
router.register("items", ItemViewSet, basename="menu-item")

urlpatterns = [path("", include(router.urls))]
