from rest_framework import serializers
from apps.files.models import FileAsset


class FileAssetSerializer(serializers.ModelSerializer):
    class Meta:
        model = FileAsset
        fields = ["id", "kind", "filename", "file_url", "content_type",
                  "size_bytes", "uploaded_by_id", "created_at"]
