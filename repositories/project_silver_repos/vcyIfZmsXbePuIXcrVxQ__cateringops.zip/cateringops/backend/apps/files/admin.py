from django.contrib import admin
from apps.files.models import FileAsset


@admin.register(FileAsset)
class FileAdmin(admin.ModelAdmin):
    list_display = ("filename", "kind", "tenant", "created_at")
