from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from apps.files.models import FileAsset
from apps.files.serializers import FileAssetSerializer


class FileViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = FileAssetSerializer

    def get_queryset(self):
        return FileAsset.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        )
