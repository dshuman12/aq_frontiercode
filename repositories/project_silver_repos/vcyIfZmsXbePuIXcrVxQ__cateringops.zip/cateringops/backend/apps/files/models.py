from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class FileAsset(TenantScoped):
    KIND_CHOICES = [("photo", "Photo"), ("avatar", "Avatar"), ("logo", "Logo"),
                   ("attachment", "Attachment"), ("export", "Export"), ("other", "Other")]
    kind = models.CharField(max_length=16, choices=KIND_CHOICES, default="other")
    filename = models.CharField(max_length=200)
    file_url = models.URLField()
    content_type = models.CharField(max_length=80, blank=True, default="")
    size_bytes = models.PositiveBigIntegerField(default=0)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, related_name="+")
