from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.files.views import FileViewSet

router = DefaultRouter()
router.register("", FileViewSet, basename="file")

urlpatterns = [path("", include(router.urls))]
