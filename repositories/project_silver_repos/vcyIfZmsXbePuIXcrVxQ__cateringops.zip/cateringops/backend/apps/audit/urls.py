from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.audit.views import AuditViewSet

router = DefaultRouter()
router.register("", AuditViewSet, basename="audit")

urlpatterns = [path("", include(router.urls))]
