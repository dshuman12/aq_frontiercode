from apps.audit.models import AuditEntry


def record(*, tenant, actor, action: str, resource_type: str, resource_id: str,
          summary: str = "", before=None, after=None, severity: str = "audit",
          request_ip=None, request_path: str = "", user_agent: str = "") -> AuditEntry:
    return AuditEntry.objects.create(
        tenant=tenant, actor=actor, action=action, resource_type=resource_type,
        resource_id=resource_id, summary=summary[:400],
        before=before or {}, after=after or {}, severity=severity,
        request_ip=request_ip, request_path=request_path[:400],
        user_agent=user_agent[:400],
    )
