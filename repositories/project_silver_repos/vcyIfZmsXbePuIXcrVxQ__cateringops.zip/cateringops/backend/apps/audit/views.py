from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from apps.audit.models import AuditEntry
from apps.audit.serializers import AuditEntrySerializer


class AuditViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = AuditEntrySerializer

    def get_queryset(self):
        return AuditEntry.objects.filter(tenant_id=self.kwargs["tenant_id"])
