"""Append-only audit log."""
from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.core.models import TenantScoped


class AuditEntry(TenantScoped):
    SEVERITY_CHOICES = [("info", "Info"), ("warn", "Warn"),
                       ("error", "Error"), ("audit", "Audit")]
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                             null=True, related_name="+")
    action = models.CharField(max_length=120, db_index=True)
    resource_type = models.CharField(max_length=80, db_index=True)
    resource_id = models.CharField(max_length=80, db_index=True)
    severity = models.CharField(max_length=8, choices=SEVERITY_CHOICES, default="audit")
    summary = models.CharField(max_length=400, blank=True, default="")
    before = models.JSONField(default=dict, blank=True)
    after = models.JSONField(default=dict, blank=True)
    request_ip = models.GenericIPAddressField(null=True, blank=True)
    request_path = models.CharField(max_length=400, blank=True, default="")
    user_agent = models.CharField(max_length=400, blank=True, default="")
    at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ["-at"]

    def save(self, *args, **kwargs):
        if self.pk and not kwargs.pop("_force", False):
            raise Exception("AuditEntry is append-only")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise Exception("AuditEntry is append-only")
