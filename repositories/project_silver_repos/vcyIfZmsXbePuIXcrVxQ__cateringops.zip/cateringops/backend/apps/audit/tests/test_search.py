import pytest

from apps.audit.models import AuditEntry
from apps.audit.services import record


@pytest.mark.django_db
def test_query_by_resource(tenant, user):
    record(tenant=tenant, actor=user, action="x", resource_type="Order",
          resource_id="abc", summary="x")
    record(tenant=tenant, actor=user, action="y", resource_type="Quote",
          resource_id="def", summary="y")
    assert AuditEntry.objects.filter(tenant=tenant, resource_type="Order",
                                     resource_id="abc").count() == 1
