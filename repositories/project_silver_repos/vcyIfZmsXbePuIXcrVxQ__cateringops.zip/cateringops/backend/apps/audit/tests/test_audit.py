import pytest

from apps.audit.services import record


@pytest.mark.django_db
def test_record(tenant, user):
    e = record(tenant=tenant, actor=user, action="order.create",
              resource_type="Order", resource_id="abc", summary="x")
    assert e.action == "order.create"


@pytest.mark.django_db
def test_cannot_update(tenant, user):
    e = record(tenant=tenant, actor=user, action="x",
              resource_type="X", resource_id="1", summary="x")
    e.summary = "altered"
    with pytest.raises(Exception):
        e.save()


@pytest.mark.django_db
def test_cannot_delete(tenant, user):
    e = record(tenant=tenant, actor=user, action="x",
              resource_type="X", resource_id="1", summary="x")
    with pytest.raises(Exception):
        e.delete()


@pytest.mark.django_db
def test_summary_truncated(tenant, user):
    e = record(tenant=tenant, actor=user, action="x", resource_type="X",
              resource_id="1", summary="x" * 1000)
    assert len(e.summary) <= 400
