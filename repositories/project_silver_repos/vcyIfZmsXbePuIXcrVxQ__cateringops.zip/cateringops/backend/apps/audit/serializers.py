from rest_framework import serializers
from apps.audit.models import AuditEntry


class AuditEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditEntry
        fields = ["id", "actor_id", "action", "resource_type", "resource_id",
                  "summary", "severity", "before", "after",
                  "request_ip", "request_path", "user_agent", "at"]
