from django.contrib import admin
from apps.audit.models import AuditEntry


@admin.register(AuditEntry)
class AuditEntryAdmin(admin.ModelAdmin):
    list_display = ("at", "actor", "action", "resource_type", "resource_id", "severity")
    list_filter = ("severity",)
    readonly_fields = ("at", "actor", "action", "resource_type", "resource_id",
                      "severity", "summary", "before", "after",
                      "request_ip", "request_path", "user_agent")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
