"""Idempotency-Key cache helpers."""
from __future__ import annotations

import hashlib
import json

from django.core.cache import cache


def cache_key(key: str, scope: str) -> str:
    return f"idem:{scope}:{key}"


def get_cached(key: str, scope: str):
    return cache.get(cache_key(key, scope))


def save_response(key: str, scope: str, status_code: int, data: dict, ttl: int = 600):
    payload = json.dumps({"status": status_code, "data": data}, default=str)
    cache.set(cache_key(key, scope), payload, ttl)


def fingerprint(body: dict) -> str:
    return hashlib.sha256(json.dumps(body, sort_keys=True, default=str).encode()).hexdigest()
