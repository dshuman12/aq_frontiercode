"""Tiny feature-flag helper backed by settings."""
from __future__ import annotations

from django.conf import settings


def is_enabled(flag: str, *, tenant=None) -> bool:
    flags = getattr(settings, "FEATURE_FLAGS", {})
    if flag not in flags:
        return False
    config = flags[flag]
    if isinstance(config, bool):
        return config
    if isinstance(config, dict):
        if config.get("enabled") is False:
            return False
        allow = config.get("allowlist_tenant_slugs") or []
        if allow and tenant is not None:
            return tenant.slug in allow
        return bool(config.get("enabled", False))
    return False
