from django.core.cache import cache
from django.db import connection
from django.http import JsonResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny


@api_view(["GET"])
@permission_classes([AllowAny])
def live(request):
    return JsonResponse({"status": "ok"})


@api_view(["GET"])
@permission_classes([AllowAny])
def ready(request):
    checks = {"db": False, "cache": False}
    try:
        with connection.cursor() as c:
            c.execute("SELECT 1")
            checks["db"] = True
    except Exception:
        pass
    try:
        cache.set("__r__", "1", 1)
        checks["cache"] = cache.get("__r__") == "1"
    except Exception:
        pass
    ok = all(checks.values())
    return JsonResponse({"status": "ok" if ok else "degraded", **checks},
                       status=200 if ok else 503)
