"""Role-based access control.

Roles (from plan §4.3):
  owner, general_manager, catering_manager, kitchen_manager,
  chef, prep_staff, delivery_driver, billing_staff, viewer
"""
from __future__ import annotations

ROLE_PERMS: dict[str, list[str]] = {
    "owner": ["*"],
    "general_manager": [
        "tenants.*", "locations.*", "staff.*", "roles.*",
        "customers.*", "menu.*", "packages.*",
        "inquiries.*", "quotes.*", "orders.*", "production.*",
        "kitchen.*", "delivery.*", "billing.*", "payments.*",
        "documents.*", "notifications.*", "reports.*", "audit.read", "files.*",
    ],
    "catering_manager": [
        "customers.*", "menu.read", "menu.update", "packages.read", "packages.update",
        "inquiries.*", "quotes.*", "orders.*", "billing.*",
        "payments.read", "documents.*", "notifications.read", "reports.read", "files.*",
    ],
    "kitchen_manager": [
        "production.*", "kitchen.*", "menu.read", "packages.read", "orders.read",
    ],
    "chef": [
        "production.read", "production.update_status",
        "kitchen.read", "kitchen.update_status", "orders.read",
    ],
    "prep_staff": [
        "production.read", "production.update_status",
        "kitchen.read", "kitchen.update_status",
    ],
    "delivery_driver": ["delivery.read", "delivery.update_status", "orders.read"],
    "billing_staff": [
        "billing.*", "payments.*", "customers.read", "orders.read",
        "reports.read", "documents.read",
    ],
    "viewer": [
        "tenants.read", "locations.read", "staff.read", "customers.read",
        "menu.read", "packages.read", "inquiries.read", "quotes.read",
        "orders.read", "production.read", "kitchen.read", "delivery.read",
        "billing.read", "payments.read", "documents.read",
        "notifications.read", "reports.read",
    ],
}


def has_perm(role: str, perm: str) -> bool:
    if role not in ROLE_PERMS:
        return False
    for g in ROLE_PERMS[role]:
        if g == "*" or g == perm:
            return True
        if g.endswith(".*") and perm.startswith(g[:-2] + "."):
            return True
    return False


def require_perm(role: str, perm: str) -> None:
    from apps.core.exceptions import PermissionDenied
    if not has_perm(role, perm):
        raise PermissionDenied(f"role {role!r} cannot {perm}")
