import pytest

from apps.core.exceptions import PermissionDenied
from apps.core.permissions import has_perm, require_perm


def test_owner_wildcard():
    assert has_perm("owner", "anything.at.all")


@pytest.mark.parametrize("role,perm,expected", [
    ("general_manager", "quotes.send", True),
    ("catering_manager", "quotes.send", True),
    ("catering_manager", "production.update_status", False),
    ("kitchen_manager", "production.update_status", True),
    ("kitchen_manager", "billing.send", False),
    ("chef", "production.update_status", True),
    ("chef", "quotes.send", False),
    ("delivery_driver", "delivery.update_status", True),
    ("delivery_driver", "quotes.send", False),
    ("billing_staff", "billing.send", True),
    ("billing_staff", "production.update_status", False),
    ("viewer", "quotes.send", False),
])
def test_role_perms(role, perm, expected):
    assert has_perm(role, perm) is expected


def test_unknown_role():
    assert not has_perm("garbage", "anything")


def test_require_raises():
    with pytest.raises(PermissionDenied):
        require_perm("viewer", "quotes.send")
