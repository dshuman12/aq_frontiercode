import pytest


@pytest.mark.django_db
def test_live_always_ok(api_client):
    r = api_client.get("/health/live/")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


@pytest.mark.django_db
def test_ready_returns_db_status(api_client):
    r = api_client.get("/health/ready/")
    assert r.status_code in (200, 503)
    assert "db" in r.json()
