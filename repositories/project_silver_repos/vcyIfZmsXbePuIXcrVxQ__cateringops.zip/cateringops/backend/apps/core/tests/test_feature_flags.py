import pytest
from django.test import override_settings

from apps.core.feature_flags import is_enabled


def test_unknown_false():
    assert is_enabled("nope") is False


@override_settings(FEATURE_FLAGS={"foo": True})
def test_bool_true():
    assert is_enabled("foo") is True


@override_settings(FEATURE_FLAGS={"foo": {"enabled": True, "allowlist_tenant_slugs": ["a"]}})
def test_allowlist():
    class T:
        slug = "a"
    assert is_enabled("foo", tenant=T()) is True
    class S:
        slug = "b"
    assert is_enabled("foo", tenant=S()) is False
