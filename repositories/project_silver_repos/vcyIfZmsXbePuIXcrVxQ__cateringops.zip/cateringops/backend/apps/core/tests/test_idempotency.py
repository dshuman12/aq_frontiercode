from apps.core.idempotency import cache_key, fingerprint


def test_fingerprint_stable_for_key_order():
    a = {"a": 1, "b": 2}
    b = {"b": 2, "a": 1}
    assert fingerprint(a) == fingerprint(b)


def test_fingerprint_changes_for_value_changes():
    assert fingerprint({"a": 1}) != fingerprint({"a": 2})


def test_cache_key_scoped():
    assert cache_key("x", "quote.send") == "idem:quote.send:x"
