"""Domain exceptions + DRF handler."""
from __future__ import annotations

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import exception_handler as drf_handler


class AppError(Exception):
    http_status = status.HTTP_400_BAD_REQUEST
    code = "app_error"

    def __init__(self, message: str, *, code: str | None = None, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.code = code or self.code
        self.details = details or {}


class ValidationError(AppError):
    http_status = status.HTTP_400_BAD_REQUEST
    code = "validation_error"


class NotFound(AppError):
    http_status = status.HTTP_404_NOT_FOUND
    code = "not_found"


class PermissionDenied(AppError):
    http_status = status.HTTP_403_FORBIDDEN
    code = "permission_denied"


class Conflict(AppError):
    http_status = status.HTTP_409_CONFLICT
    code = "conflict"


class StateError(AppError):
    """Action is not allowed in the current state."""
    http_status = status.HTTP_422_UNPROCESSABLE_ENTITY
    code = "state_error"


class PaymentError(AppError):
    http_status = status.HTTP_422_UNPROCESSABLE_ENTITY
    code = "payment_error"


class DepositRequired(AppError):
    http_status = status.HTTP_402_PAYMENT_REQUIRED
    code = "deposit_required"


def drf_exception_handler(exc, context):
    if isinstance(exc, AppError):
        return Response(
            {"error": {"code": exc.code, "message": exc.message, "details": exc.details}},
            status=exc.http_status,
        )
    return drf_handler(exc, context)
