"""Print all URL routes."""
from django.core.management.base import BaseCommand
from django.urls import URLPattern, URLResolver, get_resolver


class Command(BaseCommand):
    help = "Print all routes."

    def handle(self, *args, **options):
        for path, name in self._walk(get_resolver().url_patterns):
            self.stdout.write(f"{path:60} {name or ''}")

    def _walk(self, patterns, prefix=""):
        for p in patterns:
            if isinstance(p, URLResolver):
                yield from self._walk(p.url_patterns, prefix + str(p.pattern))
            elif isinstance(p, URLPattern):
                yield prefix + str(p.pattern), p.name
