"""Manual readiness check."""
from django.core.cache import cache
from django.core.management.base import BaseCommand
from django.db import connection


class Command(BaseCommand):
    help = "Run readiness checks."

    def handle(self, *args, **options):
        ok = True
        try:
            with connection.cursor() as c:
                c.execute("SELECT 1")
            self.stdout.write(self.style.SUCCESS("db: OK"))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"db: FAIL ({e})"))
            ok = False
        try:
            cache.set("__hc__", "1", 1)
            assert cache.get("__hc__") == "1"
            self.stdout.write(self.style.SUCCESS("cache: OK"))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"cache: FAIL ({e})"))
            ok = False
        if not ok:
            raise SystemExit(1)
