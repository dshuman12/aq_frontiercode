"""Dump RBAC matrix as Markdown."""
from django.core.management.base import BaseCommand

from apps.core.permissions import ROLE_PERMS, has_perm


class Command(BaseCommand):
    help = "Dump role × permission matrix."

    def handle(self, *args, **options):
        all_perms = sorted({p for perms in ROLE_PERMS.values() for p in perms if p != "*"})
        roles = sorted(ROLE_PERMS)
        self.stdout.write("| Permission | " + " | ".join(roles) + " |")
        self.stdout.write("|" + "---|" * (len(roles) + 1))
        for p in all_perms:
            row = ["yes" if has_perm(r, p) else "" for r in roles]
            self.stdout.write(f"| `{p}` | " + " | ".join(row) + " |")
