"""Seed a demo tenant with realistic catering data."""
from __future__ import annotations
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Seed a demo tenant with realistic catering data."

    def handle(self, *args, **options):
        U = get_user_model()
        owner, _ = U.objects.get_or_create(
            email="chef@aurora-catering.test",
            defaults={"first_name": "Aurora", "last_name": "Owner"},
        )
        owner.set_password("demo-pass-123")
        owner.save()

        from apps.tenants.models import Tenant
        from apps.tenants.services import onboard_tenant
        if Tenant.objects.filter(slug="aurora-catering").exists():
            t = Tenant.objects.get(slug="aurora-catering")
        else:
            t = onboard_tenant(
                owner=owner, slug="aurora-catering", name="Aurora Catering",
                contact_email="hello@aurora-catering.test",
                default_deposit_pct=Decimal("25.00"),
            )

        from apps.locations.services import create_location
        try:
            loc = create_location(
                tenant=t, slug="main", name="Main Kitchen", is_main=True,
                address_line1="1 Aurora Way", city="Seattle", state="WA",
                postal_code="98101", catering_enabled=True, delivery_enabled=True,
            )
        except Exception:
            from apps.locations.models import Location
            loc = Location.objects.get(tenant=t, slug="main")

        from apps.menu.services import create_category, create_item
        try:
            cat = create_category(tenant=t, slug="boxed-lunch", name="Boxed lunches",
                                 kind="boxed_lunch", sort_order=1)
        except Exception:
            from apps.menu.models import MenuCategory
            cat = MenuCategory.objects.get(tenant=t, slug="boxed-lunch")

        from apps.menu.models import MenuItem
        if not MenuItem.objects.filter(tenant=t).exists():
            create_item(tenant=t, category=cat, name="Mediterranean box",
                       price="14.50", serves=1, sku="BL-MED")
            create_item(tenant=t, category=cat, name="Sandwich tray (12)",
                       price="89.00", serves=12, sku="BL-SAND-12")

        from apps.packages.models import Package
        from apps.packages.services import add_item, create_package
        if not Package.objects.filter(tenant=t).exists():
            pkg = create_package(
                tenant=t, slug="corp-lunch", name="Corporate lunch package",
                price_per_person="22.50", minimum_guest_count=10, maximum_guest_count=300,
                description="Sandwich tray + chips + cookie + bottled water per person.",
            )
            mi = MenuItem.objects.filter(tenant=t).first()
            add_item(package=pkg, menu_item=mi, portion_per_person="1.0")

        self.stdout.write(self.style.SUCCESS(
            f"Demo seeded: tenant slug={t.slug}, login chef@aurora-catering.test / demo-pass-123"
        ))
