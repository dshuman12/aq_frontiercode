"""Reusable abstract models."""
from __future__ import annotations

import uuid

from django.db import models


class UuidPkModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    class Meta:
        abstract = True


class TimestampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SoftDeleteModel(models.Model):
    archived_at = models.DateTimeField(null=True, blank=True, db_index=True)

    class Meta:
        abstract = True

    def archive(self):
        from django.utils import timezone
        self.archived_at = timezone.now()
        self.save(update_fields=["archived_at"])

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None


class TenantScoped(UuidPkModel, TimestampedModel, SoftDeleteModel):
    tenant = models.ForeignKey(
        "tenants.Tenant", on_delete=models.CASCADE, related_name="+",
    )

    class Meta:
        abstract = True
