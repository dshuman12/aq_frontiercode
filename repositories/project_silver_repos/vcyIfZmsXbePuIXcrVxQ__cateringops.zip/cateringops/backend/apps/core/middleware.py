"""Bind structlog context per request."""
from __future__ import annotations

import uuid

import structlog


class LogContextMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        trace_id = request.headers.get("x-trace-id") or uuid.uuid4().hex
        structlog.contextvars.bind_contextvars(
            trace_id=trace_id,
            method=request.method,
            path=request.path,
            user_id=getattr(getattr(request, "user", None), "id", None),
            tenant_id=(
                request.resolver_match.kwargs.get("tenant_id")
                if request.resolver_match else None
            ),
        )
        try:
            response = self.get_response(request)
        finally:
            structlog.contextvars.clear_contextvars()
        response["x-trace-id"] = trace_id
        return response
