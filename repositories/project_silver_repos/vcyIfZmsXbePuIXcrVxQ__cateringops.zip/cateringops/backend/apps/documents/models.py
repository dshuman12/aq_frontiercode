from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class Document(TenantScoped):
    KIND_CHOICES = [
        ("signed_agreement", "Signed agreement"),
        ("tax_exempt", "Tax-exempt"),
        ("delivery_instructions", "Delivery instructions"),
        ("venue_doc", "Venue document"),
        ("quote_pdf", "Quote PDF"),
        ("invoice_pdf", "Invoice PDF"),
        ("receipt_pdf", "Receipt PDF"),
        ("other", "Other"),
    ]
    customer = models.ForeignKey("customers.Customer", on_delete=models.SET_NULL,
                                null=True, blank=True, related_name="documents")
    order = models.ForeignKey("orders.Order", on_delete=models.SET_NULL,
                             null=True, blank=True, related_name="documents")
    kind = models.CharField(max_length=32, choices=KIND_CHOICES, default="other")
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, default="")
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, related_name="+")


class DocumentVersion(TenantScoped):
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="versions")
    version_number = models.PositiveIntegerField()
    file_url = models.URLField()
    filename = models.CharField(max_length=200)
    content_type = models.CharField(max_length=80, blank=True, default="")
    size_bytes = models.PositiveBigIntegerField(default=0)
    note = models.CharField(max_length=400, blank=True, default="")

    class Meta:
        unique_together = [("document", "version_number")]
        ordering = ["-version_number"]


class DocumentPermission(TenantScoped):
    SCOPE_CHOICES = [("internal", "Internal"), ("customer", "Customer-visible"),
                    ("billing", "Billing staff")]
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="permissions")
    scope = models.CharField(max_length=16, choices=SCOPE_CHOICES, default="internal")
