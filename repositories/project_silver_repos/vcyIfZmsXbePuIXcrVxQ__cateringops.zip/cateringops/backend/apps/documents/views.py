from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from apps.documents.models import Document
from apps.documents.serializers import DocumentSerializer


class DocumentViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = DocumentSerializer

    def get_queryset(self):
        return Document.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("versions", "permissions")
