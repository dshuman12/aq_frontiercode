from django.contrib import admin
from apps.documents.models import Document, DocumentPermission, DocumentVersion


admin.site.register(Document)
admin.site.register(DocumentVersion)
admin.site.register(DocumentPermission)
