import pytest

from apps.documents.services import upload, upload_new_version


@pytest.mark.django_db
def test_upload_v1(tenant, user):
    d = upload(tenant=tenant, kind="signed_agreement", title="X",
              file_url="s3://x", filename="a.pdf", uploaded_by=user)
    assert d.versions.first().version_number == 1


@pytest.mark.django_db
def test_increments(tenant, user):
    d = upload(tenant=tenant, kind="signed_agreement", title="X",
              file_url="s3://x", filename="a.pdf", uploaded_by=user)
    upload_new_version(document=d, file_url="s3://2", filename="b.pdf")
    upload_new_version(document=d, file_url="s3://3", filename="c.pdf")
    versions = list(d.versions.order_by("version_number").values_list("version_number", flat=True))
    assert versions == [1, 2, 3]
