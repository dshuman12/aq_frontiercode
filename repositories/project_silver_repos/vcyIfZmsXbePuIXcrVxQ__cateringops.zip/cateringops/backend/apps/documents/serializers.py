from rest_framework import serializers
from apps.documents.models import Document, DocumentVersion


class VersionSerializer(serializers.ModelSerializer):
    class Meta:
        model = DocumentVersion
        fields = ["id", "version_number", "file_url", "filename",
                  "content_type", "size_bytes", "note", "created_at"]


class DocumentSerializer(serializers.ModelSerializer):
    versions = VersionSerializer(many=True, read_only=True)

    class Meta:
        model = Document
        fields = ["id", "kind", "title", "description", "customer_id", "order_id",
                  "uploaded_by_id", "versions", "created_at"]
