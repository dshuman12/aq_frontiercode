from __future__ import annotations
from django.db import transaction

from apps.documents.models import Document, DocumentPermission, DocumentVersion


@transaction.atomic
def upload(*, tenant, kind: str, title: str, file_url: str, filename: str,
          content_type: str = "", size_bytes: int = 0, customer=None, order=None,
          uploaded_by=None, scope: str = "internal") -> Document:
    doc = Document.objects.create(
        tenant=tenant, kind=kind, title=title,
        customer=customer, order=order, uploaded_by=uploaded_by,
    )
    DocumentVersion.objects.create(
        tenant=tenant, document=doc, version_number=1, file_url=file_url,
        filename=filename, content_type=content_type, size_bytes=size_bytes,
    )
    DocumentPermission.objects.create(tenant=tenant, document=doc, scope=scope)
    return doc


@transaction.atomic
def upload_new_version(*, document, file_url: str, filename: str,
                      content_type: str = "", size_bytes: int = 0,
                      note: str = "") -> DocumentVersion:
    last = document.versions.order_by("-version_number").first()
    next_v = (last.version_number if last else 0) + 1
    return DocumentVersion.objects.create(
        tenant=document.tenant, document=document, version_number=next_v,
        file_url=file_url, filename=filename, content_type=content_type,
        size_bytes=size_bytes, note=note,
    )
