from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from apps.locations.models import Location
from apps.locations.serializers import LocationSerializer


class LocationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = LocationSerializer

    def get_queryset(self):
        return Location.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        )

    def perform_create(self, serializer):
        from apps.tenants.models import Tenant
        serializer.save(tenant=Tenant.objects.get(pk=self.kwargs["tenant_id"]))
