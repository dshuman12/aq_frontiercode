from rest_framework import serializers
from apps.locations.models import BusinessHours, DeliveryZone, HolidayHours, Location


class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = ["id", "slug", "name", "address_line1", "address_line2",
                  "city", "state", "postal_code", "country", "phone",
                  "is_main", "catering_enabled", "pickup_enabled", "delivery_enabled",
                  "delivery_radius_miles", "tax_rate_pct"]


class BusinessHoursSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessHours
        fields = ["id", "location_id", "weekday", "open_time", "close_time", "closed"]


class HolidaySerializer(serializers.ModelSerializer):
    class Meta:
        model = HolidayHours
        fields = ["id", "location_id", "date", "closed", "label"]


class DeliveryZoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryZone
        fields = ["id", "location_id", "name", "postal_codes",
                  "minimum_order_amount", "delivery_fee", "estimated_minutes"]
