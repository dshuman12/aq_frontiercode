from __future__ import annotations

from datetime import date, time

from django.db import transaction

from apps.core.exceptions import Conflict
from apps.locations.models import BusinessHours, DeliveryZone, HolidayHours, Location


@transaction.atomic
def create_location(*, tenant, slug: str, name: str, **fields) -> Location:
    if Location.objects.filter(tenant=tenant, slug=slug).exists():
        raise Conflict(f"location {slug!r} exists")
    is_main = fields.pop("is_main", False)
    if is_main:
        Location.objects.filter(tenant=tenant, is_main=True).update(is_main=False)
    return Location.objects.create(tenant=tenant, slug=slug, name=name, is_main=is_main, **fields)


def set_hours(*, location: Location, weekday: int, open_time: time | None,
             close_time: time | None, closed: bool = False) -> BusinessHours:
    obj, _ = BusinessHours.objects.update_or_create(
        tenant=location.tenant, location=location, weekday=weekday,
        defaults={"open_time": open_time, "close_time": close_time, "closed": closed},
    )
    return obj


def set_holiday(*, location: Location, dt: date, closed: bool = True, label: str = "") -> HolidayHours:
    obj, _ = HolidayHours.objects.update_or_create(
        tenant=location.tenant, location=location, date=dt,
        defaults={"closed": closed, "label": label},
    )
    return obj


def add_zone(*, location: Location, name: str, postal_codes: list,
            minimum_order_amount, delivery_fee, estimated_minutes: int = 45) -> DeliveryZone:
    return DeliveryZone.objects.create(
        tenant=location.tenant, location=location, name=name,
        postal_codes=postal_codes, minimum_order_amount=minimum_order_amount,
        delivery_fee=delivery_fee, estimated_minutes=estimated_minutes,
    )


def find_zone(*, location: Location, postal_code: str) -> DeliveryZone | None:
    pc = postal_code.strip()
    for z in DeliveryZone.objects.filter(location=location, archived_at__isnull=True):
        if pc in z.postal_codes:
            return z
    return None
