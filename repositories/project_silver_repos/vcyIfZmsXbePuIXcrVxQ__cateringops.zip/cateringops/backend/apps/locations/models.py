"""Tenant locations + business hours + delivery zones."""
from __future__ import annotations

from django.db import models
from apps.core.models import TenantScoped


class Location(TenantScoped):
    slug = models.SlugField(max_length=80)
    name = models.CharField(max_length=200)
    address_line1 = models.CharField(max_length=200, blank=True, default="")
    address_line2 = models.CharField(max_length=200, blank=True, default="")
    city = models.CharField(max_length=120, blank=True, default="")
    state = models.CharField(max_length=64, blank=True, default="")
    postal_code = models.CharField(max_length=24, blank=True, default="")
    country = models.CharField(max_length=2, default="US")
    phone = models.CharField(max_length=32, blank=True, default="")

    is_main = models.BooleanField(default=False)
    catering_enabled = models.BooleanField(default=True)
    pickup_enabled = models.BooleanField(default=True)
    delivery_enabled = models.BooleanField(default=True)
    delivery_radius_miles = models.PositiveIntegerField(default=20)

    tax_rate_pct = models.DecimalField(max_digits=5, decimal_places=4, default="0.0000")

    class Meta:
        unique_together = [("tenant", "slug")]


class BusinessHours(TenantScoped):
    DAY_CHOICES = [(i, day) for i, day in enumerate(
        ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])]
    location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name="hours")
    weekday = models.IntegerField(choices=DAY_CHOICES)
    open_time = models.TimeField(null=True, blank=True)
    close_time = models.TimeField(null=True, blank=True)
    closed = models.BooleanField(default=False)

    class Meta:
        unique_together = [("location", "weekday")]


class HolidayHours(TenantScoped):
    location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name="holiday_hours")
    date = models.DateField()
    open_time = models.TimeField(null=True, blank=True)
    close_time = models.TimeField(null=True, blank=True)
    closed = models.BooleanField(default=False)
    label = models.CharField(max_length=120, blank=True, default="")

    class Meta:
        unique_together = [("location", "date")]


class DeliveryZone(TenantScoped):
    location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name="zones")
    name = models.CharField(max_length=120)
    postal_codes = models.JSONField(default=list)
    minimum_order_amount = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    delivery_fee = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    estimated_minutes = models.PositiveIntegerField(default=45)
