from datetime import date

from apps.locations.models import BusinessHours, HolidayHours, Location


def active_locations(tenant):
    return Location.objects.filter(tenant=tenant, archived_at__isnull=True).order_by("-is_main", "name")


def is_open_on(location: Location, dt: date) -> bool:
    hol = HolidayHours.objects.filter(location=location, date=dt).first()
    if hol:
        return not hol.closed
    bh = BusinessHours.objects.filter(location=location, weekday=dt.weekday()).first()
    if not bh:
        return True
    return not bh.closed
