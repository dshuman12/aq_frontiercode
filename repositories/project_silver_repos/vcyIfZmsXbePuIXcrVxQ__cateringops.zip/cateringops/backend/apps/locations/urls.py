from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.locations.views import LocationViewSet

router = DefaultRouter()
router.register("locations", LocationViewSet, basename="location")

urlpatterns = [path("t/<uuid:tenant_id>/", include(router.urls))]
