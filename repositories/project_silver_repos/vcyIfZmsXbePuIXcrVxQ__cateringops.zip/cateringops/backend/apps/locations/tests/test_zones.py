import pytest
from decimal import Decimal

from apps.locations.services import add_zone, find_zone


@pytest.mark.django_db
def test_multiple_zones(location):
    add_zone(location=location, name="N", postal_codes=["98101"],
            minimum_order_amount=Decimal("0"), delivery_fee=Decimal("30"))
    add_zone(location=location, name="S", postal_codes=["98110"],
            minimum_order_amount=Decimal("250"), delivery_fee=Decimal("50"))
    assert find_zone(location=location, postal_code="98110").name == "S"
    assert find_zone(location=location, postal_code="98101").name == "N"


@pytest.mark.django_db
def test_archived_excluded(location):
    z = add_zone(location=location, name="X", postal_codes=["98101"],
                minimum_order_amount=Decimal("0"), delivery_fee=Decimal("30"))
    z.archive()
    assert find_zone(location=location, postal_code="98101") is None
