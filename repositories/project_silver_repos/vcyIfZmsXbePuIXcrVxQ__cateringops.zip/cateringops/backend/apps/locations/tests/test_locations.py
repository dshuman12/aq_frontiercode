import pytest
from decimal import Decimal

from apps.core.exceptions import Conflict
from apps.locations.services import add_zone, create_location, find_zone, set_hours
from apps.locations.selectors import is_open_on


@pytest.mark.django_db
def test_duplicate_slug_rejected(tenant):
    create_location(tenant=tenant, slug="x", name="X")
    with pytest.raises(Conflict):
        create_location(tenant=tenant, slug="x", name="Y")


@pytest.mark.django_db
def test_marking_main_unmarks_others(tenant):
    a = create_location(tenant=tenant, slug="a", name="A", is_main=True)
    b = create_location(tenant=tenant, slug="b", name="B", is_main=True)
    a.refresh_from_db()
    assert a.is_main is False
    assert b.is_main is True


@pytest.mark.django_db
def test_zone_lookup(location):
    z = add_zone(location=location, name="N", postal_codes=["98101", "98102"],
                minimum_order_amount=Decimal("250"), delivery_fee=Decimal("40"))
    assert find_zone(location=location, postal_code="98101") == z
    assert find_zone(location=location, postal_code="00000") is None


@pytest.mark.django_db
def test_set_hours_upserts(location):
    from datetime import time
    a = set_hours(location=location, weekday=2, open_time=time(9), close_time=time(17), closed=False)
    b = set_hours(location=location, weekday=2, open_time=None, close_time=None, closed=True)
    assert a.id == b.id
    b.refresh_from_db()
    assert b.closed is True


@pytest.mark.django_db
def test_is_open_default(location):
    from datetime import date
    assert is_open_on(location, date(2025, 6, 1))
