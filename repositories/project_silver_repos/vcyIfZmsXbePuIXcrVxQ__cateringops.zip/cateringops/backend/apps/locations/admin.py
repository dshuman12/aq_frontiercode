from django.contrib import admin
from apps.locations.models import BusinessHours, DeliveryZone, HolidayHours, Location


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ("name", "tenant", "is_main", "catering_enabled", "delivery_enabled")
    search_fields = ("name", "slug")


admin.site.register(BusinessHours)
admin.site.register(HolidayHours)
admin.site.register(DeliveryZone)
