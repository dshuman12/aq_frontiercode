from rest_framework import serializers
from apps.billing.models import (
    CancellationFee, Deposit, DepositRule, Invoice, InvoiceLine, Receipt,
)


class DepositRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = DepositRule
        fields = ["id", "location_id", "name", "minimum_total",
                  "deposit_pct", "due_days_before_event", "is_active"]


class DepositSerializer(serializers.ModelSerializer):
    class Meta:
        model = Deposit
        fields = ["id", "order_id", "amount_required", "amount_paid",
                  "due_at", "paid_at", "status"]


class InvoiceLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceLine
        fields = ["id", "label", "quantity", "unit_price", "line_total", "sort_order"]


class ReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Receipt
        fields = ["id", "receipt_number", "pdf_url", "issued_at", "payment_id"]


class InvoiceListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invoice
        fields = ["id", "invoice_number", "customer_id", "order_id",
                  "total", "amount_paid", "balance_due", "status",
                  "issued_at", "due_at", "paid_at"]


class InvoiceDetailSerializer(InvoiceListSerializer):
    lines = InvoiceLineSerializer(many=True, read_only=True)
    receipts = ReceiptSerializer(many=True, read_only=True)

    class Meta(InvoiceListSerializer.Meta):
        fields = InvoiceListSerializer.Meta.fields + [
            "subtotal", "tax_total", "service_charge_total", "delivery_fee",
            "deposit_applied", "notes", "pdf_url", "lines", "receipts",
        ]
