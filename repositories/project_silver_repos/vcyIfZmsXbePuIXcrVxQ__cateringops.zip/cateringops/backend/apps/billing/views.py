from decimal import Decimal

from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.billing import serializers as ser, services
from apps.billing.models import Deposit, DepositRule, Invoice


class DepositRuleViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ser.DepositRuleSerializer

    def get_queryset(self):
        return DepositRule.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        )


class DepositViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ser.DepositSerializer

    def get_queryset(self):
        return Deposit.objects.filter(tenant_id=self.kwargs["tenant_id"])

    @action(detail=True, methods=["post"])
    def mark_paid(self, request, tenant_id=None, pk=None):
        services.mark_paid(deposit=self.get_object(), amount=Decimal(request.data["amount"]))
        return Response(ser.DepositSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def refund(self, request, tenant_id=None, pk=None):
        services.refund_deposit(deposit=self.get_object(), reason=request.data.get("reason", ""))
        return Response(ser.DepositSerializer(self.get_object()).data)


class InvoiceViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        return ser.InvoiceDetailSerializer if self.action != "list" else ser.InvoiceListSerializer

    def get_queryset(self):
        return Invoice.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("lines", "receipts")

    @action(detail=False, methods=["post"], url_path="from-order")
    def from_order(self, request, tenant_id=None):
        from apps.orders.models import Order
        o = Order.objects.get(pk=request.data["order"], tenant_id=tenant_id)
        inv = services.generate_invoice(o)
        return Response(ser.InvoiceDetailSerializer(inv).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def send(self, request, tenant_id=None, pk=None):
        services.issue_invoice(invoice=self.get_object())
        return Response(ser.InvoiceDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def void(self, request, tenant_id=None, pk=None):
        services.void_invoice(invoice=self.get_object(),
                             reason=request.data.get("reason", ""))
        return Response(ser.InvoiceDetailSerializer(self.get_object()).data)
