from celery import shared_task


@shared_task
def send_deposit_reminders():
    from apps.billing.selectors import deposits_due_soon
    from apps.notifications.tasks import dispatch_template
    from apps.tenants.models import Tenant
    n = 0
    for t in Tenant.objects.filter(archived_at__isnull=True):
        for d in deposits_due_soon(t, days=3):
            dispatch_template.delay("deposit.reminder", {"deposit_id": str(d.id)})
            n += 1
    return {"reminders": n}
