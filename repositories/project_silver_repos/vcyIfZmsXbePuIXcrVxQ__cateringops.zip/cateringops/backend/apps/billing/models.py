"""Deposits + Invoices + Receipts."""
import secrets
from django.db import models
from apps.core.models import TenantScoped


class DepositRule(TenantScoped):
    location = models.ForeignKey("locations.Location", on_delete=models.CASCADE,
                                related_name="deposit_rules", null=True, blank=True)
    name = models.CharField(max_length=120)
    minimum_total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    deposit_pct = models.DecimalField(max_digits=5, decimal_places=2, default="25.00")
    due_days_before_event = models.PositiveIntegerField(default=14)
    is_active = models.BooleanField(default=True)


class Deposit(TenantScoped):
    STATUS_CHOICES = [
        ("pending", "Pending"), ("paid", "Paid"),
        ("refunded", "Refunded"), ("forfeited", "Forfeited"),
    ]
    order = models.OneToOneField("orders.Order", on_delete=models.CASCADE, related_name="deposit")
    amount_required = models.DecimalField(max_digits=12, decimal_places=2)
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    due_at = models.DateTimeField(null=True, blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default="pending")
    stripe_payment_intent_id = models.CharField(max_length=120, blank=True, default="")
    stripe_charge_id = models.CharField(max_length=120, blank=True, default="")


class CancellationFee(TenantScoped):
    order = models.OneToOneField("orders.Order", on_delete=models.CASCADE,
                                related_name="cancellation_fee")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    reason = models.TextField()
    applied_at = models.DateTimeField(auto_now_add=True)


class Invoice(TenantScoped):
    STATUS_CHOICES = [
        ("draft", "Draft"), ("sent", "Sent"),
        ("partially_paid", "Partially paid"), ("paid", "Paid"),
        ("overdue", "Overdue"), ("void", "Void"),
    ]
    invoice_number = models.CharField(max_length=32, unique=True)
    order = models.OneToOneField("orders.Order", on_delete=models.PROTECT, related_name="invoice")
    customer = models.ForeignKey("customers.Customer", on_delete=models.PROTECT, related_name="invoices")

    subtotal = models.DecimalField(max_digits=12, decimal_places=2)
    tax_total = models.DecimalField(max_digits=12, decimal_places=2)
    service_charge_total = models.DecimalField(max_digits=12, decimal_places=2)
    delivery_fee = models.DecimalField(max_digits=12, decimal_places=2)
    total = models.DecimalField(max_digits=12, decimal_places=2)
    deposit_applied = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    balance_due = models.DecimalField(max_digits=12, decimal_places=2)

    status = models.CharField(max_length=24, choices=STATUS_CHOICES, default="draft", db_index=True)
    issued_at = models.DateTimeField(null=True, blank=True)
    due_at = models.DateField(null=True, blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    public_token = models.CharField(max_length=80, unique=True, default=secrets.token_urlsafe)
    notes = models.TextField(blank=True, default="")
    pdf_url = models.URLField(blank=True, default="")


class InvoiceLine(TenantScoped):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name="lines")
    label = models.CharField(max_length=200)
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=12, decimal_places=2)
    sort_order = models.IntegerField(default=0)


class Receipt(TenantScoped):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name="receipts")
    payment = models.OneToOneField("payments.Payment", on_delete=models.PROTECT, related_name="receipt")
    receipt_number = models.CharField(max_length=32, unique=True)
    pdf_url = models.URLField(blank=True, default="")
    issued_at = models.DateTimeField(auto_now_add=True)
