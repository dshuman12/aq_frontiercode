from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.billing.views import DepositRuleViewSet, DepositViewSet, InvoiceViewSet

router = DefaultRouter()
router.register("rules", DepositRuleViewSet, basename="deposit-rule")
router.register("deposits", DepositViewSet, basename="deposit")
router.register("invoices", InvoiceViewSet, basename="invoice")

urlpatterns = [path("", include(router.urls))]
