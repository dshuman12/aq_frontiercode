from django.contrib import admin
from apps.billing.models import (
    CancellationFee, Deposit, DepositRule, Invoice, InvoiceLine, Receipt,
)


admin.site.register(DepositRule)
admin.site.register(Deposit)
admin.site.register(CancellationFee)


class LineInline(admin.TabularInline):
    model = InvoiceLine
    extra = 0


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ("invoice_number", "customer", "total", "balance_due", "status", "tenant")
    inlines = [LineInline]


admin.site.register(Receipt)
