from django.core.management.base import BaseCommand
from apps.billing.services import mark_overdue


class Command(BaseCommand):
    help = "Mark sent invoices past due_at as overdue."

    def handle(self, *args, **options):
        n = mark_overdue()
        self.stdout.write(self.style.SUCCESS(f"Marked {n} overdue"))
