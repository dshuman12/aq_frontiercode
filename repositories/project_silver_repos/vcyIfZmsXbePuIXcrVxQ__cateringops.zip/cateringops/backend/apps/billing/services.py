from __future__ import annotations
from datetime import timedelta
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import Conflict, PaymentError, ValidationError
from apps.billing.models import (
    CancellationFee, Deposit, DepositRule, Invoice, InvoiceLine, Receipt,
)


# ---- Deposits ----

@transaction.atomic
def ensure_deposit(*, order, due_at=None) -> Deposit:
    if hasattr(order, "deposit"):
        return order.deposit
    return Deposit.objects.create(
        tenant=order.tenant, order=order,
        amount_required=order.deposit_required_amount, due_at=due_at,
    )


def resolve_due_at(order) -> "datetime":
    from datetime import datetime
    rule = DepositRule.objects.filter(tenant=order.tenant, is_active=True).first()
    days = rule.due_days_before_event if rule else 14
    event_dt = datetime.combine(order.event_date, order.event_time)
    return event_dt - timedelta(days=days)


@transaction.atomic
def mark_paid(*, deposit, amount, stripe_payment_intent_id="", stripe_charge_id="") -> Deposit:
    from apps.orders.services import apply_deposit_payment, confirm as confirm_order
    amount = Decimal(amount)
    if amount <= 0:
        raise ValidationError("amount > 0")
    deposit.amount_paid = (deposit.amount_paid + amount).quantize(Decimal("0.01"))
    if stripe_payment_intent_id:
        deposit.stripe_payment_intent_id = stripe_payment_intent_id
    if stripe_charge_id:
        deposit.stripe_charge_id = stripe_charge_id
    if deposit.amount_paid >= deposit.amount_required:
        deposit.status = "paid"
        deposit.paid_at = timezone.now()
    deposit.save()
    apply_deposit_payment(deposit.order, amount)
    if deposit.status == "paid":
        confirm_order(deposit.order)
    return deposit


@transaction.atomic
def refund_deposit(*, deposit, reason: str = "") -> Deposit:
    if deposit.status != "paid":
        raise Conflict("only paid deposits can be refunded")
    deposit.status = "refunded"
    deposit.save(update_fields=["status"])
    return deposit


@transaction.atomic
def forfeit_deposit(*, order, amount=None, reason: str = "") -> CancellationFee:
    if not hasattr(order, "deposit") or order.deposit.status != "paid":
        raise Conflict("no paid deposit to forfeit")
    fee = amount or order.deposit.amount_paid
    if hasattr(order, "cancellation_fee"):
        raise Conflict("already applied")
    cf = CancellationFee.objects.create(
        tenant=order.tenant, order=order, amount=fee, reason=reason,
    )
    order.deposit.status = "forfeited"
    order.deposit.save(update_fields=["status"])
    return cf


@transaction.atomic
def charge_via_stripe(*, deposit, payment_method_id: str) -> Deposit:
    from django.conf import settings

    try:
        import stripe
    except ImportError as exc:
        raise PaymentError("stripe not installed") from exc

    stripe.api_key = settings.STRIPE_SECRET_KEY
    if deposit.status == "paid":
        raise Conflict("already paid")

    intent = stripe.PaymentIntent.create(
        amount=int(deposit.amount_required * 100),
        currency=deposit.tenant.currency.lower(),
        payment_method=payment_method_id, confirm=True, off_session=True,
        metadata={"order_id": str(deposit.order_id), "kind": "deposit"},
    )
    if intent.status != "succeeded":
        raise PaymentError(f"stripe status {intent.status}")
    return mark_paid(
        deposit=deposit, amount=deposit.amount_required,
        stripe_payment_intent_id=intent.id,
        stripe_charge_id=intent.latest_charge or "",
    )


# ---- Invoices ----

def _inv_number(tenant) -> str:
    seq = Invoice.objects.filter(tenant=tenant).count() + 1
    return f"INV-{timezone.now().year}-{seq:05d}"


@transaction.atomic
def generate_invoice(order, *, due_in_days: int = 14) -> Invoice:
    if hasattr(order, "invoice"):
        return order.invoice
    applied = order.deposit_paid_amount
    balance = order.total - applied
    inv = Invoice.objects.create(
        tenant=order.tenant, invoice_number=_inv_number(order.tenant),
        order=order, customer=order.customer,
        subtotal=order.subtotal, tax_total=order.tax_total,
        service_charge_total=order.service_charge_total,
        delivery_fee=order.delivery_fee, total=order.total,
        deposit_applied=applied, balance_due=balance,
        due_at=(timezone.now() + timedelta(days=due_in_days)).date(),
    )
    for i, oi in enumerate(order.items.all()):
        InvoiceLine.objects.create(
            tenant=order.tenant, invoice=inv,
            label=oi.label, quantity=oi.quantity, unit_price=oi.unit_price,
            line_total=oi.line_total, sort_order=i,
        )
    return inv


@transaction.atomic
def issue_invoice(*, invoice) -> Invoice:
    if invoice.status != "draft":
        raise Conflict(f"status {invoice.status}")
    invoice.status = "sent"
    invoice.issued_at = timezone.now()
    invoice.save(update_fields=["status", "issued_at"])
    return invoice


@transaction.atomic
def apply_invoice_payment(*, invoice, amount, payment=None) -> Invoice:
    amount = Decimal(amount)
    if amount <= 0:
        raise ValidationError("amount > 0")
    invoice.amount_paid = (invoice.amount_paid + amount).quantize(Decimal("0.01"))
    invoice.balance_due = max(invoice.total - invoice.deposit_applied - invoice.amount_paid, Decimal("0"))
    if invoice.balance_due <= 0:
        invoice.status = "paid"
        invoice.paid_at = timezone.now()
    elif invoice.amount_paid > 0:
        invoice.status = "partially_paid"
    invoice.save()
    if payment:
        seq = Receipt.objects.filter(tenant=invoice.tenant).count() + 1
        Receipt.objects.create(
            tenant=invoice.tenant, invoice=invoice, payment=payment,
            receipt_number=f"R-{timezone.now().year}-{seq:05d}",
        )
    return invoice


@transaction.atomic
def void_invoice(*, invoice, reason: str = "") -> Invoice:
    if invoice.status == "paid":
        raise Conflict("cannot void paid invoice")
    invoice.status = "void"
    invoice.notes = (invoice.notes + f"\n[VOID] {reason}").strip()
    invoice.save(update_fields=["status", "notes"])
    return invoice


def mark_overdue(*, today=None):
    today = today or timezone.now().date()
    return Invoice.objects.filter(
        status__in=("sent", "partially_paid"), due_at__lt=today, archived_at__isnull=True,
    ).update(status="overdue")
