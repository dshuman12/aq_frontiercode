import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.core.exceptions import Conflict, ValidationError
from apps.billing.services import ensure_deposit, forfeit_deposit, mark_paid, refund_deposit


@pytest.fixture
def order(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today() + timedelta(days=20), event_time=time(12),
                     guest_count=10, items=[{"label": "X", "quantity": 1, "unit_price": "500"}],
                     actor=user)
    o.deposit_required_amount = Decimal("100")
    o.save(update_fields=["deposit_required_amount"])
    return o


@pytest.mark.django_db
def test_ensure_idempotent(order):
    a = ensure_deposit(order=order)
    b = ensure_deposit(order=order)
    assert a.id == b.id


@pytest.mark.django_db
def test_mark_paid_full(order):
    d = ensure_deposit(order=order)
    mark_paid(deposit=d, amount=Decimal("100"))
    d.refresh_from_db()
    assert d.status == "paid"
    order.refresh_from_db()
    assert order.status == "confirmed"


@pytest.mark.django_db
def test_partial_doesnt_confirm(order):
    d = ensure_deposit(order=order)
    mark_paid(deposit=d, amount=Decimal("20"))
    d.refresh_from_db()
    assert d.status == "pending"


@pytest.mark.django_db
def test_partial_then_full_confirms(order):
    d = ensure_deposit(order=order)
    mark_paid(deposit=d, amount=Decimal("20"))
    mark_paid(deposit=d, amount=Decimal("80"))
    d.refresh_from_db()
    assert d.status == "paid"


@pytest.mark.django_db
def test_validation(order):
    d = ensure_deposit(order=order)
    with pytest.raises(ValidationError):
        mark_paid(deposit=d, amount=Decimal("0"))


@pytest.mark.django_db
def test_refund(order):
    d = ensure_deposit(order=order)
    mark_paid(deposit=d, amount=Decimal("100"))
    refund_deposit(deposit=d)
    d.refresh_from_db()
    assert d.status == "refunded"


@pytest.mark.django_db
def test_cannot_refund_pending(order):
    d = ensure_deposit(order=order)
    with pytest.raises(Conflict):
        refund_deposit(deposit=d)


@pytest.mark.django_db
def test_forfeit(order, user):
    d = ensure_deposit(order=order)
    mark_paid(deposit=d, amount=Decimal("100"))
    cf = forfeit_deposit(order=order, reason="late cancel")
    assert cf.amount == Decimal("100")
    d.refresh_from_db()
    assert d.status == "forfeited"
