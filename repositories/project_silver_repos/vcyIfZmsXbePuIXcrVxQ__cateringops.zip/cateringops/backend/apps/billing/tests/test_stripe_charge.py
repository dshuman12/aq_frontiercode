import pytest
from decimal import Decimal

from apps.core.exceptions import Conflict
from apps.billing.services import charge_via_stripe, ensure_deposit, mark_paid


@pytest.mark.django_db
def test_paid_blocks_stripe_charge(tenant, location, user):
    from datetime import date, time, timedelta
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today() + timedelta(days=10), event_time=time(12),
                     guest_count=10, items=[{"label": "X", "quantity": 1, "unit_price": "1000"}],
                     actor=user)
    o.deposit_required_amount = Decimal("100")
    o.save(update_fields=["deposit_required_amount"])
    d = ensure_deposit(order=o)
    mark_paid(deposit=d, amount=Decimal("100"))
    with pytest.raises(Conflict):
        charge_via_stripe(deposit=d, payment_method_id="pm_x")
