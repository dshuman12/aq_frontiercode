import pytest
from decimal import Decimal


@pytest.fixture
def inv(tenant, location, user):
    from datetime import date, time
    from apps.customers.services import create_customer
    from apps.orders.services import (
        apply_deposit_payment, complete, confirm, create_direct,
        mark_ready, start_production,
    )
    from apps.billing.services import generate_invoice, issue_invoice
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today(), event_time=time(12), guest_count=10,
                     items=[{"label": "X", "quantity": 1, "unit_price": "500"}], actor=user)
    apply_deposit_payment(o, Decimal("100"))
    o.deposit_required_amount = Decimal("100")
    o.save(update_fields=["deposit_required_amount"])
    confirm(o, actor=user); start_production(o, actor=user)
    mark_ready(o, actor=user); complete(o, actor=user)
    inv = generate_invoice(o); issue_invoice(invoice=inv)
    return inv


@pytest.mark.django_db
def test_overpayment_clamps_to_zero(inv):
    from apps.billing.services import apply_invoice_payment
    apply_invoice_payment(invoice=inv, amount=Decimal("99999"))
    inv.refresh_from_db()
    assert inv.balance_due == Decimal("0")
    assert inv.status == "paid"
