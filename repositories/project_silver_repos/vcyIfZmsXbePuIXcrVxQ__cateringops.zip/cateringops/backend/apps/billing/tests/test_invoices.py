import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.core.exceptions import Conflict, ValidationError
from apps.billing.services import (
    apply_invoice_payment, generate_invoice, issue_invoice, mark_overdue, void_invoice,
)


@pytest.fixture
def order_completed(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import (
        apply_deposit_payment, complete, confirm, create_direct,
        mark_ready, start_production,
    )
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today(), event_time=time(12), guest_count=10,
                     items=[{"label": "X", "quantity": 1, "unit_price": "300"}], actor=user)
    apply_deposit_payment(o, Decimal("100"))
    o.deposit_required_amount = Decimal("100")
    o.save(update_fields=["deposit_required_amount"])
    confirm(o, actor=user); start_production(o, actor=user)
    mark_ready(o, actor=user); complete(o, actor=user)
    return o


@pytest.mark.django_db
def test_generate(order_completed):
    inv = generate_invoice(order_completed)
    assert inv.total == Decimal("300.00")
    assert inv.deposit_applied == Decimal("100.00")
    assert inv.balance_due == Decimal("200.00")


@pytest.mark.django_db
def test_idempotent(order_completed):
    a = generate_invoice(order_completed)
    b = generate_invoice(order_completed)
    assert a.id == b.id


@pytest.mark.django_db
def test_issue_then_pay(order_completed):
    inv = generate_invoice(order_completed)
    issue_invoice(invoice=inv)
    apply_invoice_payment(invoice=inv, amount=Decimal("100"))
    inv.refresh_from_db()
    assert inv.status == "partially_paid"
    apply_invoice_payment(invoice=inv, amount=Decimal("100"))
    inv.refresh_from_db()
    assert inv.status == "paid"


@pytest.mark.django_db
def test_validation(order_completed):
    inv = generate_invoice(order_completed)
    issue_invoice(invoice=inv)
    with pytest.raises(ValidationError):
        apply_invoice_payment(invoice=inv, amount=Decimal("0"))


@pytest.mark.django_db
def test_void(order_completed):
    inv = generate_invoice(order_completed)
    void_invoice(invoice=inv, reason="dispute")
    inv.refresh_from_db()
    assert inv.status == "void"


@pytest.mark.django_db
def test_cannot_void_paid(order_completed):
    inv = generate_invoice(order_completed)
    issue_invoice(invoice=inv)
    apply_invoice_payment(invoice=inv, amount=inv.balance_due)
    with pytest.raises(Conflict):
        void_invoice(invoice=inv)


@pytest.mark.django_db
def test_overdue(order_completed):
    inv = generate_invoice(order_completed)
    issue_invoice(invoice=inv)
    inv.due_at = date.today() - timedelta(days=1)
    inv.save(update_fields=["due_at"])
    assert mark_overdue() == 1
    inv.refresh_from_db()
    assert inv.status == "overdue"
