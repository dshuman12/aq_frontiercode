from datetime import timedelta
from decimal import Decimal

from django.db.models import Sum
from django.utils import timezone

from apps.billing.models import Deposit, Invoice


def deposits_due_soon(tenant, *, days: int = 7):
    cutoff = timezone.now() + timedelta(days=days)
    return Deposit.objects.filter(
        tenant=tenant, status="pending", due_at__lte=cutoff, archived_at__isnull=True,
    )


def total_collected(tenant) -> Decimal:
    total = Deposit.objects.filter(
        tenant=tenant, status__in=("paid", "refunded", "forfeited"),
    ).aggregate(s=Sum("amount_paid"))["s"]
    return total or Decimal("0.00")


def outstanding_balance(tenant) -> Decimal:
    total = Invoice.objects.filter(
        tenant=tenant, status__in=("sent", "partially_paid", "overdue"),
        archived_at__isnull=True,
    ).aggregate(s=Sum("balance_due"))["s"]
    return total or Decimal("0.00")
