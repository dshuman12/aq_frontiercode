from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.roles.views import CustomRoleViewSet

router = DefaultRouter()
router.register("custom-roles", CustomRoleViewSet, basename="custom-role")

urlpatterns = [path("t/<uuid:tenant_id>/roles/", include(router.urls))]
