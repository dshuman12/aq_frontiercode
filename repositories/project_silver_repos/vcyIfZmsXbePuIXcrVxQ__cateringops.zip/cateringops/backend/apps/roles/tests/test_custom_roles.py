import pytest

from apps.roles.services import create_custom_role, custom_role_has


@pytest.mark.django_db
def test_extends_base(tenant):
    role = create_custom_role(
        tenant=tenant, slug="event_lead", name="Event lead",
        base_role="catering_manager", extra_perms=["delivery.assign_driver"],
    )
    assert custom_role_has(role, "quotes.send")
    assert custom_role_has(role, "delivery.assign_driver")
    assert not custom_role_has(role, "billing.refund")
