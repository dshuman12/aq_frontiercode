from django.contrib import admin
from apps.roles.models import CustomRole, LocationAccess, PermissionGroup


@admin.register(CustomRole)
class CustomRoleAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "tenant", "base_role")


admin.site.register(PermissionGroup)
admin.site.register(LocationAccess)
