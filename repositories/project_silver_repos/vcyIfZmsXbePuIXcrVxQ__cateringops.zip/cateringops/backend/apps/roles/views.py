from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticated

from apps.roles.models import CustomRole


class CustomRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomRole
        fields = ["id", "slug", "name", "base_role", "extra_perms", "description"]


class CustomRoleViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = CustomRoleSerializer

    def get_queryset(self):
        return CustomRole.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        )

    def perform_create(self, serializer):
        from apps.tenants.models import Tenant
        serializer.save(tenant=Tenant.objects.get(pk=self.kwargs["tenant_id"]))
