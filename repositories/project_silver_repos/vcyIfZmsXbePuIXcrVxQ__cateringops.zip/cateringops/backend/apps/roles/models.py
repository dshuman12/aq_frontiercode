"""Custom roles + permission groups + location-level access."""
from django.db import models
from apps.core.models import TenantScoped


class CustomRole(TenantScoped):
    name = models.CharField(max_length=120)
    slug = models.SlugField(max_length=80)
    base_role = models.CharField(max_length=32, default="viewer")
    extra_perms = models.JSONField(default=list)
    description = models.TextField(blank=True, default="")

    class Meta:
        unique_together = [("tenant", "slug")]


class PermissionGroup(TenantScoped):
    name = models.CharField(max_length=120)
    slug = models.SlugField(max_length=80)
    perms = models.JSONField(default=list)


class LocationAccess(TenantScoped):
    member = models.ForeignKey("tenants.TenantMembership", on_delete=models.CASCADE,
                              related_name="location_access")
    location = models.ForeignKey("locations.Location", on_delete=models.CASCADE,
                                related_name="member_access")

    class Meta:
        unique_together = [("member", "location")]
