from __future__ import annotations

from django.db import transaction

from apps.core.exceptions import Conflict
from apps.core.permissions import ROLE_PERMS, has_perm
from apps.roles.models import CustomRole, LocationAccess


@transaction.atomic
def create_custom_role(*, tenant, slug: str, name: str, base_role: str = "viewer",
                       extra_perms=None) -> CustomRole:
    if CustomRole.objects.filter(tenant=tenant, slug=slug).exists():
        raise Conflict(f"role {slug!r} exists")
    if base_role not in ROLE_PERMS:
        raise ValueError(f"unknown base_role {base_role!r}")
    return CustomRole.objects.create(
        tenant=tenant, slug=slug, name=name, base_role=base_role,
        extra_perms=extra_perms or [],
    )


def custom_role_has(role: CustomRole, perm: str) -> bool:
    if has_perm(role.base_role, perm):
        return True
    for p in role.extra_perms or []:
        if p == "*" or p == perm:
            return True
        if p.endswith(".*") and perm.startswith(p[:-2] + "."):
            return True
    return False


def grant_location(*, member, location) -> LocationAccess:
    obj, _ = LocationAccess.objects.get_or_create(
        tenant=member.tenant, member=member, location=location,
    )
    return obj


def can_access_location(member, location) -> bool:
    if not LocationAccess.objects.filter(member=member).exists():
        return True  # No restriction → can access
    return LocationAccess.objects.filter(member=member, location=location).exists()
