from apps.packages.models import Package


def active_packages(tenant):
    return Package.objects.filter(
        tenant=tenant, is_active=True, archived_at__isnull=True,
    ).order_by("name")
