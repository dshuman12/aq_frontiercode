from __future__ import annotations
from decimal import Decimal, ROUND_HALF_UP

from django.db import transaction

from apps.core.exceptions import Conflict, ValidationError
from apps.packages.models import Package, PackageItem, PackageUpgrade


@transaction.atomic
def create_package(*, tenant, slug: str, name: str, price_per_person,
                  minimum_guest_count: int = 10, maximum_guest_count: int = 500,
                  **fields) -> Package:
    if Package.objects.filter(tenant=tenant, slug=slug).exists():
        raise Conflict(f"package {slug!r} exists")
    if minimum_guest_count > maximum_guest_count:
        raise ValidationError("minimum > maximum")
    if Decimal(price_per_person) <= 0:
        raise ValidationError("price_per_person must be positive")
    return Package.objects.create(
        tenant=tenant, slug=slug, name=name,
        price_per_person=Decimal(price_per_person),
        minimum_guest_count=minimum_guest_count,
        maximum_guest_count=maximum_guest_count, **fields,
    )


def add_item(*, package: Package, menu_item, portion_per_person="1.000",
            note: str = "", sort_order: int = 0) -> PackageItem:
    return PackageItem.objects.create(
        tenant=package.tenant, package=package, menu_item=menu_item,
        portion_per_person=Decimal(portion_per_person), note=note, sort_order=sort_order,
    )


def add_upgrade(*, package: Package, name: str,
               additional_price_per_person="0.00", additional_flat_price="0.00",
               **fields) -> PackageUpgrade:
    return PackageUpgrade.objects.create(
        tenant=package.tenant, package=package, name=name,
        additional_price_per_person=Decimal(additional_price_per_person),
        additional_flat_price=Decimal(additional_flat_price), **fields,
    )


def estimate_total(package: Package, guest_count: int, upgrades=None) -> Decimal:
    if guest_count < package.minimum_guest_count:
        raise ValidationError(f"guests {guest_count} < minimum {package.minimum_guest_count}")
    if guest_count > package.maximum_guest_count:
        raise ValidationError(f"guests {guest_count} > maximum {package.maximum_guest_count}")
    base = package.price_per_person * Decimal(guest_count)
    extra = Decimal("0")
    for up in upgrades or []:
        extra += up.additional_price_per_person * Decimal(guest_count) + up.additional_flat_price
    return (base + extra).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def required_quantity(inclusion: PackageItem, guest_count: int) -> int:
    item = inclusion.menu_item
    portions = inclusion.portion_per_person * Decimal(guest_count)
    per_unit = Decimal(item.serves)
    rounded = portions / per_unit
    rounded_int = rounded.to_integral_value(rounding=ROUND_HALF_UP)
    if rounded_int * per_unit < portions:
        rounded_int += 1
    return int(rounded_int)
