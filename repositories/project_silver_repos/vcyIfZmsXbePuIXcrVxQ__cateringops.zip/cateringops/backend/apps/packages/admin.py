from django.contrib import admin
from apps.packages.models import Package, PackageItem, PackageUpgrade


class ItemInline(admin.TabularInline):
    model = PackageItem
    extra = 0


class UpgradeInline(admin.TabularInline):
    model = PackageUpgrade
    extra = 0


@admin.register(Package)
class PackageAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "price_per_person", "is_active", "tenant")
    inlines = [ItemInline, UpgradeInline]
