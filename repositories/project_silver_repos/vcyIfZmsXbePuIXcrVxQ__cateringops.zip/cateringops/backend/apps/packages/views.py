from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.packages import serializers as ser, services
from apps.packages.models import Package
from apps.tenants.models import Tenant


class PackageViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        return ser.PackageDetailSerializer if self.action != "list" else ser.PackageListSerializer

    def get_queryset(self):
        return Package.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("items__menu_item", "upgrades")

    def perform_create(self, serializer):
        serializer.save(tenant=Tenant.objects.get(pk=self.kwargs["tenant_id"]))

    @action(detail=True, methods=["get"])
    def estimate(self, request, tenant_id=None, pk=None):
        p = self.get_object()
        guests = int(request.query_params.get("guest_count", 0))
        upgrades = list(p.upgrades.filter(id__in=request.query_params.getlist("upgrade")))
        total = services.estimate_total(p, guests, upgrades)
        return Response({"total": str(total), "guest_count": guests})
