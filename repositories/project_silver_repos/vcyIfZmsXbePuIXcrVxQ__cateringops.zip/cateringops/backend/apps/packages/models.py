"""Catering packages: bundles priced per person with min/max guests."""
from django.db import models
from apps.core.models import TenantScoped


class Package(TenantScoped):
    slug = models.SlugField(max_length=80)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True, default="")
    price_per_person = models.DecimalField(max_digits=12, decimal_places=2)
    minimum_guest_count = models.PositiveIntegerField(default=10)
    maximum_guest_count = models.PositiveIntegerField(default=500)
    lead_time_hours = models.PositiveIntegerField(default=24)
    serving_instructions = models.TextField(blank=True, default="")
    production_notes = models.TextField(blank=True, default="")
    is_vegetarian_friendly = models.BooleanField(default=False)
    is_vegan_friendly = models.BooleanField(default=False)
    is_gluten_free_friendly = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    tags = models.JSONField(default=list, blank=True)
    photo_url = models.URLField(blank=True, default="")

    class Meta:
        unique_together = [("tenant", "slug")]


class PackageItem(TenantScoped):
    package = models.ForeignKey(Package, on_delete=models.CASCADE, related_name="items")
    menu_item = models.ForeignKey("menu.MenuItem", on_delete=models.PROTECT, related_name="+")
    portion_per_person = models.DecimalField(max_digits=8, decimal_places=3, default="1.000")
    note = models.CharField(max_length=200, blank=True, default="")
    sort_order = models.IntegerField(default=0)

    class Meta:
        ordering = ["sort_order"]


class PackageUpgrade(TenantScoped):
    package = models.ForeignKey(Package, on_delete=models.CASCADE, related_name="upgrades")
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True, default="")
    additional_price_per_person = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    additional_flat_price = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    is_default = models.BooleanField(default=False)
