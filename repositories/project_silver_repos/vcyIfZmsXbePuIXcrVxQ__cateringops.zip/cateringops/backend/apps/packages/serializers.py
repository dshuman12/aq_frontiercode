from rest_framework import serializers
from apps.packages.models import Package, PackageItem, PackageUpgrade


class PackageItemSerializer(serializers.ModelSerializer):
    menu_item_name = serializers.CharField(source="menu_item.name", read_only=True)

    class Meta:
        model = PackageItem
        fields = ["id", "menu_item_id", "menu_item_name", "portion_per_person", "note", "sort_order"]


class PackageUpgradeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PackageUpgrade
        fields = ["id", "name", "description", "additional_price_per_person",
                  "additional_flat_price", "is_default"]


class PackageListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Package
        fields = ["id", "slug", "name", "price_per_person",
                  "minimum_guest_count", "maximum_guest_count", "is_active"]


class PackageDetailSerializer(PackageListSerializer):
    items = PackageItemSerializer(many=True, read_only=True)
    upgrades = PackageUpgradeSerializer(many=True, read_only=True)

    class Meta(PackageListSerializer.Meta):
        fields = PackageListSerializer.Meta.fields + [
            "description", "lead_time_hours", "serving_instructions", "production_notes",
            "is_vegetarian_friendly", "is_vegan_friendly", "is_gluten_free_friendly",
            "tags", "photo_url", "items", "upgrades",
        ]
