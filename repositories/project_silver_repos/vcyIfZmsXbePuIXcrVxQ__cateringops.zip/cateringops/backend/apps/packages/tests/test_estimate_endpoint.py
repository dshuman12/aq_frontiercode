import pytest


@pytest.mark.django_db
def test_estimate(auth_client, tenant):
    from apps.packages.services import create_package
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="22.50",
                      minimum_guest_count=10, maximum_guest_count=200)
    r = auth_client.get(f"/api/t/{tenant.id}/packages/{p.id}/estimate/?guest_count=40")
    assert r.status_code == 200
    assert r.json()["total"] == "900.00"


@pytest.mark.django_db
def test_below_min_returns_error(auth_client, tenant):
    from apps.packages.services import create_package
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="22.50",
                      minimum_guest_count=20)
    r = auth_client.get(f"/api/t/{tenant.id}/packages/{p.id}/estimate/?guest_count=5")
    assert r.status_code == 400
