import pytest
from decimal import Decimal

from apps.core.exceptions import Conflict, ValidationError
from apps.packages.services import (
    add_item, add_upgrade, create_package, estimate_total, required_quantity,
)


@pytest.fixture
def category(db, tenant):
    from apps.menu.services import create_category
    return create_category(tenant=tenant, slug="x", name="X", kind="boxed_lunch")


@pytest.fixture
def menu_item(db, tenant, category):
    from apps.menu.services import create_item
    return create_item(tenant=tenant, category=category, name="Tray (10)", price="50", serves=10)


@pytest.mark.django_db
def test_create_package_basic(tenant):
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="22.50",
                      minimum_guest_count=10, maximum_guest_count=200)
    assert p.price_per_person == Decimal("22.50")


@pytest.mark.django_db
def test_duplicate_rejected(tenant):
    create_package(tenant=tenant, slug="d", name="A", price_per_person="10")
    with pytest.raises(Conflict):
        create_package(tenant=tenant, slug="d", name="B", price_per_person="10")


@pytest.mark.django_db
def test_min_gt_max_rejected(tenant):
    with pytest.raises(ValidationError):
        create_package(tenant=tenant, slug="x", name="X", price_per_person="10",
                      minimum_guest_count=100, maximum_guest_count=10)


@pytest.mark.django_db
def test_zero_price_rejected(tenant):
    with pytest.raises(ValidationError):
        create_package(tenant=tenant, slug="x", name="X", price_per_person="0")


@pytest.mark.django_db
def test_estimate_basic(tenant):
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="20",
                      minimum_guest_count=10, maximum_guest_count=200)
    assert estimate_total(p, 40) == Decimal("800.00")


@pytest.mark.django_db
def test_estimate_with_upgrades(tenant):
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="20",
                      minimum_guest_count=10, maximum_guest_count=200)
    u = add_upgrade(package=p, name="Drinks",
                   additional_price_per_person="3", additional_flat_price="50")
    # 40*20 = 800; 40*3 + 50 = 170; total = 970
    assert estimate_total(p, 40, [u]) == Decimal("970.00")


@pytest.mark.django_db
def test_below_min_rejected(tenant):
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="20",
                      minimum_guest_count=20)
    with pytest.raises(ValidationError):
        estimate_total(p, 10)


@pytest.mark.django_db
def test_above_max_rejected(tenant):
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="20",
                      minimum_guest_count=10, maximum_guest_count=50)
    with pytest.raises(ValidationError):
        estimate_total(p, 100)


@pytest.mark.django_db
def test_required_qty_rounds_up(tenant, menu_item):
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="20",
                      minimum_guest_count=1, maximum_guest_count=1000)
    inc = add_item(package=p, menu_item=menu_item, portion_per_person="1.0")
    assert required_quantity(inc, 25) == 3  # 25 portions, tray of 10 → 3 trays
    assert required_quantity(inc, 30) == 3
    assert required_quantity(inc, 31) == 4


@pytest.mark.django_db
def test_required_qty_fractional_portion(tenant, menu_item):
    p = create_package(tenant=tenant, slug="x", name="X", price_per_person="20",
                      minimum_guest_count=1, maximum_guest_count=1000)
    inc = add_item(package=p, menu_item=menu_item, portion_per_person="0.5")
    assert required_quantity(inc, 40) == 2  # 20 portions / 10 = 2 trays
