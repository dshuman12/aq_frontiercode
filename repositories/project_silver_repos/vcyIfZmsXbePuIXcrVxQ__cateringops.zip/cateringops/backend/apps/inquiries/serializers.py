from rest_framework import serializers
from apps.inquiries.models import Attachment, Inquiry, Message, StatusHistory


class StatusHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = StatusHistory
        fields = ["id", "from_status", "to_status", "actor_id", "note", "at"]


class MessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Message
        fields = ["id", "from_customer", "author_id", "body", "created_at"]


class AttachmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attachment
        fields = ["id", "file_url", "filename", "content_type", "size_bytes"]


class InquiryListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Inquiry
        fields = ["id", "event_date", "event_time", "guest_count", "event_type",
                  "fulfillment", "contact_name", "contact_email", "status",
                  "assigned_to_id", "submitted_at"]


class InquirySubmitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Inquiry
        fields = ["event_date", "event_time", "guest_count", "event_type",
                  "fulfillment", "delivery_address", "delivery_postal_code",
                  "contact_name", "contact_email", "contact_phone", "company_name",
                  "budget_low", "budget_high", "dietary_notes", "special_instructions"]


class InquiryDetailSerializer(InquiryListSerializer):
    status_history = StatusHistorySerializer(many=True, read_only=True)
    messages = MessageSerializer(many=True, read_only=True)
    attachments = AttachmentSerializer(many=True, read_only=True)
    declined_reason = serializers.CharField(read_only=True)

    class Meta(InquiryListSerializer.Meta):
        fields = InquiryListSerializer.Meta.fields + [
            "delivery_address", "delivery_postal_code", "company_name",
            "budget_low", "budget_high", "dietary_notes", "special_instructions",
            "customer_id", "source", "declined_reason",
            "status_history", "messages", "attachments",
        ]
