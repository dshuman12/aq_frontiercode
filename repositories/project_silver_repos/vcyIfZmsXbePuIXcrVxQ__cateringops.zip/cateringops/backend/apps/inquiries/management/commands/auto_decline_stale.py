from django.core.management.base import BaseCommand
from apps.inquiries.tasks import auto_decline_stale_inquiries


class Command(BaseCommand):
    help = "Auto-decline inquiries older than --days (default 21)."

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=21)

    def handle(self, *args, days=21, **options):
        r = auto_decline_stale_inquiries(days=days)
        self.stdout.write(self.style.SUCCESS(f"Declined {r['declined']}"))
