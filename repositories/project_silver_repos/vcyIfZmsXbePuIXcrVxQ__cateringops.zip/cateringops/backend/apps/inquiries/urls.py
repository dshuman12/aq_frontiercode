from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.inquiries.views import InquiryViewSet

router = DefaultRouter()
router.register("", InquiryViewSet, basename="inquiry")

urlpatterns = [path("", include(router.urls))]
