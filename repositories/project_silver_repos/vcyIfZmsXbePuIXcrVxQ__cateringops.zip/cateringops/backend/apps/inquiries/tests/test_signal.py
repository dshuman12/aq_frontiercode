"""Inquiry creation should fire notification task once."""
import pytest
from datetime import date, time, timedelta
from unittest.mock import patch


@pytest.mark.django_db
def test_signal_fires(tenant):
    from apps.inquiries.services import submit_inquiry
    with patch("apps.notifications.tasks.notify_new_inquiry.delay") as mock_delay:
        submit_inquiry(tenant=tenant, payload={
            "event_date": (date.today() + timedelta(days=5)).isoformat(),
            "event_time": time(12), "guest_count": 10, "event_type": "wedding",
            "contact_name": "X", "contact_email": "x@x.test",
        })
        assert mock_delay.called


@pytest.mark.django_db
def test_update_doesnt_fire(tenant):
    from apps.inquiries.services import submit_inquiry
    inq = submit_inquiry(tenant=tenant, payload={
        "event_date": (date.today() + timedelta(days=5)).isoformat(),
        "event_time": time(12), "guest_count": 10, "event_type": "wedding",
        "contact_name": "X", "contact_email": "x@x.test",
    })
    with patch("apps.notifications.tasks.notify_new_inquiry.delay") as mock_delay:
        inq.guest_count = 15
        inq.save()
        assert not mock_delay.called
