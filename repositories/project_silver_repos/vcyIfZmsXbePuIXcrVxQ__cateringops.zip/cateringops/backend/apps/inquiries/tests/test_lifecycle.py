import pytest
from datetime import date, time, timedelta

from apps.core.exceptions import Conflict
from apps.inquiries.services import (
    add_message, decline, submit_inquiry, transition,
)


@pytest.fixture
def inquiry(tenant):
    return submit_inquiry(tenant=tenant, payload={
        "event_date": (date.today() + timedelta(days=10)).isoformat(),
        "event_time": time(12), "guest_count": 30, "event_type": "wedding",
        "contact_name": "X", "contact_email": "x@x.test",
    })


@pytest.mark.django_db
def test_valid_transition(inquiry, user):
    transition(inquiry=inquiry, to_status="reviewed", actor=user)
    assert inquiry.status == "reviewed"


@pytest.mark.django_db
def test_invalid_transition_rejected(inquiry, user):
    with pytest.raises(Conflict):
        transition(inquiry=inquiry, to_status="converted", actor=user)


@pytest.mark.django_db
def test_terminal_locked(inquiry, user):
    decline(inquiry=inquiry, reason="too small", actor=user)
    with pytest.raises(Conflict):
        transition(inquiry=inquiry, to_status="reviewed", actor=user)


@pytest.mark.django_db
def test_happy_path(inquiry, user):
    transition(inquiry=inquiry, to_status="reviewed", actor=user)
    transition(inquiry=inquiry, to_status="quote_created", actor=user)
    transition(inquiry=inquiry, to_status="converted", actor=user)
    assert inquiry.status == "converted"


@pytest.mark.django_db
def test_message_recorded(inquiry, user):
    m = add_message(inquiry=inquiry, body="Can you do gluten free?", author=user)
    assert m.body.startswith("Can")
