import pytest
from datetime import date, time, timedelta

from apps.inquiries.services import attach, submit_inquiry


@pytest.mark.django_db
def test_attach(tenant):
    inq = submit_inquiry(tenant=tenant, payload={
        "event_date": (date.today() + timedelta(days=5)).isoformat(),
        "event_time": time(12), "guest_count": 10, "event_type": "wedding",
        "contact_name": "X", "contact_email": "x@x.test",
    })
    a = attach(inquiry=inq, file_url="s3://x", filename="floor.pdf", size_bytes=1234)
    assert a.filename == "floor.pdf"
    assert inq.attachments.count() == 1
