import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.core.exceptions import ValidationError
from apps.inquiries.services import submit_inquiry


@pytest.fixture
def payload():
    return {
        "event_date": (date.today() + timedelta(days=14)).isoformat(),
        "event_time": time(12, 0), "guest_count": 40, "event_type": "corporate_lunch",
        "fulfillment": "delivery", "delivery_address": "100 Office",
        "contact_name": "Maria", "contact_email": "m@acme.test",
        "contact_phone": "555", "company_name": "Acme",
        "budget_low": Decimal("400"), "budget_high": Decimal("600"),
    }


@pytest.mark.django_db
def test_submit_creates_inquiry_and_customer(tenant, payload):
    inq = submit_inquiry(tenant=tenant, payload=payload)
    assert inq.status == "new"
    assert inq.customer.primary_email == "m@acme.test"


@pytest.mark.django_db
def test_links_existing_customer(tenant, payload):
    a = submit_inquiry(tenant=tenant, payload=payload)
    payload["event_date"] = (date.today() + timedelta(days=30)).isoformat()
    b = submit_inquiry(tenant=tenant, payload=payload)
    assert a.customer_id == b.customer_id


@pytest.mark.django_db
def test_past_date_rejected(tenant, payload):
    payload["event_date"] = (date.today() - timedelta(days=1)).isoformat()
    with pytest.raises(ValidationError):
        submit_inquiry(tenant=tenant, payload=payload)


@pytest.mark.django_db
def test_zero_guests_rejected(tenant, payload):
    payload["guest_count"] = 0
    with pytest.raises(ValidationError):
        submit_inquiry(tenant=tenant, payload=payload)


@pytest.mark.django_db
def test_missing_field_rejected(tenant, payload):
    del payload["event_time"]
    with pytest.raises(ValidationError):
        submit_inquiry(tenant=tenant, payload=payload)
