import pytest
from datetime import date, time, timedelta


@pytest.fixture
def make_inq(tenant):
    def _make(days=10, status="new"):
        from apps.inquiries.services import submit_inquiry, transition
        inq = submit_inquiry(tenant=tenant, payload={
            "event_date": (date.today() + timedelta(days=days)).isoformat(),
            "event_time": time(12), "guest_count": 20, "event_type": "wedding",
            "contact_name": "X", "contact_email": f"x{days}@x.test",
        })
        if status != "new":
            transition(inquiry=inq, to_status=status, actor=None)
        return inq
    return _make


@pytest.mark.django_db
def test_filter_by_status(tenant, make_inq):
    from apps.inquiries.selectors import inquiries_for
    make_inq(days=10, status="new")
    make_inq(days=20, status="reviewed")
    assert inquiries_for(tenant, status="new").count() == 1


@pytest.mark.django_db
def test_open_count_excludes_terminal(tenant, make_inq):
    from apps.inquiries.selectors import open_count
    make_inq(days=10, status="new")
    make_inq(days=20, status="reviewed")
    make_inq(days=30, status="declined")
    assert open_count(tenant) == 2


@pytest.mark.django_db
def test_upcoming(tenant, make_inq):
    from apps.inquiries.selectors import upcoming
    make_inq(days=5)
    make_inq(days=20)
    assert upcoming(tenant).count() == 2
