from __future__ import annotations
from datetime import date

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import Conflict, NotFound, ValidationError
from apps.customers.services import find_or_create_by_email
from apps.inquiries.models import Attachment, Inquiry, Message, StatusHistory

ALLOWED = {
    "new": {"reviewed", "needs_more_info", "declined", "cancelled"},
    "reviewed": {"quote_created", "needs_more_info", "declined", "cancelled"},
    "needs_more_info": {"reviewed", "declined", "cancelled"},
    "quote_created": {"converted", "declined", "cancelled"},
    "converted": set(), "declined": set(), "cancelled": set(),
}


_FIELDS = {
    "event_date", "event_time", "guest_count", "event_type",
    "fulfillment", "delivery_address", "delivery_postal_code",
    "contact_name", "contact_email", "contact_phone", "company_name",
    "budget_low", "budget_high", "dietary_notes", "special_instructions",
}


@transaction.atomic
def submit_inquiry(*, tenant, payload: dict) -> Inquiry:
    required = ("event_date", "event_time", "guest_count", "event_type",
                "contact_name", "contact_email")
    for k in required:
        if not payload.get(k):
            raise ValidationError(f"{k} is required")
    if payload.get("guest_count", 0) < 1:
        raise ValidationError("guest_count must be >= 1")
    event_date = (date.fromisoformat(payload["event_date"])
                 if isinstance(payload["event_date"], str) else payload["event_date"])
    if event_date < timezone.now().date():
        raise ValidationError("event_date must be in the future")

    customer = find_or_create_by_email(
        tenant=tenant, email=payload["contact_email"],
        defaults={
            "primary_contact_name": payload["contact_name"],
            "primary_phone": payload.get("contact_phone", ""),
            "company_name": payload.get("company_name", ""),
            "kind": "business" if payload.get("company_name") else "individual",
        },
    )
    inquiry = Inquiry.objects.create(
        tenant=tenant, customer=customer,
        source=payload.get("source", "public_form"),
        **{k: v for k, v in payload.items() if k in _FIELDS}
    )
    StatusHistory.objects.create(
        tenant=tenant, inquiry=inquiry, from_status="",
        to_status="new", actor=None, note="auto-created",
    )
    return inquiry


@transaction.atomic
def transition(*, inquiry: Inquiry, to_status: str, actor=None, note: str = "") -> Inquiry:
    if to_status not in ALLOWED.get(inquiry.status, set()):
        raise Conflict(f"cannot transition {inquiry.status} → {to_status}")
    from_status = inquiry.status
    inquiry.status = to_status
    inquiry.save(update_fields=["status"])
    StatusHistory.objects.create(
        tenant=inquiry.tenant, inquiry=inquiry,
        from_status=from_status, to_status=to_status, actor=actor, note=note,
    )
    return inquiry


def assign(*, inquiry: Inquiry, assignee, actor=None) -> Inquiry:
    inquiry.assigned_to = assignee
    inquiry.save(update_fields=["assigned_to"])
    StatusHistory.objects.create(
        tenant=inquiry.tenant, inquiry=inquiry,
        from_status=inquiry.status, to_status=inquiry.status,
        actor=actor, note=f"assigned to {assignee.email}",
    )
    return inquiry


def add_message(*, inquiry: Inquiry, body: str, author=None, from_customer: bool = False) -> Message:
    return Message.objects.create(
        tenant=inquiry.tenant, inquiry=inquiry, body=body,
        author=author, from_customer=from_customer,
    )


def attach(*, inquiry: Inquiry, file_url: str, filename: str,
          content_type: str = "", size_bytes: int = 0) -> Attachment:
    return Attachment.objects.create(
        tenant=inquiry.tenant, inquiry=inquiry, file_url=file_url,
        filename=filename, content_type=content_type, size_bytes=size_bytes,
    )


def decline(*, inquiry: Inquiry, reason: str, actor=None) -> Inquiry:
    transition(inquiry=inquiry, to_status="declined", actor=actor, note=reason)
    inquiry.declined_reason = reason
    inquiry.save(update_fields=["declined_reason"])
    return inquiry
