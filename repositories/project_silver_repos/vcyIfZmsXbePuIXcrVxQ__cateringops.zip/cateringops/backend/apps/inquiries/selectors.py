from datetime import date

from django.utils import timezone

from apps.inquiries.models import Inquiry


def inquiries_for(tenant, *, status=None, assignee=None):
    qs = Inquiry.objects.filter(tenant=tenant, archived_at__isnull=True)
    if status:
        qs = qs.filter(status=status)
    if assignee is not None:
        qs = qs.filter(assigned_to=assignee)
    return qs.select_related("customer", "assigned_to").order_by("-submitted_at")


def upcoming(tenant):
    return inquiries_for(tenant).filter(event_date__gte=timezone.now().date())


def open_count(tenant) -> int:
    return Inquiry.objects.filter(
        tenant=tenant, status__in=("new", "reviewed", "needs_more_info"),
        archived_at__isnull=True,
    ).count()
