from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from apps.inquiries import serializers as ser, services
from apps.inquiries.models import Inquiry
from apps.tenants.models import Tenant


class InquiryViewSet(viewsets.ModelViewSet):
    def get_permissions(self):
        return [AllowAny()] if self.action == "submit" else [IsAuthenticated()]

    def get_serializer_class(self):
        if self.action == "submit":
            return ser.InquirySubmitSerializer
        return ser.InquiryDetailSerializer if self.action != "list" else ser.InquiryListSerializer

    def get_queryset(self):
        return Inquiry.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("status_history", "messages", "attachments")

    @action(detail=False, methods=["post"], permission_classes=[AllowAny])
    def submit(self, request, tenant_id=None):
        t = Tenant.objects.get(pk=tenant_id)
        s = ser.InquirySubmitSerializer(data=request.data); s.is_valid(raise_exception=True)
        inq = services.submit_inquiry(tenant=t, payload=s.validated_data)
        return Response(ser.InquiryDetailSerializer(inq).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def status(self, request, tenant_id=None, pk=None):
        inq = self.get_object()
        services.transition(inquiry=inq, to_status=request.data["to"],
                           actor=request.user, note=request.data.get("note", ""))
        return Response(ser.InquiryDetailSerializer(inq).data)

    @action(detail=True, methods=["post"])
    def assign(self, request, tenant_id=None, pk=None):
        from django.contrib.auth import get_user_model
        inq = self.get_object()
        services.assign(inquiry=inq,
                       assignee=get_user_model().objects.get(pk=request.data["assignee"]),
                       actor=request.user)
        return Response(ser.InquiryDetailSerializer(inq).data)

    @action(detail=True, methods=["post"])
    def message(self, request, tenant_id=None, pk=None):
        m = services.add_message(inquiry=self.get_object(), body=request.data["body"],
                                author=request.user)
        return Response(ser.MessageSerializer(m).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def decline(self, request, tenant_id=None, pk=None):
        inq = self.get_object()
        services.decline(inquiry=inq, reason=request.data["reason"], actor=request.user)
        return Response(ser.InquiryDetailSerializer(inq).data)
