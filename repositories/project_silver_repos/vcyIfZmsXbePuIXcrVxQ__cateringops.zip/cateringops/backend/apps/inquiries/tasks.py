from datetime import timedelta

from celery import shared_task
from django.utils import timezone


@shared_task
def auto_decline_stale_inquiries(days: int = 21):
    from apps.inquiries.models import Inquiry
    cutoff = timezone.now() - timedelta(days=days)
    qs = Inquiry.objects.filter(status="new", submitted_at__lt=cutoff, archived_at__isnull=True)
    n = qs.count()
    qs.update(status="declined", declined_reason=f"auto-declined after {days} days idle")
    return {"declined": n}
