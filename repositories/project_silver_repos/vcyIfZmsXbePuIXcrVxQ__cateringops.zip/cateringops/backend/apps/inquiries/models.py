"""Inquiry: a customer's request to cater an event."""
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class Inquiry(TenantScoped):
    STATUS_CHOICES = [
        ("new", "New"), ("reviewed", "Reviewed"),
        ("needs_more_info", "Needs more info"), ("quote_created", "Quote created"),
        ("converted", "Converted"), ("declined", "Declined"), ("cancelled", "Cancelled"),
    ]
    EVENT_TYPE_CHOICES = [
        ("corporate_lunch", "Corporate lunch"),
        ("corporate_breakfast", "Corporate breakfast"),
        ("wedding", "Wedding"), ("party", "Party"), ("school", "School event"),
        ("church", "Church"), ("private", "Private"), ("other", "Other"),
    ]
    FULFILLMENT_CHOICES = [("pickup", "Pickup"), ("delivery", "Delivery")]

    event_date = models.DateField()
    event_time = models.TimeField()
    guest_count = models.PositiveIntegerField()
    event_type = models.CharField(max_length=32, choices=EVENT_TYPE_CHOICES)
    fulfillment = models.CharField(max_length=16, choices=FULFILLMENT_CHOICES, default="delivery")
    delivery_address = models.CharField(max_length=400, blank=True, default="")
    delivery_postal_code = models.CharField(max_length=24, blank=True, default="")

    contact_name = models.CharField(max_length=200)
    contact_email = models.EmailField()
    contact_phone = models.CharField(max_length=32, blank=True, default="")
    company_name = models.CharField(max_length=200, blank=True, default="")

    budget_low = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    budget_high = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    dietary_notes = models.TextField(blank=True, default="")
    special_instructions = models.TextField(blank=True, default="")

    status = models.CharField(max_length=24, choices=STATUS_CHOICES, default="new", db_index=True)
    declined_reason = models.TextField(blank=True, default="")

    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, blank=True, related_name="assigned_inquiries")
    customer = models.ForeignKey("customers.Customer", on_delete=models.SET_NULL,
                                null=True, blank=True, related_name="inquiries")

    source = models.CharField(max_length=24, default="public_form")
    submitted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=["tenant", "status", "event_date"]),
            models.Index(fields=["tenant", "assigned_to"]),
        ]
        ordering = ["-submitted_at"]


class StatusHistory(TenantScoped):
    inquiry = models.ForeignKey(Inquiry, on_delete=models.CASCADE, related_name="status_history")
    from_status = models.CharField(max_length=24)
    to_status = models.CharField(max_length=24)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                             null=True, related_name="+")
    note = models.CharField(max_length=400, blank=True, default="")
    at = models.DateTimeField(auto_now_add=True)


class Message(TenantScoped):
    inquiry = models.ForeignKey(Inquiry, on_delete=models.CASCADE, related_name="messages")
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                              null=True, blank=True, related_name="+")
    from_customer = models.BooleanField(default=False)
    body = models.TextField()

    class Meta:
        ordering = ["created_at"]


class Attachment(TenantScoped):
    inquiry = models.ForeignKey(Inquiry, on_delete=models.CASCADE, related_name="attachments")
    file_url = models.URLField()
    filename = models.CharField(max_length=200)
    content_type = models.CharField(max_length=80, blank=True, default="")
    size_bytes = models.PositiveBigIntegerField(default=0)
