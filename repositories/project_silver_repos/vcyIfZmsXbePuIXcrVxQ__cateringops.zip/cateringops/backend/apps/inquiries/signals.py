"""Notify on new inquiry."""
from django.db.models.signals import post_save
from django.dispatch import receiver
from apps.inquiries.models import Inquiry


@receiver(post_save, sender=Inquiry)
def on_new(sender, instance, created, **kwargs):
    if not created:
        return
    from apps.notifications.tasks import notify_new_inquiry
    notify_new_inquiry.delay(str(instance.id))
