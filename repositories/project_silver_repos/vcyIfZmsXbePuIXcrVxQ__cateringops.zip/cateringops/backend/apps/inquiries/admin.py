from django.contrib import admin
from apps.inquiries.models import Attachment, Inquiry, Message, StatusHistory


class HistoryInline(admin.TabularInline):
    model = StatusHistory
    extra = 0
    readonly_fields = ("from_status", "to_status", "actor", "note", "at")


@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ("event_date", "guest_count", "event_type", "contact_name", "status", "tenant")
    list_filter = ("status", "event_type")
    search_fields = ("contact_name", "contact_email")
    inlines = [HistoryInline]


admin.site.register(Message)
admin.site.register(Attachment)
