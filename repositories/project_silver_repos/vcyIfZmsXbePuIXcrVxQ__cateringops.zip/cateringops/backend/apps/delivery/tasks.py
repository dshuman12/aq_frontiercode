from celery import shared_task


@shared_task
def send_delivery_reminders():
    from datetime import timedelta
    from django.utils import timezone
    from apps.delivery.models import Delivery
    from apps.notifications.tasks import dispatch_template
    cutoff = timezone.now() + timedelta(hours=4)
    qs = Delivery.objects.filter(
        status__in=("scheduled", "ready"),
        delivery_window_start__lte=cutoff, archived_at__isnull=True,
    )
    n = 0
    for d in qs:
        dispatch_template.delay("delivery.reminder", {"delivery_id": str(d.id)})
        n += 1
    return {"reminders": n}
