import pytest
from datetime import date, time, timedelta


@pytest.mark.django_db
def test_today(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    from apps.delivery.services import create_for_order
    from apps.delivery.selectors import deliveries_today
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today(), event_time=time(12), guest_count=10,
                     fulfillment="delivery", delivery_address="X",
                     items=[{"label": "X", "quantity": 1, "unit_price": "100"}], actor=user)
    d = create_for_order(order=o)
    assert d in deliveries_today(tenant)
