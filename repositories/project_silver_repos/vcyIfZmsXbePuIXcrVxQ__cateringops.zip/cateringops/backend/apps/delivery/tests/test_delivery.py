import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.core.exceptions import Conflict, ValidationError
from apps.delivery.services import (
    assign_driver, create_for_order, mark_failed, record_proof, transition,
)


@pytest.fixture
def order(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    c = create_customer(tenant=tenant, primary_email="x@x.test",
                       primary_contact_name="J", primary_phone="555")
    return create_direct(tenant=tenant, customer=c, location=location,
                        event_date=date.today() + timedelta(days=2), event_time=time(12),
                        guest_count=20, fulfillment="delivery",
                        delivery_address="100 X", items=[{"label": "X", "quantity": 1, "unit_price": "100"}],
                        actor=user)


@pytest.fixture
def pickup_order(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    return create_direct(tenant=tenant, customer=c, location=location,
                        event_date=date.today() + timedelta(days=2), event_time=time(12),
                        guest_count=10, fulfillment="pickup",
                        items=[{"label": "X", "quantity": 1, "unit_price": "100"}], actor=user)


@pytest.fixture
def driver(db):
    from django.contrib.auth import get_user_model
    return get_user_model().objects.create_user(email="dr@x.test", password="pw-correct-horse-9")


@pytest.mark.django_db
def test_pickup_no_delivery(pickup_order):
    with pytest.raises(ValidationError):
        create_for_order(order=pickup_order)


@pytest.mark.django_db
def test_idempotent(order):
    a = create_for_order(order=order)
    b = create_for_order(order=order)
    assert a.id == b.id


@pytest.mark.django_db
def test_assign_then_dispatch(order, driver, user):
    d = create_for_order(order=order)
    assign_driver(delivery=d, driver=driver, actor=user)
    d.refresh_from_db()
    assert d.driver_id == driver.id
    assert d.status == "driver_assigned"
    transition(delivery=d, to_status="out_for_delivery", actor=user)
    d.refresh_from_db()
    assert d.status == "out_for_delivery"


@pytest.mark.django_db
def test_proof_records_delivered(order, driver, user):
    d = create_for_order(order=order)
    assign_driver(delivery=d, driver=driver, actor=user)
    transition(delivery=d, to_status="out_for_delivery", actor=user)
    p = record_proof(delivery=d, received_by_name="Security")
    assert p.received_by_name == "Security"
    d.refresh_from_db()
    assert d.status == "delivered"


@pytest.mark.django_db
def test_cannot_proof_too_early(order):
    d = create_for_order(order=order)
    with pytest.raises(Conflict):
        record_proof(delivery=d, received_by_name="X")


@pytest.mark.django_db
def test_failed_then_returned(order, driver, user):
    d = create_for_order(order=order)
    assign_driver(delivery=d, driver=driver, actor=user)
    transition(delivery=d, to_status="out_for_delivery", actor=user)
    mark_failed(delivery=d, reason="locked office", actor=user)
    d.refresh_from_db()
    assert "locked office" in d.failure_reason
    transition(delivery=d, to_status="returned", actor=user)
    d.refresh_from_db()
    assert d.status == "returned"


@pytest.mark.django_db
def test_reassign_closes_prior(order, driver, user):
    from django.contrib.auth import get_user_model
    d = create_for_order(order=order)
    other = get_user_model().objects.create_user(email="o@x.test", password="pw-correct-horse-9")
    assign_driver(delivery=d, driver=driver, actor=user)
    assign_driver(delivery=d, driver=other, actor=user)
    d.refresh_from_db()
    assert d.driver_id == other.id
    closed = d.assignments.filter(unassigned_at__isnull=False).count()
    assert closed == 1


@pytest.mark.django_db
def test_invalid_transition(order, user):
    d = create_for_order(order=order)
    with pytest.raises(Conflict):
        transition(delivery=d, to_status="delivered", actor=user)
