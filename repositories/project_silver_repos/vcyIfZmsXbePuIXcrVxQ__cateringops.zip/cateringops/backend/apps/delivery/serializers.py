from rest_framework import serializers
from apps.delivery.models import (
    Delivery, DeliveryAssignment, DeliveryProof, DeliveryStatusHistory,
)


class HistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryStatusHistory
        fields = ["id", "from_status", "to_status", "actor_id", "note", "at"]


class ProofSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryProof
        fields = ["id", "signature_url", "photo_url", "received_by_name", "note", "received_at"]


class AssignmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryAssignment
        fields = ["id", "driver_id", "assigned_at", "unassigned_at", "note"]


class DeliveryListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Delivery
        fields = ["id", "order_id", "address", "delivery_window_start",
                  "delivery_window_end", "status", "driver_id"]


class DeliveryDetailSerializer(DeliveryListSerializer):
    status_history = HistorySerializer(many=True, read_only=True)
    proofs = ProofSerializer(many=True, read_only=True)
    assignments = AssignmentSerializer(many=True, read_only=True)

    class Meta(DeliveryListSerializer.Meta):
        fields = DeliveryListSerializer.Meta.fields + [
            "contact_name", "contact_phone", "delivery_instructions",
            "driver_notes", "failure_reason", "delivered_at",
            "status_history", "proofs", "assignments",
        ]
