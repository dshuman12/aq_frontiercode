from django.contrib import admin
from apps.delivery.models import (
    Delivery, DeliveryAssignment, DeliveryProof, DeliveryStatusHistory,
)


admin.site.register(Delivery)
admin.site.register(DeliveryAssignment)
admin.site.register(DeliveryProof)
admin.site.register(DeliveryStatusHistory)
