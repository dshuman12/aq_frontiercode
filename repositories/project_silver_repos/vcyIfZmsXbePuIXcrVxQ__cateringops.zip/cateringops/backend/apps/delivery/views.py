from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.delivery import services
from apps.delivery.models import Delivery
from apps.delivery.serializers import (
    DeliveryDetailSerializer, DeliveryListSerializer, ProofSerializer,
)


class DeliveryViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        return DeliveryDetailSerializer if self.action != "list" else DeliveryListSerializer

    def get_queryset(self):
        return Delivery.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("status_history", "proofs", "assignments")

    @action(detail=True, methods=["post"])
    def assign_driver(self, request, tenant_id=None, pk=None):
        from django.contrib.auth import get_user_model
        d = self.get_object()
        driver = get_user_model().objects.get(pk=request.data["driver"])
        services.assign_driver(delivery=d, driver=driver, actor=request.user)
        return Response(DeliveryDetailSerializer(d).data)

    @action(detail=True, methods=["post"])
    def start(self, request, tenant_id=None, pk=None):
        services.transition(delivery=self.get_object(), to_status="out_for_delivery", actor=request.user)
        return Response(DeliveryDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"], url_path="upload-proof")
    def proof(self, request, tenant_id=None, pk=None):
        p = services.record_proof(
            delivery=self.get_object(),
            signature_url=request.data.get("signature_url", ""),
            photo_url=request.data.get("photo_url", ""),
            received_by_name=request.data.get("received_by_name", ""),
            note=request.data.get("note", ""),
        )
        return Response(ProofSerializer(p).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def fail(self, request, tenant_id=None, pk=None):
        services.mark_failed(delivery=self.get_object(),
                            reason=request.data["reason"], actor=request.user)
        return Response(DeliveryDetailSerializer(self.get_object()).data)
