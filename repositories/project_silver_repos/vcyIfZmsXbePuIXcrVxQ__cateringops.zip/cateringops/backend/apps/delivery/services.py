from __future__ import annotations
from datetime import datetime, timedelta

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import Conflict, ValidationError
from apps.delivery.models import Delivery, DeliveryAssignment, DeliveryProof, DeliveryStatusHistory

ALLOWED = {
    "scheduled": {"preparing", "ready", "driver_assigned", "failed"},
    "preparing": {"ready", "failed"},
    "ready": {"driver_assigned", "out_for_delivery", "failed"},
    "driver_assigned": {"out_for_delivery", "failed"},
    "out_for_delivery": {"delivered", "failed", "returned"},
    "delivered": set(),
    "failed": {"returned"},
    "returned": set(),
}


@transaction.atomic
def create_for_order(*, order, window_start=None, window_end=None) -> Delivery:
    if hasattr(order, "delivery"):
        return order.delivery
    if order.fulfillment != "delivery":
        raise ValidationError("order is not a delivery")
    event_dt = datetime.combine(order.event_date, order.event_time)
    ws = window_start or (event_dt - timedelta(minutes=30))
    we = window_end or (event_dt + timedelta(minutes=15))
    return Delivery.objects.create(
        tenant=order.tenant, order=order, address=order.delivery_address,
        postal_code=order.delivery_postal_code,
        contact_name=order.customer.primary_contact_name or "",
        contact_phone=order.customer.primary_phone or "",
        delivery_window_start=ws, delivery_window_end=we,
    )


@transaction.atomic
def transition(*, delivery, to_status: str, actor=None, note: str = "") -> Delivery:
    if to_status not in ALLOWED.get(delivery.status, set()):
        raise Conflict(f"cannot transition {delivery.status} → {to_status}")
    fr = delivery.status
    delivery.status = to_status
    if to_status == "delivered":
        delivery.delivered_at = timezone.now()
    elif to_status == "failed":
        delivery.failure_reason = note
    delivery.save()
    DeliveryStatusHistory.objects.create(
        tenant=delivery.tenant, delivery=delivery,
        from_status=fr, to_status=to_status, actor=actor, note=note,
    )
    return delivery


@transaction.atomic
def assign_driver(*, delivery, driver, actor=None, note: str = "") -> DeliveryAssignment:
    if delivery.status in ("delivered", "returned"):
        raise Conflict("delivery already complete")
    if delivery.driver is not None and delivery.driver_id != driver.id:
        DeliveryAssignment.objects.filter(
            delivery=delivery, unassigned_at__isnull=True
        ).update(unassigned_at=timezone.now())
    delivery.driver = driver
    delivery.save(update_fields=["driver"])
    a = DeliveryAssignment.objects.create(
        tenant=delivery.tenant, delivery=delivery, driver=driver, note=note,
    )
    if delivery.status in ("scheduled", "ready"):
        transition(delivery=delivery, to_status="driver_assigned", actor=actor,
                  note=f"assigned to {driver.email}")
    return a


@transaction.atomic
def record_proof(*, delivery, signature_url: str = "", photo_url: str = "",
                received_by_name: str = "", note: str = "") -> DeliveryProof:
    if delivery.status not in ("out_for_delivery", "driver_assigned"):
        raise Conflict("not ready for proof")
    proof = DeliveryProof.objects.create(
        tenant=delivery.tenant, delivery=delivery,
        signature_url=signature_url, photo_url=photo_url,
        received_by_name=received_by_name, note=note,
    )
    transition(delivery=delivery, to_status="delivered", actor=None,
              note=f"received by {received_by_name or 'unspecified'}")
    return proof


@transaction.atomic
def mark_failed(*, delivery, reason: str, actor=None) -> Delivery:
    return transition(delivery=delivery, to_status="failed", actor=actor, note=reason)
