"""Delivery schedule + driver assignment + proof of delivery."""
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class Delivery(TenantScoped):
    STATUS_CHOICES = [
        ("scheduled", "Scheduled"), ("preparing", "Preparing"),
        ("ready", "Ready"), ("driver_assigned", "Driver assigned"),
        ("out_for_delivery", "Out for delivery"),
        ("delivered", "Delivered"), ("failed", "Failed"), ("returned", "Returned"),
    ]
    order = models.OneToOneField("orders.Order", on_delete=models.CASCADE, related_name="delivery")
    address = models.CharField(max_length=400)
    postal_code = models.CharField(max_length=24, blank=True, default="")
    contact_name = models.CharField(max_length=200, blank=True, default="")
    contact_phone = models.CharField(max_length=32, blank=True, default="")
    delivery_window_start = models.DateTimeField()
    delivery_window_end = models.DateTimeField()
    delivery_instructions = models.TextField(blank=True, default="")
    status = models.CharField(max_length=24, choices=STATUS_CHOICES, default="scheduled", db_index=True)
    driver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                              null=True, blank=True, related_name="deliveries")
    driver_notes = models.TextField(blank=True, default="")
    failure_reason = models.TextField(blank=True, default="")
    delivered_at = models.DateTimeField(null=True, blank=True)


class DeliveryAssignment(TenantScoped):
    delivery = models.ForeignKey(Delivery, on_delete=models.CASCADE, related_name="assignments")
    driver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    assigned_at = models.DateTimeField(auto_now_add=True)
    unassigned_at = models.DateTimeField(null=True, blank=True)
    note = models.CharField(max_length=300, blank=True, default="")


class DeliveryStatusHistory(TenantScoped):
    delivery = models.ForeignKey(Delivery, on_delete=models.CASCADE, related_name="status_history")
    from_status = models.CharField(max_length=24)
    to_status = models.CharField(max_length=24)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                             null=True, related_name="+")
    note = models.CharField(max_length=300, blank=True, default="")
    at = models.DateTimeField(auto_now_add=True)


class DeliveryProof(TenantScoped):
    delivery = models.ForeignKey(Delivery, on_delete=models.CASCADE, related_name="proofs")
    signature_url = models.URLField(blank=True, default="")
    photo_url = models.URLField(blank=True, default="")
    received_by_name = models.CharField(max_length=200, blank=True, default="")
    received_at = models.DateTimeField(auto_now_add=True)
    note = models.TextField(blank=True, default="")
