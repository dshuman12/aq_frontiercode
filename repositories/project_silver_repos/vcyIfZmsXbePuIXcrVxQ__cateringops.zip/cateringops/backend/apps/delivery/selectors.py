from datetime import timedelta

from django.utils import timezone

from apps.delivery.models import Delivery


def deliveries_today(tenant):
    start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
    return Delivery.objects.filter(
        tenant=tenant, delivery_window_start__gte=start,
        delivery_window_start__lt=start + timedelta(days=1),
        archived_at__isnull=True,
    ).select_related("order", "driver")


def deliveries_for_driver(driver):
    return Delivery.objects.filter(driver=driver, archived_at__isnull=True).order_by("delivery_window_start")
