from django.contrib import admin
from apps.payments.models import Payment, Refund


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("order", "amount", "method", "kind", "status", "received_at")
    list_filter = ("method", "kind", "status")


admin.site.register(Refund)
