from __future__ import annotations
from decimal import Decimal

from django.db import models, transaction

from apps.core.exceptions import Conflict, PaymentError, ValidationError
from apps.billing.services import apply_invoice_payment
from apps.payments.models import Payment, Refund


@transaction.atomic
def record_payment(*, order, invoice=None, amount, method: str, kind: str,
                  note: str = "", reference: str = "",
                  stripe_payment_intent_id: str = "",
                  stripe_charge_id: str = "") -> Payment:
    amount = Decimal(amount)
    if amount <= 0:
        raise ValidationError("amount > 0")
    p = Payment.objects.create(
        tenant=order.tenant, order=order, invoice=invoice,
        amount=amount, method=method, kind=kind, note=note, reference=reference,
        stripe_payment_intent_id=stripe_payment_intent_id,
        stripe_charge_id=stripe_charge_id,
    )
    if invoice is not None and kind == "balance":
        apply_invoice_payment(invoice=invoice, amount=amount, payment=p)
    if kind == "deposit" and hasattr(order, "deposit"):
        from apps.billing.services import mark_paid
        mark_paid(deposit=order.deposit, amount=amount,
                 stripe_payment_intent_id=stripe_payment_intent_id,
                 stripe_charge_id=stripe_charge_id)
    return p


@transaction.atomic
def refund_payment(*, payment, amount, reason: str, stripe_refund_id: str = "") -> Refund:
    amount = Decimal(amount)
    already = (Refund.objects.filter(payment=payment).aggregate(s=models.Sum("amount"))["s"]
              or Decimal("0"))
    if already + amount > payment.amount:
        raise PaymentError("refund exceeds available")
    r = Refund.objects.create(
        tenant=payment.tenant, payment=payment,
        amount=amount, reason=reason, stripe_refund_id=stripe_refund_id,
    )
    payment.status = ("refunded" if already + amount == payment.amount
                     else "partially_refunded")
    payment.save(update_fields=["status"])
    return r


@transaction.atomic
def handle_stripe_webhook(event: dict) -> dict:
    kind = event.get("type", "")
    data = event.get("data", {}).get("object", {})
    if kind == "payment_intent.succeeded":
        from apps.billing.models import Deposit
        from apps.billing.services import mark_paid
        d = Deposit.objects.filter(stripe_payment_intent_id=data.get("id")).first()
        if d and d.status != "paid":
            mark_paid(deposit=d, amount=Decimal(data.get("amount", 0)) / Decimal("100"),
                     stripe_payment_intent_id=data["id"],
                     stripe_charge_id=data.get("latest_charge", ""))
        return {"handled": kind}
    if kind == "charge.refunded":
        p = Payment.objects.filter(stripe_charge_id=data.get("id")).first()
        if p:
            amount = Decimal(data.get("amount_refunded", 0)) / Decimal("100")
            already = (Refund.objects.filter(payment=p).aggregate(s=models.Sum("amount"))["s"]
                      or Decimal("0"))
            if amount > already:
                refund_payment(payment=p, amount=amount - already, reason="stripe webhook")
        return {"handled": kind}
    return {"ignored": kind}
