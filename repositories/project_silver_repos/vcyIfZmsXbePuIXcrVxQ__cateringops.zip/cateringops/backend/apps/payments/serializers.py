from rest_framework import serializers
from apps.payments.models import Payment, Refund


class RefundSerializer(serializers.ModelSerializer):
    class Meta:
        model = Refund
        fields = ["id", "amount", "reason", "refunded_at", "stripe_refund_id"]


class PaymentSerializer(serializers.ModelSerializer):
    refunds = RefundSerializer(many=True, read_only=True)

    class Meta:
        model = Payment
        fields = ["id", "order_id", "invoice_id", "amount", "method", "kind",
                  "status", "received_at", "note", "reference",
                  "stripe_charge_id", "refunds"]
