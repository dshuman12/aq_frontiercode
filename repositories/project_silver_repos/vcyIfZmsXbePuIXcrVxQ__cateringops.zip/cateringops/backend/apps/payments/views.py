from decimal import Decimal
import json

from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from apps.payments import services
from apps.payments.models import Payment
from apps.payments.serializers import PaymentSerializer, RefundSerializer


class PaymentViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = PaymentSerializer

    def get_queryset(self):
        return Payment.objects.filter(tenant_id=self.kwargs["tenant_id"]).prefetch_related("refunds")

    def create(self, request, tenant_id=None):
        from apps.billing.models import Invoice
        from apps.orders.models import Order
        order = Order.objects.get(pk=request.data["order"], tenant_id=tenant_id)
        invoice = Invoice.objects.get(pk=request.data["invoice"]) if request.data.get("invoice") else None
        p = services.record_payment(
            order=order, invoice=invoice, amount=Decimal(request.data["amount"]),
            method=request.data["method"], kind=request.data["kind"],
            note=request.data.get("note", ""), reference=request.data.get("reference", ""),
        )
        return Response(PaymentSerializer(p).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def refund(self, request, tenant_id=None, pk=None):
        r = services.refund_payment(
            payment=self.get_object(), amount=Decimal(request.data["amount"]),
            reason=request.data["reason"],
        )
        return Response(RefundSerializer(r).data, status=status.HTTP_201_CREATED)


@api_view(["POST"])
@permission_classes([AllowAny])
def stripe_webhook(request):
    event = json.loads(request.body)
    return Response(services.handle_stripe_webhook(event))
