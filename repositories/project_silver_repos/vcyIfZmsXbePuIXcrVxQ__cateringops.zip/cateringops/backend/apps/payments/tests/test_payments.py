import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.core.exceptions import PaymentError, ValidationError
from apps.payments.services import handle_stripe_webhook, record_payment, refund_payment


@pytest.fixture
def order_invoice(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import (
        apply_deposit_payment, complete, confirm, create_direct,
        mark_ready, start_production,
    )
    from apps.billing.services import generate_invoice, issue_invoice
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today(), event_time=time(12), guest_count=10,
                     items=[{"label": "X", "quantity": 1, "unit_price": "500"}], actor=user)
    apply_deposit_payment(o, Decimal("100"))
    o.deposit_required_amount = Decimal("100")
    o.save(update_fields=["deposit_required_amount"])
    confirm(o, actor=user); start_production(o, actor=user)
    mark_ready(o, actor=user); complete(o, actor=user)
    inv = generate_invoice(o); issue_invoice(invoice=inv)
    return o, inv


@pytest.mark.django_db
def test_balance_updates_invoice(order_invoice):
    o, inv = order_invoice
    record_payment(order=o, invoice=inv, amount=Decimal("400"), method="stripe", kind="balance")
    inv.refresh_from_db()
    assert inv.status == "paid"


@pytest.mark.django_db
def test_amount_validation(order_invoice):
    o, _ = order_invoice
    with pytest.raises(ValidationError):
        record_payment(order=o, amount=Decimal("0"), method="cash", kind="balance")


@pytest.mark.django_db
def test_refund_full(order_invoice):
    o, inv = order_invoice
    p = record_payment(order=o, invoice=inv, amount=Decimal("400"),
                      method="stripe", kind="balance")
    refund_payment(payment=p, amount=Decimal("400"), reason="cancel")
    p.refresh_from_db()
    assert p.status == "refunded"


@pytest.mark.django_db
def test_refund_partial(order_invoice):
    o, inv = order_invoice
    p = record_payment(order=o, invoice=inv, amount=Decimal("400"),
                      method="stripe", kind="balance")
    refund_payment(payment=p, amount=Decimal("100"), reason="partial")
    p.refresh_from_db()
    assert p.status == "partially_refunded"


@pytest.mark.django_db
def test_refund_excess_blocked(order_invoice):
    o, inv = order_invoice
    p = record_payment(order=o, invoice=inv, amount=Decimal("400"),
                      method="stripe", kind="balance")
    with pytest.raises(PaymentError):
        refund_payment(payment=p, amount=Decimal("500"), reason="bad")


@pytest.mark.django_db
def test_webhook_ignores_unknown():
    r = handle_stripe_webhook({"type": "ping", "data": {"object": {}}})
    assert "ignored" in r
