"""Replay of stripe webhook must not double-apply."""
import pytest


@pytest.mark.django_db
def test_replay_unknown_intent():
    from apps.payments.services import handle_stripe_webhook
    event = {"type": "payment_intent.succeeded",
            "data": {"object": {"id": "pi_unknown", "amount": 5000}}}
    r1 = handle_stripe_webhook(event)
    r2 = handle_stripe_webhook(event)
    assert "handled" in r1
    assert "handled" in r2
