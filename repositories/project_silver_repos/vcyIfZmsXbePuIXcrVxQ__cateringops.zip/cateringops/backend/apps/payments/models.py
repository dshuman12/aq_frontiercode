"""Payment + Refund records (deposit and balance)."""
from django.db import models
from apps.core.models import TenantScoped


class Payment(TenantScoped):
    METHOD_CHOICES = [
        ("stripe", "Stripe"), ("cash", "Cash"), ("check", "Check"),
        ("bank_transfer", "Bank transfer"), ("manual", "Manual"),
    ]
    KIND_CHOICES = [("deposit", "Deposit"), ("balance", "Balance"), ("adjustment", "Adjustment")]
    STATUS_CHOICES = [
        ("succeeded", "Succeeded"), ("failed", "Failed"),
        ("refunded", "Refunded"), ("partially_refunded", "Partially refunded"),
    ]

    order = models.ForeignKey("orders.Order", on_delete=models.PROTECT, related_name="payments")
    invoice = models.ForeignKey("billing.Invoice", on_delete=models.SET_NULL,
                               null=True, blank=True, related_name="payments")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    method = models.CharField(max_length=16, choices=METHOD_CHOICES)
    kind = models.CharField(max_length=16, choices=KIND_CHOICES)
    status = models.CharField(max_length=24, choices=STATUS_CHOICES, default="succeeded")
    received_at = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=300, blank=True, default="")
    stripe_payment_intent_id = models.CharField(max_length=120, blank=True, default="")
    stripe_charge_id = models.CharField(max_length=120, blank=True, default="")
    reference = models.CharField(max_length=120, blank=True, default="")


class Refund(TenantScoped):
    payment = models.ForeignKey(Payment, on_delete=models.PROTECT, related_name="refunds")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    reason = models.TextField()
    refunded_at = models.DateTimeField(auto_now_add=True)
    stripe_refund_id = models.CharField(max_length=120, blank=True, default="")
