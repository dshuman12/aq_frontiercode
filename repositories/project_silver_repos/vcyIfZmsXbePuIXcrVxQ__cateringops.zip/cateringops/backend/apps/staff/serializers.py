from rest_framework import serializers
from apps.staff.models import StaffProfile


class StaffProfileSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source="user.email", read_only=True)

    class Meta:
        model = StaffProfile
        fields = ["id", "email", "employee_id", "hire_date", "pay_rate",
                  "pay_kind", "emergency_contact_name", "emergency_contact_phone", "notes"]
