from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.staff.views import StaffViewSet

router = DefaultRouter()
router.register("staff", StaffViewSet, basename="staff")

urlpatterns = [path("t/<uuid:tenant_id>/", include(router.urls))]
