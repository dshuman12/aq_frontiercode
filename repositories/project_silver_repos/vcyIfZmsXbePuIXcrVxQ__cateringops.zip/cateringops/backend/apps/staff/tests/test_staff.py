import pytest

from apps.staff.models import StaffProfile


@pytest.mark.django_db
def test_create(tenant, user):
    sp = StaffProfile.objects.create(tenant=tenant, user=user,
                                    employee_id="E-1", pay_kind="salary")
    assert sp.employee_id == "E-1"


@pytest.mark.django_db
def test_one_to_one(tenant, user):
    StaffProfile.objects.create(tenant=tenant, user=user)
    with pytest.raises(Exception):
        StaffProfile.objects.create(tenant=tenant, user=user)
