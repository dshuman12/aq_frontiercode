from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from apps.staff.models import StaffProfile
from apps.staff.serializers import StaffProfileSerializer


class StaffViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = StaffProfileSerializer

    def get_queryset(self):
        return StaffProfile.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).select_related("user")
