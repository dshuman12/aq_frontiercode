"""StaffProfile: extra HR-ish fields beyond User."""
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class StaffProfile(TenantScoped):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name="staff_profile")
    employee_id = models.CharField(max_length=64, blank=True, default="")
    hire_date = models.DateField(null=True, blank=True)
    pay_rate = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    pay_kind = models.CharField(max_length=16,
        choices=[("hourly", "Hourly"), ("salary", "Salary"), ("event", "Per-event")],
        default="hourly")
    emergency_contact_name = models.CharField(max_length=200, blank=True, default="")
    emergency_contact_phone = models.CharField(max_length=32, blank=True, default="")
    notes = models.TextField(blank=True, default="")
