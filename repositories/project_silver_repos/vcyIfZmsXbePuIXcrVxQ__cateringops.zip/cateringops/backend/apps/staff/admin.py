from django.contrib import admin
from apps.staff.models import StaffProfile


@admin.register(StaffProfile)
class StaffAdmin(admin.ModelAdmin):
    list_display = ("user", "tenant", "employee_id", "pay_kind", "hire_date")
