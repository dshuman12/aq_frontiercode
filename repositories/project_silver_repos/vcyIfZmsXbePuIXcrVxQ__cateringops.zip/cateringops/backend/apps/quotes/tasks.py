from celery import shared_task

from apps.quotes.services import expire_stale


@shared_task
def expire_stale_quotes():
    return {"expired": expire_stale()}
