from django.contrib import admin
from apps.quotes.models import ApprovalEvent, Quote, QuoteLine, QuoteRevision, StatusHistory


class LineInline(admin.TabularInline):
    model = QuoteLine
    extra = 0


@admin.register(Quote)
class QuoteAdmin(admin.ModelAdmin):
    list_display = ("quote_number", "customer", "event_date", "total", "status", "tenant")
    list_filter = ("status",)
    inlines = [LineInline]


admin.site.register(QuoteRevision)
admin.site.register(ApprovalEvent)
admin.site.register(StatusHistory)
