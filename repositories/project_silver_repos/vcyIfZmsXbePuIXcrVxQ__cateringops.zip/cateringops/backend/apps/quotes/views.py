from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from apps.quotes import serializers as ser, services
from apps.quotes.models import Quote
from apps.tenants.models import Tenant


class QuoteViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        return ser.QuoteDetailSerializer if self.action != "list" else ser.QuoteListSerializer

    def get_queryset(self):
        return Quote.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("lines", "status_history", "revisions", "approval_events")

    @action(detail=False, methods=["post"])
    def from_inquiry(self, request, tenant_id=None):
        from apps.inquiries.models import Inquiry
        from apps.inquiries.services import transition
        from apps.locations.models import Location
        t = Tenant.objects.get(pk=tenant_id)
        inq = Inquiry.objects.get(pk=request.data["inquiry"], tenant=t)
        loc = Location.objects.get(pk=request.data["location"], tenant=t)
        q = services.create_draft(
            tenant=t, customer=inq.customer, location=loc,
            event_date=inq.event_date, event_time=inq.event_time,
            guest_count=inq.guest_count, fulfillment=inq.fulfillment,
            delivery_address=inq.delivery_address, created_by=request.user,
        )
        q.inquiry = inq
        q.save(update_fields=["inquiry"])
        transition(inquiry=inq, to_status="quote_created", actor=request.user)
        return Response(ser.QuoteDetailSerializer(q).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def add_package(self, request, tenant_id=None, pk=None):
        from apps.packages.models import Package
        q = self.get_object()
        p = Package.objects.get(pk=request.data["package"], tenant=q.tenant)
        line = services.add_package_line(quote=q, package=p,
                                        guest_count=request.data.get("guest_count"))
        return Response(ser.LineSerializer(line).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def add_item(self, request, tenant_id=None, pk=None):
        from apps.menu.models import MenuItem
        q = self.get_object()
        i = MenuItem.objects.get(pk=request.data["menu_item"], tenant=q.tenant)
        line = services.add_menu_line(
            quote=q, menu_item=i, quantity=request.data["quantity"],
            label=request.data.get("label", ""),
            override_unit_price=request.data.get("unit_price"),
            note=request.data.get("note", ""),
        )
        return Response(ser.LineSerializer(line).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def add_custom(self, request, tenant_id=None, pk=None):
        line = services.add_custom_line(
            quote=self.get_object(), label=request.data["label"],
            quantity=request.data["quantity"], unit_price=request.data["unit_price"],
            note=request.data.get("note", ""),
        )
        return Response(ser.LineSerializer(line).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def discount(self, request, tenant_id=None, pk=None):
        services.set_discount(quote=self.get_object(),
                             kind=request.data["kind"],
                             value=request.data.get("value", "0"))
        return Response(ser.QuoteDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def fees(self, request, tenant_id=None, pk=None):
        services.set_fees(
            quote=self.get_object(),
            tax_rate_pct=request.data.get("tax_rate_pct"),
            service_charge_rate_pct=request.data.get("service_charge_rate_pct"),
            delivery_fee=request.data.get("delivery_fee"),
        )
        return Response(ser.QuoteDetailSerializer(self.get_object()).data)

    @action(detail=True, methods=["post"])
    def send(self, request, tenant_id=None, pk=None):
        services.send_quote(
            quote=self.get_object(), actor=request.user,
            expires_in_days=int(request.data.get("expires_in_days", 14)),
        )
        return Response(ser.QuoteDetailSerializer(self.get_object()).data)


@api_view(["GET"])
@permission_classes([AllowAny])
def public_quote(request, token):
    q = services.find_by_token(token)
    services.record_view(quote=q, ip=request.META.get("REMOTE_ADDR"),
                        user_agent=request.META.get("HTTP_USER_AGENT", ""))
    return Response(ser.QuotePublicSerializer(q).data)


@api_view(["POST"])
@permission_classes([AllowAny])
def public_approve(request, token):
    q = services.find_by_token(token)
    services.approve(quote=q, ip=request.META.get("REMOTE_ADDR"),
                    user_agent=request.META.get("HTTP_USER_AGENT", ""))
    return Response(ser.QuotePublicSerializer(q).data)


@api_view(["POST"])
@permission_classes([AllowAny])
def public_reject(request, token):
    q = services.find_by_token(token)
    services.reject(quote=q, reason=request.data.get("reason", ""),
                   ip=request.META.get("REMOTE_ADDR"),
                   user_agent=request.META.get("HTTP_USER_AGENT", ""))
    return Response(ser.QuotePublicSerializer(q).data)
