"""Quote builder: lines, money pipeline, revisions, customer approval."""
import secrets
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class Quote(TenantScoped):
    STATUS_CHOICES = [
        ("draft", "Draft"), ("sent", "Sent"), ("viewed", "Viewed"),
        ("approved", "Approved"), ("rejected", "Rejected"), ("expired", "Expired"),
        ("converted", "Converted"), ("cancelled", "Cancelled"),
    ]
    DISCOUNT_KIND = [("none", "None"), ("flat", "Flat"), ("percent", "Percent")]

    quote_number = models.CharField(max_length=32, unique=True)
    inquiry = models.ForeignKey("inquiries.Inquiry", on_delete=models.SET_NULL,
                               null=True, blank=True, related_name="quotes")
    customer = models.ForeignKey("customers.Customer", on_delete=models.PROTECT, related_name="quotes")
    location = models.ForeignKey("locations.Location", on_delete=models.PROTECT, related_name="+")

    event_date = models.DateField()
    event_time = models.TimeField()
    guest_count = models.PositiveIntegerField()
    fulfillment = models.CharField(max_length=16, default="delivery")
    delivery_address = models.CharField(max_length=400, blank=True, default="")

    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    discount_kind = models.CharField(max_length=16, choices=DISCOUNT_KIND, default="none")
    discount_value = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    discount_total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    tax_rate_pct = models.DecimalField(max_digits=5, decimal_places=4, default="0.0000")
    tax_total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    service_charge_rate_pct = models.DecimalField(max_digits=5, decimal_places=4, default="0.0000")
    service_charge_total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    delivery_fee = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")
    total = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")

    deposit_required_pct = models.DecimalField(max_digits=5, decimal_places=2, default="25.00")
    deposit_required_amount = models.DecimalField(max_digits=12, decimal_places=2, default="0.00")

    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default="draft", db_index=True)
    approval_token = models.CharField(max_length=80, unique=True, default=secrets.token_urlsafe)
    expires_at = models.DateTimeField(null=True, blank=True)

    customer_note = models.TextField(blank=True, default="")
    internal_note = models.TextField(blank=True, default="")
    sent_at = models.DateTimeField(null=True, blank=True)
    first_viewed_at = models.DateTimeField(null=True, blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    rejected_at = models.DateTimeField(null=True, blank=True)
    rejected_reason = models.TextField(blank=True, default="")

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, related_name="+")


class QuoteLine(TenantScoped):
    KIND_CHOICES = [("package", "Package"), ("menu_item", "Menu item"), ("custom", "Custom")]
    quote = models.ForeignKey(Quote, on_delete=models.CASCADE, related_name="lines")
    kind = models.CharField(max_length=16, choices=KIND_CHOICES)
    package = models.ForeignKey("packages.Package", on_delete=models.SET_NULL,
                               null=True, blank=True, related_name="+")
    menu_item = models.ForeignKey("menu.MenuItem", on_delete=models.SET_NULL,
                                 null=True, blank=True, related_name="+")
    label = models.CharField(max_length=200)
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=12, decimal_places=2)
    note = models.CharField(max_length=300, blank=True, default="")
    sort_order = models.IntegerField(default=0)

    class Meta:
        ordering = ["sort_order"]


class QuoteRevision(TenantScoped):
    quote = models.ForeignKey(Quote, on_delete=models.CASCADE, related_name="revisions")
    version_number = models.PositiveIntegerField()
    snapshot = models.JSONField()
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, related_name="+")
    note = models.CharField(max_length=300, blank=True, default="")

    class Meta:
        unique_together = [("quote", "version_number")]


class ApprovalEvent(TenantScoped):
    KIND_CHOICES = [("opened", "Opened"), ("approved", "Approved"), ("rejected", "Rejected")]
    quote = models.ForeignKey(Quote, on_delete=models.CASCADE, related_name="approval_events")
    kind = models.CharField(max_length=16, choices=KIND_CHOICES)
    ip = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.CharField(max_length=400, blank=True, default="")
    payload = models.JSONField(default=dict, blank=True)


class StatusHistory(TenantScoped):
    quote = models.ForeignKey(Quote, on_delete=models.CASCADE, related_name="status_history")
    from_status = models.CharField(max_length=16)
    to_status = models.CharField(max_length=16)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                             null=True, related_name="+")
    note = models.CharField(max_length=300, blank=True, default="")
    at = models.DateTimeField(auto_now_add=True)
