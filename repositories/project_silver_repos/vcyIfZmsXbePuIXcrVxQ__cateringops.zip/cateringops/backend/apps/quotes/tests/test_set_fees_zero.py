import pytest
from decimal import Decimal

from apps.quotes.services import add_menu_line, set_fees


@pytest.mark.django_db
def test_zero_tax_clears_tax_total(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    set_fees(quote=draft_quote, tax_rate_pct="0.10")
    draft_quote.refresh_from_db()
    assert draft_quote.tax_total > 0
    set_fees(quote=draft_quote, tax_rate_pct="0")
    draft_quote.refresh_from_db()
    assert draft_quote.tax_total == Decimal("0.00")
