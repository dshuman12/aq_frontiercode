import pytest
from decimal import Decimal

from apps.quotes.selectors import conversion_pct, pipeline


@pytest.mark.django_db
def test_conversion_zero(tenant):
    assert conversion_pct(tenant) == Decimal("0")


@pytest.mark.django_db
def test_pipeline_buckets(draft_quote, menu_item):
    from apps.quotes.services import add_menu_line
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    p = pipeline(draft_quote.tenant)
    assert "draft" in p
    assert p["draft"]["count"] == 1
