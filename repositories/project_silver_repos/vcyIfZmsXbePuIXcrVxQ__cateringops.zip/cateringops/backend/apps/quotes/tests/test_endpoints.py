"""Public quote endpoints with signed tokens."""
import pytest

from apps.quotes.services import add_menu_line, send_quote


@pytest.fixture
def sent_quote(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    send_quote(quote=draft_quote)
    return draft_quote


@pytest.mark.django_db
def test_public_view_no_auth(api_client, sent_quote, tenant):
    r = api_client.get(f"/api/t/{tenant.id}/quotes/public/{sent_quote.approval_token}/")
    assert r.status_code == 200
    assert "total" in r.data


@pytest.mark.django_db
def test_unknown_token_404(api_client, tenant):
    r = api_client.get(f"/api/t/{tenant.id}/quotes/public/bogus/")
    assert r.status_code == 404


@pytest.mark.django_db
def test_public_approve(api_client, sent_quote, tenant):
    r = api_client.post(f"/api/t/{tenant.id}/quotes/public/{sent_quote.approval_token}/approve/")
    assert r.status_code == 200
    sent_quote.refresh_from_db()
    assert sent_quote.status == "approved"


@pytest.mark.django_db
def test_public_reject(api_client, sent_quote, tenant):
    r = api_client.post(
        f"/api/t/{tenant.id}/quotes/public/{sent_quote.approval_token}/reject/",
        {"reason": "scope changed"}, format="json",
    )
    assert r.status_code == 200
    sent_quote.refresh_from_db()
    assert sent_quote.status == "rejected"
    assert sent_quote.rejected_reason == "scope changed"
