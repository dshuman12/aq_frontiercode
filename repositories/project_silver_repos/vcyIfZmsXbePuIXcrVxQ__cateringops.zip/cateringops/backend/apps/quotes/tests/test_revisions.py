import pytest

from apps.quotes.services import add_menu_line, send_quote, snapshot


@pytest.mark.django_db
def test_send_creates_v1(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    send_quote(quote=draft_quote)
    assert draft_quote.revisions.count() == 1
    r = draft_quote.revisions.first()
    assert r.version_number == 1
    assert "lines" in r.snapshot


@pytest.mark.django_db
def test_snapshot_increments(draft_quote, menu_item, user):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    snapshot(quote=draft_quote, changed_by=user, note="a")
    snapshot(quote=draft_quote, changed_by=user, note="b")
    versions = list(draft_quote.revisions.order_by("version_number").values_list("version_number", flat=True))
    assert versions == [1, 2]
