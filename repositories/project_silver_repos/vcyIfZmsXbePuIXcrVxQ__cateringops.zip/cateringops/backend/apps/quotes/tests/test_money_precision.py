import pytest
from decimal import Decimal


@pytest.mark.django_db
def test_tax_rounds_half_up(draft_quote, menu_item):
    from apps.quotes.services import add_menu_line, set_fees
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)  # 150
    set_fees(quote=draft_quote, tax_rate_pct="0.0825")
    draft_quote.refresh_from_db()
    # 150 * 0.0825 = 12.375 → 12.38
    assert draft_quote.tax_total == Decimal("12.38")


@pytest.mark.django_db
def test_no_negative_total(draft_quote, menu_item):
    from apps.quotes.services import add_menu_line, set_discount
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=1)
    set_discount(quote=draft_quote, kind="flat", value="9999")
    draft_quote.refresh_from_db()
    assert draft_quote.total >= Decimal("0")
