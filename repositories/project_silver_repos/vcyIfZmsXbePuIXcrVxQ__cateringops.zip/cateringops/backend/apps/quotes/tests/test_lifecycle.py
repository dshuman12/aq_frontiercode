import pytest
from datetime import timedelta
from django.utils import timezone

from apps.core.exceptions import Conflict, StateError
from apps.quotes.services import (
    add_menu_line, approve, expire_stale, find_by_token,
    record_view, reject, send_quote,
)


@pytest.mark.django_db
def test_empty_send_blocked(draft_quote):
    with pytest.raises(StateError):
        send_quote(quote=draft_quote)


@pytest.mark.django_db
def test_send_sets_expiry(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    send_quote(quote=draft_quote, expires_in_days=10)
    draft_quote.refresh_from_db()
    assert draft_quote.status == "sent"
    assert draft_quote.expires_at is not None


@pytest.mark.django_db
def test_view_transitions_to_viewed(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    send_quote(quote=draft_quote)
    record_view(quote=draft_quote)
    draft_quote.refresh_from_db()
    assert draft_quote.status == "viewed"


@pytest.mark.django_db
def test_approve(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    send_quote(quote=draft_quote)
    approve(quote=draft_quote)
    draft_quote.refresh_from_db()
    assert draft_quote.status == "approved"


@pytest.mark.django_db
def test_reject_records_reason(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    send_quote(quote=draft_quote)
    reject(quote=draft_quote, reason="too pricey")
    draft_quote.refresh_from_db()
    assert draft_quote.status == "rejected"
    assert draft_quote.rejected_reason == "too pricey"


@pytest.mark.django_db
def test_cannot_approve_draft(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    with pytest.raises(Conflict):
        approve(quote=draft_quote)


@pytest.mark.django_db
def test_expired_blocks_approve(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    send_quote(quote=draft_quote)
    draft_quote.expires_at = timezone.now() - timedelta(hours=1)
    draft_quote.save(update_fields=["expires_at"])
    with pytest.raises(StateError):
        approve(quote=draft_quote)
    draft_quote.refresh_from_db()
    assert draft_quote.status == "expired"


@pytest.mark.django_db
def test_expire_sweeper(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    send_quote(quote=draft_quote)
    draft_quote.expires_at = timezone.now() - timedelta(minutes=5)
    draft_quote.save(update_fields=["expires_at"])
    assert expire_stale() == 1


@pytest.mark.django_db
def test_find_by_token(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    send_quote(quote=draft_quote)
    assert find_by_token(draft_quote.approval_token).id == draft_quote.id
