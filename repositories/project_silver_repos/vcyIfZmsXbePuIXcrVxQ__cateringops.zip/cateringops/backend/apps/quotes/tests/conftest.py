import pytest
from datetime import date, time, timedelta
from decimal import Decimal


@pytest.fixture
def customer(tenant):
    from apps.customers.services import create_customer
    return create_customer(tenant=tenant, kind="business",
                          company_name="Acme", primary_email="ops@acme.test")


@pytest.fixture
def draft_quote(tenant, customer, location, user):
    from apps.quotes.services import create_draft
    return create_draft(
        tenant=tenant, customer=customer, location=location,
        event_date=date.today() + timedelta(days=14),
        event_time=time(12), guest_count=40, created_by=user,
    )


@pytest.fixture
def menu_item(tenant):
    from apps.menu.services import create_category, create_item
    cat = create_category(tenant=tenant, slug="lunch", name="Lunch", kind="boxed_lunch")
    return create_item(tenant=tenant, category=cat, name="Box A", price="15", serves=1)


@pytest.fixture
def package(tenant, menu_item):
    from apps.packages.services import add_item, create_package
    p = create_package(tenant=tenant, slug="corp", name="Corp", price_per_person="22.50",
                      minimum_guest_count=10, maximum_guest_count=200)
    add_item(package=p, menu_item=menu_item, portion_per_person="1.0")
    return p
