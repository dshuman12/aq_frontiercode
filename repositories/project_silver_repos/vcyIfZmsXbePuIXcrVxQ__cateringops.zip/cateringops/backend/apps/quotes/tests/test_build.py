import pytest
from decimal import Decimal

from apps.core.exceptions import Conflict, ValidationError
from apps.quotes.services import (
    add_custom_line, add_menu_line, add_package_line, remove_line, set_discount, set_fees,
)


@pytest.mark.django_db
def test_package_line(draft_quote, package):
    add_package_line(quote=draft_quote, package=package)
    draft_quote.refresh_from_db()
    assert draft_quote.total == Decimal("900.00")


@pytest.mark.django_db
def test_menu_line(draft_quote, menu_item):
    line = add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    assert line.line_total == Decimal("150.00")


@pytest.mark.django_db
def test_qty_validation(draft_quote, menu_item):
    with pytest.raises(ValidationError):
        add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=0)


@pytest.mark.django_db
def test_custom_line(draft_quote):
    line = add_custom_line(quote=draft_quote, label="Linen", quantity=4, unit_price="15")
    assert line.line_total == Decimal("60.00")


@pytest.mark.django_db
def test_remove_recalculates(draft_quote, menu_item):
    a = add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    remove_line(quote=draft_quote, line=a)
    draft_quote.refresh_from_db()
    assert draft_quote.subtotal == Decimal("75.00")


@pytest.mark.django_db
def test_fees_apply(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    set_fees(quote=draft_quote, tax_rate_pct="0.10", delivery_fee="40")
    draft_quote.refresh_from_db()
    assert draft_quote.total == Decimal("205.00")


@pytest.mark.django_db
def test_flat_discount(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    set_discount(quote=draft_quote, kind="flat", value="20")
    draft_quote.refresh_from_db()
    assert draft_quote.total == Decimal("130.00")


@pytest.mark.django_db
def test_percent_discount(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    set_discount(quote=draft_quote, kind="percent", value="10")
    draft_quote.refresh_from_db()
    assert draft_quote.total == Decimal("135.00")


@pytest.mark.django_db
def test_flat_capped(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=2)
    set_discount(quote=draft_quote, kind="flat", value="9999")
    draft_quote.refresh_from_db()
    assert draft_quote.total == Decimal("0.00")


@pytest.mark.django_db
def test_deposit_calculated(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=10)
    draft_quote.refresh_from_db()
    assert draft_quote.deposit_required_amount == Decimal("37.50")


@pytest.mark.django_db
def test_sent_locks_modifications(draft_quote, menu_item):
    add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
    from apps.quotes.services import send_quote
    send_quote(quote=draft_quote)
    with pytest.raises(Conflict):
        add_menu_line(quote=draft_quote, menu_item=menu_item, quantity=5)
