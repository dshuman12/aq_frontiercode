"""Quote services."""
from __future__ import annotations

from datetime import timedelta
from decimal import Decimal, ROUND_HALF_UP

from django.db import models, transaction
from django.utils import timezone

from apps.core.exceptions import Conflict, NotFound, StateError, ValidationError
from apps.quotes.models import ApprovalEvent, Quote, QuoteLine, QuoteRevision, StatusHistory

ALLOWED = {
    "draft": {"sent", "cancelled"},
    "sent": {"viewed", "approved", "rejected", "expired", "cancelled"},
    "viewed": {"approved", "rejected", "expired", "cancelled"},
    "approved": {"converted", "cancelled"},
    "rejected": set(), "expired": set(), "converted": set(), "cancelled": set(),
}


def _r(v: Decimal) -> Decimal:
    return Decimal(v).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@transaction.atomic
def create_draft(*, tenant, customer, location, event_date, event_time, guest_count,
                fulfillment="delivery", delivery_address="", created_by=None,
                deposit_required_pct=None, tax_rate_pct=None,
                service_charge_rate_pct=None) -> Quote:
    seq = Quote.objects.filter(tenant=tenant).count() + 1
    return Quote.objects.create(
        tenant=tenant, quote_number=f"Q-{timezone.now().year}-{seq:05d}",
        customer=customer, location=location,
        event_date=event_date, event_time=event_time, guest_count=guest_count,
        fulfillment=fulfillment, delivery_address=delivery_address, created_by=created_by,
        deposit_required_pct=Decimal(deposit_required_pct or tenant.default_deposit_pct),
        tax_rate_pct=Decimal(tax_rate_pct if tax_rate_pct is not None else location.tax_rate_pct),
        service_charge_rate_pct=Decimal(
            service_charge_rate_pct if service_charge_rate_pct is not None
            else tenant.default_service_charge_pct / Decimal("100")
        ),
    )


def _check(quote: Quote, *allowed):
    if quote.status not in allowed:
        raise Conflict(f"not allowed in status {quote.status}")


@transaction.atomic
def add_package_line(*, quote, package, guest_count=None) -> QuoteLine:
    _check(quote, "draft")
    from apps.packages.services import estimate_total
    qc = guest_count or quote.guest_count
    total = estimate_total(package, qc)
    line = QuoteLine.objects.create(
        tenant=quote.tenant, quote=quote, kind="package", package=package,
        label=f"{package.name} ({qc} guests)", quantity=1,
        unit_price=total, line_total=total, sort_order=quote.lines.count(),
    )
    recalculate(quote)
    return line


@transaction.atomic
def add_menu_line(*, quote, menu_item, quantity, label="", override_unit_price=None,
                 note="") -> QuoteLine:
    _check(quote, "draft")
    if quantity < 1:
        raise ValidationError("quantity >= 1")
    unit = Decimal(override_unit_price) if override_unit_price else menu_item.price
    total = unit * Decimal(quantity)
    line = QuoteLine.objects.create(
        tenant=quote.tenant, quote=quote, kind="menu_item", menu_item=menu_item,
        label=label or menu_item.name, quantity=quantity,
        unit_price=unit, line_total=total, note=note, sort_order=quote.lines.count(),
    )
    recalculate(quote)
    return line


@transaction.atomic
def add_custom_line(*, quote, label, quantity, unit_price, note="") -> QuoteLine:
    _check(quote, "draft")
    line = QuoteLine.objects.create(
        tenant=quote.tenant, quote=quote, kind="custom",
        label=label, quantity=quantity, unit_price=Decimal(unit_price),
        line_total=Decimal(unit_price) * Decimal(quantity),
        note=note, sort_order=quote.lines.count(),
    )
    recalculate(quote)
    return line


def remove_line(*, quote, line) -> None:
    _check(quote, "draft")
    line.delete()
    recalculate(quote)


@transaction.atomic
def set_fees(*, quote, tax_rate_pct=None, service_charge_rate_pct=None,
            delivery_fee=None) -> Quote:
    _check(quote, "draft")
    if tax_rate_pct is not None:
        quote.tax_rate_pct = Decimal(tax_rate_pct)
    if service_charge_rate_pct is not None:
        quote.service_charge_rate_pct = Decimal(service_charge_rate_pct)
    if delivery_fee is not None:
        quote.delivery_fee = Decimal(delivery_fee)
    quote.save(update_fields=["tax_rate_pct", "service_charge_rate_pct", "delivery_fee"])
    recalculate(quote)
    return quote


@transaction.atomic
def set_discount(*, quote, kind: str, value) -> Quote:
    _check(quote, "draft")
    if kind not in ("none", "flat", "percent"):
        raise ValidationError("invalid discount kind")
    quote.discount_kind = kind
    quote.discount_value = Decimal(value or "0.00")
    quote.save(update_fields=["discount_kind", "discount_value"])
    recalculate(quote)
    return quote


@transaction.atomic
def recalculate(quote: Quote) -> Quote:
    subtotal = sum((l.line_total for l in quote.lines.all()), Decimal("0"))
    discount = Decimal("0")
    if quote.discount_kind == "flat":
        discount = min(quote.discount_value, subtotal)
    elif quote.discount_kind == "percent":
        discount = subtotal * quote.discount_value / Decimal("100")
    discounted = subtotal - discount
    tax = discounted * quote.tax_rate_pct
    svc = discounted * quote.service_charge_rate_pct
    total = discounted + tax + svc + quote.delivery_fee
    deposit = total * quote.deposit_required_pct / Decimal("100")

    quote.subtotal = _r(subtotal)
    quote.discount_total = _r(discount)
    quote.tax_total = _r(tax)
    quote.service_charge_total = _r(svc)
    quote.total = _r(total)
    quote.deposit_required_amount = _r(deposit)
    quote.save(update_fields=[
        "subtotal", "discount_total", "tax_total",
        "service_charge_total", "total", "deposit_required_amount",
    ])
    return quote


@transaction.atomic
def snapshot(*, quote, changed_by=None, note: str = "") -> QuoteRevision:
    last = quote.revisions.aggregate(m=models.Max("version_number"))["m"] or 0
    snap = {
        "quote_number": quote.quote_number,
        "event_date": quote.event_date.isoformat(),
        "guest_count": quote.guest_count,
        "subtotal": str(quote.subtotal),
        "discount_total": str(quote.discount_total),
        "tax_total": str(quote.tax_total),
        "service_charge_total": str(quote.service_charge_total),
        "delivery_fee": str(quote.delivery_fee),
        "total": str(quote.total),
        "deposit_required_amount": str(quote.deposit_required_amount),
        "lines": [
            {"kind": l.kind, "label": l.label, "quantity": l.quantity,
             "unit_price": str(l.unit_price), "line_total": str(l.line_total)}
            for l in quote.lines.all()
        ],
    }
    return QuoteRevision.objects.create(
        tenant=quote.tenant, quote=quote, version_number=last + 1,
        snapshot=snap, changed_by=changed_by, note=note,
    )


def _transition(quote, to_status, actor=None, note=""):
    if to_status not in ALLOWED.get(quote.status, set()):
        raise Conflict(f"cannot transition {quote.status} → {to_status}")
    fr = quote.status
    quote.status = to_status
    quote.save(update_fields=["status"])
    StatusHistory.objects.create(
        tenant=quote.tenant, quote=quote,
        from_status=fr, to_status=to_status, actor=actor, note=note,
    )
    return quote


@transaction.atomic
def send_quote(*, quote, actor=None, expires_in_days: int = 14) -> Quote:
    if not quote.lines.exists():
        raise StateError("cannot send empty quote")
    if quote.total <= 0:
        raise StateError("quote total must be > 0")
    snapshot(quote=quote, changed_by=actor, note="sent")
    quote.sent_at = timezone.now()
    quote.expires_at = timezone.now() + timedelta(days=expires_in_days)
    quote.save(update_fields=["sent_at", "expires_at"])
    _transition(quote, "sent", actor=actor, note="sent to customer")
    return quote


@transaction.atomic
def record_view(*, quote, ip=None, user_agent: str = "") -> Quote:
    if quote.status not in ("sent", "viewed"):
        return quote
    if quote.first_viewed_at is None:
        quote.first_viewed_at = timezone.now()
        quote.save(update_fields=["first_viewed_at"])
        _transition(quote, "viewed", actor=None, note="customer viewed")
    ApprovalEvent.objects.create(
        tenant=quote.tenant, quote=quote, kind="opened",
        ip=ip, user_agent=user_agent[:400],
    )
    return quote


@transaction.atomic
def approve(*, quote, ip=None, user_agent: str = "") -> Quote:
    if quote.expires_at and timezone.now() > quote.expires_at:
        _transition(quote, "expired", actor=None, note="expired before approval")
        raise StateError("quote has expired")
    if quote.status not in ("sent", "viewed"):
        raise Conflict("not approvable")
    quote.approved_at = timezone.now()
    quote.save(update_fields=["approved_at"])
    _transition(quote, "approved", actor=None, note="customer approved")
    ApprovalEvent.objects.create(
        tenant=quote.tenant, quote=quote, kind="approved",
        ip=ip, user_agent=user_agent[:400],
    )
    return quote


@transaction.atomic
def reject(*, quote, reason: str = "", ip=None, user_agent: str = "") -> Quote:
    if quote.status not in ("sent", "viewed"):
        raise Conflict("not rejectable")
    quote.rejected_at = timezone.now()
    quote.rejected_reason = reason
    quote.save(update_fields=["rejected_at", "rejected_reason"])
    _transition(quote, "rejected", actor=None, note=reason)
    ApprovalEvent.objects.create(
        tenant=quote.tenant, quote=quote, kind="rejected",
        ip=ip, user_agent=user_agent[:400], payload={"reason": reason},
    )
    return quote


def find_by_token(token: str) -> Quote:
    try:
        return Quote.objects.get(approval_token=token, archived_at__isnull=True)
    except Quote.DoesNotExist as exc:
        raise NotFound("quote not found") from exc


@transaction.atomic
def expire_stale() -> int:
    qs = Quote.objects.filter(
        status__in=("sent", "viewed"), expires_at__lt=timezone.now(), archived_at__isnull=True,
    )
    n = 0
    for q in qs:
        _transition(q, "expired", actor=None, note="auto-expired")
        n += 1
    return n
