from django.core.management.base import BaseCommand
from apps.quotes.services import expire_stale


class Command(BaseCommand):
    help = "Expire any quotes past their expires_at."

    def handle(self, *args, **options):
        n = expire_stale()
        self.stdout.write(self.style.SUCCESS(f"Expired {n} quotes"))
