from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.quotes.views import QuoteViewSet, public_approve, public_quote, public_reject

router = DefaultRouter()
router.register("", QuoteViewSet, basename="quote")

urlpatterns = [
    path("public/<str:token>/", public_quote),
    path("public/<str:token>/approve/", public_approve),
    path("public/<str:token>/reject/", public_reject),
    path("", include(router.urls)),
]
