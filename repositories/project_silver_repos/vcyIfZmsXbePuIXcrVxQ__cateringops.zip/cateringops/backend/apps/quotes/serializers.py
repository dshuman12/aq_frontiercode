from rest_framework import serializers
from apps.quotes.models import ApprovalEvent, Quote, QuoteLine, QuoteRevision, StatusHistory


class LineSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuoteLine
        fields = ["id", "kind", "label", "quantity", "unit_price", "line_total",
                  "package_id", "menu_item_id", "note", "sort_order"]


class HistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = StatusHistory
        fields = ["id", "from_status", "to_status", "actor_id", "note", "at"]


class RevisionSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuoteRevision
        fields = ["id", "version_number", "snapshot", "changed_by_id", "note", "created_at"]


class ApprovalEventSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalEvent
        fields = ["id", "kind", "ip", "user_agent", "payload", "created_at"]


class QuoteListSerializer(serializers.ModelSerializer):
    customer_name = serializers.SerializerMethodField()

    class Meta:
        model = Quote
        fields = ["id", "quote_number", "customer_id", "customer_name",
                  "event_date", "guest_count", "total", "status", "created_at"]

    def get_customer_name(self, q):
        return q.customer.company_name or q.customer.primary_contact_name or q.customer.primary_email


class QuoteDetailSerializer(QuoteListSerializer):
    lines = LineSerializer(many=True, read_only=True)
    status_history = HistorySerializer(many=True, read_only=True)
    revisions = RevisionSerializer(many=True, read_only=True)
    approval_events = ApprovalEventSerializer(many=True, read_only=True)

    class Meta(QuoteListSerializer.Meta):
        fields = QuoteListSerializer.Meta.fields + [
            "location_id", "event_time", "fulfillment", "delivery_address",
            "subtotal", "discount_kind", "discount_value", "discount_total",
            "tax_rate_pct", "tax_total", "service_charge_rate_pct", "service_charge_total",
            "delivery_fee", "deposit_required_pct", "deposit_required_amount",
            "customer_note", "internal_note", "expires_at", "sent_at",
            "first_viewed_at", "approved_at", "rejected_at", "rejected_reason",
            "lines", "status_history", "revisions", "approval_events",
        ]


class QuotePublicSerializer(serializers.ModelSerializer):
    lines = LineSerializer(many=True, read_only=True)
    tenant_name = serializers.CharField(source="tenant.name", read_only=True)
    tenant_brand_color = serializers.CharField(source="tenant.brand_color", read_only=True)

    class Meta:
        model = Quote
        fields = ["id", "quote_number", "event_date", "event_time", "guest_count",
                  "fulfillment", "delivery_address",
                  "subtotal", "discount_total", "tax_total", "service_charge_total",
                  "delivery_fee", "total", "deposit_required_amount", "expires_at",
                  "status", "customer_note", "lines", "tenant_name", "tenant_brand_color"]
