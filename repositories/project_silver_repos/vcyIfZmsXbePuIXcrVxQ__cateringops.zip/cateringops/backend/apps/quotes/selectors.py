from datetime import timedelta
from decimal import Decimal

from django.db.models import Count, Sum
from django.utils import timezone

from apps.quotes.models import Quote


def quotes_for(tenant, *, status=None):
    qs = Quote.objects.filter(tenant=tenant, archived_at__isnull=True)
    if status:
        qs = qs.filter(status=status)
    return qs.select_related("customer", "location").order_by("-created_at")


def conversion_pct(tenant, days: int = 30) -> Decimal:
    since = timezone.now() - timedelta(days=days)
    qs = Quote.objects.filter(tenant=tenant, sent_at__gte=since)
    total = qs.count()
    if not total:
        return Decimal("0")
    approved = qs.filter(status__in=("approved", "converted")).count()
    return (Decimal(approved) / Decimal(total) * Decimal("100")).quantize(Decimal("0.01"))


def pipeline(tenant) -> dict:
    rows = (
        Quote.objects.filter(tenant=tenant, archived_at__isnull=True)
        .values("status").annotate(total=Sum("total"), count=Count("id"))
    )
    return {r["status"]: {"total": r["total"] or Decimal("0"), "count": r["count"]} for r in rows}
