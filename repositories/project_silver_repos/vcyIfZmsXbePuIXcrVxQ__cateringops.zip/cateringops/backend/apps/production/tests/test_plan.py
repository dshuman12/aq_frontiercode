import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.core.exceptions import Conflict
from apps.production.services import create_batch, generate_plan, schedule, update_batch


@pytest.fixture
def order_with_package(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.menu.services import create_category, create_item
    from apps.orders.services import create_from_quote
    from apps.packages.services import add_item, create_package
    from apps.quotes.services import add_package_line, approve, create_draft, send_quote

    c = create_customer(tenant=tenant, primary_email="x@x.test")
    cat = create_category(tenant=tenant, slug="lunch", name="Lunch", kind="boxed_lunch")
    mi = create_item(tenant=tenant, category=cat, name="Tray (10)", price="50", serves=10)
    pkg = create_package(tenant=tenant, slug="c", name="Corp", price_per_person="22.50",
                        minimum_guest_count=10, maximum_guest_count=200)
    add_item(package=pkg, menu_item=mi, portion_per_person="1.0")
    q = create_draft(tenant=tenant, customer=c, location=location,
                    event_date=date.today() + timedelta(days=5), event_time=time(12),
                    guest_count=40, created_by=user)
    add_package_line(quote=q, package=pkg)
    send_quote(quote=q); approve(quote=q)
    return create_from_quote(quote=q, actor=user)


@pytest.mark.django_db
def test_plan_expands_package(order_with_package):
    plan = generate_plan(order_with_package)
    # 40 guests * 1 portion = 40 portions, tray of 10 → 4 trays
    assert plan.items.first().quantity == 4


@pytest.mark.django_db
def test_idempotent(order_with_package):
    a = generate_plan(order_with_package)
    b = generate_plan(order_with_package)
    assert a.id == b.id


@pytest.mark.django_db
def test_regenerate(order_with_package):
    a = generate_plan(order_with_package)
    aid = a.id
    b = generate_plan(order_with_package, regenerate=True)
    assert b.id != aid


@pytest.mark.django_db
def test_checklists_seeded(order_with_package):
    plan = generate_plan(order_with_package)
    labels = {c.label for c in plan.checklists.all()}
    assert "Packaging" in labels
    assert "Utensils & extras" in labels


@pytest.mark.django_db
def test_schedule_only_from_draft(order_with_package):
    plan = generate_plan(order_with_package)
    schedule(plan)
    with pytest.raises(Conflict):
        schedule(plan)


@pytest.mark.django_db
def test_batch_transitions(order_with_package, user):
    plan = generate_plan(order_with_package)
    b = create_batch(plan=plan, label="Trays", item_ids=[plan.items.first().id])
    for s in ("prep_started", "cooking", "packing", "ready", "completed"):
        update_batch(b, to_status=s, actor=user)
    b.refresh_from_db()
    assert b.status == "completed"
    plan.refresh_from_db()
    assert plan.status == "completed"


@pytest.mark.django_db
def test_invalid_transition(order_with_package, user):
    plan = generate_plan(order_with_package)
    b = create_batch(plan=plan, label="A")
    with pytest.raises(Conflict):
        update_batch(b, to_status="completed", actor=user)


@pytest.mark.django_db
def test_issue_recovery(order_with_package, user):
    plan = generate_plan(order_with_package)
    b = create_batch(plan=plan, label="A")
    update_batch(b, to_status="prep_started", actor=user)
    update_batch(b, to_status="issue", actor=user, issue_note="oven down")
    b.refresh_from_db()
    assert b.issue_note == "oven down"
    update_batch(b, to_status="cooking", actor=user)
    b.refresh_from_db()
    assert b.status == "cooking"
