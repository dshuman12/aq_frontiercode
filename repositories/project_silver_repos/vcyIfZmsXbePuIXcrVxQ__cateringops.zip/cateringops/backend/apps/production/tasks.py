from celery import shared_task


@shared_task
def generate_production_plan(order_id: str):
    from apps.orders.models import Order
    from apps.production.services import generate_plan
    try:
        o = Order.objects.get(pk=order_id)
    except Order.DoesNotExist:
        return {"missing": order_id}
    plan = generate_plan(o)
    return {"plan_id": str(plan.id), "items": plan.items.count()}


@shared_task
def send_production_reminders():
    from datetime import timedelta
    from django.utils import timezone
    from apps.production.models import ProductionPlan
    from apps.notifications.tasks import dispatch_template
    cutoff = timezone.now() + timedelta(hours=24)
    qs = ProductionPlan.objects.filter(target_complete_at__lte=cutoff, status="scheduled",
                                       archived_at__isnull=True)
    n = 0
    for p in qs:
        dispatch_template.delay("production.reminder", {"plan_id": str(p.id)})
        n += 1
    return {"reminders": n}
