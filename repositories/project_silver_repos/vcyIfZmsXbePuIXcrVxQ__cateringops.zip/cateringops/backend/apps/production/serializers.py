from rest_framework import serializers

from apps.production.models import (
    KitchenStation, ProductionBatch, ProductionChecklist, ProductionChecklistItem,
    ProductionPlan, ProductionPlanItem,
)


class StationSerializer(serializers.ModelSerializer):
    class Meta:
        model = KitchenStation
        fields = ["id", "slug", "name", "description", "sort_order"]


class PlanItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionPlanItem
        fields = ["id", "menu_item_id", "label", "quantity", "station_id",
                  "allergen_notes", "note"]


class BatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionBatch
        fields = ["id", "plan_id", "label", "status", "station_id", "assigned_to_id",
                  "started_at", "completed_at", "issue_note"]


class ChecklistItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionChecklistItem
        fields = ["id", "label", "is_checked", "checked_by_id", "checked_at"]


class ChecklistSerializer(serializers.ModelSerializer):
    entries = ChecklistItemSerializer(many=True, read_only=True)

    class Meta:
        model = ProductionChecklist
        fields = ["id", "label", "entries"]


class PlanDetailSerializer(serializers.ModelSerializer):
    items = PlanItemSerializer(many=True, read_only=True)
    batches = BatchSerializer(many=True, read_only=True)
    checklists = ChecklistSerializer(many=True, read_only=True)

    class Meta:
        model = ProductionPlan
        fields = ["id", "order_id", "target_complete_at", "status",
                  "notes", "items", "batches", "checklists"]
