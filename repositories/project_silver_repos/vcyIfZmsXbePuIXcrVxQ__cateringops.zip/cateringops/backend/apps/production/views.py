from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.production import serializers as ser, services
from apps.production.models import KitchenStation, ProductionBatch, ProductionPlan


class StationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ser.StationSerializer

    def get_queryset(self):
        return KitchenStation.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        )


class PlanViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ser.PlanDetailSerializer

    def get_queryset(self):
        return ProductionPlan.objects.filter(
            tenant_id=self.kwargs["tenant_id"], archived_at__isnull=True
        ).prefetch_related("items", "batches", "checklists__entries")

    @action(detail=True, methods=["post"], url_path="batches")
    def make_batch(self, request, tenant_id=None, pk=None):
        b = services.create_batch(plan=self.get_object(), label=request.data["label"],
                                 item_ids=request.data.get("item_ids", []))
        return Response(ser.BatchSerializer(b).data, status=status.HTTP_201_CREATED)


class BatchViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ser.BatchSerializer

    def get_queryset(self):
        return ProductionBatch.objects.filter(tenant_id=self.kwargs["tenant_id"])

    @action(detail=True, methods=["post"])
    def update_status(self, request, tenant_id=None, pk=None):
        b = self.get_object()
        services.update_batch(b, to_status=request.data["to"],
                             actor=request.user, issue_note=request.data.get("issue_note", ""))
        # Broadcast over Channels
        from asgiref.sync import async_to_sync
        from channels.layers import get_channel_layer
        layer = get_channel_layer()
        if layer:
            async_to_sync(layer.group_send)(
                f"kitchen.{tenant_id}",
                {"type": "kitchen.message", "payload": ser.BatchSerializer(b).data},
            )
        return Response(ser.BatchSerializer(b).data)
