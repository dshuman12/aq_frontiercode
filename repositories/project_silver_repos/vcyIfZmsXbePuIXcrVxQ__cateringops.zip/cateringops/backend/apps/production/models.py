"""Production planning: turn an order into a kitchen prep plan."""
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class KitchenStation(TenantScoped):
    name = models.CharField(max_length=120)
    slug = models.SlugField(max_length=80)
    description = models.TextField(blank=True, default="")
    sort_order = models.IntegerField(default=0)

    class Meta:
        unique_together = [("tenant", "slug")]


class ProductionPlan(TenantScoped):
    STATUS_CHOICES = [
        ("draft", "Draft"), ("scheduled", "Scheduled"),
        ("in_progress", "In progress"), ("ready", "Ready"),
        ("completed", "Completed"),
    ]
    order = models.OneToOneField("orders.Order", on_delete=models.CASCADE,
                                related_name="production_plan")
    target_complete_at = models.DateTimeField()
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default="draft", db_index=True)
    notes = models.TextField(blank=True, default="")


class ProductionPlanItem(TenantScoped):
    plan = models.ForeignKey(ProductionPlan, on_delete=models.CASCADE, related_name="items")
    menu_item = models.ForeignKey("menu.MenuItem", on_delete=models.PROTECT,
                                 null=True, blank=True, related_name="+")
    label = models.CharField(max_length=200)
    quantity = models.PositiveIntegerField()
    station = models.ForeignKey(KitchenStation, on_delete=models.SET_NULL,
                               null=True, blank=True, related_name="plan_items")
    allergen_notes = models.TextField(blank=True, default="")
    note = models.CharField(max_length=300, blank=True, default="")


class ProductionBatch(TenantScoped):
    STATUS_CHOICES = [
        ("not_started", "Not started"), ("prep_started", "Prep started"),
        ("cooking", "Cooking"), ("packing", "Packing"),
        ("ready", "Ready"), ("completed", "Completed"), ("issue", "Issue"),
    ]
    plan = models.ForeignKey(ProductionPlan, on_delete=models.CASCADE, related_name="batches")
    label = models.CharField(max_length=200)
    items = models.ManyToManyField(ProductionPlanItem, related_name="batches")
    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                   null=True, blank=True, related_name="+")
    station = models.ForeignKey(KitchenStation, on_delete=models.SET_NULL,
                               null=True, blank=True, related_name="batches")
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default="not_started", db_index=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    issue_note = models.TextField(blank=True, default="")


class ProductionChecklist(TenantScoped):
    plan = models.ForeignKey(ProductionPlan, on_delete=models.CASCADE, related_name="checklists")
    label = models.CharField(max_length=200)


class ProductionChecklistItem(TenantScoped):
    checklist = models.ForeignKey(ProductionChecklist, on_delete=models.CASCADE, related_name="entries")
    label = models.CharField(max_length=200)
    is_checked = models.BooleanField(default=False)
    checked_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, blank=True, related_name="+")
    checked_at = models.DateTimeField(null=True, blank=True)
