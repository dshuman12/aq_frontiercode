from django.contrib import admin
from apps.production.models import (
    KitchenStation, ProductionBatch, ProductionChecklist, ProductionChecklistItem,
    ProductionPlan, ProductionPlanItem,
)


admin.site.register(KitchenStation)
admin.site.register(ProductionPlan)
admin.site.register(ProductionBatch)
admin.site.register(ProductionPlanItem)
admin.site.register(ProductionChecklist)
admin.site.register(ProductionChecklistItem)
