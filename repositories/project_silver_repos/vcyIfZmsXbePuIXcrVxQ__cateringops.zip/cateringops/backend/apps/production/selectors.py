from django.utils import timezone

from apps.production.models import ProductionPlan


def todays_plans(tenant):
    today = timezone.now().date()
    return ProductionPlan.objects.filter(
        tenant=tenant, order__event_date=today, archived_at__isnull=True,
    ).select_related("order").prefetch_related("items", "batches")
