from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.production.views import BatchViewSet, PlanViewSet, StationViewSet

router = DefaultRouter()
router.register("stations", StationViewSet, basename="station")
router.register("plans", PlanViewSet, basename="plan")
router.register("batches", BatchViewSet, basename="batch")

urlpatterns = [path("", include(router.urls))]
