from __future__ import annotations
from datetime import datetime, timedelta

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import Conflict
from apps.packages.services import required_quantity
from apps.production.models import (
    KitchenStation, ProductionBatch, ProductionChecklist, ProductionChecklistItem,
    ProductionPlan, ProductionPlanItem,
)


def _target(order):
    event_dt = datetime.combine(order.event_date, order.event_time)
    return event_dt - (timedelta(hours=2) if order.fulfillment == "delivery"
                      else timedelta(minutes=30))


@transaction.atomic
def generate_plan(order, *, regenerate: bool = False) -> ProductionPlan:
    if hasattr(order, "production_plan"):
        if not regenerate:
            return order.production_plan
        order.production_plan.delete()
    plan = ProductionPlan.objects.create(
        tenant=order.tenant, order=order, target_complete_at=_target(order),
    )
    for oi in order.items.all():
        if oi.kind == "package" and oi.package:
            for inc in oi.package.items.select_related("menu_item").all():
                qty = required_quantity(inc, order.guest_count)
                ProductionPlanItem.objects.create(
                    tenant=order.tenant, plan=plan, menu_item=inc.menu_item,
                    label=inc.menu_item.name, quantity=qty,
                    allergen_notes=inc.menu_item.allergen_notes,
                )
        elif oi.kind == "menu_item" and oi.menu_item:
            ProductionPlanItem.objects.create(
                tenant=order.tenant, plan=plan, menu_item=oi.menu_item,
                label=oi.menu_item.name, quantity=oi.quantity,
                allergen_notes=oi.menu_item.allergen_notes,
            )
        else:
            ProductionPlanItem.objects.create(
                tenant=order.tenant, plan=plan, label=oi.label, quantity=oi.quantity,
            )
    _seed_checklists(plan)
    return plan


def _seed_checklists(plan: ProductionPlan):
    cl = ProductionChecklist.objects.create(tenant=plan.tenant, plan=plan, label="Packaging")
    for lbl in ["Trays packed", "Lids secured", "Labels applied", "Allergen flags visible"]:
        ProductionChecklistItem.objects.create(tenant=plan.tenant, checklist=cl, label=lbl)
    cl2 = ProductionChecklist.objects.create(tenant=plan.tenant, plan=plan, label="Utensils & extras")
    for lbl in ["Serving utensils", "Plates/napkins", "Drinkware", "Heating pans"]:
        ProductionChecklistItem.objects.create(tenant=plan.tenant, checklist=cl2, label=lbl)


@transaction.atomic
def schedule(plan: ProductionPlan) -> ProductionPlan:
    if plan.status != "draft":
        raise Conflict(f"status {plan.status}")
    plan.status = "scheduled"
    plan.save(update_fields=["status"])
    return plan


@transaction.atomic
def create_batch(*, plan, label: str, item_ids: list = None, station=None,
                assigned_to=None) -> ProductionBatch:
    b = ProductionBatch.objects.create(
        tenant=plan.tenant, plan=plan, label=label, station=station, assigned_to=assigned_to,
    )
    if item_ids:
        items = ProductionPlanItem.objects.filter(plan=plan, id__in=item_ids)
        b.items.set(items)
    return b


VALID_BATCH = {
    "not_started": {"prep_started", "issue"},
    "prep_started": {"cooking", "packing", "issue"},
    "cooking": {"packing", "ready", "issue"},
    "packing": {"ready", "issue"},
    "ready": {"completed", "issue"},
    "completed": set(),
    "issue": {"prep_started", "cooking", "packing", "ready"},
}


@transaction.atomic
def update_batch(batch, *, to_status: str, actor=None, issue_note: str = "") -> ProductionBatch:
    if to_status not in VALID_BATCH.get(batch.status, set()):
        raise Conflict(f"cannot move {batch.status} → {to_status}")
    if to_status == "prep_started" and batch.started_at is None:
        batch.started_at = timezone.now()
    if to_status == "completed":
        batch.completed_at = timezone.now()
    if to_status == "issue":
        batch.issue_note = issue_note
    batch.status = to_status
    batch.save()
    _advance_plan(batch.plan)
    return batch


def _advance_plan(plan: ProductionPlan):
    if not plan.batches.exists():
        return
    batches = plan.batches.all()
    if all(b.status == "completed" for b in batches) and plan.status != "completed":
        plan.status = "completed"
        plan.save(update_fields=["status"])
        return
    if all(b.status in ("ready", "completed") for b in batches) and plan.status != "ready":
        plan.status = "ready"
        plan.save(update_fields=["status"])
        return
    if any(b.status in ("prep_started", "cooking", "packing") for b in batches) \
       and plan.status not in ("in_progress", "ready", "completed"):
        plan.status = "in_progress"
        plan.save(update_fields=["status"])


def check_item(*, item, by, checked: bool = True) -> ProductionChecklistItem:
    item.is_checked = checked
    if checked:
        item.checked_by = by
        item.checked_at = timezone.now()
    else:
        item.checked_by = None
        item.checked_at = None
    item.save()
    return item
