import pytest

from apps.customers.services import (
    add_address, add_contact, add_note, create_customer,
    find_or_create_by_email,
)


@pytest.mark.django_db
def test_create_business(tenant):
    c = create_customer(tenant=tenant, kind="business",
                       company_name="Acme", primary_email="ops@acme.test")
    assert c.kind == "business"


@pytest.mark.django_db
def test_find_or_create_finds_existing(tenant):
    create_customer(tenant=tenant, primary_email="foo@x.test")
    c = find_or_create_by_email(tenant=tenant, email="foo@x.test")
    assert c.primary_email == "foo@x.test"


@pytest.mark.django_db
def test_setting_primary_contact_demotes_others(tenant):
    c = create_customer(tenant=tenant)
    a = add_contact(customer=c, name="A", is_primary=True)
    b = add_contact(customer=c, name="B", is_primary=True)
    a.refresh_from_db()
    assert a.is_primary is False
    assert b.is_primary is True


@pytest.mark.django_db
def test_default_delivery_address_demotes_same_kind(tenant):
    c = create_customer(tenant=tenant)
    a = add_address(customer=c, kind="delivery", line1="1", city="X", state="WA",
                   postal_code="98101", is_default=True)
    b = add_address(customer=c, kind="delivery", line1="2", city="X", state="WA",
                   postal_code="98102", is_default=True)
    a.refresh_from_db()
    assert a.is_default is False
    assert b.is_default is True


@pytest.mark.django_db
def test_default_billing_doesnt_affect_delivery(tenant):
    c = create_customer(tenant=tenant)
    d = add_address(customer=c, kind="delivery", line1="D", city="X", state="WA",
                   postal_code="98101", is_default=True)
    add_address(customer=c, kind="billing", line1="B", city="X", state="WA",
               postal_code="98101", is_default=True)
    d.refresh_from_db()
    assert d.is_default is True


@pytest.mark.django_db
def test_pin_note(tenant, user):
    c = create_customer(tenant=tenant)
    n = add_note(customer=c, author=user, body="VIP", pinned=True)
    assert n.pinned is True
