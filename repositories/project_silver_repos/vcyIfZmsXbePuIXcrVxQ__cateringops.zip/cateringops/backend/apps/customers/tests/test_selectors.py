import pytest

from apps.customers.selectors import active_customers, search_customers
from apps.customers.services import create_customer


@pytest.mark.django_db
def test_active_excludes_archived(tenant):
    c = create_customer(tenant=tenant, company_name="One")
    create_customer(tenant=tenant, company_name="Two")
    c.archive()
    assert list(active_customers(tenant).values_list("company_name", flat=True)) == ["Two"]


@pytest.mark.django_db
def test_search_by_email(tenant):
    create_customer(tenant=tenant, primary_email="alice@acme.test")
    create_customer(tenant=tenant, primary_email="bob@globex.test")
    assert search_customers(tenant, "acme").count() == 1


@pytest.mark.django_db
def test_search_by_company(tenant):
    create_customer(tenant=tenant, company_name="Acme Tech")
    create_customer(tenant=tenant, company_name="Globex")
    assert search_customers(tenant, "acme").count() == 1
