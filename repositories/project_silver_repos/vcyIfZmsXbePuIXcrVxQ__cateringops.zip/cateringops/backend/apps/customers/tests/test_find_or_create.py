import pytest

from apps.core.exceptions import NotFound
from apps.customers.services import create_customer, find_or_create_by_email


@pytest.mark.django_db
def test_finds_existing(tenant):
    create_customer(tenant=tenant, primary_email="foo@x.test")
    c = find_or_create_by_email(tenant=tenant, email="foo@x.test")
    assert c.primary_email == "foo@x.test"


@pytest.mark.django_db
def test_creates_missing(tenant):
    c = find_or_create_by_email(tenant=tenant, email="new@x.test",
                                defaults={"company_name": "X"})
    assert c.company_name == "X"


@pytest.mark.django_db
def test_normalizes_email(tenant):
    create_customer(tenant=tenant, primary_email="MIXED@x.test")
    c = find_or_create_by_email(tenant=tenant, email="  Mixed@x.test  ")
    assert c.primary_email.lower() == "mixed@x.test"


@pytest.mark.django_db
def test_empty_email_raises(tenant):
    with pytest.raises(NotFound):
        find_or_create_by_email(tenant=tenant, email="")
