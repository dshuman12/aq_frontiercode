from django.contrib import admin
from apps.customers.models import Customer, CustomerAddress, CustomerContact, CustomerNote


class ContactInline(admin.TabularInline):
    model = CustomerContact
    extra = 0


class AddressInline(admin.TabularInline):
    model = CustomerAddress
    extra = 0


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("company_name", "primary_contact_name", "primary_email", "kind")
    search_fields = ("company_name", "primary_contact_name", "primary_email")
    inlines = [ContactInline, AddressInline]


admin.site.register(CustomerNote)
