from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.customers import selectors, serializers as ser, services
from apps.tenants.models import Tenant


class CustomerViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        return ser.CustomerDetailSerializer if self.action != "list" else ser.CustomerListSerializer

    def get_queryset(self):
        t = Tenant.objects.get(pk=self.kwargs["tenant_id"])
        q = self.request.query_params.get("q")
        if q:
            return selectors.search_customers(t, q)
        return selectors.active_customers(t)

    def perform_create(self, serializer):
        serializer.save(tenant=Tenant.objects.get(pk=self.kwargs["tenant_id"]))

    @action(detail=True, methods=["post"], url_path="contacts")
    def add_contact(self, request, tenant_id=None, pk=None):
        c = self.get_object()
        ct = services.add_contact(customer=c, **request.data)
        return Response(ser.ContactSerializer(ct).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"], url_path="addresses")
    def add_address(self, request, tenant_id=None, pk=None):
        c = self.get_object()
        a = services.add_address(customer=c, **request.data)
        return Response(ser.AddressSerializer(a).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"], url_path="notes")
    def add_note(self, request, tenant_id=None, pk=None):
        c = self.get_object()
        n = services.add_note(customer=c, author=request.user,
                             body=request.data["body"], pinned=request.data.get("pinned", False))
        return Response(ser.NoteSerializer(n).data, status=status.HTTP_201_CREATED)
