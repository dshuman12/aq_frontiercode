from rest_framework import serializers
from apps.customers.models import Customer, CustomerAddress, CustomerContact, CustomerNote


class ContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerContact
        fields = ["id", "name", "title", "email", "phone", "is_primary"]


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerAddress
        fields = ["id", "kind", "label", "line1", "line2", "city", "state",
                  "postal_code", "country", "delivery_instructions", "is_default"]


class NoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerNote
        fields = ["id", "body", "pinned", "author_id", "created_at"]


class CustomerListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ["id", "kind", "company_name", "primary_contact_name",
                  "primary_email", "primary_phone", "tax_exempt", "tags"]


class CustomerDetailSerializer(CustomerListSerializer):
    contacts = ContactSerializer(many=True, read_only=True)
    addresses = AddressSerializer(many=True, read_only=True)

    class Meta(CustomerListSerializer.Meta):
        fields = CustomerListSerializer.Meta.fields + [
            "tax_exempt_id", "dietary_preferences", "notes", "contacts", "addresses",
        ]
