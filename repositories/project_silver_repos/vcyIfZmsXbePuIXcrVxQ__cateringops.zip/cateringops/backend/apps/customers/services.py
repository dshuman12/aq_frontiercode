from __future__ import annotations
from django.db import transaction

from apps.core.exceptions import NotFound
from apps.customers.models import Customer, CustomerAddress, CustomerContact, CustomerNote


@transaction.atomic
def create_customer(*, tenant, kind: str = "individual", **fields) -> Customer:
    return Customer.objects.create(tenant=tenant, kind=kind, **fields)


def update_customer(c: Customer, **fields) -> Customer:
    for k, v in fields.items():
        setattr(c, k, v)
    c.save()
    return c


@transaction.atomic
def add_contact(*, customer: Customer, **fields) -> CustomerContact:
    if fields.get("is_primary"):
        CustomerContact.objects.filter(customer=customer, is_primary=True).update(is_primary=False)
    return CustomerContact.objects.create(tenant=customer.tenant, customer=customer, **fields)


@transaction.atomic
def add_address(*, customer: Customer, **fields) -> CustomerAddress:
    if fields.get("is_default"):
        CustomerAddress.objects.filter(
            customer=customer, kind=fields.get("kind"), is_default=True
        ).update(is_default=False)
    return CustomerAddress.objects.create(tenant=customer.tenant, customer=customer, **fields)


def add_note(*, customer: Customer, author, body: str, pinned: bool = False) -> CustomerNote:
    return CustomerNote.objects.create(
        tenant=customer.tenant, customer=customer, author=author, body=body, pinned=pinned,
    )


def find_or_create_by_email(*, tenant, email: str, defaults=None) -> Customer:
    email = (email or "").strip().lower()
    if not email:
        raise NotFound("email required")
    c = Customer.objects.filter(tenant=tenant, primary_email=email, archived_at__isnull=True).first()
    if c:
        return c
    return Customer.objects.create(tenant=tenant, primary_email=email, **(defaults or {}))
