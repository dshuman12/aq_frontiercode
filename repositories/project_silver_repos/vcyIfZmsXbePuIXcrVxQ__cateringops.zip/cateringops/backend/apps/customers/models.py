"""Customers: business or individual entities placing catering orders."""
from django.db import models
from apps.core.models import TenantScoped


class Customer(TenantScoped):
    KIND_CHOICES = [("individual", "Individual"), ("business", "Business")]
    kind = models.CharField(max_length=16, choices=KIND_CHOICES, default="individual")
    company_name = models.CharField(max_length=200, blank=True, default="")
    primary_contact_name = models.CharField(max_length=200, blank=True, default="")
    primary_email = models.EmailField(blank=True, default="")
    primary_phone = models.CharField(max_length=32, blank=True, default="")
    tax_exempt = models.BooleanField(default=False)
    tax_exempt_id = models.CharField(max_length=64, blank=True, default="")
    dietary_preferences = models.JSONField(default=list, blank=True)
    tags = models.JSONField(default=list, blank=True)
    notes = models.TextField(blank=True, default="")

    class Meta:
        indexes = [
            models.Index(fields=["tenant", "primary_email"]),
            models.Index(fields=["tenant", "kind"]),
        ]


class CustomerContact(TenantScoped):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="contacts")
    name = models.CharField(max_length=200)
    title = models.CharField(max_length=120, blank=True, default="")
    email = models.EmailField(blank=True, default="")
    phone = models.CharField(max_length=32, blank=True, default="")
    is_primary = models.BooleanField(default=False)


class CustomerAddress(TenantScoped):
    KIND_CHOICES = [("billing", "Billing"), ("delivery", "Delivery"), ("event", "Event")]
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="addresses")
    kind = models.CharField(max_length=16, choices=KIND_CHOICES, default="delivery")
    label = models.CharField(max_length=120, blank=True, default="")
    line1 = models.CharField(max_length=200)
    line2 = models.CharField(max_length=200, blank=True, default="")
    city = models.CharField(max_length=120)
    state = models.CharField(max_length=64)
    postal_code = models.CharField(max_length=24)
    country = models.CharField(max_length=2, default="US")
    delivery_instructions = models.TextField(blank=True, default="")
    is_default = models.BooleanField(default=False)


class CustomerNote(TenantScoped):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="notes_list")
    author = models.ForeignKey("users.User", on_delete=models.SET_NULL, null=True, related_name="+")
    body = models.TextField()
    pinned = models.BooleanField(default=False)
