from django.db.models import Q

from apps.customers.models import Customer


def active_customers(tenant, *, kind=None):
    qs = Customer.objects.filter(tenant=tenant, archived_at__isnull=True)
    if kind:
        qs = qs.filter(kind=kind)
    return qs.order_by("company_name", "primary_contact_name")


def search_customers(tenant, q: str):
    return active_customers(tenant).filter(
        Q(company_name__icontains=q) | Q(primary_contact_name__icontains=q) | Q(primary_email__icontains=q)
    )
