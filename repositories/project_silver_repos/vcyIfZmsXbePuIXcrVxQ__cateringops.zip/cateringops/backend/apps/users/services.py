"""User-account services: register, verify, password reset, 2FA, sessions."""
from __future__ import annotations

import secrets
from datetime import timedelta

import pyotp
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import ValidationError
from apps.users.models import DeviceSession, EmailVerification, PasswordResetToken

User = get_user_model()


@transaction.atomic
def register(*, email: str, password: str, first_name: str = "", last_name: str = "") -> User:
    email = email.strip().lower()
    if User.objects.filter(email=email).exists():
        raise ValidationError("email already registered")
    return User.objects.create_user(
        email=email, password=password, first_name=first_name, last_name=last_name
    )


def issue_email_verification(*, user: User) -> EmailVerification:
    return EmailVerification.objects.create(
        user=user, token=secrets.token_urlsafe(40),
        expires_at=timezone.now() + timedelta(days=2),
    )


@transaction.atomic
def verify_email(*, token: str) -> User:
    try:
        t = EmailVerification.objects.select_for_update().get(token=token)
    except EmailVerification.DoesNotExist as exc:
        raise ValidationError("invalid token") from exc
    if not t.is_valid():
        raise ValidationError("expired or used")
    t.used_at = timezone.now()
    t.save(update_fields=["used_at"])
    t.user.email_verified_at = timezone.now()
    t.user.save(update_fields=["email_verified_at"])
    return t.user


def issue_password_reset(*, email: str) -> PasswordResetToken | None:
    u = User.objects.filter(email=email.strip().lower()).first()
    if not u:
        return None
    return PasswordResetToken.objects.create(
        user=u, token=secrets.token_urlsafe(40),
        expires_at=timezone.now() + timedelta(hours=1),
    )


@transaction.atomic
def confirm_password_reset(*, token: str, new_password: str) -> User:
    try:
        t = PasswordResetToken.objects.select_for_update().get(token=token)
    except PasswordResetToken.DoesNotExist as exc:
        raise ValidationError("invalid token") from exc
    if not t.is_valid():
        raise ValidationError("expired or used")
    t.used_at = timezone.now()
    t.save(update_fields=["used_at"])
    t.user.set_password(new_password)
    t.user.save(update_fields=["password"])
    return t.user


def setup_twofa(*, user: User) -> str:
    secret = pyotp.random_base32()
    user.twofa_secret = secret
    user.save(update_fields=["twofa_secret"])
    return secret


def verify_twofa(*, user: User, code: str) -> bool:
    if not user.twofa_secret:
        return False
    totp = pyotp.TOTP(user.twofa_secret)
    if totp.verify(code, valid_window=1):
        if not user.twofa_enabled:
            user.twofa_enabled = True
            user.save(update_fields=["twofa_enabled"])
        return True
    return False


def record_device_session(*, user: User, ip: str | None, user_agent: str) -> DeviceSession:
    return DeviceSession.objects.create(user=user, ip=ip, user_agent=user_agent[:400])


def revoke_session(*, user: User, session_id) -> None:
    DeviceSession.objects.filter(
        user=user, id=session_id, revoked_at__isnull=True,
    ).update(revoked_at=timezone.now())
