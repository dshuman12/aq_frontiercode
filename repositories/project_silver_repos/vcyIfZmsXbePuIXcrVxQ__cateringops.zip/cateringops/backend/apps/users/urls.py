from django.urls import path
from apps.users import views

urlpatterns = [
    path("register/", views.register),
    path("login/", views.LoginView.as_view()),
    path("refresh/", views.RefreshView.as_view()),
    path("password-reset/request/", views.password_reset_request),
    path("password-reset/confirm/", views.password_reset_confirm),
    path("verify-email/", views.verify_email),
    path("me/", views.me),
    path("2fa/setup/", views.twofa_setup),
    path("2fa/verify/", views.twofa_verify),
    path("sessions/", views.sessions),
    path("sessions/<uuid:session_id>/revoke/", views.revoke_session),
]
