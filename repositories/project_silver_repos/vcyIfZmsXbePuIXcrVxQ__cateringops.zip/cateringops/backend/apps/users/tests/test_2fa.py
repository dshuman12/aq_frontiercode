import pytest

from apps.users.services import setup_twofa, verify_twofa


@pytest.mark.django_db
def test_setup_secret_persisted(user):
    secret = setup_twofa(user=user)
    user.refresh_from_db()
    assert user.twofa_secret == secret


@pytest.mark.django_db
def test_verify_wrong_code_false(user):
    setup_twofa(user=user)
    assert verify_twofa(user=user, code="000000") is False


@pytest.mark.django_db
def test_verify_no_secret_false(user):
    assert verify_twofa(user=user, code="123456") is False
