import pytest

from apps.core.exceptions import ValidationError
from apps.users.services import confirm_password_reset, issue_password_reset


@pytest.mark.django_db
def test_unknown_email_returns_none():
    assert issue_password_reset(email="missing@x.test") is None


@pytest.mark.django_db
def test_confirm_changes_password(user):
    t = issue_password_reset(email=user.email)
    confirm_password_reset(token=t.token, new_password="brand-new-pw-9")
    user.refresh_from_db()
    assert user.check_password("brand-new-pw-9")


@pytest.mark.django_db
def test_invalid_token_raises():
    with pytest.raises(ValidationError):
        confirm_password_reset(token="bogus", new_password="brand-new-pw-9")


@pytest.mark.django_db
def test_token_single_use(user):
    t = issue_password_reset(email=user.email)
    confirm_password_reset(token=t.token, new_password="x" * 12)
    with pytest.raises(ValidationError):
        confirm_password_reset(token=t.token, new_password="y" * 12)
