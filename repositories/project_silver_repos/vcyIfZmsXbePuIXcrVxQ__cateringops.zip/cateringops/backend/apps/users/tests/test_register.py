import pytest


@pytest.mark.django_db
def test_register_endpoint_creates_user(api_client):
    r = api_client.post("/api/auth/register/", {
        "email": "new@example.test", "password": "pw-correct-horse-1",
    }, format="json")
    assert r.status_code == 201


@pytest.mark.django_db
def test_register_duplicate_rejected(api_client, user):
    r = api_client.post("/api/auth/register/", {
        "email": user.email, "password": "another-pw-9",
    }, format="json")
    assert r.status_code == 400


@pytest.mark.django_db
def test_login_returns_tokens(api_client, user):
    r = api_client.post("/api/auth/login/",
                       {"email": user.email, "password": "pw-correct-horse-1"}, format="json")
    assert r.status_code == 200
    assert "access" in r.data and "refresh" in r.data


@pytest.mark.django_db
def test_login_wrong_password_401(api_client, user):
    r = api_client.post("/api/auth/login/",
                       {"email": user.email, "password": "nope"}, format="json")
    assert r.status_code == 401
