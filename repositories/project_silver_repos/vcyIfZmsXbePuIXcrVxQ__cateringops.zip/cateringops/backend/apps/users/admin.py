from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as Base
from apps.users.models import DeviceSession, EmailVerification, PasswordResetToken, User


@admin.register(User)
class UserAdmin(Base):
    list_display = ("email", "first_name", "last_name", "is_staff", "twofa_enabled")
    search_fields = ("email",)
    ordering = ("-date_joined",)


admin.site.register(DeviceSession)
admin.site.register(EmailVerification)
admin.site.register(PasswordResetToken)
