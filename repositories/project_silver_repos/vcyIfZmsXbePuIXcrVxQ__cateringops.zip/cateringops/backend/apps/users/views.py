from rest_framework import permissions, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from apps.users import serializers as ser, services
from apps.users.models import DeviceSession


@api_view(["POST"])
@permission_classes([permissions.AllowAny])
def register(request):
    s = ser.RegisterSerializer(data=request.data); s.is_valid(raise_exception=True)
    user = services.register(**s.validated_data)
    services.issue_email_verification(user=user)
    return Response(ser.UserSerializer(user).data, status=status.HTTP_201_CREATED)


class LoginView(TokenObtainPairView):
    permission_classes = [permissions.AllowAny]


class RefreshView(TokenRefreshView):
    permission_classes = [permissions.AllowAny]


@api_view(["POST"])
def password_reset_request(request):
    s = ser.PasswordResetRequest(data=request.data); s.is_valid(raise_exception=True)
    services.issue_password_reset(**s.validated_data)
    return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["POST"])
def password_reset_confirm(request):
    s = ser.PasswordResetConfirm(data=request.data); s.is_valid(raise_exception=True)
    services.confirm_password_reset(**s.validated_data)
    return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["POST"])
def verify_email(request):
    s = ser.EmailVerifyIn(data=request.data); s.is_valid(raise_exception=True)
    services.verify_email(**s.validated_data)
    return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET"])
def me(request):
    return Response(ser.UserSerializer(request.user).data)


@api_view(["POST"])
def twofa_setup(request):
    secret = services.setup_twofa(user=request.user)
    return Response({"secret": secret})


@api_view(["POST"])
def twofa_verify(request):
    s = ser.TwoFAVerifyIn(data=request.data); s.is_valid(raise_exception=True)
    ok = services.verify_twofa(user=request.user, code=s.validated_data["code"])
    return Response({"ok": ok}, status=200 if ok else 400)


@api_view(["GET"])
def sessions(request):
    qs = DeviceSession.objects.filter(user=request.user, revoked_at__isnull=True).order_by("-last_seen_at")
    return Response([{"id": str(s.id), "ip": s.ip, "user_agent": s.user_agent,
                     "last_seen_at": s.last_seen_at, "created_at": s.created_at} for s in qs])


@api_view(["POST"])
def revoke_session(request, session_id):
    services.revoke_session(user=request.user, session_id=session_id)
    return Response(status=204)
