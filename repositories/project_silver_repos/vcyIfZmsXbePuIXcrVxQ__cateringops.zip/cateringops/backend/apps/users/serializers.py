from django.contrib.auth import get_user_model
from rest_framework import serializers

User = get_user_model()


class RegisterSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(min_length=10, write_only=True)
    first_name = serializers.CharField(required=False, allow_blank=True)
    last_name = serializers.CharField(required=False, allow_blank=True)


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "email", "first_name", "last_name", "phone",
                  "twofa_enabled", "is_email_verified", "date_joined"]
        read_only_fields = ["id", "twofa_enabled", "is_email_verified", "date_joined"]


class PasswordResetRequest(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirm(serializers.Serializer):
    token = serializers.CharField()
    new_password = serializers.CharField(min_length=10)


class EmailVerifyIn(serializers.Serializer):
    token = serializers.CharField()


class TwoFAVerifyIn(serializers.Serializer):
    code = serializers.CharField(min_length=6, max_length=6)
