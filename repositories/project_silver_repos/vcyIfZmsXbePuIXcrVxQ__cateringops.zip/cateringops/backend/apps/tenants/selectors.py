from apps.tenants.models import Tenant, TenantMembership


def tenants_for(user) -> list[Tenant]:
    ids = TenantMembership.objects.filter(
        user=user, is_active=True, archived_at__isnull=True,
    ).values_list("tenant_id", flat=True)
    return list(Tenant.objects.filter(id__in=ids, archived_at__isnull=True))


def members_of(tenant: Tenant):
    return TenantMembership.objects.filter(
        tenant=tenant, archived_at__isnull=True,
    ).select_related("user").order_by("user__email")
