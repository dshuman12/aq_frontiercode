"""Tenant = a single restaurant operating CateringOps."""
from __future__ import annotations

from django.conf import settings
from django.db import models

from apps.core.models import SoftDeleteModel, TimestampedModel, UuidPkModel


class Tenant(UuidPkModel, TimestampedModel, SoftDeleteModel):
    slug = models.SlugField(unique=True, max_length=80)
    name = models.CharField(max_length=200)
    legal_name = models.CharField(max_length=200, blank=True, default="")
    timezone = models.CharField(max_length=64, default="America/Los_Angeles")
    currency = models.CharField(max_length=3, default="USD")
    tax_id = models.CharField(max_length=64, blank=True, default="")

    contact_email = models.EmailField(blank=True, default="")
    contact_phone = models.CharField(max_length=32, blank=True, default="")
    contact_address = models.CharField(max_length=300, blank=True, default="")

    logo_url = models.URLField(blank=True, default="")
    brand_color = models.CharField(max_length=16, blank=True, default="#0369a1")

    default_deposit_pct = models.DecimalField(max_digits=5, decimal_places=2, default="25.00")
    default_service_charge_pct = models.DecimalField(max_digits=5, decimal_places=2, default="0.00")
    cancellation_policy = models.TextField(blank=True, default="")
    stripe_account_id = models.CharField(max_length=80, blank=True, default="")

    def __str__(self) -> str:
        return self.name


class TenantMembership(UuidPkModel, TimestampedModel, SoftDeleteModel):
    ROLE_CHOICES = [
        ("owner", "Owner"), ("general_manager", "General manager"),
        ("catering_manager", "Catering manager"), ("kitchen_manager", "Kitchen manager"),
        ("chef", "Chef"), ("prep_staff", "Prep staff"),
        ("delivery_driver", "Delivery driver"), ("billing_staff", "Billing staff"),
        ("viewer", "Viewer"),
    ]
    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE, related_name="members")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                            related_name="memberships")
    role = models.CharField(max_length=32, choices=ROLE_CHOICES)
    title = models.CharField(max_length=120, blank=True, default="")
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = [("tenant", "user")]


class Invitation(UuidPkModel, TimestampedModel, SoftDeleteModel):
    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE, related_name="invitations")
    email = models.EmailField()
    role = models.CharField(max_length=32, choices=TenantMembership.ROLE_CHOICES)
    token = models.CharField(max_length=80, unique=True)
    expires_at = models.DateTimeField()
    accepted_at = models.DateTimeField(null=True, blank=True)
    invited_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                  null=True, related_name="+")
