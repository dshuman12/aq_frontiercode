from __future__ import annotations

import secrets
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import Conflict, NotFound, ValidationError
from apps.tenants.models import Invitation, Tenant, TenantMembership


@transaction.atomic
def onboard_tenant(*, owner, slug: str, name: str, **profile) -> Tenant:
    if Tenant.objects.filter(slug=slug).exists():
        raise Conflict(f"slug {slug!r} is taken")
    t = Tenant.objects.create(slug=slug, name=name, **profile)
    TenantMembership.objects.create(tenant=t, user=owner, role="owner", title="Owner")
    return t


def is_member(*, user, tenant: Tenant) -> bool:
    return TenantMembership.objects.filter(
        tenant=tenant, user=user, is_active=True, archived_at__isnull=True
    ).exists()


def member_role(*, user, tenant: Tenant) -> str | None:
    m = TenantMembership.objects.filter(
        tenant=tenant, user=user, is_active=True, archived_at__isnull=True
    ).first()
    return m.role if m else None


@transaction.atomic
def invite(*, tenant: Tenant, email: str, role: str, invited_by) -> Invitation:
    email = email.strip().lower()
    if TenantMembership.objects.filter(tenant=tenant, user__email=email, is_active=True).exists():
        raise Conflict("already a member")
    return Invitation.objects.create(
        tenant=tenant, email=email, role=role,
        token=secrets.token_urlsafe(32),
        expires_at=timezone.now() + timedelta(days=14),
        invited_by=invited_by,
    )


@transaction.atomic
def accept(*, token: str, user) -> TenantMembership:
    try:
        inv = Invitation.objects.select_for_update().get(token=token)
    except Invitation.DoesNotExist as exc:
        raise NotFound("invitation not found") from exc
    if inv.accepted_at is not None:
        raise ValidationError("already accepted")
    if inv.expires_at < timezone.now():
        raise ValidationError("expired")
    if inv.email.lower() != user.email.lower():
        raise ValidationError("email mismatch")
    inv.accepted_at = timezone.now()
    inv.save(update_fields=["accepted_at"])
    m, _ = TenantMembership.objects.get_or_create(
        tenant=inv.tenant, user=user, defaults={"role": inv.role}
    )
    m.role = inv.role
    m.is_active = True
    m.save(update_fields=["role", "is_active"])
    return m


def deactivate_member(*, tenant: Tenant, member_id) -> None:
    TenantMembership.objects.filter(tenant=tenant, id=member_id).update(is_active=False)
