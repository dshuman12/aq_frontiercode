from django.contrib import admin
from apps.tenants.models import Invitation, Tenant, TenantMembership


@admin.register(Tenant)
class TenantAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "currency", "created_at")
    search_fields = ("name", "slug")


@admin.register(TenantMembership)
class MembershipAdmin(admin.ModelAdmin):
    list_display = ("user", "tenant", "role", "is_active")
    list_filter = ("role", "is_active")


admin.site.register(Invitation)
