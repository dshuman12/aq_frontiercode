from rest_framework import serializers
from apps.tenants.models import Invitation, Tenant, TenantMembership


class TenantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tenant
        fields = ["id", "slug", "name", "legal_name", "timezone", "currency", "tax_id",
                  "contact_email", "contact_phone", "contact_address",
                  "logo_url", "brand_color", "default_deposit_pct",
                  "default_service_charge_pct", "cancellation_policy"]


class MembershipSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source="user.email", read_only=True)
    full_name = serializers.SerializerMethodField()

    class Meta:
        model = TenantMembership
        fields = ["id", "email", "full_name", "role", "title", "is_active", "created_at"]

    def get_full_name(self, m):
        return f"{m.user.first_name} {m.user.last_name}".strip() or m.user.email


class InvitationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invitation
        fields = ["id", "email", "role", "expires_at", "accepted_at", "created_at"]
        read_only_fields = ["id", "expires_at", "accepted_at", "created_at"]
