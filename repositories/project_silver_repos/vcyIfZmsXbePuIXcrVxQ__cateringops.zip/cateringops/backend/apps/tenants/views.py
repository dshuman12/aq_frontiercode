from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.core.exceptions import PermissionDenied
from apps.tenants import selectors, serializers as ser, services
from apps.tenants.models import Tenant


class TenantViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ser.TenantSerializer

    def get_queryset(self):
        return Tenant.objects.filter(
            members__user=self.request.user, members__is_active=True, archived_at__isnull=True,
        ).distinct()

    def perform_create(self, serializer):
        services.onboard_tenant(owner=self.request.user, **serializer.validated_data)

    @action(detail=False, methods=["get"])
    def me(self, request):
        return Response(ser.TenantSerializer(selectors.tenants_for(request.user), many=True).data)

    @action(detail=True, methods=["post"])
    def invite(self, request, pk=None):
        t = self.get_object()
        role = services.member_role(user=request.user, tenant=t)
        if role not in ("owner", "general_manager"):
            raise PermissionDenied("only owner/GM can invite")
        inv = services.invite(tenant=t, email=request.data["email"],
                             role=request.data["role"], invited_by=request.user)
        return Response(ser.InvitationSerializer(inv).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["get"])
    def members(self, request, pk=None):
        return Response(ser.MembershipSerializer(selectors.members_of(self.get_object()), many=True).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def accept_invite(request):
    m = services.accept(token=request.data["token"], user=request.user)
    return Response(ser.MembershipSerializer(m).data)
