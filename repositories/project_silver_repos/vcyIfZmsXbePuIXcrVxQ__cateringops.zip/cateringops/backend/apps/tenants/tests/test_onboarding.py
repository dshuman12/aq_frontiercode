import pytest

from apps.core.exceptions import Conflict
from apps.tenants.services import is_member, member_role, onboard_tenant


@pytest.mark.django_db
def test_onboard_creates_owner_membership(user):
    t = onboard_tenant(owner=user, slug="x", name="X")
    assert is_member(user=user, tenant=t)
    assert member_role(user=user, tenant=t) == "owner"


@pytest.mark.django_db
def test_onboard_rejects_duplicate_slug(user, another_user):
    onboard_tenant(owner=user, slug="x", name="X")
    with pytest.raises(Conflict):
        onboard_tenant(owner=another_user, slug="x", name="Y")
