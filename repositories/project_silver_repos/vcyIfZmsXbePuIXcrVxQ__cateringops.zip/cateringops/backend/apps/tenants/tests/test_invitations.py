import pytest

from apps.core.exceptions import Conflict, NotFound, ValidationError
from apps.tenants.services import accept, invite, is_member


@pytest.fixture
def tenant_owned_by(user):
    from apps.tenants.services import onboard_tenant
    return onboard_tenant(owner=user, slug="t", name="T")


@pytest.mark.django_db
def test_invite_then_accept(user, another_user, tenant_owned_by):
    inv = invite(tenant=tenant_owned_by, email=another_user.email,
                role="chef", invited_by=user)
    m = accept(token=inv.token, user=another_user)
    assert m.role == "chef"
    assert is_member(user=another_user, tenant=tenant_owned_by)


@pytest.mark.django_db
def test_wrong_email_rejected(user, another_user, tenant_owned_by):
    inv = invite(tenant=tenant_owned_by, email="someone@elsewhere.test",
                role="chef", invited_by=user)
    with pytest.raises(ValidationError):
        accept(token=inv.token, user=another_user)


@pytest.mark.django_db
def test_unknown_token_rejected(user):
    with pytest.raises(NotFound):
        accept(token="bogus", user=user)


@pytest.mark.django_db
def test_existing_member_invite_rejected(user, tenant_owned_by):
    with pytest.raises(Conflict):
        invite(tenant=tenant_owned_by, email=user.email, role="chef", invited_by=user)
