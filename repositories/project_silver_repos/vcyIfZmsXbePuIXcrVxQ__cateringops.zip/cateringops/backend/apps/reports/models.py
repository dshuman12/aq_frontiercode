from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class ReportExport(TenantScoped):
    STATUS_CHOICES = [("queued", "Queued"), ("running", "Running"),
                     ("succeeded", "Succeeded"), ("failed", "Failed")]
    name = models.CharField(max_length=80)
    format = models.CharField(max_length=8, choices=[("csv", "CSV"), ("pdf", "PDF")])
    params = models.JSONField(default=dict, blank=True)
    file_url = models.URLField(blank=True, default="")
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                                    null=True, related_name="+")
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default="queued")
    error = models.TextField(blank=True, default="")
    completed_at = models.DateTimeField(null=True, blank=True)
