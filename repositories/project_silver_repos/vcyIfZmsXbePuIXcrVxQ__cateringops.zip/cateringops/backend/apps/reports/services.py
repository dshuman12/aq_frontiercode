"""9 canonical reports + CSV export."""
from __future__ import annotations

import csv
import io
from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Count, Sum
from django.utils import timezone


def _range(since=None, until=None):
    until = until or timezone.now().date()
    since = since or (until - timedelta(days=30))
    return since, until


def catering_revenue(tenant, *, since=None, until=None) -> dict:
    from apps.orders.models import Order
    since, until = _range(since, until)
    qs = Order.objects.filter(tenant=tenant, status="completed",
                              event_date__gte=since, event_date__lte=until,
                              archived_at__isnull=True)
    rows = [
        {"order_number": o.order_number,
         "customer": o.customer.company_name or o.customer.primary_email,
         "event_date": o.event_date.isoformat(), "total": str(o.total)}
        for o in qs.select_related("customer").order_by("event_date")
    ]
    total = qs.aggregate(s=Sum("total"))["s"] or Decimal("0")
    return {"rows": rows, "total": str(total),
            "meta": {"since": since.isoformat(), "until": until.isoformat()}}


def quote_conversion(tenant, *, since=None, until=None) -> dict:
    from apps.quotes.models import Quote
    since, until = _range(since, until)
    qs = Quote.objects.filter(tenant=tenant, sent_at__date__gte=since,
                              sent_at__date__lte=until, archived_at__isnull=True)
    total = qs.count()
    approved = qs.filter(status__in=("approved", "converted")).count()
    rate = (Decimal(approved) / Decimal(total) * Decimal("100")) if total else Decimal("0")
    return {"sent": total, "approved": approved,
            "rejected": qs.filter(status="rejected").count(),
            "expired": qs.filter(status="expired").count(),
            "conversion_pct": str(rate.quantize(Decimal("0.01"))),
            "meta": {"since": since.isoformat(), "until": until.isoformat()}}


def deposit_report(tenant) -> dict:
    from apps.billing.models import Deposit
    qs = Deposit.objects.filter(tenant=tenant, archived_at__isnull=True)
    rows = [{"order_id": str(d.order_id), "amount_required": str(d.amount_required),
             "amount_paid": str(d.amount_paid), "status": d.status,
             "paid_at": d.paid_at.isoformat() if d.paid_at else None}
            for d in qs.select_related("order")]
    return {"rows": rows,
            "total_collected": str(qs.filter(status="paid").aggregate(s=Sum("amount_paid"))["s"] or Decimal("0")),
            "total_pending": str(qs.filter(status="pending").aggregate(s=Sum("amount_required"))["s"] or Decimal("0"))}


def outstanding_balances(tenant) -> dict:
    from apps.billing.models import Invoice
    qs = Invoice.objects.filter(tenant=tenant,
                                status__in=("sent", "partially_paid", "overdue"),
                                archived_at__isnull=True)
    rows = [{"invoice_number": i.invoice_number, "customer_id": str(i.customer_id),
             "balance_due": str(i.balance_due),
             "due_at": i.due_at.isoformat() if i.due_at else None, "status": i.status}
            for i in qs.select_related("customer")]
    return {"rows": rows,
            "total_outstanding": str(qs.aggregate(s=Sum("balance_due"))["s"] or Decimal("0"))}


def menu_performance(tenant, *, since=None, until=None) -> dict:
    from apps.orders.models import OrderItem
    since, until = _range(since, until)
    qs = (OrderItem.objects.filter(
        tenant=tenant, kind="menu_item", order__status="completed",
        order__event_date__gte=since, order__event_date__lte=until,
    ).values("menu_item_id", "label")
        .annotate(units=Sum("quantity"), revenue=Sum("line_total"),
                  orders=Count("order", distinct=True))
        .order_by("-revenue"))
    rows = [{"menu_item_id": str(r["menu_item_id"]) if r["menu_item_id"] else None,
             "label": r["label"], "units": r["units"],
             "revenue": str(r["revenue"] or 0), "orders": r["orders"]} for r in qs]
    return {"rows": rows, "meta": {"since": since.isoformat(), "until": until.isoformat()}}


def package_performance(tenant, *, since=None, until=None) -> dict:
    from apps.orders.models import OrderItem
    since, until = _range(since, until)
    qs = (OrderItem.objects.filter(
        tenant=tenant, kind="package", order__status="completed",
        order__event_date__gte=since, order__event_date__lte=until,
    ).values("package_id", "label")
        .annotate(times_sold=Count("id"), revenue=Sum("line_total"))
        .order_by("-revenue"))
    return {"rows": [{"package_id": str(r["package_id"]) if r["package_id"] else None,
                      "label": r["label"], "times_sold": r["times_sold"],
                      "revenue": str(r["revenue"] or 0)} for r in qs]}


def delivery_success(tenant, *, since=None, until=None) -> dict:
    from apps.delivery.models import Delivery
    since, until = _range(since, until)
    qs = Delivery.objects.filter(tenant=tenant,
                                 delivery_window_start__date__gte=since,
                                 delivery_window_start__date__lte=until,
                                 archived_at__isnull=True)
    total = qs.count()
    delivered = qs.filter(status="delivered").count()
    failed = qs.filter(status="failed").count()
    rate = (Decimal(delivered) / Decimal(total) * Decimal("100")) if total else Decimal("0")
    return {"total": total, "delivered": delivered, "failed": failed,
            "success_pct": str(rate.quantize(Decimal("0.01")))}


def cancellation_report(tenant, *, since=None, until=None) -> dict:
    from apps.orders.models import Order
    since, until = _range(since, until)
    qs = Order.objects.filter(tenant=tenant, status="cancelled",
                              cancelled_at__date__gte=since,
                              cancelled_at__date__lte=until, archived_at__isnull=True)
    rows = [{"order_number": o.order_number, "cancelled_at": o.cancelled_at.isoformat(),
             "reason": o.cancelled_reason, "total": str(o.total)}
            for o in qs.order_by("-cancelled_at")]
    return {"rows": rows, "count": qs.count()}


def customer_repeats(tenant) -> dict:
    from apps.orders.models import Order
    qs = (Order.objects.filter(tenant=tenant, status="completed", archived_at__isnull=True)
          .values("customer_id")
          .annotate(orders=Count("id"), revenue=Sum("total"))
          .filter(orders__gt=1).order_by("-revenue"))
    return {"rows": [{"customer_id": str(r["customer_id"]), "orders": r["orders"],
                      "revenue": str(r["revenue"] or 0)} for r in qs]}


def to_csv(rows: list, headers=None) -> str:
    if not rows:
        return ""
    buf = io.StringIO()
    headers = headers or list(rows[0].keys())
    w = csv.DictWriter(buf, fieldnames=headers, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow(r)
    return buf.getvalue()
