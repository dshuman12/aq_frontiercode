import pytest
from datetime import date, time, timedelta
from decimal import Decimal

from apps.reports.services import (
    catering_revenue, customer_repeats, delivery_success, deposit_report,
    menu_performance, outstanding_balances, package_performance,
    quote_conversion, to_csv,
)


@pytest.fixture
def completed_order(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import (
        apply_deposit_payment, complete, confirm, create_direct, mark_ready, start_production,
    )
    c = create_customer(tenant=tenant, primary_email="t@t.test", company_name="Acme")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today(), event_time=time(12), guest_count=20,
                     items=[{"label": "Box", "quantity": 20, "unit_price": "12.50",
                             "kind": "menu_item"}], actor=user)
    o.deposit_required_amount = Decimal("50")
    o.save(update_fields=["deposit_required_amount"])
    apply_deposit_payment(o, Decimal("50"))
    confirm(o, actor=user); start_production(o, actor=user)
    mark_ready(o, actor=user); complete(o, actor=user)
    return o


@pytest.mark.django_db
def test_revenue(tenant, completed_order):
    rep = catering_revenue(tenant, since=date.today() - timedelta(days=1),
                          until=date.today() + timedelta(days=1))
    assert rep["total"] == "250.00"


@pytest.mark.django_db
def test_revenue_excludes_incomplete(tenant, location, user):
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    c = create_customer(tenant=tenant, primary_email="t@t.test")
    create_direct(tenant=tenant, customer=c, location=location,
                 event_date=date.today(), event_time=time(12), guest_count=10,
                 items=[{"label": "X", "quantity": 1, "unit_price": "100"}], actor=user)
    rep = catering_revenue(tenant)
    assert rep["total"] == "0"


@pytest.mark.django_db
def test_conversion_zero(tenant):
    assert quote_conversion(tenant)["sent"] == 0


@pytest.mark.django_db
def test_deposit_report(tenant, completed_order):
    rep = deposit_report(tenant)
    assert "rows" in rep


@pytest.mark.django_db
def test_outstanding_zero(tenant):
    rep = outstanding_balances(tenant)
    assert rep["total_outstanding"] == "0"


@pytest.mark.django_db
def test_menu_performance(tenant, completed_order):
    rep = menu_performance(tenant)
    assert len(rep["rows"]) == 1
    assert rep["rows"][0]["units"] == 20


@pytest.mark.django_db
def test_package_performance_empty(tenant):
    assert package_performance(tenant)["rows"] == []


@pytest.mark.django_db
def test_delivery_success_empty(tenant):
    assert delivery_success(tenant)["total"] == 0


@pytest.mark.django_db
def test_repeats_only_returns_repeats(tenant, completed_order):
    assert customer_repeats(tenant)["rows"] == []


def test_to_csv_empty():
    assert to_csv([]) == ""


def test_to_csv_rows():
    out = to_csv([{"a": "1", "b": "2"}])
    assert "a,b" in out


def test_to_csv_escapes_quotes():
    out = to_csv([{"a": 'has "q"'}])
    assert '"has ""q"""' in out


def test_to_csv_escapes_comma_and_newline():
    out = to_csv([{"a": "comma,here"}, {"a": "newline\nhere"}])
    assert '"comma,here"' in out
    assert '"newline\nhere"' in out
