import pytest


@pytest.mark.django_db
def test_unknown_404(auth_client, tenant):
    r = auth_client.get(f"/api/t/{tenant.id}/reports/nonexistent/")
    assert r.status_code == 404


@pytest.mark.django_db
def test_known_200(auth_client, tenant):
    r = auth_client.get(f"/api/t/{tenant.id}/reports/catering-revenue/")
    assert r.status_code == 200
    assert "rows" in r.data
