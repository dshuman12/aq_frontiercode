from django.contrib import admin
from apps.reports.models import ReportExport


@admin.register(ReportExport)
class ReportExportAdmin(admin.ModelAdmin):
    list_display = ("name", "format", "status", "completed_at")
