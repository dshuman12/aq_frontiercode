from datetime import date

from django.http import HttpResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.reports import services
from apps.tenants.models import Tenant


REPORTS = {
    "catering-revenue": services.catering_revenue,
    "quote-conversion": services.quote_conversion,
    "deposit": services.deposit_report,
    "outstanding-balance": services.outstanding_balances,
    "menu-performance": services.menu_performance,
    "package-performance": services.package_performance,
    "delivery-success": services.delivery_success,
    "cancellation": services.cancellation_report,
    "customer-repeats": services.customer_repeats,
}


def _parse_range(request):
    p = {}
    if request.query_params.get("since"):
        p["since"] = date.fromisoformat(request.query_params["since"])
    if request.query_params.get("until"):
        p["until"] = date.fromisoformat(request.query_params["until"])
    return p


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def run(request, tenant_id, name):
    fn = REPORTS.get(name)
    if not fn:
        return Response({"error": "unknown report"}, status=404)
    return Response(fn(Tenant.objects.get(pk=tenant_id), **_parse_range(request)))


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def export_csv(request, tenant_id, name):
    fn = REPORTS.get(name)
    if not fn:
        return Response({"error": "unknown report"}, status=404)
    data = fn(Tenant.objects.get(pk=tenant_id), **_parse_range(request))
    csv_text = services.to_csv(data.get("rows", []))
    response = HttpResponse(csv_text, content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{name}.csv"'
    return response
