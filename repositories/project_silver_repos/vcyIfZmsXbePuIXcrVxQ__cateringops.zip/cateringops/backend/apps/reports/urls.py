from django.urls import path
from apps.reports.views import export_csv, run


urlpatterns = [
    path("<str:name>/", run),
    path("<str:name>/export.csv", export_csv),
]
