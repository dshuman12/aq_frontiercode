from django.urls import path
from apps.kitchen.views import board

urlpatterns = [path("board/", board)]
