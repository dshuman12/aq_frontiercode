"""Kitchen board events (notes, delay alerts) — separate from production for read perf."""
from django.conf import settings
from django.db import models
from apps.core.models import TenantScoped


class KitchenEvent(TenantScoped):
    KIND_CHOICES = [
        ("batch_status", "Batch status"),
        ("note", "Kitchen note"),
        ("delay", "Delay alert"),
    ]
    batch = models.ForeignKey("production.ProductionBatch", on_delete=models.CASCADE,
                              null=True, blank=True, related_name="kitchen_events")
    kind = models.CharField(max_length=24, choices=KIND_CHOICES)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                              related_name="+")
    payload = models.JSONField(default=dict)
    at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-at"]
