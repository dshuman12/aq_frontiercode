from django.contrib import admin
from apps.kitchen.models import KitchenEvent


@admin.register(KitchenEvent)
class KitchenEventAdmin(admin.ModelAdmin):
    list_display = ("kind", "batch", "actor", "at")
    list_filter = ("kind",)
