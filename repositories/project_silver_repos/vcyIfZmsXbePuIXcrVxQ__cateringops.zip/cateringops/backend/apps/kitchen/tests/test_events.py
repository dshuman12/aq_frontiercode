import pytest

from apps.kitchen.services import add_note, flag_delay


@pytest.fixture
def batch(tenant, location, user):
    from datetime import date, time, timedelta
    from apps.customers.services import create_customer
    from apps.orders.services import create_direct
    from apps.production.services import create_batch, generate_plan
    c = create_customer(tenant=tenant, primary_email="x@x.test")
    o = create_direct(tenant=tenant, customer=c, location=location,
                     event_date=date.today() + timedelta(days=1), event_time=time(12),
                     guest_count=10, items=[{"label": "X", "quantity": 1, "unit_price": "100"}],
                     actor=user)
    plan = generate_plan(o)
    return create_batch(plan=plan, label="A")


@pytest.mark.django_db
def test_add_note(batch, user):
    e = add_note(batch=batch, body="extra sauce", actor=user)
    assert e.kind == "note"
    assert e.payload["body"] == "extra sauce"


@pytest.mark.django_db
def test_flag_delay(batch, user):
    e = flag_delay(batch=batch, minutes_late=15, reason="oven", actor=user)
    assert e.payload["minutes_late"] == 15
