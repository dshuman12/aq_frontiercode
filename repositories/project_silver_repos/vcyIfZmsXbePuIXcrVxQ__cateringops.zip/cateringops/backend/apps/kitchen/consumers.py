from channels.generic.websocket import AsyncJsonWebsocketConsumer


class KitchenConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self):
        self.tenant_id = self.scope["url_route"]["kwargs"]["tenant_id"]
        self.group_name = f"kitchen.{self.tenant_id}"
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def kitchen_message(self, event):
        await self.send_json(event["payload"])
