from django.urls import path
from apps.kitchen.consumers import KitchenConsumer


websocket_urlpatterns = [
    path("ws/kitchen/<str:tenant_id>/", KitchenConsumer.as_asgi()),
]
