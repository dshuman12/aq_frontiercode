from apps.kitchen.models import KitchenEvent


def add_note(*, batch, body: str, actor) -> KitchenEvent:
    return KitchenEvent.objects.create(
        tenant=batch.tenant, batch=batch, kind="note",
        actor=actor, payload={"body": body},
    )


def flag_delay(*, batch, minutes_late: int, reason: str, actor) -> KitchenEvent:
    return KitchenEvent.objects.create(
        tenant=batch.tenant, batch=batch, kind="delay", actor=actor,
        payload={"minutes_late": minutes_late, "reason": reason},
    )
