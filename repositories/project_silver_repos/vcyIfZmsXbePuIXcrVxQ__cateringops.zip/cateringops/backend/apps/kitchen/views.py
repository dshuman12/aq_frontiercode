from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.production.selectors import todays_plans
from apps.tenants.models import Tenant


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def board(request, tenant_id):
    t = Tenant.objects.get(pk=tenant_id)
    items = []
    for plan in todays_plans(t):
        for batch in plan.batches.all():
            items.append({
                "id": str(batch.id),
                "event_time": plan.order.event_time.isoformat(),
                "station": batch.station.name if batch.station else "",
                "label": batch.label,
                "qty": batch.items.count(),
                "status": batch.status,
            })
    return Response({"items": items})
