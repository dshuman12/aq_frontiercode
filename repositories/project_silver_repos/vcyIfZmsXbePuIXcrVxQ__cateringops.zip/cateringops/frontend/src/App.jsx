import { Route, Routes, Navigate } from "react-router-dom";
import { LoginPage } from "./features/auth/LoginPage";
import { Shell } from "./Shell";
import { DashboardHome } from "./features/dashboard/DashboardHome";

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/t/:tenantId" element={<Shell />}>
        <Route index element={<DashboardHome />} />
      </Route>
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
