import { Outlet, NavLink, useParams } from "react-router-dom";

const NAV = [
  { to: "", label: "Dashboard", end: true },
  { to: "inquiries", label: "Inquiries" },
  { to: "quotes", label: "Quotes" },
  { to: "orders", label: "Orders" },
  { to: "production", label: "Production" },
  { to: "kitchen", label: "Kitchen" },
  { to: "delivery", label: "Delivery" },
  { to: "customers", label: "Customers" },
  { to: "menu", label: "Menu" },
  { to: "packages", label: "Packages" },
  { to: "billing", label: "Billing" },
  { to: "reports", label: "Reports" },
];

export function Shell() {
  const { tenantId } = useParams();
  return (
    <div className="flex min-h-screen">
      <aside className="w-56 border-r border-ops-100 bg-white p-4">
        <h1 className="mb-4 text-lg font-semibold text-ops-800">CateringOps</h1>
        <ul className="space-y-1 text-sm">
          {NAV.map((i) => (
            <li key={i.to}>
              <NavLink
                to={`/t/${tenantId}/${i.to}`}
                end={i.end}
                className={({ isActive }) =>
                  `block rounded px-3 py-1.5 ${isActive ? "bg-ops-100 text-ops-900 font-medium" : "text-ops-700 hover:bg-ops-50"}`
                }
              >
                {i.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </aside>
      <main className="flex-1 p-6"><Outlet /></main>
    </div>
  );
}
