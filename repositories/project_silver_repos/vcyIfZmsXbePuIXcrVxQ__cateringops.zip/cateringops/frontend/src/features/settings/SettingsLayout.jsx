import { NavLink, Outlet, useParams } from "react-router-dom";

const TABS = [
  { to: "general", label: "General" },
  { to: "team", label: "Team" },
  { to: "locations", label: "Locations" },
  { to: "deposit-rules", label: "Deposit rules" },
  { to: "notifications", label: "Notifications" },
];

export function SettingsLayout() {
  const { tenantId } = useParams();
  return (
    <div className="flex gap-6">
      <nav className="w-48 flex-shrink-0">
        <ul className="space-y-1 text-sm">
          {TABS.map((t) => (
            <li key={t.to}>
              <NavLink to={`/t/${tenantId}/settings/${t.to}`}
                       className={({ isActive }) => `block rounded px-3 py-1.5 ${
                         isActive ? "bg-ops-100 text-ops-900" : "text-ops-700"
                       }`}>
                {t.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      <main className="flex-1"><Outlet /></main>
    </div>
  );
}
