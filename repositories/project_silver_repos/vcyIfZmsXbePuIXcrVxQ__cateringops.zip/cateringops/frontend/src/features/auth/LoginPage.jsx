import { useState } from "react";
import { useNavigate } from "react-router-dom";

export function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const nav = useNavigate();

  async function onSubmit(e) {
    e.preventDefault();
    const r = await fetch("/api/auth/login/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (!r.ok) { setError("invalid credentials"); return; }
    const j = await r.json();
    localStorage.setItem("co:access", j.access);
    localStorage.setItem("co:refresh", j.refresh);
    const me = await fetch("/api/tenants/me/", { headers: { Authorization: `Bearer ${j.access}` } });
    const list = await me.json();
    if (list?.[0]) nav(`/t/${list[0].id}`);
  }

  return (
    <div className="mx-auto max-w-sm p-8">
      <h1 className="mb-4 text-3xl font-semibold text-ops-900">Sign in</h1>
      <form onSubmit={onSubmit} className="space-y-3">
        <label className="block">
          <span className="text-sm">Email</span>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                 className="w-full rounded border border-ops-200 p-2" required />
        </label>
        <label className="block">
          <span className="text-sm">Password</span>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                 className="w-full rounded border border-ops-200 p-2" required />
        </label>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button className="w-full rounded bg-ops-700 px-4 py-2 text-white">Sign in</button>
      </form>
    </div>
  );
}
