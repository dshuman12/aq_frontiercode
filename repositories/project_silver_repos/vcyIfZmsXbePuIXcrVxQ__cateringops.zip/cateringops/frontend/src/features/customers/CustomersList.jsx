import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { fetchCustomers } from "../../api/customers";

export function CustomersList() {
  const { tenantId } = useParams();
  const [q, setQ] = useState("");
  const { data, isLoading } = useQuery({
    queryKey: ["customers", tenantId, q],
    queryFn: () => fetchCustomers(tenantId, q),
  });
  return (
    <div className="space-y-3">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-ops-900">Customers</h1>
        <Link to={`/t/${tenantId}/customers/new`}
              className="rounded bg-ops-700 px-4 py-2 text-sm text-white">New</Link>
      </header>
      <input type="search" value={q} onChange={(e) => setQ(e.target.value)}
             placeholder="Search…"
             className="w-80 rounded border border-ops-200 px-3 py-2 text-sm" />
      {isLoading ? <p>Loading…</p> :
        <table className="w-full text-sm">
          <thead className="text-left text-ops-700">
            <tr><th>Name</th><th>Kind</th><th>Email</th><th>Phone</th></tr>
          </thead>
          <tbody>
            {(data?.results ?? data ?? []).map((c) => (
              <tr key={c.id} className="border-t border-ops-100">
                <td><Link to={`/t/${tenantId}/customers/${c.id}`} className="underline">
                  {c.company_name || c.primary_contact_name || c.primary_email}
                </Link></td>
                <td>{c.kind}</td>
                <td>{c.primary_email}</td>
                <td>{c.primary_phone}</td>
              </tr>
            ))}
          </tbody>
        </table>}
    </div>
  );
}
