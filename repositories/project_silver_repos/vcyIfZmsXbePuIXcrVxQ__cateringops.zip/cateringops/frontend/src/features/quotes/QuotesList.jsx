import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { http } from "../../api/http";

export function QuotesList() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["quotes", tenantId],
    queryFn: () => http(`/t/${tenantId}/quotes/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Quotes</h1>
      <table className="w-full text-sm">
        <thead className="text-left text-ops-700">
          <tr><th>Quote #</th><th>Customer</th><th>Event date</th><th>Total</th><th>Status</th></tr>
        </thead>
        <tbody>
          {(data?.results ?? data ?? []).map((q) => (
            <tr key={q.id} className="border-t border-ops-100">
              <td><Link to={`/t/${tenantId}/quotes/${q.id}`} className="underline">{q.quote_number}</Link></td>
              <td>{q.customer_name}</td>
              <td>{q.event_date}</td>
              <td>${Number(q.total).toFixed(2)}</td>
              <td>{q.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
