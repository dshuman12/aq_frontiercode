import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

export function MenuList() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["menu", tenantId],
    queryFn: () => http(`/t/${tenantId}/menu/items/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Catering menu</h1>
      <table className="w-full text-sm">
        <thead className="text-left text-ops-700">
          <tr><th>Name</th><th>Category</th><th>Pack</th><th>Serves</th><th>Price</th></tr>
        </thead>
        <tbody>
          {(data?.results ?? data ?? []).map((i) => (
            <tr key={i.id} className="border-t border-ops-100">
              <td>{i.name}</td><td>{i.category_name}</td>
              <td>{i.packaging}</td><td>{i.serves}</td>
              <td>${Number(i.price).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
