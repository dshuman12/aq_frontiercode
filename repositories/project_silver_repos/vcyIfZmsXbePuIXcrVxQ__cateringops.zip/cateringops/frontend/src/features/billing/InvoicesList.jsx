import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

export function InvoicesList() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["invoices", tenantId],
    queryFn: () => http(`/t/${tenantId}/billing/invoices/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Invoices</h1>
      <table className="w-full text-sm">
        <thead className="text-left text-ops-700">
          <tr><th>Invoice #</th><th>Total</th><th>Balance</th><th>Status</th><th>Due</th></tr>
        </thead>
        <tbody>
          {(data?.results ?? data ?? []).map((i) => (
            <tr key={i.id} className="border-t border-ops-100">
              <td>{i.invoice_number}</td>
              <td>${Number(i.total).toFixed(2)}</td>
              <td>${Number(i.balance_due).toFixed(2)}</td>
              <td>{i.status}</td>
              <td>{i.due_at}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
