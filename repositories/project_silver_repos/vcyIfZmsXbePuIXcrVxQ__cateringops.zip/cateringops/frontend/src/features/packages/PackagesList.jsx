import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { http } from "../../api/http";

export function PackagesList() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["packages", tenantId],
    queryFn: () => http(`/t/${tenantId}/packages/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Catering packages</h1>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {(data?.results ?? data ?? []).map((p) => (
          <Link key={p.id} to={`/t/${tenantId}/packages/${p.id}`}
                className="block rounded-xl border border-ops-100 bg-white p-4 hover:border-ops-600">
            <h3 className="font-semibold text-ops-900">{p.name}</h3>
            <p className="text-sm">${Number(p.price_per_person).toFixed(2)}/person</p>
            <p className="text-sm text-ops-700">{p.minimum_guest_count}–{p.maximum_guest_count} guests</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
