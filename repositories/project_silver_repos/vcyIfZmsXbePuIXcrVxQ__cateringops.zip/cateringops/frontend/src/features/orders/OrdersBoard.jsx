import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { http } from "../../api/http";

const COLS = ["pending_deposit", "confirmed", "in_production",
              "ready_for_pickup", "out_for_delivery", "completed"];

export function OrdersBoard() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["orders", tenantId],
    queryFn: () => http(`/t/${tenantId}/orders/`),
  });
  if (isLoading) return <p>Loading…</p>;
  const all = data?.results ?? data ?? [];
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Orders</h1>
      <div className="grid grid-cols-3 gap-3 lg:grid-cols-6">
        {COLS.map((s) => (
          <div key={s} className="rounded-lg border border-ops-100 bg-white p-2">
            <h3 className="mb-2 text-xs font-medium uppercase text-ops-700">{s.replace(/_/g, " ")}</h3>
            <ul className="space-y-1">
              {all.filter((o) => o.status === s).map((o) => (
                <li key={o.id} className="rounded bg-ops-50 p-2 text-xs">
                  <Link to={`/t/${tenantId}/orders/${o.id}`} className="font-medium underline">{o.order_number}</Link>
                  <div className="text-ops-700">{o.customer_name}</div>
                  <div>${Number(o.total).toFixed(2)}</div>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
