import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

export function NotificationCenter() {
  const { tenantId } = useParams();
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["notifs", tenantId],
    queryFn: () => http(`/t/${tenantId}/notifications/`),
  });
  const markRead = useMutation({
    mutationFn: (id) => http(`/t/${tenantId}/notifications/${id}/read/`, { method: "POST" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notifs", tenantId] }),
  });
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Notifications</h1>
      <ul className="space-y-2">
        {(data?.results ?? data ?? []).map((n) => (
          <li key={n.id} className={`rounded border p-3 ${n.read_at ? "bg-white" : "bg-ops-50"}`}>
            <div className="flex justify-between">
              <div>
                <strong>{n.subject}</strong>
                <p className="text-sm text-ops-700">{n.body}</p>
                <time className="text-xs text-ops-500">{new Date(n.created_at).toLocaleString()}</time>
              </div>
              {!n.read_at && (
                <button onClick={() => markRead.mutate(n.id)} className="text-xs underline">Mark read</button>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
