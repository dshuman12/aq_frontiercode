import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

export function DeliveryBoard() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["delivery", tenantId],
    queryFn: () => http(`/t/${tenantId}/delivery/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Delivery board</h1>
      <table className="w-full text-sm">
        <thead className="text-left text-ops-700">
          <tr><th>Window</th><th>Address</th><th>Status</th><th>Driver</th></tr>
        </thead>
        <tbody>
          {(data?.results ?? data ?? []).map((d) => (
            <tr key={d.id} className="border-t border-ops-100">
              <td>{new Date(d.delivery_window_start).toLocaleTimeString()}</td>
              <td>{d.address}</td>
              <td>{d.status}</td>
              <td>{d.driver_id ? "assigned" : "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
