import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

export function ProductionBoard() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["plans", tenantId],
    queryFn: () => http(`/t/${tenantId}/production/plans/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Production board</h1>
      {(data?.results ?? data ?? []).map((p) => (
        <div key={p.id} className="rounded border border-ops-100 bg-white p-3">
          <div className="flex justify-between">
            <strong>Plan #{p.id.slice(0, 8)}</strong>
            <span className="text-sm">{p.status}</span>
          </div>
          <ul className="mt-2 space-y-1 text-sm">
            {p.items.map((i) => <li key={i.id}>{i.quantity} × {i.label}</li>)}
          </ul>
        </div>
      ))}
    </div>
  );
}
