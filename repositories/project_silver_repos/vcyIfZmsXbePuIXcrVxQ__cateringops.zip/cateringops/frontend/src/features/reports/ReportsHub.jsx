import { Link, useParams } from "react-router-dom";

const REPORTS = [
  ["catering-revenue", "Catering revenue", "Completed-order totals"],
  ["quote-conversion", "Quote conversion", "Sent → approved %"],
  ["deposit", "Deposits", "Collected / pending"],
  ["outstanding-balance", "Outstanding balance", "Invoices with balance"],
  ["menu-performance", "Menu performance", "Top items"],
  ["package-performance", "Package performance", "Top packages"],
  ["delivery-success", "Delivery success", "Delivered / failed %"],
  ["cancellation", "Cancellation", "Cancelled orders"],
  ["customer-repeats", "Customer repeats", "Returning customers"],
];

export function ReportsHub() {
  const { tenantId } = useParams();
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Reports</h1>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {REPORTS.map(([slug, title, hint]) => (
          <Link key={slug} to={`/t/${tenantId}/reports/${slug}`}
                className="block rounded-xl border border-ops-100 bg-white p-4 hover:border-ops-600">
            <h3 className="font-semibold text-ops-900">{title}</h3>
            <p className="text-sm text-ops-700">{hint}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
