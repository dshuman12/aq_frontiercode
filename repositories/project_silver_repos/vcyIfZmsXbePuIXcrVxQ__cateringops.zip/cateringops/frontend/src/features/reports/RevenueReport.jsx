import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

export function RevenueReport() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["rev", tenantId],
    queryFn: () => http(`/t/${tenantId}/reports/catering-revenue/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <div>
      <h2 className="text-xl font-semibold text-ops-900">Catering revenue</h2>
      <p className="text-sm text-ops-700">{data?.meta?.since} → {data?.meta?.until}</p>
      <p className="mt-2 text-2xl">Total: ${Number(data.total).toFixed(2)}</p>
      <a href={`/api/t/${tenantId}/reports/catering-revenue/export.csv`} className="mt-2 inline-block text-sm underline">
        Download CSV
      </a>
      <table className="mt-4 w-full text-sm">
        <thead><tr className="text-left"><th>Order</th><th>Customer</th><th>Date</th><th>Total</th></tr></thead>
        <tbody>
          {(data.rows || []).map((r, i) => (
            <tr key={i} className="border-t border-ops-100">
              <td>{r.order_number}</td>
              <td>{r.customer}</td>
              <td>{r.event_date}</td>
              <td>${Number(r.total).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
