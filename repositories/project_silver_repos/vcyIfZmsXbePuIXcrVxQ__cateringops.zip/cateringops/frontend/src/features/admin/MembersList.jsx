import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";
import { ROLE_LABELS } from "../../lib/permissions";

export function MembersList() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["members", tenantId],
    queryFn: () => http(`/tenants/${tenantId}/members/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <table className="w-full text-sm">
      <thead className="text-left text-ops-700">
        <tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th></tr>
      </thead>
      <tbody>
        {(data || []).map((m) => (
          <tr key={m.id} className="border-t border-ops-100">
            <td>{m.full_name}</td>
            <td>{m.email}</td>
            <td>{ROLE_LABELS[m.role] || m.role}</td>
            <td>{m.is_active ? "yes" : "no"}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
