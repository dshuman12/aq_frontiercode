import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

export function AuditLog() {
  const { tenantId } = useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["audit", tenantId],
    queryFn: () => http(`/t/${tenantId}/audit/`),
  });
  if (isLoading) return <p>Loading…</p>;
  return (
    <table className="w-full text-sm">
      <thead className="text-left text-ops-700">
        <tr><th>When</th><th>Actor</th><th>Action</th><th>Resource</th></tr>
      </thead>
      <tbody>
        {(data?.results ?? data ?? []).map((e) => (
          <tr key={e.id} className="border-t border-ops-100">
            <td>{new Date(e.at).toLocaleString()}</td>
            <td>{e.actor_id}</td>
            <td>{e.action}</td>
            <td>{e.resource_type}#{e.resource_id}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
