import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { http } from "../../api/http";

function Card({ title, value, hint }) {
  return (
    <div className="rounded-xl border border-ops-100 bg-white p-4">
      <div className="text-sm text-ops-700">{title}</div>
      <div className="mt-1 text-2xl font-semibold text-ops-900">{value}</div>
      {hint && <div className="mt-1 text-xs text-ops-500">{hint}</div>}
    </div>
  );
}

export function DashboardHome() {
  const { tenantId } = useParams();
  const inq = useQuery({ queryKey: ["i", tenantId], queryFn: () => http(`/t/${tenantId}/inquiries/?status=new`) });
  const quotes = useQuery({ queryKey: ["q", tenantId], queryFn: () => http(`/t/${tenantId}/quotes/?status=sent`) });
  const orders = useQuery({ queryKey: ["o", tenantId], queryFn: () => http(`/t/${tenantId}/orders/?status=confirmed`) });
  const rev = useQuery({ queryKey: ["r", tenantId], queryFn: () => http(`/t/${tenantId}/reports/catering-revenue/`) });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold text-ops-900">Dashboard</h1>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
        <Card title="New inquiries" value={inq.data?.count ?? "—"} />
        <Card title="Quotes out" value={quotes.data?.count ?? "—"} />
        <Card title="Confirmed orders" value={orders.data?.count ?? "—"} />
        <Card title="30d revenue" value={rev.data?.total ? `$${Number(rev.data.total).toFixed(2)}` : "—"} />
      </div>
    </div>
  );
}
