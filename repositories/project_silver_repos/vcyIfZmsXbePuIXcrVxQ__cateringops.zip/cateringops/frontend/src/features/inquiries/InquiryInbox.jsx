import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { http } from "../../api/http";

const TABS = ["new", "reviewed", "needs_more_info", "quote_created", "converted", "declined"];

export function InquiryInbox() {
  const { tenantId } = useParams();
  const [tab, setTab] = useState("new");
  const { data, isLoading } = useQuery({
    queryKey: ["inq", tenantId, tab],
    queryFn: () => http(`/t/${tenantId}/inquiries/?status=${tab}`),
  });

  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold text-ops-900">Inquiries</h1>
      <div className="flex gap-2 border-b">
        {TABS.map((s) => (
          <button key={s} onClick={() => setTab(s)}
                  className={`px-3 py-2 text-sm ${tab === s ? "border-b-2 border-ops-700 text-ops-900" : "text-ops-600"}`}>
            {s.replace(/_/g, " ")}
          </button>
        ))}
      </div>
      {isLoading ? <p>Loading…</p> :
        <table className="w-full text-sm">
          <thead className="text-left text-ops-700">
            <tr><th>Event date</th><th>Guests</th><th>Type</th><th>Contact</th></tr>
          </thead>
          <tbody>
            {(data?.results ?? data ?? []).map((i) => (
              <tr key={i.id} className="border-t border-ops-100">
                <td><Link to={`/t/${tenantId}/inquiries/${i.id}`} className="underline text-ops-800">{i.event_date}</Link></td>
                <td>{i.guest_count}</td>
                <td>{i.event_type.replace(/_/g, " ")}</td>
                <td>{i.contact_name}</td>
              </tr>
            ))}
          </tbody>
        </table>}
    </div>
  );
}
