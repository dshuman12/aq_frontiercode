import { create } from "zustand";

export const useAuth = create((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  logout: () => {
    localStorage.removeItem("co:access");
    localStorage.removeItem("co:refresh");
    set({ user: null });
  },
}));
