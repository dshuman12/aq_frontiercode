import { create } from "zustand";

export const useTenant = create((set) => ({
  current: null,
  setCurrent: (t) => set({ current: t }),
}));
