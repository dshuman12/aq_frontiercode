import { http } from "./http";

export const fetchReport = (tid, name, params = "") => http(`/t/${tid}/reports/${name}/${params}`);
export const exportReportCsv = (tid, name) => {
  window.location.href = `/api/t/${tid}/reports/${name}/export.csv`;
};
