import { http } from "./http";

export const fetchQuotes = (tid, params = "") => http(`/t/${tid}/quotes/${params}`);
export const fetchQuote = (tid, id) => http(`/t/${tid}/quotes/${id}/`);
export const sendQuote = (tid, id) => http(`/t/${tid}/quotes/${id}/send/`, { method: "POST" });
export const fromInquiry = (tid, body) =>
  http(`/t/${tid}/quotes/from_inquiry/`, { method: "POST", body });
export const addItem = (tid, id, body) =>
  http(`/t/${tid}/quotes/${id}/add_item/`, { method: "POST", body });
export const addPackage = (tid, id, body) =>
  http(`/t/${tid}/quotes/${id}/add_package/`, { method: "POST", body });
