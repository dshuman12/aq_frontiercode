import { http } from "./http";

export const fetchOrders = (tid, p = "") => http(`/t/${tid}/orders/${p}`);
export const fetchOrder = (tid, id) => http(`/t/${tid}/orders/${id}/`);
export const fromQuote = (tid, qid) => http(`/t/${tid}/orders/from-quote/`, { method: "POST", body: { quote: qid } });
export const confirmOrder = (tid, id) => http(`/t/${tid}/orders/${id}/confirm/`, { method: "POST" });
export const startProduction = (tid, id) => http(`/t/${tid}/orders/${id}/start_production/`, { method: "POST" });
export const markReady = (tid, id) => http(`/t/${tid}/orders/${id}/mark_ready/`, { method: "POST" });
export const completeOrder = (tid, id) => http(`/t/${tid}/orders/${id}/complete/`, { method: "POST" });
export const cancelOrder = (tid, id, reason) => http(`/t/${tid}/orders/${id}/cancel/`, { method: "POST", body: { reason } });
