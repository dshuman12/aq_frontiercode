import { http } from "./http";

export const fetchInquiries = (tid, params = "") => http(`/t/${tid}/inquiries/${params}`);
export const fetchInquiry = (tid, id) => http(`/t/${tid}/inquiries/${id}/`);
export const transitionInquiry = (tid, id, to, note = "") =>
  http(`/t/${tid}/inquiries/${id}/status/`, { method: "POST", body: { to, note } });
export const assignInquiry = (tid, id, assignee) =>
  http(`/t/${tid}/inquiries/${id}/assign/`, { method: "POST", body: { assignee } });
