import { http } from "./http";

export const fetchCustomers = (tid, q = "") =>
  http(`/t/${tid}/customers/${q ? `?q=${encodeURIComponent(q)}` : ""}`);
export const fetchCustomer = (tid, id) => http(`/t/${tid}/customers/${id}/`);
export const createCustomer = (tid, body) =>
  http(`/t/${tid}/customers/`, { method: "POST", body });
