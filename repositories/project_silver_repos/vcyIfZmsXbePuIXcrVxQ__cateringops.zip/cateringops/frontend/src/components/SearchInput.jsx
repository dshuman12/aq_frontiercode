import { useEffect, useState } from "react";
import { useDebounce } from "../lib/useDebounce";

export function SearchInput({ placeholder = "Search…", onChange, defaultValue = "" }) {
  const [text, setText] = useState(defaultValue);
  const debounced = useDebounce(text, 250);
  useEffect(() => { onChange?.(debounced); }, [debounced, onChange]);
  return (
    <input type="search" value={text} onChange={(e) => setText(e.target.value)}
           placeholder={placeholder}
           className="w-64 rounded border border-ops-200 px-3 py-1.5 text-sm" />
  );
}
