import { useEffect } from "react";

export function ConfirmDialog({ open, title, message, confirmLabel = "Confirm", onConfirm, onClose }) {
  useEffect(() => {
    if (!open) return;
    const h = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-lg">
        <h3 className="text-lg font-semibold text-ops-900">{title}</h3>
        <p className="mt-2 text-ops-700">{message}</p>
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded border px-3 py-1.5 text-sm">Cancel</button>
          <button onClick={() => { onConfirm(); onClose(); }}
                  className="rounded bg-ops-700 px-3 py-1.5 text-sm text-white">{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}
