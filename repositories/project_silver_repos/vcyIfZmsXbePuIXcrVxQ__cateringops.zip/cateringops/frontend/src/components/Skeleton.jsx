export function Skeleton({ rows = 3, columns = 4 }) {
  return (
    <table className="w-full text-sm">
      <tbody>
        {Array.from({ length: rows }).map((_, r) => (
          <tr key={r} className="border-t">
            {Array.from({ length: columns }).map((_, c) => (
              <td key={c} className="py-2">
                <div className="h-3 w-3/4 animate-pulse rounded bg-ops-100" />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
