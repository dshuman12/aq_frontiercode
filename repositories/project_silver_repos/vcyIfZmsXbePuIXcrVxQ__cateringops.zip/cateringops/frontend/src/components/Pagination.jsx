export function Pagination({ page, totalPages, onPage }) {
  if (totalPages <= 1) return null;
  return (
    <nav className="mt-3 flex items-center justify-between text-sm">
      <button disabled={page <= 1} onClick={() => onPage(page - 1)}
              className="rounded border px-3 py-1 disabled:opacity-40">Previous</button>
      <span className="text-ops-700">Page {page} of {totalPages}</span>
      <button disabled={page >= totalPages} onClick={() => onPage(page + 1)}
              className="rounded border px-3 py-1 disabled:opacity-40">Next</button>
    </nav>
  );
}
