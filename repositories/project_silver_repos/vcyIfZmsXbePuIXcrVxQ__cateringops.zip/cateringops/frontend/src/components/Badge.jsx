const V = {
  default: "bg-ops-100 text-ops-800",
  info: "bg-blue-100 text-blue-800",
  warn: "bg-amber-100 text-amber-800",
  danger: "bg-red-100 text-red-800",
  ok: "bg-emerald-100 text-emerald-800",
};

export function Badge({ variant = "default", children }) {
  return <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${V[variant] || V.default}`}>{children}</span>;
}
