export function EmptyState({ title, message, actionLabel, actionHref }) {
  return (
    <div className="rounded-xl border border-dashed border-ops-200 bg-white p-8 text-center">
      <h3 className="text-lg font-semibold text-ops-900">{title}</h3>
      <p className="mt-2 text-ops-700">{message}</p>
      {actionHref && (
        <a href={actionHref} className="mt-4 inline-block rounded bg-ops-700 px-4 py-1.5 text-sm text-white">
          {actionLabel}
        </a>
      )}
    </div>
  );
}
