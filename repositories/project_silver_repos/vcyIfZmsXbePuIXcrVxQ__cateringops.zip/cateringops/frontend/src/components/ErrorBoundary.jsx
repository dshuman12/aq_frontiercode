import { Component } from "react";

export class ErrorBoundary extends Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(error) { return { error }; }
  componentDidCatch(error, info) { console.error("CateringOps UI error:", error, info); }
  render() {
    if (this.state.error) {
      return (
        <div className="rounded border border-red-300 bg-red-50 p-4 text-sm text-red-800">
          <p className="font-medium">Something broke in this view.</p>
          <p className="mt-1">{String(this.state.error.message || this.state.error)}</p>
          <button onClick={() => this.setState({ error: null })}
                  className="mt-2 rounded bg-red-700 px-3 py-1 text-white">Retry</button>
        </div>
      );
    }
    return this.props.children;
  }
}
