export function PageHeader({ title, subtitle, actions }) {
  return (
    <header className="mb-4 flex items-center justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold text-ops-900">{title}</h1>
        {subtitle && <p className="text-ops-700">{subtitle}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </header>
  );
}
