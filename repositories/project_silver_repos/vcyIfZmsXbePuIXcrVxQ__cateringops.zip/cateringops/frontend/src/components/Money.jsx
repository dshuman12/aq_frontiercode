export function Money({ value, currency = "USD" }) {
  return <span>{new Intl.NumberFormat(undefined, { style: "currency", currency }).format(Number(value || 0))}</span>;
}
