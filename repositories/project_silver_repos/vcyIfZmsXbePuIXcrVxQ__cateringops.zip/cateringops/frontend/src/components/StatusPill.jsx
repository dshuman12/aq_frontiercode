const COLORS = {
  new: "bg-ops-100 text-ops-900",
  reviewed: "bg-blue-100 text-blue-800",
  needs_more_info: "bg-amber-100 text-amber-800",
  quote_created: "bg-purple-100 text-purple-800",
  converted: "bg-emerald-100 text-emerald-800",
  declined: "bg-red-100 text-red-800",
  draft: "bg-zinc-100 text-zinc-800",
  sent: "bg-blue-100 text-blue-800",
  viewed: "bg-indigo-100 text-indigo-800",
  approved: "bg-emerald-100 text-emerald-800",
  rejected: "bg-red-100 text-red-800",
  expired: "bg-amber-100 text-amber-800",
  pending_deposit: "bg-amber-100 text-amber-800",
  confirmed: "bg-blue-100 text-blue-800",
  in_production: "bg-orange-100 text-orange-800",
  ready_for_pickup: "bg-emerald-100 text-emerald-800",
  out_for_delivery: "bg-orange-100 text-orange-800",
  completed: "bg-emerald-100 text-emerald-800",
  delivered: "bg-emerald-100 text-emerald-800",
  failed: "bg-red-100 text-red-800",
};

export function StatusPill({ status }) {
  const cls = COLORS[status] || "bg-zinc-100 text-zinc-800";
  return <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}>{status?.replace(/_/g, " ")}</span>;
}
