import { useEffect } from "react";

export function Drawer({ open, onClose, title, children }) {
  useEffect(() => {
    if (!open) return;
    const h = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex">
      <button aria-label="Close" className="flex-1 bg-black/30" onClick={onClose} />
      <aside className="w-full max-w-md overflow-y-auto bg-white p-4 shadow-xl">
        <header className="mb-3 flex items-center justify-between">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="text-ops-700">x</button>
        </header>
        {children}
      </aside>
    </div>
  );
}
