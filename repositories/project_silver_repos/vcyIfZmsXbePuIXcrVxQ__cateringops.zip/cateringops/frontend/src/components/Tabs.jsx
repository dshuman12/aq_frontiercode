export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="mb-4 flex gap-1 border-b">
      {tabs.map((t) => (
        <button key={t.value} onClick={() => onChange(t.value)}
                className={`px-3 py-2 text-sm ${value === t.value ? "border-b-2 border-ops-700 text-ops-900" : "text-ops-600 hover:text-ops-800"}`}>
          {t.label}
        </button>
      ))}
    </div>
  );
}
