.PHONY: shell test smoke

shell:
	cd backend && ./manage.py shell

test:
	cd backend && pytest

smoke:
	curl -fsS http://localhost:8000/health/live/
	curl -fsS http://localhost:8000/health/ready/
