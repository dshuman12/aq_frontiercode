import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

import "./styles.css";
import { InquiryForm } from "./features/InquiryForm";
import { QuoteApproval } from "./features/QuoteApproval";
import { OrderTracker } from "./features/OrderTracker";

const client = new QueryClient();
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <QueryClientProvider client={client}>
      <BrowserRouter>
        <Routes>
          <Route path="/inquire/:tenantSlug" element={<InquiryForm />} />
          <Route path="/q/:token" element={<QuoteApproval />} />
          <Route path="/o/:token" element={<OrderTracker />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
);
