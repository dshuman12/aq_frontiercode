import { useState } from "react";
import { useForm } from "react-hook-form";
import { useParams } from "react-router-dom";

export function InquiryForm() {
  const { tenantSlug } = useParams();
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [done, setDone] = useState(false);

  async function onSubmit(values) {
    const r = await fetch(`/api/t/${tenantSlug}/inquiries/submit/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    if (r.ok) setDone(true);
  }

  if (done) {
    return (
      <div className="mx-auto max-w-md p-8 text-center">
        <h2 className="text-2xl font-semibold">Thanks!</h2>
        <p className="mt-2 text-gray-700">We'll respond within one business day.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mx-auto max-w-md space-y-4 p-8">
      <h1 className="text-2xl font-semibold">Catering inquiry</h1>
      <Field label="Event date" error={errors.event_date?.message}>
        <input type="date" {...register("event_date", { required: "required" })} className="w-full rounded border p-2" />
      </Field>
      <Field label="Event time" error={errors.event_time?.message}>
        <input type="time" {...register("event_time", { required: "required" })} className="w-full rounded border p-2" />
      </Field>
      <Field label="Guest count" error={errors.guest_count?.message}>
        <input type="number" min="1" {...register("guest_count", { required: "required", valueAsNumber: true })} className="w-full rounded border p-2" />
      </Field>
      <Field label="Event type">
        <select {...register("event_type", { required: true })} className="w-full rounded border p-2">
          <option value="corporate_lunch">Corporate lunch</option>
          <option value="wedding">Wedding</option>
          <option value="party">Party</option>
          <option value="school">School</option>
          <option value="other">Other</option>
        </select>
      </Field>
      <Field label="Your name">
        <input {...register("contact_name", { required: true })} className="w-full rounded border p-2" />
      </Field>
      <Field label="Email">
        <input type="email" {...register("contact_email", { required: true })} className="w-full rounded border p-2" />
      </Field>
      <Field label="Phone">
        <input {...register("contact_phone")} className="w-full rounded border p-2" />
      </Field>
      <Field label="Company">
        <input {...register("company_name")} className="w-full rounded border p-2" />
      </Field>
      <Field label="Dietary notes">
        <textarea {...register("dietary_notes")} rows={3} className="w-full rounded border p-2" />
      </Field>
      <button className="w-full rounded bg-sky-700 px-4 py-2 text-white">Submit</button>
    </form>
  );
}

function Field({ label, error, children }) {
  return (
    <label className="block">
      <span className="block text-sm font-medium">{label}</span>
      {children}
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </label>
  );
}
