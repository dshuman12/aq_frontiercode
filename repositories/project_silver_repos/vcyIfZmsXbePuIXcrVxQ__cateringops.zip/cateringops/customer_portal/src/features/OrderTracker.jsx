import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const STAGES = ["pending_deposit", "confirmed", "in_production",
                "ready_for_pickup", "out_for_delivery", "completed"];

export function OrderTracker() {
  const { token } = useParams();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    function poll() {
      fetch(`/api/orders/public/${token}/`).then(r => r.json()).then(setOrder);
    }
    poll();
    const id = setInterval(poll, 30000);
    return () => clearInterval(id);
  }, [token]);

  if (!order) return <p className="p-8">Loading…</p>;
  const idx = STAGES.indexOf(order.status);
  return (
    <div className="mx-auto max-w-2xl p-8">
      <h1 className="text-3xl font-semibold">{order.tenant_name}</h1>
      <p className="text-sm text-gray-600">Order {order.order_number}</p>
      <h2 className="mt-4 text-xl">{order.event_date} · {order.guest_count} guests</h2>
      <p className="mt-2">Status: <strong>{order.status.replace(/_/g, " ")}</strong></p>
      <div className="mt-6 flex gap-2">
        {STAGES.map((s, i) => (
          <div key={s} className={`flex-1 rounded-full p-2 text-center text-xs ${i <= idx ? "bg-sky-700 text-white" : "bg-gray-200"}`}>
            {s.replace(/_/g, " ")}
          </div>
        ))}
      </div>
      <p className="mt-6">Remaining: ${Number(order.remaining_balance).toFixed(2)}</p>
    </div>
  );
}
