import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export function QuoteApproval() {
  const { token } = useParams();
  const [quote, setQuote] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch(`/api/quotes/public/${token}/`).then(r => r.json()).then(setQuote);
  }, [token]);

  if (!quote) return <p className="p-8">Loading…</p>;

  async function act(action, body = {}) {
    setBusy(true);
    const r = await fetch(`/api/quotes/public/${token}/${action}/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    setQuote(await r.json());
    setBusy(false);
  }

  return (
    <div className="mx-auto max-w-2xl p-8"
         style={{ borderTop: `4px solid ${quote.tenant_brand_color}` }}>
      <h1 className="text-3xl font-semibold">{quote.tenant_name}</h1>
      <p className="text-sm text-gray-600">Quote {quote.quote_number}</p>
      <h2 className="mt-4 text-xl">{quote.event_date} — {quote.guest_count} guests</h2>
      <table className="mt-6 w-full text-sm">
        <thead><tr><th className="text-left">Item</th><th className="text-right">Qty</th><th className="text-right">Total</th></tr></thead>
        <tbody>
          {quote.lines.map((l) => (
            <tr key={l.id} className="border-t">
              <td>{l.label}</td><td className="text-right">{l.quantity}</td>
              <td className="text-right">${Number(l.line_total).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-4 text-right text-xl"><strong>Total: ${Number(quote.total).toFixed(2)}</strong></p>
      <p className="text-right text-sm text-gray-600">
        Deposit: ${Number(quote.deposit_required_amount).toFixed(2)}
      </p>
      {(quote.status === "sent" || quote.status === "viewed") ? (
        <div className="mt-6 flex gap-3">
          <button onClick={() => act("approve")} disabled={busy}
                  className="rounded bg-sky-700 px-6 py-2 text-white">Approve</button>
          <button onClick={() => {
            const reason = window.prompt("Reason?") || "";
            act("reject", { reason });
          }} disabled={busy} className="rounded border px-6 py-2">Reject</button>
        </div>
      ) : <p className="mt-6 text-lg">Status: <strong>{quote.status}</strong></p>}
    </div>
  );
}
