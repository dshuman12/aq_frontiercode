import { useEffect, useState } from "react";

export function Board() {
  const [routes, setRoutes] = useState([]);
  useEffect(() => {
    const token = localStorage.getItem("co:access") || "";
    fetch("/api/t/me/delivery/today/", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.json()).then((d) => setRoutes(d.routes || []));
  }, []);
  return (
    <div style={{ padding: 16, fontFamily: "system-ui" }}>
      <h1>Today's deliveries</h1>
      <ul>{routes.map((r) => <li key={r.id}>{r.window} → {r.address} ({r.status})</li>)}</ul>
    </div>
  );
}
