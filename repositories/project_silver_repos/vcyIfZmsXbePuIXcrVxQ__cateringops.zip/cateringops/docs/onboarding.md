# Onboarding

```bash
git clone <repo> cateringops && cd cateringops
docker compose -f docker/compose.dev.yml up -d
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements/dev.txt
./manage.py migrate
./manage.py seed_demo
./manage.py runserver
```

Other shells:
- `cd backend && celery -A config worker -l info`
- `cd frontend && npm install && npm run dev`
- `cd customer_portal && npm install && npm run dev`

Visit http://localhost:5173, sign in as `chef@aurora-catering.test` /
`demo-pass-123`.

## Concepts

- **Tenant is the restaurant.** Every URL: `/api/t/<tenant_id>/...`.
- **Service layer.** Logic in `apps.<module>.services`. Views thin.
- **Soft delete.** `archived_at`; filter `archived_at__isnull=True`.
- **Money:** `Decimal(12, 2)`. UUID PKs throughout.

## Frontends

| Dir | Port | Purpose |
|---|---|---|
| `frontend/` | 5173 | Staff app |
| `customer_portal/` | 5174 | Public inquiry/quote/order |
| `kitchen_board/` | 5175 | Live kitchen display |
| `delivery_board/` | 5176 | Driver routes |

## Conventions

- `pre-commit install` once.
- Service test min: 1 happy + 1 failure path.
- Commit prefix: `inquiries:`, `quotes:`, `orders:`, etc.
