# Changelog

## v0.1 — 2025-10

Initial release. M1-M17 complete:
- Inquiries → quotes → orders → production → kitchen → delivery → invoices.
- Customer portal (inquiry form, quote approval, order tracker).
- Kitchen board (WebSocket).
- Delivery board.
- 9 reports + CSV export.
- 22 Django apps, 4 frontends.
- 9 ADRs covering tenant scoping, money precision, Channels, no ORM magic,
  UUID PKs, soft delete, REST-not-GraphQL, quote tokens, Stripe webhooks.
