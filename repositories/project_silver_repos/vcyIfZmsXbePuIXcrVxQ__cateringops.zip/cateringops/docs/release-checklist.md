# Release checklist

Cut every two weeks.

## Pre-flight

- [ ] Migration plan reviewed; two-deploy for drops.
- [ ] Feature flags reviewed.
- [ ] Smoke test on staging.
- [ ] Changelog drafted.

## Day-of

- [ ] Cut release branch.
- [ ] CI green.
- [ ] Migrations applied in staging.
- [ ] Tag and promote staging → prod.

## Post-flight

- [ ] Dashboard check.
- [ ] Pager check.
- [ ] Flags reviewed at full rollout.
