# Observability

## Logs

Structured via structlog. `LogContextMiddleware` binds `trace_id`,
`method`, `path`, `user_id`, `tenant_id` to every log line within a request.

## Metrics

Prometheus on `/internal/metrics`. Default set:
- `cateringops_quotes_sent_total{tenant}`
- `cateringops_orders_created_total{tenant}`
- `cateringops_deposits_collected_dollars{tenant}`
- `cateringops_celery_task_duration_seconds{task}`

## Dashboards

- **Pipeline:** inquiries → quotes → orders, conversion %.
- **Kitchen:** batch durations, delays.
- **Money:** deposits, outstanding invoices, refunds.
- **Reliability:** Celery queue depth, WS connect rate, 5xx by URL.

## When to add a metric

If you're about to write a Slack alert, you probably want a metric.
