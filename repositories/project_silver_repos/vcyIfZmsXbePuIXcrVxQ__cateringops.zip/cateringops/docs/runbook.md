# Runbook

## On-call pages

- 5xx > 1% for 5min
- Celery depth > 1000 sustained
- Postgres replication lag > 30s
- Daphne unreachable
- Stripe webhook failures > 10% over 5min

## First 5 minutes

1. Ack.
2. Check `#cateringops-incidents`.
3. Operations dashboard — what changed in last hour?
4. `kubectl get pods -n cateringops` — crash-looping?
5. Post status: "Investigating <thing>".

## Common issues

### Stuck Celery worker
`kubectl rollout restart deploy/celery-worker -n cateringops`

### Kitchen board silent
Check Redis client count, restart Daphne.

### Stripe signature mismatch
Verify `STRIPE_WEBHOOK_SECRET` matches Stripe dashboard.

## Escalation

After 30min unresolved, page secondary. Catering managers depend on this for
their day; don't let it linger.
