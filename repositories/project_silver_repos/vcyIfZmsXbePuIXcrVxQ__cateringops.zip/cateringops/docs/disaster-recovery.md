# Disaster recovery

## Backups

- Postgres: WAL-G to S3, full daily + WAL streaming. Monthly restore drill.
- S3: versioned, replicated.
- Redis: NOT backed up; treat as ephemeral.

## RTO / RPO

- RPO: 15 minutes.
- RTO: 1 hour.

## Failover playbook

1. Trigger Postgres failover.
2. Update `DATABASE_URL` secret.
3. Restart Celery workers.
4. Smoke test: `make smoke`.
5. Announce in `#cateringops-incidents`.
