# ADR 0001: Tenant id is required in every URL

**Status:** Accepted
**Date:** 2025-01-30
**Author:** misbah

## Decision

Every tenant-scoped API URL begins with `/api/t/<tenant_id>/...`. Routing
parses the tenant id, views verify membership, selectors filter by
`tenant=...`.

## Why

Defense in depth. If a selector ever forgets `.filter(tenant=)`, the view-
layer membership check still 404s. Reviewers see "is this scoped?" in the
URL alone.

## Trade-offs

Slightly more verbose URLs. Acceptable.
