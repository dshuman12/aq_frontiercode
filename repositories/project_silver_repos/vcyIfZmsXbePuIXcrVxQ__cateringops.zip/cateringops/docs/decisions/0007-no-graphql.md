# ADR 0007: REST/DRF, not GraphQL

**Status:** Accepted
**Date:** 2025-04-15

## Decision

We use DRF for the API. Not GraphQL.

## Why

- Audit story is simpler: every action is a verb + URL we log to AuditEntry.
- Caching is easier: edge-cache `/menu/items/` without a GraphQL cache layer.
- Multi-tenant scoping is in the URL — reviewers see scoping at a glance.

## Trade-offs

- Mobile clients sometimes over-fetch; we mitigate with thin `*_list`
  serializers.
- N+1 risk handled by explicit `select_related` / `prefetch_related`.
