# ADR 0003: Django Channels for realtime, not SSE or polling

**Status:** Accepted
**Date:** 2025-02-03

## Decision

Kitchen board and per-user notification stream use Channels with a Redis
layer.

## Why

- Bidirectional (chef updates batch → server broadcasts to other devices).
- We already run Redis for Celery; no new infrastructure.
- SSE has proxy-buffering quirks; polling burns DB.
