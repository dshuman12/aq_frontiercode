# ADR 0009: Stripe webhooks are the source of truth

**Status:** Accepted
**Date:** 2025-09-29

## Decision

Synchronous Stripe API calls record optimistic state ("intent created"). The
webhook handler is the **final** authority on "paid" / "refunded", and is
idempotent.

## Why

Stripe explicitly recommends webhook-first state. Sync responses can be
lost (timeout, browser close). Webhooks survive.
