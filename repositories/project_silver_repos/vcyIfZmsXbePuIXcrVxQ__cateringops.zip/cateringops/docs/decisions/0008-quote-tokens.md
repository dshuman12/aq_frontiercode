# ADR 0008: Quote approval is via signed token in URL

**Status:** Accepted
**Date:** 2025-09-28

## Decision

Quotes carry an `approval_token` (URL-safe 80-byte random). Customers approve
via `/quote/<token>` — no account, no login.

## Why

The person approving the quote (assistant, planner) is usually NOT the
customer-of-record. Forcing signup is a documented conversion-killer.

## Mitigations

- 14-day default expiration.
- Once approved or rejected, terminal: no further state changes.
- IP + UA recorded on every approval event.
