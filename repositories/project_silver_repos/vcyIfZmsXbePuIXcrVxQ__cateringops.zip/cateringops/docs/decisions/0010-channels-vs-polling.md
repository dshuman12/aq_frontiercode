# ADR 0010: Polling is banned for kitchen/delivery, use WebSockets

**Status:** Accepted
**Date:** 2025-10-18

## Decision

The kitchen board and notification stream MUST use WebSockets (Channels).
We never poll status APIs for live-update UX.

## Why

A busy catering kitchen has 6-10 tablets on the board. Polling every 5s =
~70 req/min/tablet → 700 req/min for nothing during slow periods. WS is
push-based; idle = silent.

## Exception

The customer-facing order tracker polls every 30s. It's not a kitchen-grade
real-time use case; customer sees status changes within 30s, which is fine.
