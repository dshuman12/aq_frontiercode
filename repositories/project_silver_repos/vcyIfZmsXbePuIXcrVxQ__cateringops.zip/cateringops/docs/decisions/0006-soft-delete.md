# ADR 0006: Soft-delete by default; hard-delete only for true drafts

**Status:** Accepted
**Date:** 2025-04-12

## Decision

- Soft delete (`archived_at`) for everything with historical/audit value:
  Customer, Quote, Order, Invoice, Payment, MenuItem, Package.
- Hard delete only for: draft quote revisions, expired sessions, draft
  inquiries never sent anywhere.

## Why

Soft delete preserves the audit trail. A customer dispute about an invoice
8 months later finds the invoice even after "deletion". True drafts have no
historical value and pollute the index.

## Apply

New model? Ask "does any historical record reference this?" Yes → soft.
No → hard is OK.
