# ADR 0011: Quote→Order conversion copies lines

**Status:** Accepted
**Date:** 2025-10-19

## Decision

Quote line items are **copied** into OrderItem rows at conversion time.
Order lines are independent from quote lines. The Quote FK is preserved
for audit but never used at runtime by order code.

## Why

- Customers sometimes add an item late after approval; quote should NOT
  drift silently.
- Production planning reads OrderItem; a live reference forces freeze-
  mid-edit which is gross.
- Quote snapshots already preserve pricing history.

## Trade-offs

- Mild duplication. Acceptable.
