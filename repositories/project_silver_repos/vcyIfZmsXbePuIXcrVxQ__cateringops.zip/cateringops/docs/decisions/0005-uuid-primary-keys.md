# ADR 0005: UUIDv4 primary keys everywhere

**Status:** Accepted
**Date:** 2025-04-10

## Decision

Every business model uses `UUIDField(primary_key=True, default=uuid.uuid4)`.
We never expose sequential integer IDs.

## Why

- Predictable URLs reveal business volume; UUIDs don't.
- Cross-tenant id collisions impossible.
- Imports/exports between tenants don't risk collisions.

## Trade-offs

- 16 bytes vs 4 for the PK. Postgres handles it.
