# ADR 0012: Status history rows, not event sourcing

**Status:** Accepted
**Date:** 2025-10-22

## Decision

Each stateful resource has both:
- A `status` field on the row (current state).
- A `*StatusHistory` table with one row per transition.

We do NOT do event sourcing.

## Why

Event sourcing is theoretically pure, practically annoying:
- Reads require replays; expensive for "what's now" queries (kitchen board).
- Replaying past events through migrations is painful.
- Auditors want "the row" + "who changed it when."

Status field + history table gives both: cheap current state, durable trail.
