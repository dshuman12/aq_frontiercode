# ADR 0002: Money is `Decimal(12, 2)`, never float

**Status:** Accepted
**Date:** 2025-01-31

## Decision

Money fields: `DecimalField(max_digits=12, decimal_places=2)`. Rate fields:
`DecimalField(6, 4)`. Construct from string: `Decimal("12.50")` not
`Decimal(12.50)`.

## Why

Float-money is radioactive. Previous projects have shipped invoice totals
that were off by 1 cent because of `0.1 + 0.2`. Decimal removes the class
of bug entirely.
