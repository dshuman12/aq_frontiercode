# ADR 0014: Celery Beat schedule in code, not DB

**Status:** Accepted
**Date:** 2025-10-30

## Decision

`CELERY_BEAT_SCHEDULE` lives in `config/celery.py`. We don't use
`django-celery-beat`'s DB scheduler.

## Why

- Beat config is part of a release. Changing schedule = a PR + a deploy.
- DB-backed beat introduces a lock-coordination table that has caused
  outages in prior projects.

## What's scheduled

- `expire_stale_quotes` daily 02:00.
- `send_deposit_reminders` daily 09:00.
- `send_production_reminders` daily 06:30.
- `daily_digest` daily 17:00.
- `cleanup_notifications` daily 03:30.
