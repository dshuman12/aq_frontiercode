# ADR 0013: API versioning is via URL prefix `/api/v1/`

**Status:** Accepted (forward-looking; not yet implemented)
**Date:** 2025-10-30

## Decision

When we add public-facing API consumers (mobile app, integrations), we'll
version via URL prefix: `/api/v1/...`. Current internal endpoints will be
versioned to `/api/v1/` and we'll continue to break-change only on `v2`.

## Why

URL versioning is the simplest, most visible scheme. We considered:
- Header versioning (`Accept: application/vnd.cateringops+json; version=1`):
  hard to test, hidden in tooling.
- Date-based (`/api/2025-10/...`): clever but our customers won't track dates.

## When

Not yet. Internal-only consumers don't need it. The day we publish
documentation for a third-party developer, we cut v1.
