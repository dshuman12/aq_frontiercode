# ADR 0004: No clever ORM magic. Selectors + services explicit.

**Status:** Accepted
**Date:** 2025-02-05

## Decision

- No model Manager subclasses for cross-row queries (use `selectors.py`).
- No `save()` overrides that mutate other rows (use services or signals).
- No DRF `validate_*` methods that mutate DB (those are services).

## Why

ORM magic is convenient until it bites. The two worst regressions I've
shipped came from `save()` overrides that derived totals incorrectly in
some edge case. Explicit code reviews better.
