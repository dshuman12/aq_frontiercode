# Security overview

## Surface

- JWT auth: 1h access + 7d refresh, rotated on refresh, blacklisted on logout.
- Stripe handles all card data; we never touch a PAN.
- Webhooks verified by signature.
- Quote approval tokens are 80-byte URL-safe random.
- Admin actions audited via `apps.audit`.

## Tenant isolation

Every endpoint scopes by URL kwarg `tenant_id`. Every selector filters by
`tenant=...`. Cross-tenant 404 tests in `apps.core.tests`.

## Vulnerability handling

Acknowledge within 24h. Triage:
- P0 (DB access) → fix today
- P1 (cross-tenant) → fix this week
- P2 (DoS, info disclosure) → fix this sprint

Notify affected tenants if data crossed boundaries.
