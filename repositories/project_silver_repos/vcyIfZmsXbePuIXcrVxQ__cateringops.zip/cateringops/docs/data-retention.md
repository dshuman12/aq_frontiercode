# Data retention

| Object | Hot | Cold | Purge |
|---|---|---|---|
| AuditEntry | 3y | 7y | never |
| Quote, Order | 3y | 7y | 10y |
| Invoice, Payment | 7y | 10y | never |
| Inquiry (declined) | 6mo | — | 1y |
| Notification (read) | 90d | — | 1y |
| Email log | 90d | — | 1y |

Invoice/payment never purge: tax authorities ask for 7+-year records.
