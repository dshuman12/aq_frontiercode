# Database overview

## Conventions

- UUIDv4 primary keys throughout. We never expose sequential integers.
- Soft delete via `archived_at` on every business model.
- Money: `Decimal(12, 2)`. Rates: `Decimal(6, 4)`. Guest count: integer.
- Timezone-aware (`USE_TZ = True`).

## Major models

- `User`, `Tenant`, `Location`, `TenantMembership`, `Invitation`.
- `Customer`, `CustomerContact`, `CustomerAddress`, `CustomerNote`.
- `MenuCategory`, `MenuItem`, `Package`, `PackageItem`, `PackageUpgrade`.
- `Inquiry` → `Quote` → `Order` (with status histories).
- `ProductionPlan` → `ProductionBatch` → `KitchenEvent`.
- `Delivery` → `DeliveryAssignment` → `DeliveryProof`.
- `Deposit`, `Invoice`, `InvoiceLine`, `Payment`, `Refund`, `Receipt`.
- `Document` (S3-backed), `Notification`, `AuditEntry`.

## Indexes

- `(tenant_id, status, event_date)` on `Order`.
- GIN on `tags` arrays.
