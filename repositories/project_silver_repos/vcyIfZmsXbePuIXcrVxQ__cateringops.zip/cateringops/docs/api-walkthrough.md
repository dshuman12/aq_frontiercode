# API walkthrough — full catering job

## 1. Customer submits

Public:
```
POST /api/t/<tid>/inquiries/submit/
{ "event_date":"2025-11-15", "event_time":"12:00", "guest_count":40,
  "event_type":"corporate_lunch", "delivery_address":"100 SF",
  "contact_name":"Maria", "contact_email":"m@acme.test" }
→ 201
```

## 2. Manager builds quote

```
POST /api/t/<tid>/inquiries/<id>/status/   { "to":"reviewed" }
POST /api/t/<tid>/quotes/from_inquiry/     { "inquiry":"...", "location":"..." }
POST /api/t/<tid>/quotes/<qid>/add_package/{ "package":"..." }
POST /api/t/<tid>/quotes/<qid>/fees/       { "tax_rate_pct":"0.0825", "delivery_fee":"45.00" }
POST /api/t/<tid>/quotes/<qid>/send/       { "expires_in_days":14 }
```

## 3. Customer approves (public)

```
GET  /api/t/<tid>/quotes/public/<token>/         → records "viewed"
POST /api/t/<tid>/quotes/public/<token>/approve/
```

## 4. Convert + deposit

```
POST /api/t/<tid>/orders/from-quote/   { "quote":"<qid>" }
POST /api/t/<tid>/billing/deposits/<did>/mark_paid/  { "amount":"237.50" }
   → triggers order.confirm + production-plan generation
```

## 5. Kitchen / Delivery

Production plan auto-generates. Chef updates batches via Channels-backed
kitchen board. Manager assigns driver, driver uploads proof.

## 6. Invoice + balance

```
POST /api/t/<tid>/billing/invoices/from-order/ { "order":"..." }
POST /api/t/<tid>/billing/invoices/<inv>/send/
POST /api/t/<tid>/payments/  { "order":"...", "invoice":"<inv>",
                              "amount":"712.50", "method":"stripe", "kind":"balance" }
```
