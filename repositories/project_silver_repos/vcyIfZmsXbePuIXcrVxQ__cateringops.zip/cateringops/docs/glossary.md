# Glossary

**Inquiry.** Customer's first request for catering. Has event date, guest count.

**Quote.** Priced offer. Sent, viewed, approved/rejected via signed token URL.

**Order.** Confirmed job. Lifecycle: pending_deposit → confirmed → in_production
→ ready/out_for_delivery → completed.

**Package.** Bundle of menu items, priced per person.

**Production plan.** Kitchen prep plan auto-generated on order confirm.

**Batch.** Kitchen production unit. Status: not_started → prep_started → cooking
→ packing → ready → completed.

**Delivery.** Schedule for delivery orders. Has window, driver, proof.

**Deposit.** Required up-front. Stripe webhooks are the source of truth.

**Invoice.** From completed order. Records deposit applied and balance.
