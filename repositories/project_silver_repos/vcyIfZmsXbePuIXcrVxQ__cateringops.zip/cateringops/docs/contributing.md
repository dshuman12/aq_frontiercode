# Contributing

1. Branch off `main`.
2. `pre-commit install` once.
3. Tests required for service changes (1 happy + 1 failure).
4. Open PR; CI must pass.

## Style

- Backend: black, ruff, isort.
- Frontend: ESLint + Prettier.
- Commits: scope-prefix + one-line:
  - `quotes: round half-up`
  - `delivery: skip pickup orders`

## ADRs

Significant decision? Add to `docs/decisions/`. Short, 1 page max.
