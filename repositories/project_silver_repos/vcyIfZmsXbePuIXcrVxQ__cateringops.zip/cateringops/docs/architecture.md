# CateringOps architecture

```
        ┌─ staff app (5173) ─┐
        │  customer portal   │
ops ───→│  kitchen board     │──→ Django ASGI ──→ Postgres 15
        │  delivery board    │      │      │
        └────────────────────┘      │      └→ Channels (Redis)
                                    └→ Celery worker ──→ Redis broker
                                          │
                                          └→ Stripe API
```

## Service-layer pattern

Business logic lives in `apps.<module>.services`. Views and serializers
stay thin. Read queries live in `selectors.py`.

## Tenant model

A `Tenant` is the unit of isolation. Every business model has a `tenant`
FK. Every URL is scoped: `/api/t/<tenant_id>/...`.

## Workflow apps

`inquiries` (M6) → `quotes` (M7) → `orders` (M8) → `production` (M10) →
`kitchen` (M11) → `delivery` (M12) → `billing` (M9) → `payments` (M9).
