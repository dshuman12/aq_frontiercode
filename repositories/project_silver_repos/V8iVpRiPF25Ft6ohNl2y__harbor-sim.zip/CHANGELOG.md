# Changelog

Notable changes between releases. The version numbers are aspirational
- harbor-sim has no PyPI presence, but I tag the tree when the API or
the trace format moves.

## 0.3.1 - 2026-04-28

Bug fixes that piled up since 0.3.0. Nothing breaks compatibility but
two of the fixes change observable behavior under partition.

- `invariants/linearizability.py`: fixed a witness-record bug where
  read-set candidates were being deduplicated using object identity
  instead of value equality. Showed up as false-negatives on the
  `mixed-rw-partition` scenario.
- `runtime/mailbox.py`: dropped a leftover debug log line that was
  blowing up the trace size on long runs.
- `cli/inspect.py`: `--filter type=apply` now matches on the
  protocol-specific event type, not the transport type.

## 0.3.0 - 2026-03-14

Trace format v2. v1 traces are still readable (via the migrate helper)
but no longer written.

- Added the trace envelope: every frame now carries a small header with
  the frame type, length, and a CRC. The previous format relied on
  newline-delimited JSON which made partial reads hard to recover from.
- Reworked `harbor_sim/trace/recorder.py` to write frames through a
  small batched buffer. Per-event allocation cost dropped from ~3us to
  ~0.7us on the bench machine.
- New CLI: `harbor-sim trace migrate <input> <output>`.
- New CLI: `harbor-sim diff <a> <b>` for comparing two traces with
  event-level granularity.

Breaking-ish: invariant witness records now use the new envelope. If
you were parsing trace files by hand, you'll need to update.

## 0.2.4 - 2026-02-22

- Quorum-KV: write quorum lookup was using the configured replica
  count instead of the live replica count, which made reads spuriously
  reject during clean restarts. Fixed in `protocols/quorum_kv/replica.py`.
- Scenario loader: the validator now permits negative `clock_skew_ms`
  values. They were always supposed to work; the validator just
  rejected them with an unhelpful error.

## 0.2.3 - 2026-02-09

- Conformance suite covers 14 scenarios now (was 9). The new ones
  exercise the partition-during-snapshot path which used to lock up.
- Replay engine respects `--until` for the first time. There's a known
  determinism gap in this code path - see TODO.md.

## 0.2.0 - 2026-01-18

First version with both protocols working end-to-end.

- Raft-lite leader election + log replication.
- Quorum-KV read/write with configurable quorum sizes.
- Scenario v2 (the v1 prototype was thrown out before anyone besides
  me wrote one).

## 0.1.0 - 2025-12-22

Initial layout. Scheduler, transport, mailbox, recorder. No protocols
yet; just enough scaffolding to make sure determinism survived round-
tripping through the trace format.
