# Security policy

This is a simulator. It doesn't open sockets, doesn't read untrusted
files at runtime by default, and the YAML loader uses `yaml.safe_load`.
There isn't a meaningful attack surface in normal use.

That said: if you find anything that looks like a security issue,
email asifhammad84@gmail.com rather than opening a public issue, and
I'll respond within a few days.

A couple of caveats worth knowing:

- The trace format uses zstd. If you feed a maliciously crafted trace
  to `harbor-sim replay`, zstd's decompressor handles bounds-checking.
  The frame parser does too, but I haven't fuzzed it as hard as I'd
  like.
- The CLI uses `click`, which handles argument parsing. Don't pipe
  unverified content into `harbor-sim run -` until I've added a size
  cap on stdin.
