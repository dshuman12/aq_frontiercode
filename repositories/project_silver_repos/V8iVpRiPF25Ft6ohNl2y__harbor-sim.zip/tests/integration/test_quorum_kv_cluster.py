"""End-to-end tests for the quorum_kv protocol."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from harbor_sim.ids import NodeId
from harbor_sim.protocols.quorum_kv.policy import QuorumPolicy
from harbor_sim.protocols.quorum_kv.replica import QuorumKV
from harbor_sim.runtime.node import Node
from harbor_sim.runtime.simulator import Simulator
from harbor_sim.transport import LinkConfig


class _Client:
    """A trivial client: drives put/get, captures replies."""

    def __init__(self) -> None:
        self.replies: list[dict[str, Any]] = []
        self._rid = 0

    def next_rid(self) -> str:
        self._rid += 1
        return f"r{self._rid}"

    def on_init(self, ctx) -> None: pass
    def on_shutdown(self, ctx) -> None: pass
    def on_timer(self, ctx, key, payload) -> None: pass
    def on_message(self, ctx, msg) -> None:
        self.replies.append(dict(msg.body))


def _build_kv_cluster(
    tmp_path: Path,
    n: int = 3,
    r: int = 2,
    w: int = 2,
    floor: int = 0,
    seed: int = 0,
):
    nodes = [NodeId(f"n{i+1}") for i in range(n)]
    sim = Simulator.make(seed=seed, workdir=tmp_path)
    protos = {}
    for nid in nodes:
        peers = [p for p in nodes if p != nid]
        policy = QuorumPolicy(
            n_replicas=n, read_quorum=r, write_quorum=w, staleness_floor=floor
        )
        proto = QuorumKV(node=nid, peers=peers, policy=policy)
        protos[nid] = proto
        node = Node.make(
            node_id=nid,
            protocol=proto,
            scheduler=sim.scheduler,
            transport=sim.transport,
            rng=sim.rng,
            sim_clock=sim.clock,
            workdir=tmp_path / str(nid),
        )
        sim.add_node(node)
    for a in nodes:
        for b in nodes:
            if a != b:
                sim.transport.add_link(
                    LinkConfig(a, b, latency_low_ms=5, latency_high_ms=10)
                )
    sim.boot_all()
    return sim, protos, nodes


def _wire_client(sim: Simulator, client_id: NodeId, target: NodeId) -> _Client:
    client = _Client()
    cnode = Node.make(
        node_id=client_id,
        protocol=client,
        scheduler=sim.scheduler,
        transport=sim.transport,
        rng=sim.rng,
        sim_clock=sim.clock,
        workdir=sim.snapshots.root.parent / str(client_id),
    )
    sim.add_node(cnode)
    sim.transport.add_link(LinkConfig(client_id, target, 1, 2))
    sim.transport.add_link(LinkConfig(target, client_id, 1, 2))
    cnode.boot()
    return client


def test_put_replicates_to_quorum(tmp_path: Path):
    sim, protos, nodes = _build_kv_cluster(tmp_path, seed=1)
    client = _wire_client(sim, NodeId("client"), nodes[0])
    rid = client.next_rid()
    sim.transport.send(
        NodeId("client"), nodes[0], "qkv_put",
        {"rid": rid, "key": "x", "value": 1},
    )
    sim.run(horizon_ms=500)
    # The first node should have an ack.
    assert any(r.get("ok") and r.get("kind") == "put" for r in client.replies)
    # And at least 2 of 3 replicas should have the value (write quorum).
    have_value = sum(1 for p in protos.values() if "x" in p.store)
    assert have_value >= 2


def test_get_returns_written_value(tmp_path: Path):
    sim, protos, nodes = _build_kv_cluster(tmp_path, seed=2)
    client = _wire_client(sim, NodeId("client"), nodes[0])
    rid = client.next_rid()
    sim.transport.send(
        NodeId("client"), nodes[0], "qkv_put",
        {"rid": rid, "key": "x", "value": 42},
    )
    sim.run(horizon_ms=500)
    rid2 = client.next_rid()
    sim.transport.send(
        NodeId("client"), nodes[0], "qkv_get",
        {"rid": rid2, "key": "x"},
    )
    sim.run(horizon_ms=1500)
    gets = [r for r in client.replies if r.get("kind") == "get"]
    assert gets
    assert gets[-1].get("found") is True
    assert gets[-1].get("value") == 42


def test_get_missing_key_returns_not_found(tmp_path: Path):
    sim, protos, nodes = _build_kv_cluster(tmp_path, seed=3)
    client = _wire_client(sim, NodeId("client"), nodes[0])
    rid = client.next_rid()
    sim.transport.send(
        NodeId("client"), nodes[0], "qkv_get",
        {"rid": rid, "key": "absent"},
    )
    sim.run(horizon_ms=1_000)
    gets = [r for r in client.replies if r.get("kind") == "get"]
    assert gets and gets[-1].get("found") is False


def test_last_write_quorum_recorded(tmp_path: Path):
    sim, protos, nodes = _build_kv_cluster(tmp_path, seed=4)
    client = _wire_client(sim, NodeId("client"), nodes[0])
    rid = client.next_rid()
    sim.transport.send(
        NodeId("client"), nodes[0], "qkv_put",
        {"rid": rid, "key": "x", "value": 1},
    )
    sim.run(horizon_ms=500)
    # The coordinator should have recorded which replicas acked.
    assert "x" in protos[nodes[0]].last_write_quorum
    assert len(protos[nodes[0]].last_write_quorum["x"]) >= 2


def test_deterministic_across_runs(tmp_path: Path):
    def run(workdir: Path):
        sim, protos, nodes = _build_kv_cluster(workdir, seed=99)
        client = _wire_client(sim, NodeId("client"), nodes[0])
        for i in range(5):
            sim.transport.send(
                NodeId("client"), nodes[0], "qkv_put",
                {"rid": client.next_rid(), "key": f"k{i}", "value": i},
            )
        sim.run(horizon_ms=2_000)
        return [(p.node, sorted(p.store.items())) for p in protos.values()]

    out_a = run(tmp_path / "a")
    out_b = run(tmp_path / "b")
    assert out_a == out_b
