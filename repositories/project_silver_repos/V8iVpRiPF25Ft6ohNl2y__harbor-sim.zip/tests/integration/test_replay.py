"""End-to-end replay tests."""
from __future__ import annotations

from pathlib import Path

import pytest

from harbor_sim.hashing import stable_hash
from harbor_sim.replay.engine import ReplayEngine
from harbor_sim.scenario.loader import load
from harbor_sim.scenario.materialize import materialize
from harbor_sim.trace.format import LATEST, TraceHeader
from harbor_sim.trace.recorder import TraceRecorder


REPO = Path(__file__).parent.parent.parent
EXAMPLES = REPO / "examples"


def _record(scenario_file: Path, workdir: Path, horizon_ms: int = 3_000) -> Path:
    sc = load(scenario_file)
    sim = materialize(sc, workdir=workdir / "sim")
    sim.boot_all()
    trace_path = workdir / "out.trace"
    rec = TraceRecorder(path=trace_path)
    rec.open(TraceHeader(
        version=LATEST,
        run_id=int(stable_hash(sc) & 0x7FFF_FFFF),
        scenario_hash=int(stable_hash(sc)),
        seed=sc.seed,
        started_at_ms=0,
    ))
    sim.scheduler.install_hook(rec.record)
    sim.run(horizon_ms=horizon_ms)
    rec.close()
    return trace_path


def test_full_replay_matches_recording(tmp_path: Path):
    scenario_file = EXAMPLES / "leader-election-stable.yaml"
    trace = _record(scenario_file, tmp_path / "rec")
    engine = ReplayEngine(
        trace_path=trace,
        scenario_text=scenario_file.read_text(),
        workdir=tmp_path / "replay",
    )
    n = engine.replay()
    assert n > 0


def test_replay_until_cutoff(tmp_path: Path):
    scenario_file = EXAMPLES / "leader-election-stable.yaml"
    trace = _record(scenario_file, tmp_path / "rec")
    engine = ReplayEngine(
        trace_path=trace,
        scenario_text=scenario_file.read_text(),
        workdir=tmp_path / "replay",
    )
    n_full = engine.replay()
    engine2 = ReplayEngine(
        trace_path=trace,
        scenario_text=scenario_file.read_text(),
        workdir=tmp_path / "replay2",
    )
    n_partial = engine2.replay_until(cutoff_ms=500)
    assert n_partial < n_full


def test_replay_against_wrong_seed_diverges(tmp_path: Path):
    from harbor_sim.errors import DivergenceError

    scenario_file = EXAMPLES / "leader-election-stable.yaml"
    other_text = scenario_file.read_text().replace("seed: 42", "seed: 999")
    trace = _record(scenario_file, tmp_path / "rec", horizon_ms=1_500)
    engine = ReplayEngine(
        trace_path=trace,
        scenario_text=other_text,
        workdir=tmp_path / "replay",
    )
    with pytest.raises(DivergenceError):
        engine.replay()
