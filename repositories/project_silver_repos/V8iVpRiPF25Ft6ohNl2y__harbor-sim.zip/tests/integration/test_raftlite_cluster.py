"""End-to-end tests for a small raftlite cluster.

These run the actual scheduler/transport/runtime against the protocol
and assert on observable state. They are slower than the unit tests
(low single-digit seconds) but they're the only place that catches
cross-module wiring bugs.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable

import pytest

from harbor_sim.clock import ClockSkew
from harbor_sim.ids import NodeId
from harbor_sim.protocols.raftlite.protocol import Raftlite
from harbor_sim.protocols.raftlite.state import Role
from harbor_sim.runtime.node import Node
from harbor_sim.runtime.simulator import Simulator
from harbor_sim.transport import LinkConfig


def _build_cluster(
    tmp_path: Path,
    nodes: Iterable[str],
    seed: int = 0,
    latency: tuple[int, int] = (5, 20),
    skews: dict[str, int] | None = None,
) -> tuple[Simulator, dict[NodeId, Raftlite]]:
    nodes_list = [NodeId(n) for n in nodes]
    sim = Simulator.make(seed=seed, workdir=tmp_path)
    protos: dict[NodeId, Raftlite] = {}
    skews = skews or {}
    for nid in nodes_list:
        peers = [p for p in nodes_list if p != nid]
        proto = Raftlite(node=nid, peers=peers)
        protos[nid] = proto
        skew = ClockSkew(offset_ms=int(skews.get(str(nid), 0)))
        node = Node.make(
            node_id=nid,
            protocol=proto,
            scheduler=sim.scheduler,
            transport=sim.transport,
            rng=sim.rng,
            sim_clock=sim.clock,
            skew=skew,
            workdir=tmp_path / str(nid),
        )
        sim.add_node(node)

    for a in nodes_list:
        for b in nodes_list:
            if a != b:
                sim.transport.add_link(
                    LinkConfig(
                        src=a, dst=b,
                        latency_low_ms=latency[0],
                        latency_high_ms=latency[1],
                    )
                )
    sim.boot_all()
    return sim, protos


def _leaders(protos: dict[NodeId, Raftlite]) -> list[NodeId]:
    return [n for n, p in protos.items() if p.state.role == Role.LEADER]


def test_three_node_cluster_elects_a_leader(tmp_path: Path):
    sim, protos = _build_cluster(tmp_path, ["n1", "n2", "n3"], seed=1)
    sim.run(horizon_ms=2_000)
    leaders = _leaders(protos)
    assert len(leaders) == 1


def test_five_node_cluster_elects_a_leader(tmp_path: Path):
    sim, protos = _build_cluster(tmp_path, ["n1", "n2", "n3", "n4", "n5"], seed=2)
    sim.run(horizon_ms=3_000)
    leaders = _leaders(protos)
    assert len(leaders) == 1


def test_at_most_one_leader_per_term(tmp_path: Path):
    # Across the run, we should never observe two leaders simultaneously
    # in the same term. Spot-check by walking the run forward in steps.
    sim, protos = _build_cluster(tmp_path, ["n1", "n2", "n3"], seed=7)
    for stop in range(100, 2001, 100):
        sim.run(horizon_ms=stop)
        leaders_per_term: dict[int, set[NodeId]] = {}
        for n, p in protos.items():
            if p.state.role == Role.LEADER:
                term = int(p.state.current_term)
                leaders_per_term.setdefault(term, set()).add(n)
        for term, ns in leaders_per_term.items():
            assert len(ns) <= 1, f"two leaders in term {term}: {ns}"


def test_leader_steps_down_when_term_advances(tmp_path: Path):
    sim, protos = _build_cluster(tmp_path, ["n1", "n2", "n3"], seed=5)
    sim.run(horizon_ms=1_000)
    leaders = _leaders(protos)
    assert len(leaders) == 1
    leader_id = leaders[0]
    # Force a higher-term message by injecting a RequestVote from a
    # ghost candidate.
    sim.transport.add_link(LinkConfig(NodeId("ghost"), leader_id,
                                      latency_low_ms=1, latency_high_ms=1))
    sim.transport.send(
        NodeId("ghost"),
        leader_id,
        "rv",
        {
            "term": int(protos[leader_id].state.current_term) + 5,
            "candidate": "ghost",
            "last_log_index": 0,
            "last_log_term": 0,
        },
    )
    sim.run(horizon_ms=2_000)
    # After receiving the ghost RV at a higher term the leader must
    # have stepped down. It may re-win a subsequent election, but its
    # term must have advanced past the injected one.
    assert int(protos[leader_id].state.current_term) > int(
        protos[leader_id].state.current_term
    ) - 1
    saw_step_down = any(
        int(p.state.current_term) >= 5 for p in protos.values()
    )
    assert saw_step_down


def test_log_replicates_to_followers(tmp_path: Path):
    sim, protos = _build_cluster(tmp_path, ["n1", "n2", "n3"], seed=10)
    sim.run(horizon_ms=1_000)
    leaders = _leaders(protos)
    assert len(leaders) == 1
    leader_id = leaders[0]
    # Send a client propose.
    sim.transport.add_link(LinkConfig(NodeId("client"), leader_id,
                                      latency_low_ms=1, latency_high_ms=1))
    sim.transport.send(
        NodeId("client"),
        leader_id,
        "cli_propose",
        {"op": {"key": "x", "value": 1}},
    )
    sim.run(horizon_ms=2_000)
    # All replicas should now have the same last_log_index.
    last_indexes = {n: int(p.state.log.last_index()) for n, p in protos.items()}
    assert len(set(last_indexes.values())) == 1
    assert max(last_indexes.values()) >= 1


def test_quorum_match_advances_commit_index(tmp_path: Path):
    sim, protos = _build_cluster(tmp_path, ["n1", "n2", "n3"], seed=12)
    sim.run(horizon_ms=1_000)
    leaders = _leaders(protos)
    leader = protos[leaders[0]]
    # Propose three ops.
    sim.transport.add_link(LinkConfig(NodeId("client"), leaders[0],
                                      latency_low_ms=1, latency_high_ms=1))
    for v in range(3):
        sim.transport.send(
            NodeId("client"),
            leaders[0],
            "cli_propose",
            {"op": {"v": v}},
        )
    sim.run(horizon_ms=3_000)
    assert int(leader.state.commit_index) >= 3


def test_deterministic_election_across_runs(tmp_path: Path):
    sim_a, protos_a = _build_cluster(tmp_path / "a", ["n1", "n2", "n3"], seed=42)
    sim_b, protos_b = _build_cluster(tmp_path / "b", ["n1", "n2", "n3"], seed=42)
    sim_a.run(horizon_ms=2_000)
    sim_b.run(horizon_ms=2_000)
    leaders_a = _leaders(protos_a)
    leaders_b = _leaders(protos_b)
    assert leaders_a == leaders_b


def test_lease_is_set_after_quorum_heartbeats(tmp_path: Path):
    sim, protos = _build_cluster(tmp_path, ["n1", "n2", "n3"], seed=3)
    sim.run(horizon_ms=1_000)
    leaders = _leaders(protos)
    assert len(leaders) == 1
    leader = protos[leaders[0]]
    assert leader.state.lease_expires_at_ms > 0
