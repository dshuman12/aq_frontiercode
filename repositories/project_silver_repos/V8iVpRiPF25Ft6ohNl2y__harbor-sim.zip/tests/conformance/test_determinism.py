"""Conformance tests for the determinism guarantee.

These run each example scenario twice and compare every emitted
event byte-for-byte. They're the most reliable backstop against
silent non-determinism creeping in.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from harbor_sim.scenario.loader import load
from harbor_sim.scenario.materialize import materialize
from harbor_sim.trace.format import EventFrame


REPO = Path(__file__).parent.parent.parent
EXAMPLES = REPO / "examples"


def _collect_events(scenario_file: Path, workdir: Path) -> list[tuple]:
    sc = load(scenario_file)
    sim = materialize(sc, workdir=workdir)
    sim.boot_all()
    captured: list[tuple] = []

    def hook(ev) -> None:
        captured.append((ev.fire_at_ms, ev.kind, ev.target, str(ev.payload)))

    sim.scheduler.install_hook(hook)
    # Cap horizon: the conformance check doesn't need full horizons.
    horizon = min(sc.horizon_ms, 5_000)
    sim.run(horizon_ms=horizon)
    return captured


@pytest.mark.parametrize(
    "scenario_file",
    sorted(EXAMPLES.glob("*.yaml")),
    ids=lambda p: p.name,
)
def test_scenario_is_byte_deterministic(scenario_file: Path, tmp_path: Path):
    a = _collect_events(scenario_file, tmp_path / "a")
    b = _collect_events(scenario_file, tmp_path / "b")
    assert a == b, (
        f"non-deterministic events for {scenario_file.name}: "
        f"first diff at index {next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), -1)}"
    )


@pytest.mark.parametrize(
    "scenario_file",
    sorted(EXAMPLES.glob("*.yaml")),
    ids=lambda p: p.name,
)
def test_scenario_produces_events(scenario_file: Path, tmp_path: Path):
    events = _collect_events(scenario_file, tmp_path)
    # KV-only scenarios without a workload generator are quiescent;
    # they exercise the materializer but emit no scheduler events
    # until a client is wired in.
    if "kv" in scenario_file.name:
        return
    assert events, f"no events emitted for {scenario_file.name}"
