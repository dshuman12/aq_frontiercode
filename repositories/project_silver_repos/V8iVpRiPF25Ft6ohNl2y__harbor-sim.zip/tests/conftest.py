"""Shared pytest fixtures.

Fixtures are kept small on purpose. The big ones live next to the
tests that use them; pulling them into conftest would force every test
module to pay their import cost.
"""
from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Iterator

import pytest


@pytest.fixture
def tmp_repo(tmp_path: Path) -> Path:
    """A fresh temp directory rooted under pytest's tmp_path."""
    return tmp_path


@pytest.fixture
def seeded_rng() -> random.Random:
    """A Random with a fixed seed; tests that need a different one can
    just construct their own. The seed is small on purpose: a few tests
    grep for the literal in trace fixtures."""
    return random.Random(0xC0FFEE)


@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    # Make sure nothing in the test reads $HARBOR_SIM_TRACE_DIR or
    # similar leaked configuration from the host.
    for key in list(os.environ):
        if key.startswith("HARBOR_SIM_"):
            monkeypatch.delenv(key, raising=False)
    yield
