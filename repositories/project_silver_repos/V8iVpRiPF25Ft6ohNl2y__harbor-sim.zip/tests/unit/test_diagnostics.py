"""Tests for the diagnostics module."""
from __future__ import annotations

from pathlib import Path

from harbor_sim.diagnostics import (
    cluster_summary_table,
    find_node_by_role,
    snapshot_cluster,
)
from harbor_sim.ids import NodeId
from harbor_sim.protocols.raftlite.protocol import Raftlite
from harbor_sim.runtime.node import Node
from harbor_sim.runtime.simulator import Simulator
from harbor_sim.transport import LinkConfig


def _three_node_raft(tmp_path: Path, seed: int = 1):
    sim = Simulator.make(seed=seed, workdir=tmp_path)
    nodes = [NodeId(f"n{i+1}") for i in range(3)]
    protos = {}
    for nid in nodes:
        peers = [p for p in nodes if p != nid]
        proto = Raftlite(node=nid, peers=peers)
        protos[nid] = proto
        sim.add_node(Node.make(nid, proto, sim.scheduler, sim.transport,
                                sim.rng, sim.clock, workdir=tmp_path / str(nid)))
    for a in nodes:
        for b in nodes:
            if a != b:
                sim.transport.add_link(LinkConfig(a, b, 5, 10))
    return sim, protos


def test_snapshot_cluster_returns_per_node_state(tmp_path: Path):
    sim, protos = _three_node_raft(tmp_path)
    sim.run(horizon_ms=1_500)
    snap = snapshot_cluster(sim)
    assert snap.at_ms > 0
    assert set(snap.nodes.keys()) == {"n1", "n2", "n3"}
    for state in snap.nodes.values():
        assert "role" in state
        assert "current_term" in state
        assert "log_length" in state


def test_snapshot_cluster_str_renders(tmp_path: Path):
    sim, _ = _three_node_raft(tmp_path)
    sim.run(horizon_ms=1_500)
    snap = snapshot_cluster(sim)
    text = str(snap)
    assert "cluster" in text
    assert "n1" in text


def test_find_node_by_role(tmp_path: Path):
    sim, _ = _three_node_raft(tmp_path)
    sim.run(horizon_ms=2_000)
    leaders = find_node_by_role(sim, "leader")
    assert len(leaders) == 1


def test_find_node_by_role_no_match_returns_empty(tmp_path: Path):
    sim, _ = _three_node_raft(tmp_path)
    sim.run(horizon_ms=2_000)
    bogus = find_node_by_role(sim, "ghost")
    assert bogus == []


def test_cluster_summary_table_shape(tmp_path: Path):
    sim, _ = _three_node_raft(tmp_path)
    sim.run(horizon_ms=1_500)
    table = cluster_summary_table(sim)
    assert table[0] == ["node", "role", "term", "commit", "log_last"]
    assert len(table) == 4  # header + 3 nodes
    for row in table[1:]:
        assert len(row) == 5
