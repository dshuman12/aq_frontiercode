"""Smoke tests for the fuzzer."""
from __future__ import annotations

import random
from pathlib import Path

from tools.fuzz.generator import generate, mutate_scenario
from tools.fuzz.runner import run_fuzz


def test_generate_produces_first_scenario():
    it = generate(seed=42, protocol="raftlite")
    sc = next(it)
    assert sc.protocol == "raftlite"
    assert len(sc.nodes) >= 3


def test_generate_is_deterministic():
    a_iter = generate(seed=42)
    b_iter = generate(seed=42)
    for _ in range(5):
        sa = next(a_iter)
        sb = next(b_iter)
        assert sa.nodes == sb.nodes
        assert sa.failures == sb.failures


def test_mutate_scenario_changes_something():
    base = next(generate(seed=7))
    mutated = mutate_scenario(base, random.Random(7))
    changed = (
        base.nodes != mutated.nodes
        or base.failures != mutated.failures
        or base.links != mutated.links
    )
    assert changed


def test_run_fuzz_records_results(tmp_path: Path):
    sc = next(generate(seed=123))
    sc.horizon_ms = 3_000
    result = run_fuzz(sc, workdir=tmp_path)
    assert result.events > 0
    assert "agreement" in result.violations_by_invariant


def test_run_fuzz_passes_on_clean_scenario(tmp_path: Path):
    sc = next(generate(seed=1))
    sc.horizon_ms = 3_000
    result = run_fuzz(sc, workdir=tmp_path)
    # The base scenario is healthy; agreement should hold.
    assert result.violations_by_invariant["agreement"] == 0
