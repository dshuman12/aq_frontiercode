from __future__ import annotations

from pathlib import Path

import pytest

from harbor_sim.errors import CodecError
from harbor_sim.ids import LogIndex, NodeId, SnapshotId, Term
from harbor_sim.storage.snapshot import (
    CompactionRecord,
    Snapshot,
    SnapshotStore,
)


def _snap(node: str, sid: int, lii: int, lit: int, n: int) -> Snapshot:
    return Snapshot(
        id=SnapshotId(sid),
        node=NodeId(node),
        state={"applied": lii},
        compaction=CompactionRecord(
            last_included_index=LogIndex(lii),
            last_included_term=Term(lit),
            compacted_count=n,
        ),
        created_at_ms=12345,
    )


def test_compaction_record_round_trip():
    cr = CompactionRecord(
        last_included_index=LogIndex(42),
        last_included_term=Term(3),
        compacted_count=10,
    )
    blob = cr.serialize()
    back = CompactionRecord.deserialize(blob)
    assert back == cr


def test_snapshot_round_trip():
    s = _snap("n1", 7, 100, 2, 50)
    back = Snapshot.deserialize(s.serialize())
    assert back == s


def test_snapshot_deserialize_missing_state_raises():
    import msgpack

    blob = msgpack.packb({"node": "n1"}, use_bin_type=True)
    with pytest.raises(CodecError, match="missing state"):
        Snapshot.deserialize(blob)


def test_snapshot_deserialize_corrupt_raises():
    with pytest.raises(CodecError):
        Snapshot.deserialize(b"\xff\xff\xff")


def test_snapshot_deserialize_missing_compaction_uses_defaults():
    import msgpack

    blob = msgpack.packb(
        {"id": 1, "node": "n1", "state": {"x": 1}, "created_at_ms": 0},
        use_bin_type=True,
    )
    back = Snapshot.deserialize(blob)
    assert int(back.compaction.last_included_index) == 0
    assert int(back.compaction.last_included_term) == 0
    assert back.compaction.compacted_count == 0


def test_store_save_and_load(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    s = _snap("n1", 1, 100, 2, 50)
    store.save(s)
    back = store.load(NodeId("n1"), SnapshotId(1))
    assert back == s


def test_store_save_writes_compaction_sidecar(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    s = _snap("n1", 1, 100, 2, 50)
    store.save(s)
    assert (tmp_path / "n1" / "1.compaction").exists()


def test_store_load_compaction_returns_sidecar(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    s = _snap("n1", 1, 100, 2, 50)
    store.save(s)
    cr = store.load_compaction(NodeId("n1"), SnapshotId(1))
    assert cr is not None
    assert int(cr.last_included_index) == 100
    assert int(cr.last_included_term) == 2
    assert cr.compacted_count == 50


def test_store_load_compaction_missing_returns_none(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    s = _snap("n1", 1, 100, 2, 50)
    store.save(s)
    # delete the sidecar
    (tmp_path / "n1" / "1.compaction").unlink()
    cr = store.load_compaction(NodeId("n1"), SnapshotId(1))
    assert cr is None


def test_store_load_missing_snapshot_raises(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    with pytest.raises(FileNotFoundError):
        store.load(NodeId("n1"), SnapshotId(99))


def test_store_latest_for_returns_max(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    for sid in (3, 1, 5, 2, 4):
        store.save(_snap("n1", sid, 100 + sid, 1, 50))
    assert int(store.latest_for(NodeId("n1"))) == 5


def test_store_latest_for_returns_none_when_empty(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    assert store.latest_for(NodeId("n1")) is None


def test_store_list_for(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    for sid in (1, 2, 3):
        store.save(_snap("n1", sid, 100 + sid, 1, 0))
    ids = [int(s) for s in store.list_for(NodeId("n1"))]
    assert sorted(ids) == [1, 2, 3]


def test_store_rescans_existing_directory(tmp_path: Path):
    first = SnapshotStore(root=tmp_path)
    first.save(_snap("n1", 1, 100, 1, 0))
    first.save(_snap("n1", 2, 200, 1, 0))
    # Re-construct a store pointed at the same directory.
    second = SnapshotStore(root=tmp_path)
    ids = [int(s) for s in second.list_for(NodeId("n1"))]
    assert sorted(ids) == [1, 2]
    assert int(second.latest_for(NodeId("n1"))) == 2


def test_store_separates_nodes(tmp_path: Path):
    store = SnapshotStore(root=tmp_path)
    store.save(_snap("n1", 1, 100, 1, 0))
    store.save(_snap("n2", 1, 200, 1, 0))
    assert int(store.load(NodeId("n1"), SnapshotId(1)).compaction.last_included_index) == 100
    assert int(store.load(NodeId("n2"), SnapshotId(1)).compaction.last_included_index) == 200
