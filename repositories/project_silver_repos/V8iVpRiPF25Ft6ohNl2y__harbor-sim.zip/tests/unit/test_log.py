from __future__ import annotations

import pytest

from harbor_sim.errors import ProtocolError
from harbor_sim.ids import LogIndex, Term
from harbor_sim.storage.log import Log, LogEntry, deserialize, serialize


def _entry(term: int, index: int, data: dict | None = None) -> LogEntry:
    return LogEntry(term=Term(term), index=LogIndex(index), data=data or {})


def test_empty_log_invariants():
    log = Log()
    assert log.length() == 0
    assert log.first_index == 1
    assert int(log.last_index()) == 0
    assert int(log.last_term()) == 0


def test_append_one_then_get():
    log = Log()
    log.append(_entry(1, 1, {"op": "put"}))
    e = log.get(LogIndex(1))
    assert e.data == {"op": "put"}


def test_append_advances_last_index():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(1, i))
    assert int(log.last_index()) == 5
    assert log.length() == 5


def test_append_rejects_index_gap():
    log = Log()
    log.append(_entry(1, 1))
    with pytest.raises(ProtocolError, match="index gap"):
        log.append(_entry(1, 3))


def test_append_many_in_order():
    log = Log()
    log.append_many([_entry(1, 1), _entry(1, 2), _entry(2, 3)])
    assert int(log.last_index()) == 3


def test_get_predates_first_index_raises():
    log = Log(first_index=LogIndex(5))
    with pytest.raises(KeyError, match="predates"):
        log.get(LogIndex(3))


def test_get_past_last_raises():
    log = Log()
    log.append(_entry(1, 1))
    with pytest.raises(KeyError, match="past last_index"):
        log.get(LogIndex(5))


def test_contains_handles_edges():
    log = Log(first_index=LogIndex(5))
    log.append(_entry(1, 5))
    log.append(_entry(1, 6))
    assert log.contains(LogIndex(4)) is False
    assert log.contains(LogIndex(5)) is True
    assert log.contains(LogIndex(6)) is True
    assert log.contains(LogIndex(7)) is False


def test_slice_half_open():
    log = Log()
    for i in range(1, 11):
        log.append(_entry(1, i))
    s = log.slice(LogIndex(3), LogIndex(6))
    assert [int(e.index) for e in s] == [3, 4, 5]


def test_slice_low_geq_high_returns_empty():
    log = Log()
    for i in range(1, 11):
        log.append(_entry(1, i))
    assert log.slice(LogIndex(5), LogIndex(5)) == []
    assert log.slice(LogIndex(5), LogIndex(3)) == []


def test_slice_clamps_low():
    log = Log(first_index=LogIndex(5))
    log.append_many([_entry(1, 5), _entry(1, 6), _entry(1, 7)])
    s = log.slice(LogIndex(1), LogIndex(7))
    assert [int(e.index) for e in s] == [5, 6]


def test_slice_clamps_high():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(1, i))
    s = log.slice(LogIndex(3), LogIndex(100))
    assert [int(e.index) for e in s] == [3, 4, 5]


def test_truncate_from_drops_tail():
    log = Log()
    for i in range(1, 11):
        log.append(_entry(1, i))
    removed = log.truncate_from(LogIndex(5))
    assert removed == 6
    assert int(log.last_index()) == 4


def test_truncate_from_above_last_is_noop():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(1, i))
    removed = log.truncate_from(LogIndex(99))
    assert removed == 0


def test_compact_drops_prefix_and_advances_first_index():
    log = Log()
    for i in range(1, 11):
        log.append(_entry(1, i))
    compacted = log.compact(through=LogIndex(5), term=Term(1))
    assert compacted == 5
    assert int(log.first_index) == 6
    assert log.length() == 5
    assert int(log.last_included_term) == 1


def test_compact_below_first_is_noop():
    log = Log(first_index=LogIndex(5))
    log.append_many([_entry(1, 5), _entry(1, 6)])
    compacted = log.compact(through=LogIndex(3), term=Term(1))
    assert compacted == 0
    assert int(log.first_index) == 5


def test_compact_through_last_clears_log():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(2, i))
    compacted = log.compact(through=LogIndex(5), term=Term(2))
    assert compacted == 5
    assert log.length() == 0
    assert int(log.first_index) == 6
    assert int(log.last_term()) == 2


def test_serialize_round_trip():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(term=(i % 2) + 1, index=i, data={"x": i}))
    blob = serialize(log)
    restored = deserialize(blob)
    assert int(restored.first_index) == int(log.first_index)
    assert restored.length() == log.length()
    assert [(int(e.term), int(e.index), e.data) for e in restored] == [
        (int(e.term), int(e.index), e.data) for e in log
    ]


def test_serialize_round_trip_after_compaction():
    log = Log()
    for i in range(1, 11):
        log.append(_entry(1, i))
    log.compact(through=LogIndex(5), term=Term(1))
    blob = serialize(log)
    restored = deserialize(blob)
    assert int(restored.first_index) == 6
    assert int(restored.last_included_term) == 1
    assert restored.length() == 5


def test_iteration_yields_entries_in_order():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(1, i))
    indices = [int(e.index) for e in log]
    assert indices == [1, 2, 3, 4, 5]
