"""Tests for the read-repair helpers."""
from __future__ import annotations

from harbor_sim.ids import NodeId
from harbor_sim.protocols.quorum_kv.repair import (
    ReadRepair,
    consensus_round,
    staleness_vector,
)
from harbor_sim.protocols.quorum_kv.replica import VersionedValue


def _vv(value, writer: str, gen: int) -> VersionedValue:
    return VersionedValue(value=value, writer=NodeId(writer), generation=gen, written_at_ms=0)


def test_consensus_round_picks_highest():
    responses = {
        NodeId("n1"): _vv("a", "n1", 1),
        NodeId("n2"): _vv("b", "n1", 2),
        NodeId("n3"): _vv("c", "n1", 1),
    }
    winner = consensus_round(responses)
    assert winner is not None
    assert winner.value == "b"


def test_consensus_round_handles_none_responses():
    responses = {
        NodeId("n1"): None,
        NodeId("n2"): _vv("b", "n1", 2),
    }
    winner = consensus_round(responses)
    assert winner is not None
    assert winner.generation == 2


def test_consensus_round_all_none_returns_none():
    responses = {NodeId("n1"): None, NodeId("n2"): None}
    assert consensus_round(responses) is None


def test_consensus_round_writer_tiebreaker():
    responses = {
        NodeId("n1"): _vv("a", "n2", 5),
        NodeId("n2"): _vv("a", "n1", 5),
    }
    winner = consensus_round(responses)
    # Writer "n2" > "n1" lexically.
    assert winner is not None
    assert str(winner.writer) == "n2"


def test_staleness_vector_zero_when_at_winner():
    winner = _vv("w", "n1", 5)
    responses = {NodeId("n1"): winner, NodeId("n2"): _vv("b", "n1", 5)}
    out = staleness_vector(responses, winner)
    assert out[NodeId("n1")] == 0
    assert out[NodeId("n2")] == 0


def test_staleness_vector_counts_distance():
    winner = _vv("w", "n1", 10)
    responses = {NodeId("n1"): winner,
                 NodeId("n2"): _vv("b", "n1", 7),
                 NodeId("n3"): None}
    out = staleness_vector(responses, winner)
    assert out[NodeId("n2")] == 3
    assert out[NodeId("n3")] == 10  # None counted as fully behind


def test_staleness_vector_no_winner_all_zero():
    responses = {NodeId("n1"): None, NodeId("n2"): None}
    out = staleness_vector(responses, None)
    assert all(v == 0 for v in out.values())


class _FakeCtx:
    def __init__(self):
        self.sent = []

    def send(self, to, kind, body):
        self.sent.append((str(to), kind, dict(body)))


def test_repair_sends_to_stale_replicas():
    rr = ReadRepair()
    ctx = _FakeCtx()
    winner = _vv("w", "n1", 5)
    responses = {
        NodeId("n1"): winner,
        NodeId("n2"): _vv("b", "n1", 3),
        NodeId("n3"): None,
    }
    sent = rr.maybe_repair(ctx, "x", responses, winner)
    assert sent == 2
    assert {to for to, _, _ in ctx.sent} == {"n2", "n3"}
    assert rr.stats.repairs_issued == 2
    assert "x" in rr.stats.keys_touched


def test_repair_noop_when_no_winner():
    rr = ReadRepair()
    ctx = _FakeCtx()
    responses = {NodeId("n1"): None}
    sent = rr.maybe_repair(ctx, "x", responses, None)
    assert sent == 0
    assert rr.stats.repairs_issued == 0


def test_repair_noop_when_all_at_winner():
    rr = ReadRepair()
    ctx = _FakeCtx()
    winner = _vv("w", "n1", 5)
    responses = {NodeId("n1"): winner, NodeId("n2"): winner}
    sent = rr.maybe_repair(ctx, "x", responses, winner)
    assert sent == 0
