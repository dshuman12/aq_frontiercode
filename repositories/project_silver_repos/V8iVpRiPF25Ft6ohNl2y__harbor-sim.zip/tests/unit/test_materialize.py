"""Tests for the scenario materializer."""
from __future__ import annotations

from pathlib import Path

import pytest

from harbor_sim.ids import LogIndex, NodeId, SnapshotId, Term
from harbor_sim.scenario.loader import load_text
from harbor_sim.scenario.materialize import materialize
from harbor_sim.storage.snapshot import (
    CompactionRecord,
    Snapshot,
    SnapshotStore,
)


SCENARIO = """
scenario: m
seed: 1
horizon_ms: 1000
protocol: raftlite
nodes:
  - { id: n1 }
  - { id: n2 }
  - { id: n3 }
links:
  - { from: n1, to: n2, latency_ms: 5 }
  - { from: n1, to: n3, latency_ms: 5 }
  - { from: n2, to: n3, latency_ms: 5 }
"""


def test_materialize_creates_all_nodes(tmp_path: Path):
    sc = load_text(SCENARIO)
    sim = materialize(sc, workdir=tmp_path)
    assert {str(n) for n in sim.nodes} == {"n1", "n2", "n3"}


def test_materialize_wires_links_bidirectionally(tmp_path: Path):
    sc = load_text(SCENARIO)
    sim = materialize(sc, workdir=tmp_path)
    # Each declared link auto-expands into both directions because
    # bidirectional defaults to true.
    assert sim.transport.has_link(NodeId("n1"), NodeId("n2"))
    assert sim.transport.has_link(NodeId("n2"), NodeId("n1"))


def test_materialize_one_directional_link_when_disabled(tmp_path: Path):
    sc = load_text("""
scenario: x
nodes: [{id: n1}, {id: n2}]
links:
  - { from: n1, to: n2, latency_ms: 5, bidirectional: false }
""")
    sim = materialize(sc, workdir=tmp_path)
    assert sim.transport.has_link(NodeId("n1"), NodeId("n2"))
    assert not sim.transport.has_link(NodeId("n2"), NodeId("n1"))


def test_materialize_applies_clock_skew(tmp_path: Path):
    sc = load_text("""
scenario: skewed
nodes:
  - { id: n1, clock_skew_ms: 100 }
""")
    sim = materialize(sc, workdir=tmp_path)
    sim.clock.advance_to(0)
    node = sim.nodes[NodeId("n1")]
    assert node.clock.now() == 100


def test_materialize_schedules_failures(tmp_path: Path):
    sc = load_text("""
scenario: f
nodes: [{id: n1}, {id: n2}]
links:
  - { from: n1, to: n2, latency_ms: 5 }
failures:
  - { at_ms: 100, kind: partition, a: n1, b: n2, duration_ms: 500 }
""")
    sim = materialize(sc, workdir=tmp_path)
    # The partition fault and its automatic reversal both queue.
    assert sim.scheduler.pending() == 2


def test_materialize_loads_initial_snapshot(tmp_path: Path):
    # Pre-populate a snapshot at the path the simulator will look in.
    store = SnapshotStore(root=tmp_path)
    snap = Snapshot(
        id=SnapshotId(1),
        node=NodeId("n1"),
        state={"current_term": 5},
        compaction=CompactionRecord(
            last_included_index=LogIndex(10),
            last_included_term=Term(2),
            compacted_count=10,
        ),
        created_at_ms=0,
    )
    store.save(snap)

    sc = load_text("""
scenario: initial-snap
nodes:
  - { id: n1, initial_snapshot_id: 1 }
""")
    # The simulator uses the SAME snapshot store path; reuse it.
    sim = materialize(sc, workdir=tmp_path)
    proto = sim.nodes[NodeId("n1")].protocol
    # Term should now be the snapshotted value.
    assert int(proto.state.current_term) == 5
    # first_index advances past the snapshot.
    assert int(proto.state.log.first_index) == 11


def test_materialize_protocol_options_pass_through(tmp_path: Path):
    sc = load_text("""
scenario: qkv
protocol: quorum_kv
nodes:
  - { id: n1 }
  - { id: n2 }
  - { id: n3 }
links:
  - { from: n1, to: n2, latency_ms: 5 }
  - { from: n1, to: n3, latency_ms: 5 }
  - { from: n2, to: n3, latency_ms: 5 }
protocol_options:
  n_replicas: 3
  read_quorum: 1
  write_quorum: 3
""")
    sim = materialize(sc, workdir=tmp_path)
    proto = sim.nodes[NodeId("n1")].protocol
    assert proto.policy.read_quorum == 1
    assert proto.policy.write_quorum == 3
