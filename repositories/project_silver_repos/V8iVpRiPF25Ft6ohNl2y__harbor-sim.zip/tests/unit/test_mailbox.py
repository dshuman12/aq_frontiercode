from __future__ import annotations

import pytest

from harbor_sim.errors import SimulationError
from harbor_sim.ids import NodeId
from harbor_sim.runtime.mailbox import (
    DEFAULT_CAP,
    IncomingMessage,
    Mailbox,
    OutgoingMessage,
)


def _inc(i: int) -> IncomingMessage:
    return IncomingMessage(
        from_node=NodeId("peer"),
        kind="ping",
        body={"i": i},
        received_at_ms=i * 10,
    )


def _out(i: int) -> OutgoingMessage:
    return OutgoingMessage(to_node=NodeId("peer"), kind="ping", body={"i": i})


def test_inbox_fifo():
    mb = Mailbox(node=NodeId("n1"))
    for i in range(5):
        mb.push_in(_inc(i))
    assert [mb.pop_in().body["i"] for _ in range(5)] == [0, 1, 2, 3, 4]


def test_pop_in_empty_returns_none():
    mb = Mailbox(node=NodeId("n1"))
    assert mb.pop_in() is None


def test_outbox_drain_returns_in_order_and_clears():
    mb = Mailbox(node=NodeId("n1"))
    for i in range(3):
        mb.push_out(_out(i))
    drained = mb.drain_out()
    assert [m.body["i"] for m in drained] == [0, 1, 2]
    assert mb.outbox_len() == 0
    assert mb.drain_out() == []


def test_inbox_overflow_raises():
    mb = Mailbox(node=NodeId("n1"), cap=2)
    mb.push_in(_inc(0))
    mb.push_in(_inc(1))
    with pytest.raises(SimulationError, match="inbox overflow"):
        mb.push_in(_inc(2))


def test_outbox_overflow_raises():
    mb = Mailbox(node=NodeId("n1"), cap=2)
    mb.push_out(_out(0))
    mb.push_out(_out(1))
    with pytest.raises(SimulationError, match="outbox overflow"):
        mb.push_out(_out(2))


def test_default_cap_is_set():
    mb = Mailbox(node=NodeId("n1"))
    assert mb.cap == DEFAULT_CAP


def test_inbox_len_and_outbox_len_track():
    mb = Mailbox(node=NodeId("n1"))
    assert mb.inbox_len() == 0
    assert mb.outbox_len() == 0
    mb.push_in(_inc(0))
    mb.push_out(_out(0))
    assert mb.inbox_len() == 1
    assert mb.outbox_len() == 1
    mb.pop_in()
    mb.drain_out()
    assert mb.inbox_len() == 0
    assert mb.outbox_len() == 0


def test_clear_resets_both():
    mb = Mailbox(node=NodeId("n1"))
    mb.push_in(_inc(0))
    mb.push_out(_out(0))
    mb.clear()
    assert mb.inbox_len() == 0
    assert mb.outbox_len() == 0
