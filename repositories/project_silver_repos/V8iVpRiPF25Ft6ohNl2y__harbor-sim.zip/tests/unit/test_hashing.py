from __future__ import annotations

import math
import struct

import pytest

from harbor_sim.hashing import (
    blake_hash,
    blake_hash_int,
    crc32c,
    stable_hash,
)


# crc32c reference values from RFC 3720 (test vectors for the Castagnoli polynomial).
@pytest.mark.parametrize(
    "data,expected",
    [
        (b"", 0x00000000),
        (b"a", 0xC1D04330),
        (b"abc", 0x364B3FB7),
        (b"123456789", 0xE3069283),
    ],
)
def test_crc32c_reference_vectors(data, expected):
    assert crc32c(data) == expected


def test_crc32c_seed_chains_correctly():
    """CRC32C with seed = full(prefix), data = suffix equals full(prefix+suffix)."""
    prefix = b"hello, "
    suffix = b"world!"
    full = crc32c(prefix + suffix)
    seed = crc32c(prefix)
    chained = crc32c(suffix, seed=seed)
    assert chained == full


def test_blake_hash_is_deterministic():
    h1 = blake_hash(b"hello")
    h2 = blake_hash(b"hello")
    assert h1 == h2


def test_blake_hash_size_default_is_8():
    assert len(blake_hash(b"hello")) == 8


@pytest.mark.parametrize("size", [1, 4, 16, 32, 64])
def test_blake_hash_respects_size(size):
    assert len(blake_hash(b"hello", size=size)) == size


@pytest.mark.parametrize("size", [0, 65, -1])
def test_blake_hash_rejects_bad_size(size):
    with pytest.raises(ValueError, match="size"):
        blake_hash(b"x", size=size)


def test_blake_hash_int_round_trip():
    raw = blake_hash(b"hello")
    as_int = blake_hash_int(b"hello")
    assert int.from_bytes(raw, "big") == as_int


@pytest.mark.parametrize(
    "value",
    [
        None,
        True,
        False,
        0,
        1,
        -1,
        2**63,
        "",
        "hello",
        "ünicode",
        b"",
        b"\x00\x01",
        [],
        [1, 2, 3],
        (1, 2, 3),
        {},
        {"a": 1, "b": 2},
        frozenset(),
        frozenset({1, 2, 3}),
    ],
)
def test_stable_hash_round_trip(value):
    a = stable_hash(value)
    b = stable_hash(value)
    assert a == b


def test_stable_hash_dict_is_order_independent():
    a = stable_hash({"a": 1, "b": 2, "c": 3})
    b = stable_hash({"c": 3, "a": 1, "b": 2})
    assert a == b


def test_stable_hash_frozenset_is_order_independent():
    # frozensets are unordered by definition; the hash should still
    # be insensitive to iteration order across runs.
    a = stable_hash(frozenset({1, 2, 3, 4, 5}))
    b = stable_hash(frozenset({5, 4, 3, 2, 1}))
    assert a == b


def test_stable_hash_list_is_order_sensitive():
    a = stable_hash([1, 2, 3])
    b = stable_hash([3, 2, 1])
    assert a != b


def test_stable_hash_distinguishes_list_from_tuple():
    a = stable_hash([1, 2, 3])
    b = stable_hash((1, 2, 3))
    assert a != b


def test_stable_hash_distinguishes_str_from_bytes():
    a = stable_hash("abc")
    b = stable_hash(b"abc")
    assert a != b


def test_stable_hash_float_zero_normalizes():
    assert stable_hash(0.0) == stable_hash(-0.0)


def test_stable_hash_float_nan_normalizes():
    a = stable_hash(float("nan"))
    b = stable_hash(float("nan"))
    assert a == b


def test_stable_hash_float_distinct_values():
    a = stable_hash(1.0)
    b = stable_hash(2.0)
    assert a != b


def test_stable_hash_nested_structure():
    a = stable_hash({"a": [1, 2, {"x": True}], "b": None})
    b = stable_hash({"b": None, "a": [1, 2, {"x": True}]})
    assert a == b


def test_stable_hash_rejects_unknown_type():
    class Weird:
        pass

    with pytest.raises(TypeError, match="unsupported type"):
        stable_hash(Weird())


def test_stable_hash_object_with_repr_hook():
    class Repr:
        def _stable_hash_repr(self):
            return {"k": 1}

    h = stable_hash(Repr())
    assert h == stable_hash({"k": 1}) ^ stable_hash({"k": 1}) ^ h  # tautology check
    # The actual property: same repr -> same hash.
    class Repr2:
        def _stable_hash_repr(self):
            return {"k": 1}

    assert stable_hash(Repr()) == stable_hash(Repr2())
