from __future__ import annotations

import pytest

from harbor_sim.clock import SimClock
from harbor_sim.errors import ScenarioReferenceError
from harbor_sim.ids import NodeId
from harbor_sim.rng import RngBundle
from harbor_sim.scheduler import Scheduler
from harbor_sim.transport import LinkConfig, Transport, fan_out


def _setup(seed: int = 0) -> tuple[Scheduler, Transport]:
    clock = SimClock()
    rng = RngBundle(seed=seed)
    sched = Scheduler(clock=clock, rng=rng)
    trans = Transport(scheduler=sched, rng=rng)
    return sched, trans


def test_add_link_round_trip():
    _, t = _setup()
    cfg = LinkConfig(NodeId("n1"), NodeId("n2"), latency_low_ms=5, latency_high_ms=20)
    t.add_link(cfg)
    assert t.has_link(NodeId("n1"), NodeId("n2"))
    assert not t.has_link(NodeId("n2"), NodeId("n1"))


def test_add_link_rejects_bad_latency_range():
    _, t = _setup()
    with pytest.raises(ValueError, match="latency"):
        t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                              latency_low_ms=20, latency_high_ms=10))


def test_add_link_rejects_negative_latency():
    _, t = _setup()
    with pytest.raises(ValueError, match="latency"):
        t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                              latency_low_ms=-1, latency_high_ms=5))


def test_add_link_rejects_bad_drop_rate():
    _, t = _setup()
    with pytest.raises(ValueError, match="drop_rate"):
        t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"), drop_rate=1.5))
    with pytest.raises(ValueError, match="drop_rate"):
        t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"), drop_rate=-0.1))


def test_link_lookup_unknown_raises():
    _, t = _setup()
    with pytest.raises(ScenarioReferenceError):
        t.link(NodeId("n1"), NodeId("n2"))


def test_send_schedules_delivery():
    sched, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          latency_low_ms=5, latency_high_ms=5))
    fire = t.send(NodeId("n1"), NodeId("n2"), "ping", {"v": 1})
    assert fire == 5
    e = sched.step()
    assert e.kind == "deliver"
    assert e.target == "n2"
    assert e.payload["from"] == "n1"
    assert e.payload["kind"] == "ping"


def test_send_drops_when_partitioned():
    _, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2")))
    t.partition(NodeId("n1"), NodeId("n2"))
    assert t.send(NodeId("n1"), NodeId("n2"), "ping", {}) is None
    assert t.stats()["drops"] == 1


def test_partition_pair_both_directions():
    _, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2")))
    t.add_link(LinkConfig(NodeId("n2"), NodeId("n1")))
    t.partition_pair(NodeId("n1"), NodeId("n2"))
    assert t.send(NodeId("n1"), NodeId("n2"), "ping", {}) is None
    assert t.send(NodeId("n2"), NodeId("n1"), "ping", {}) is None


def test_partition_then_recover():
    sched, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          latency_low_ms=5, latency_high_ms=5))
    t.partition(NodeId("n1"), NodeId("n2"))
    assert t.send(NodeId("n1"), NodeId("n2"), "ping", {}) is None
    t.partition(NodeId("n1"), NodeId("n2"), on=False)
    assert t.send(NodeId("n1"), NodeId("n2"), "ping", {}) == 5


def test_drop_rate_deterministic_per_seed():
    sched_a, t_a = _setup(seed=42)
    sched_b, t_b = _setup(seed=42)
    for t in (t_a, t_b):
        t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                              drop_rate=0.5, latency_low_ms=1, latency_high_ms=1))
    a_out = [t_a.send(NodeId("n1"), NodeId("n2"), "ping", {"i": i}) for i in range(50)]
    b_out = [t_b.send(NodeId("n1"), NodeId("n2"), "ping", {"i": i}) for i in range(50)]
    assert a_out == b_out


def test_capacity_blocks_overflow():
    _, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          capacity=3, latency_low_ms=10, latency_high_ms=10))
    results = [t.send(NodeId("n1"), NodeId("n2"), "ping", {}) for _ in range(5)]
    delivered = [r for r in results if r is not None]
    dropped = [r for r in results if r is None]
    assert len(delivered) == 3
    assert len(dropped) == 2


def test_fifo_no_reorder_default():
    sched, t = _setup(seed=42)
    # Reorder False (default) and a wide latency range: out-of-order
    # samples should be re-clamped to monotonic delivery times.
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          latency_low_ms=5, latency_high_ms=50, reorder=False))
    fires = [t.send(NodeId("n1"), NodeId("n2"), "ping", {"i": i}) for i in range(20)]
    assert all(a <= b for a, b in zip(fires, fires[1:]))


def test_reorder_true_allows_swap():
    sched, t = _setup(seed=42)
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          latency_low_ms=5, latency_high_ms=50, reorder=True))
    fires = [t.send(NodeId("n1"), NodeId("n2"), "ping", {"i": i}) for i in range(20)]
    # With reorder on, at least one out-of-order pair is overwhelmingly
    # likely; if none appears something is wrong.
    swaps = sum(1 for a, b in zip(fires, fires[1:]) if a > b)
    assert swaps > 0


def test_unknown_link_send_raises():
    _, t = _setup()
    with pytest.raises(ScenarioReferenceError):
        t.send(NodeId("n1"), NodeId("n2"), "ping", {})


def test_stats_counts_sends_drops_delivered():
    sched, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          drop_rate=0.0, latency_low_ms=5, latency_high_ms=5))
    for _ in range(3):
        t.send(NodeId("n1"), NodeId("n2"), "ping", {})
    s = t.stats()
    assert s["sends"] == 3
    assert s["drops"] == 0
    # delivered isn't ticked until on_delivered is called.
    assert s["delivered"] == 0
    t.on_delivered(NodeId("n1"), NodeId("n2"))
    assert t.stats()["delivered"] == 1


def test_fan_out_returns_per_target_results():
    _, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          latency_low_ms=5, latency_high_ms=5))
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n3"),
                          latency_low_ms=10, latency_high_ms=10))
    out = fan_out(t, NodeId("n1"), [NodeId("n2"), NodeId("n3")], "hi", {})
    assert out == [5, 10]


def test_fan_out_handles_missing_link():
    _, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                          latency_low_ms=5, latency_high_ms=5))
    out = fan_out(t, NodeId("n1"), [NodeId("n2"), NodeId("n3")], "hi", {})
    assert out[0] == 5
    assert out[1] is None


def test_links_lists_in_insertion_order():
    _, t = _setup()
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n2")))
    t.add_link(LinkConfig(NodeId("n1"), NodeId("n3")))
    t.add_link(LinkConfig(NodeId("n2"), NodeId("n1")))
    pairs = [(l.src, l.dst) for l in t.links()]
    assert pairs == [
        (NodeId("n1"), NodeId("n2")),
        (NodeId("n1"), NodeId("n3")),
        (NodeId("n2"), NodeId("n1")),
    ]
