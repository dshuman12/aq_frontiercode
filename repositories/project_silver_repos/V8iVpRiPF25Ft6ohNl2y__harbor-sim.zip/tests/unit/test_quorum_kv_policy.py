"""Policy math for quorum_kv: read/write feasibility, staleness floor."""
from __future__ import annotations

import pytest

from harbor_sim.errors import QuorumPolicyError
from harbor_sim.ids import NodeId
from harbor_sim.protocols.quorum_kv.policy import QuorumPolicy


def test_basic_construction():
    p = QuorumPolicy(n_replicas=3, read_quorum=2, write_quorum=2)
    assert p.is_strongly_consistent()


def test_not_strongly_consistent_when_r_plus_w_le_n():
    p = QuorumPolicy(n_replicas=5, read_quorum=2, write_quorum=2)
    assert not p.is_strongly_consistent()


@pytest.mark.parametrize(
    "kwargs",
    [
        {"n_replicas": 0, "read_quorum": 1, "write_quorum": 1},
        {"n_replicas": 3, "read_quorum": 0, "write_quorum": 2},
        {"n_replicas": 3, "read_quorum": 4, "write_quorum": 2},
        {"n_replicas": 3, "read_quorum": 2, "write_quorum": 0},
        {"n_replicas": 3, "read_quorum": 2, "write_quorum": 4},
        {"n_replicas": 3, "read_quorum": 2, "write_quorum": 2, "staleness_floor": 4},
    ],
)
def test_invalid_inputs_raise(kwargs):
    with pytest.raises(ValueError):
        QuorumPolicy(**kwargs)


def test_write_feasible():
    p = QuorumPolicy(n_replicas=3, read_quorum=2, write_quorum=2)
    assert not p.write_feasible(1)
    assert p.write_feasible(2)
    assert p.write_feasible(3)


def test_read_feasible():
    p = QuorumPolicy(n_replicas=3, read_quorum=2, write_quorum=2)
    assert not p.read_feasible(1)
    assert p.read_feasible(2)


def test_require_feasibility_raises():
    p = QuorumPolicy(n_replicas=3, read_quorum=2, write_quorum=2)
    with pytest.raises(QuorumPolicyError, match="write"):
        p.require_write_feasible(1)
    with pytest.raises(QuorumPolicyError, match="read"):
        p.require_read_feasible(1)


def test_check_staleness_floor_zero_always_ok():
    p = QuorumPolicy(n_replicas=3, read_quorum=2, write_quorum=2, staleness_floor=0)
    # Disjoint read and write sets, but the floor is 0 -> ok.
    assert p.check_staleness({NodeId("n1")}, {NodeId("n2")})


def test_check_staleness_floor_one_requires_overlap():
    p = QuorumPolicy(n_replicas=3, read_quorum=2, write_quorum=2, staleness_floor=1)
    # Disjoint sets fail the floor.
    assert not p.check_staleness({NodeId("n1")}, {NodeId("n2")})
    # One overlap satisfies.
    assert p.check_staleness({NodeId("n1"), NodeId("n2")}, {NodeId("n2"), NodeId("n3")})


def test_check_staleness_floor_two_requires_two_overlap():
    p = QuorumPolicy(n_replicas=5, read_quorum=3, write_quorum=3, staleness_floor=2)
    overlap_1 = p.check_staleness(
        {NodeId("n1"), NodeId("n2"), NodeId("n3")},
        {NodeId("n3"), NodeId("n4"), NodeId("n5")},
    )
    assert overlap_1 is False
    overlap_2 = p.check_staleness(
        {NodeId("n1"), NodeId("n2"), NodeId("n3")},
        {NodeId("n2"), NodeId("n3"), NodeId("n4")},
    )
    assert overlap_2 is True
