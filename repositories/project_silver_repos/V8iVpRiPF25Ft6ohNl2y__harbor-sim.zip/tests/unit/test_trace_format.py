"""Round-trip tests for the trace format dataclasses themselves.

These exercise the to_dict/from_dict shape directly, without going
through the recorder. Useful when bumping the format - you want to
know the field-level round-trip is fine before debugging the writer.
"""
from __future__ import annotations

from harbor_sim.trace.format import (
    LATEST,
    SUPPORTED,
    V1,
    V2,
    EventFrame,
    SnapshotFrame,
    TraceHeader,
    WitnessFrame,
)


def test_version_constants():
    assert V1 == 1
    assert V2 == 2
    assert LATEST == V2
    assert V1 in SUPPORTED and V2 in SUPPORTED


def test_trace_header_round_trip():
    h = TraceHeader(
        version=LATEST,
        run_id=42,
        scenario_hash=0xDEAD,
        seed=99,
        started_at_ms=1000,
        extra={"k": "v"},
    )
    back = TraceHeader.from_dict(h.to_dict())
    assert back == h


def test_trace_header_from_partial_dict_uses_defaults():
    back = TraceHeader.from_dict({"seed": 5})
    assert back.version == LATEST
    assert back.seed == 5
    assert back.run_id == 0


def test_event_frame_round_trip():
    e = EventFrame(
        event_id=1,
        fire_at_ms=10,
        kind="deliver",
        target="n1",
        payload={"from": "n2", "kind": "ping"},
    )
    assert EventFrame.from_dict(e.to_dict()) == e


def test_event_frame_keys_are_short():
    # Wire keys are short on purpose - the codec doesn't compress
    # field names. If someone reverts to long keys, traces bloat ~3x.
    e = EventFrame(event_id=1, fire_at_ms=0, kind="x", target="y", payload={})
    keys = e.to_dict().keys()
    assert set(keys) == {"id", "t", "k", "to", "p"}


def test_event_frame_from_empty_dict_defaults():
    back = EventFrame.from_dict({})
    assert back.event_id == 0
    assert back.fire_at_ms == 0
    assert back.kind == ""


def test_witness_frame_round_trip():
    w = WitnessFrame(
        at_ms=500,
        invariant="agreement",
        severity="violation",
        detail={"term": 2, "leaders": ["n1", "n2"]},
    )
    assert WitnessFrame.from_dict(w.to_dict()) == w


def test_witness_frame_default_severity():
    back = WitnessFrame.from_dict({"t": 0, "inv": "x"})
    assert back.severity == "warn"


def test_snapshot_frame_round_trip():
    s = SnapshotFrame(
        node="n1",
        snapshot_id=7,
        state={"x": 1},
        compaction_index=10,
        compaction_term=2,
    )
    assert SnapshotFrame.from_dict(s.to_dict()) == s


def test_snapshot_frame_partial_dict_defaults():
    back = SnapshotFrame.from_dict({})
    assert back.node == ""
    assert back.snapshot_id == 0
    assert back.state == {}
