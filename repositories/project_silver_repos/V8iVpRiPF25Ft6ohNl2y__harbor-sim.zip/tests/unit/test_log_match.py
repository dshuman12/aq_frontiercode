"""Log-matching: prev-index/term consistency check + conflict finder."""
from __future__ import annotations

from harbor_sim.ids import LogIndex, Term
from harbor_sim.protocols.raftlite.log_match import (
    find_conflict_index,
    lowest_uncommitted_index,
    prev_log_matches,
    safe_to_commit,
)
from harbor_sim.storage.log import Log, LogEntry


def _entry(term: int, index: int) -> LogEntry:
    return LogEntry(term=Term(term), index=LogIndex(index), data={})


def test_prev_log_matches_at_zero_is_trivial():
    assert prev_log_matches(Log(), LogIndex(0), Term(0))
    assert prev_log_matches(Log(), LogIndex(0), Term(99))


def test_prev_log_matches_against_live_log():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(2, i))
    assert prev_log_matches(log, LogIndex(3), Term(2))
    assert not prev_log_matches(log, LogIndex(3), Term(1))


def test_prev_log_matches_above_last_returns_false():
    log = Log()
    log.append(_entry(1, 1))
    assert not prev_log_matches(log, LogIndex(99), Term(1))


def test_prev_log_matches_against_snapshot_prefix():
    log = Log(first_index=LogIndex(10), last_included_term=Term(3))
    assert prev_log_matches(log, LogIndex(5), Term(3))
    assert not prev_log_matches(log, LogIndex(5), Term(2))


def test_find_conflict_index_none_when_match():
    log = Log()
    log.append(_entry(1, 1))
    log.append(_entry(1, 2))
    log.append(_entry(2, 3))
    assert find_conflict_index(log, [_entry(1, 2), _entry(2, 3)]) is None


def test_find_conflict_index_returns_first_disagreement():
    log = Log()
    log.append(_entry(1, 1))
    log.append(_entry(1, 2))
    log.append(_entry(1, 3))
    conflict = find_conflict_index(log, [_entry(1, 2), _entry(2, 3)])
    assert conflict == LogIndex(3)


def test_find_conflict_index_none_when_past_end():
    log = Log()
    log.append(_entry(1, 1))
    assert find_conflict_index(log, [_entry(1, 5)]) is None


def test_safe_to_commit_requires_current_term():
    log = Log()
    log.append(_entry(1, 1))
    log.append(_entry(2, 2))
    assert not safe_to_commit(log, LogIndex(1), Term(2))
    assert safe_to_commit(log, LogIndex(2), Term(2))


def test_safe_to_commit_missing_index_false():
    log = Log()
    assert not safe_to_commit(log, LogIndex(99), Term(1))


def test_lowest_uncommitted_index():
    log = Log()
    for i in range(1, 6):
        log.append(_entry(1, i))
    assert lowest_uncommitted_index(log, LogIndex(2)) == LogIndex(3)
    assert lowest_uncommitted_index(log, LogIndex(5)) is None
