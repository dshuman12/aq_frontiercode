from __future__ import annotations

import io
import struct

import pytest

from harbor_sim.codec import (
    FORMAT_VERSION_LATEST,
    FORMAT_VERSION_SUPPORTED,
    HEADER_FMT,
    HEADER_SIZE,
    MAGIC,
    FrameType,
    decode_frame,
    encode_frame,
    iter_frames,
)
from harbor_sim.errors import CodecError


def _read(buf: bytes):
    return io.BytesIO(buf)


def test_encode_decode_round_trip():
    payload = {"hello": "world", "n": 42}
    blob = encode_frame(FrameType.EVENT, payload)
    frame = decode_frame(_read(blob))
    assert frame is not None
    assert frame.type == FrameType.EVENT
    assert frame.version == FORMAT_VERSION_LATEST
    assert frame.decoded() == payload


def test_decode_returns_none_at_eof():
    assert decode_frame(_read(b"")) is None


def test_decode_short_header_raises():
    with pytest.raises(CodecError, match="short header"):
        decode_frame(_read(b"H"))


def test_decode_bad_magic_raises():
    bad = b"XX" + b"\x00" * (HEADER_SIZE - 2)
    with pytest.raises(CodecError, match="bad magic"):
        decode_frame(_read(bad))


def test_decode_unsupported_version_raises():
    # Build a header by hand with version 99.
    bad_header = struct.pack(HEADER_FMT, MAGIC, 99, int(FrameType.EVENT), 0, 0)
    with pytest.raises(CodecError, match="unsupported format version"):
        decode_frame(_read(bad_header))


def test_decode_short_payload_raises():
    blob = encode_frame(FrameType.EVENT, {"a": 1})
    # Trim the payload by 1 byte.
    truncated = blob[:-1]
    with pytest.raises(CodecError, match="short payload"):
        decode_frame(_read(truncated))


def test_decode_crc_mismatch_raises():
    blob = bytearray(encode_frame(FrameType.EVENT, {"a": 1}))
    # Flip a byte in the payload.
    blob[HEADER_SIZE] ^= 0xFF
    with pytest.raises(CodecError, match="crc mismatch"):
        decode_frame(_read(bytes(blob)))


def test_decode_unknown_frame_type_raises():
    bad_header = struct.pack(
        HEADER_FMT, MAGIC, FORMAT_VERSION_LATEST, 250, 0, 0
    )
    # crc for empty payload is 0, which the encoder treats as signed 0.
    blob = bad_header + b""
    with pytest.raises(CodecError, match="unknown frame type"):
        decode_frame(_read(blob))


def test_iter_frames_walks_multiple():
    frames = [
        encode_frame(FrameType.EVENT, {"i": 0}),
        encode_frame(FrameType.EVENT, {"i": 1}),
        encode_frame(FrameType.WITNESS, {"k": "v"}),
    ]
    stream = _read(b"".join(frames))
    out = list(iter_frames(stream))
    assert [f.type for f in out] == [
        FrameType.EVENT,
        FrameType.EVENT,
        FrameType.WITNESS,
    ]
    assert [f.decoded() for f in out] == [{"i": 0}, {"i": 1}, {"k": "v"}]


def test_iter_frames_stops_at_eof_marker():
    frames = [
        encode_frame(FrameType.EVENT, {"i": 0}),
        encode_frame(FrameType.EOF, None),
        encode_frame(FrameType.EVENT, {"i": "should not be reached"}),
    ]
    out = list(iter_frames(_read(b"".join(frames))))
    assert len(out) == 1


def test_iter_frames_tolerates_missing_eof_marker():
    # v1-style streams don't have an EOF marker - we stop at EOF cleanly.
    blob = encode_frame(FrameType.EVENT, {"i": 0})
    out = list(iter_frames(_read(blob)))
    assert len(out) == 1


def test_supported_versions_includes_v1_and_latest():
    assert 1 in FORMAT_VERSION_SUPPORTED
    assert FORMAT_VERSION_LATEST in FORMAT_VERSION_SUPPORTED


def test_v1_frame_decodes_with_v2_reader():
    # Synthesize a v1 frame: same wire shape, just version=1.
    import msgpack
    from harbor_sim.hashing import crc32c

    payload = msgpack.packb({"i": 0}, use_bin_type=True)
    crc = crc32c(payload)
    crc_signed = crc - 0x1_0000_0000 if crc >= 0x8000_0000 else crc
    header = struct.pack(
        HEADER_FMT, MAGIC, 1, int(FrameType.EVENT), len(payload), crc_signed
    )
    blob = header + payload
    frame = decode_frame(_read(blob))
    assert frame is not None
    assert frame.version == 1
    assert frame.decoded() == {"i": 0}


def test_encode_uses_latest_version_only():
    blob = encode_frame(FrameType.EVENT, {"i": 0})
    magic, version, *_ = struct.unpack(HEADER_FMT, blob[:HEADER_SIZE])
    assert version == FORMAT_VERSION_LATEST
