"""Tests for the scenario YAML loader."""
from __future__ import annotations

import pytest

from harbor_sim.errors import (
    ScenarioReferenceError,
    ScenarioSyntaxError,
    ScenarioValidationError,
)
from harbor_sim.scenario.loader import load_text


VALID = """
scenario: basic
seed: 42
horizon_ms: 60000
protocol: raftlite
nodes:
  - { id: n1, role: replica }
  - { id: n2, role: replica }
  - { id: n3, role: replica }
links:
  - { from: n1, to: n2, latency_ms: [5, 20] }
  - { from: n2, to: n3, latency_ms: [5, 20] }
  - { from: n1, to: n3, latency_ms: [5, 20] }
workload:
  kind: kv
  clients: 2
  ops_per_client: 100
"""


def test_parses_basic_scenario():
    sc = load_text(VALID)
    assert sc.name == "basic"
    assert sc.seed == 42
    assert sc.horizon_ms == 60_000
    assert sc.protocol == "raftlite"
    assert len(sc.nodes) == 3
    assert len(sc.links) == 3
    assert sc.workload.clients == 2


def test_top_level_not_mapping_raises():
    with pytest.raises(ScenarioSyntaxError, match="top-level"):
        load_text("- a\n- b\n")


def test_syntax_error_carries_location():
    bad = "scenario: foo\n  : x\n"
    with pytest.raises(ScenarioSyntaxError) as exc:
        load_text(bad)
    assert exc.value.line is not None


def test_negative_seed_rejected():
    with pytest.raises(ScenarioValidationError, match="seed"):
        load_text("scenario: x\nseed: -1\nnodes: [{id: n1}]\n")


def test_zero_horizon_rejected():
    with pytest.raises(ScenarioValidationError, match="horizon_ms"):
        load_text("scenario: x\nhorizon_ms: 0\nnodes: [{id: n1}]\n")


def test_negative_horizon_rejected():
    with pytest.raises(ScenarioValidationError, match="horizon_ms"):
        load_text("scenario: x\nhorizon_ms: -10\nnodes: [{id: n1}]\n")


def test_empty_nodes_rejected():
    with pytest.raises(ScenarioValidationError, match="nodes"):
        load_text("scenario: x\nnodes: []\n")


def test_missing_nodes_rejected():
    with pytest.raises(ScenarioValidationError, match="nodes"):
        load_text("scenario: x\n")


def test_duplicate_node_id_rejected():
    bad = """
scenario: dup
nodes:
  - { id: n1 }
  - { id: n1 }
"""
    with pytest.raises(ScenarioValidationError, match="duplicate"):
        load_text(bad)


def test_bad_node_id_rejected():
    bad = """
scenario: bad
nodes:
  - { id: "n 1" }
"""
    with pytest.raises(ScenarioValidationError, match="alphanumeric"):
        load_text(bad)


def test_negative_skew_accepted():
    # Negative skew is a valid scenario - it represents a node whose
    # clock runs behind the global clock.
    sc = load_text("""
scenario: neg-skew
nodes:
  - { id: n1, clock_skew_ms: -50 }
""")
    assert sc.nodes[0].clock_skew_ms == -50


def test_initial_snapshot_id_threaded_through():
    sc = load_text("""
scenario: x
nodes:
  - { id: n1, initial_snapshot_id: 7 }
""")
    assert sc.nodes[0].initial_snapshot_id == 7


def test_initial_snapshot_must_be_int_or_null():
    with pytest.raises(ScenarioValidationError, match="initial_snapshot_id"):
        load_text("""
scenario: x
nodes:
  - { id: n1, initial_snapshot_id: oops }
""")


def test_links_default_empty():
    sc = load_text("""
scenario: x
nodes:
  - { id: n1 }
""")
    assert sc.links == []


def test_links_must_reference_known_nodes():
    bad = """
scenario: x
nodes:
  - { id: n1 }
links:
  - { from: n1, to: nowhere, latency_ms: [5, 20] }
"""
    with pytest.raises(ScenarioReferenceError):
        load_text(bad)


def test_latency_can_be_scalar():
    sc = load_text("""
scenario: x
nodes:
  - { id: n1 }
  - { id: n2 }
links:
  - { from: n1, to: n2, latency_ms: 10 }
""")
    assert sc.links[0].latency_low_ms == 10
    assert sc.links[0].latency_high_ms == 10


def test_latency_inverted_range_rejected():
    bad = """
scenario: x
nodes: [{id: n1}, {id: n2}]
links:
  - { from: n1, to: n2, latency_ms: [50, 10] }
"""
    with pytest.raises(ScenarioValidationError, match="out of order"):
        load_text(bad)


def test_negative_latency_rejected():
    bad = """
scenario: x
nodes: [{id: n1}, {id: n2}]
links:
  - { from: n1, to: n2, latency_ms: [-1, 10] }
"""
    with pytest.raises(ScenarioValidationError):
        load_text(bad)


def test_drop_rate_out_of_range_rejected():
    bad = """
scenario: x
nodes: [{id: n1}, {id: n2}]
links:
  - { from: n1, to: n2, latency_ms: 5, drop_rate: 1.5 }
"""
    with pytest.raises(ScenarioValidationError, match="drop_rate"):
        load_text(bad)


def test_capacity_must_be_positive():
    bad = """
scenario: x
nodes: [{id: n1}, {id: n2}]
links:
  - { from: n1, to: n2, latency_ms: 5, capacity: 0 }
"""
    with pytest.raises(ScenarioValidationError, match="capacity"):
        load_text(bad)


def test_workload_defaults_to_noop():
    sc = load_text("""
scenario: x
nodes: [{id: n1}]
""")
    assert sc.workload.kind == "noop"
    assert sc.workload.clients == 0


def test_workload_negative_clients_rejected():
    bad = """
scenario: x
nodes: [{id: n1}]
workload: { clients: -1 }
"""
    with pytest.raises(ScenarioValidationError, match="clients"):
        load_text(bad)


def test_failure_partition_round_trip():
    sc = load_text("""
scenario: x
nodes: [{id: n1}, {id: n2}]
links:
  - { from: n1, to: n2, latency_ms: 5 }
failures:
  - { at_ms: 1000, kind: partition, a: n1, b: n2, duration_ms: 5000 }
""")
    assert len(sc.failures) == 1
    assert sc.failures[0].kind == "partition"
    assert sc.failures[0].duration_ms == 5000


def test_failure_kind_unknown_rejected():
    bad = """
scenario: x
nodes: [{id: n1}]
failures:
  - { at_ms: 0, kind: meltdown }
"""
    with pytest.raises(ScenarioValidationError, match="unknown kind"):
        load_text(bad)


def test_failure_references_unknown_node():
    bad = """
scenario: x
nodes: [{id: n1}]
failures:
  - { at_ms: 0, kind: crash, target: ghost }
"""
    with pytest.raises(ScenarioReferenceError):
        load_text(bad)


def test_scenario_hash_stable_across_runs():
    from harbor_sim.hashing import stable_hash

    a = load_text(VALID)
    b = load_text(VALID)
    assert stable_hash(a) == stable_hash(b)
