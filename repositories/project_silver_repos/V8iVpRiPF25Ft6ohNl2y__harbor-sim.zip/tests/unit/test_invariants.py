from __future__ import annotations

from harbor_sim.invariants.agreement import AgreementChecker
from harbor_sim.invariants.election_safety import ElectionSafetyChecker
from harbor_sim.invariants.linearizability import LinearizabilityChecker
from harbor_sim.trace.format import EventFrame


def _ev(kind: str, payload: dict, fire_at_ms: int = 0) -> EventFrame:
    return EventFrame(
        event_id=0, fire_at_ms=fire_at_ms, kind=kind, target="x", payload=payload
    )


def test_agreement_single_leader_per_term_passes():
    ac = AgreementChecker()
    ac.observe(_ev("became_leader", {"term": 1, "node": "n1"}))
    ac.observe(_ev("became_leader", {"term": 2, "node": "n1"}))
    ac.observe(_ev("became_leader", {"term": 3, "node": "n2"}))
    assert ac.passed()


def test_agreement_same_node_same_term_no_violation():
    ac = AgreementChecker()
    ac.observe(_ev("became_leader", {"term": 1, "node": "n1"}))
    ac.observe(_ev("became_leader", {"term": 1, "node": "n1"}))
    assert ac.passed()


def test_agreement_two_leaders_in_term_records_violation():
    ac = AgreementChecker()
    ac.observe(_ev("became_leader", {"term": 1, "node": "n1"}))
    ac.observe(_ev("became_leader", {"term": 1, "node": "n2"}))
    assert not ac.passed()
    wits = list(ac.witnesses())
    assert len(wits) == 1
    assert wits[0].detail["term"] == 1
    assert wits[0].detail["first_leader"] == "n1"
    assert wits[0].detail["second_leader"] == "n2"


def test_agreement_ignores_unrelated_events():
    ac = AgreementChecker()
    ac.observe(_ev("tick", {}))
    ac.observe(_ev("deliver", {"from": "n1"}))
    assert ac.passed()


def test_agreement_ignores_malformed_payload():
    ac = AgreementChecker()
    ac.observe(_ev("became_leader", {"term": -1, "node": "n1"}))
    ac.observe(_ev("became_leader", {"term": 1, "node": ""}))
    assert ac.passed()


def test_election_safety_first_commit_wins():
    es = ElectionSafetyChecker()
    es.observe(_ev("commit", {"index": 1, "term": 2, "op": "put"}))
    es.observe(_ev("commit", {"index": 1, "term": 2, "op": "put"}))
    assert es.passed()


def test_election_safety_term_mismatch_records():
    es = ElectionSafetyChecker()
    es.observe(_ev("commit", {"index": 1, "term": 2, "op": "put"}))
    es.observe(_ev("commit", {"index": 1, "term": 3, "op": "put"}))
    assert not es.passed()


def test_election_safety_op_mismatch_records():
    es = ElectionSafetyChecker()
    es.observe(_ev("commit", {"index": 1, "term": 2, "op": "put_x"}))
    es.observe(_ev("commit", {"index": 1, "term": 2, "op": "put_y"}))
    assert not es.passed()


def test_linearizability_read_matching_write_passes():
    lc = LinearizabilityChecker()
    lc.observe(_ev("kv_write_complete", {
        "rid": "w1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "write_quorum": ["n1", "n2"],
    }))
    lc.observe(_ev("kv_read_complete", {
        "rid": "r1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "read_set": ["n1", "n3"],
    }))
    assert lc.passed()


def test_linearizability_read_with_no_matching_write():
    lc = LinearizabilityChecker()
    lc.observe(_ev("kv_read_complete", {
        "rid": "r1", "key": "x", "value": 9,
        "writer": "n1", "generation": 1, "read_set": [],
    }))
    assert not lc.passed()
    wits = list(lc.witnesses())
    assert wits[0].detail["kind"] == "no_matching_write"


def test_linearizability_floor_zero_skips_check():
    lc = LinearizabilityChecker(staleness_floor=0)
    lc.observe(_ev("kv_write_complete", {
        "rid": "w1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "write_quorum": ["n1", "n2"],
    }))
    lc.observe(_ev("kv_read_complete", {
        "rid": "r1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "read_set": ["n3", "n4"],
    }))
    assert lc.passed()


def test_linearizability_floor_one_disjoint_violates():
    lc = LinearizabilityChecker(staleness_floor=1)
    lc.observe(_ev("kv_write_complete", {
        "rid": "w1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "write_quorum": ["n1", "n2"],
    }))
    lc.observe(_ev("kv_read_complete", {
        "rid": "r1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "read_set": ["n3", "n4"],
    }))
    assert not lc.passed()


def test_linearizability_floor_one_overlap_ok():
    lc = LinearizabilityChecker(staleness_floor=1)
    lc.observe(_ev("kv_write_complete", {
        "rid": "w1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "write_quorum": ["n1", "n2"],
    }))
    lc.observe(_ev("kv_read_complete", {
        "rid": "r1", "key": "x", "value": 1,
        "writer": "n1", "generation": 1, "read_set": ["n2", "n3"],
    }))
    assert lc.passed()
