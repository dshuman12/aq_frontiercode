"""Tests for the logging shim."""
from __future__ import annotations

import io
import json

import pytest

from harbor_sim.logging_ import (
    JsonSink,
    Level,
    LogRecord,
    NullSink,
    Sink,
    TextSink,
    debug,
    error,
    get_level,
    get_sink,
    info,
    log,
    set_level,
    set_sink,
    trace,
    warn,
    with_context,
)


class CapturingSink(Sink):
    def __init__(self):
        self.records: list[LogRecord] = []

    def write(self, record: LogRecord) -> None:
        self.records.append(record)


@pytest.fixture(autouse=True)
def _reset_global():
    old_level = get_level()
    old_sink = get_sink()
    yield
    set_level(old_level)
    set_sink(old_sink)


def test_default_sink_is_text():
    assert isinstance(get_sink(), TextSink)


def test_default_level_is_info():
    assert get_level() == Level.INFO


def test_filter_by_level():
    cap = CapturingSink()
    set_sink(cap)
    set_level(Level.WARN)
    info("nope")
    debug("nope")
    warn("yes")
    error("yes too")
    assert [r.message for r in cap.records] == ["yes", "yes too"]


def test_trace_level_lower_than_debug():
    cap = CapturingSink()
    set_sink(cap)
    set_level(Level.TRACE)
    trace("hello")
    assert len(cap.records) == 1


def test_silent_drops_everything():
    cap = CapturingSink()
    set_sink(cap)
    set_level(Level.SILENT)
    for fn in (trace, debug, info, warn, error):
        fn("nope")
    assert cap.records == []


def test_fields_attached_to_record():
    cap = CapturingSink()
    set_sink(cap)
    info("hello", node="n1", replica=0)
    assert cap.records[0].fields == {"node": "n1", "replica": 0}


def test_text_sink_renders_known_layout():
    stream = io.StringIO()
    sink = TextSink(stream=stream)
    sink.write(LogRecord(Level.INFO, "boot", {"node": "n1"}))
    assert "[info ]" in stream.getvalue()
    assert "boot" in stream.getvalue()
    assert "node=n1" in stream.getvalue()


def test_text_sink_without_fields():
    stream = io.StringIO()
    sink = TextSink(stream=stream)
    sink.write(LogRecord(Level.WARN, "huh", {}))
    out = stream.getvalue()
    assert out.endswith("huh\n")


def test_json_sink_round_trips():
    stream = io.StringIO()
    sink = JsonSink(stream=stream)
    sink.write(LogRecord(Level.ERROR, "boom", {"x": 1, "y": "z"}))
    parsed = json.loads(stream.getvalue())
    assert parsed == {"lvl": "ERROR", "msg": "boom", "x": 1, "y": "z"}


def test_null_sink_does_nothing():
    NullSink().write(LogRecord(Level.INFO, "x", {}))


def test_with_context_merges_fields():
    cap = CapturingSink()
    set_sink(cap)
    set_level(Level.TRACE)
    node_log = with_context(node="n1")
    node_log(Level.INFO, "hello")
    node_log(Level.INFO, "again", op="put")
    assert cap.records[0].fields == {"node": "n1"}
    assert cap.records[1].fields == {"node": "n1", "op": "put"}


def test_with_context_local_fields_override_ctx():
    cap = CapturingSink()
    set_sink(cap)
    set_level(Level.TRACE)
    node_log = with_context(node="n1")
    node_log(Level.INFO, "switch", node="n2")
    assert cap.records[0].fields == {"node": "n2"}


def test_set_sink_swaps_destination():
    a = CapturingSink()
    b = CapturingSink()
    set_sink(a)
    set_level(Level.TRACE)
    info("to a")
    set_sink(b)
    info("to b")
    assert [r.message for r in a.records] == ["to a"]
    assert [r.message for r in b.records] == ["to b"]


def test_level_set_and_get_round_trip():
    set_level(Level.WARN)
    assert get_level() == Level.WARN
    set_level(Level.DEBUG)
    assert get_level() == Level.DEBUG
