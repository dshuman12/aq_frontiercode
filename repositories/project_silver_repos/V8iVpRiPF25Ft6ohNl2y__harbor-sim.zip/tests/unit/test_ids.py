"""Tests for the ID layer.

Most of the type-level guarantees are mypy-only and don't show up here.
What this file does cover: the allocator's monotonic / deterministic
contract, the composite key reprs (because the trace format prints
them), and the loose validation helpers the scenario loader leans on.
"""
from __future__ import annotations

import pytest

from harbor_sim.ids import (
    IdAllocator,
    LogEntryKey,
    LogIndex,
    NodeId,
    ReplicaId,
    ReplicaRef,
    Term,
    is_node_id,
)


def test_allocator_starts_at_zero():
    a = IdAllocator("ev")
    assert a.alloc() == 0
    assert a.alloc() == 1
    assert a.alloc() == 2


def test_allocator_peek_does_not_advance():
    a = IdAllocator("ev")
    assert a.peek() == 0
    a.alloc()
    a.alloc()
    assert a.peek() == 2
    assert a.alloc() == 2


def test_allocator_reset_with_default_zero():
    a = IdAllocator("ev")
    for _ in range(5):
        a.alloc()
    a.reset()
    assert a.alloc() == 0


def test_allocator_reset_to_arbitrary_value():
    a = IdAllocator("ev")
    a.reset(to=1000)
    assert a.alloc() == 1000
    assert a.alloc() == 1001


def test_allocator_reset_rejects_negative():
    a = IdAllocator("ev")
    with pytest.raises(ValueError):
        a.reset(to=-1)


def test_allocator_repr_is_useful():
    a = IdAllocator("ev")
    a.alloc()
    rendered = repr(a)
    assert "ev" in rendered
    assert "next=1" in rendered


def test_allocator_independence():
    # Two allocators with different names advance independently.
    ev = IdAllocator("ev")
    snap = IdAllocator("snap")
    for _ in range(3):
        ev.alloc()
    assert snap.alloc() == 0


def test_replica_ref_str():
    ref = ReplicaRef(NodeId("n1"), ReplicaId(0))
    assert str(ref) == "n1#0"


def test_replica_ref_equality_and_hash():
    a = ReplicaRef(NodeId("n1"), ReplicaId(0))
    b = ReplicaRef(NodeId("n1"), ReplicaId(0))
    c = ReplicaRef(NodeId("n1"), ReplicaId(1))
    assert a == b
    assert hash(a) == hash(b)
    assert a != c
    assert {a, b, c} == {a, c}


def test_log_entry_key_str():
    k = LogEntryKey(Term(2), LogIndex(7))
    assert str(k) == "T2/I7"


def test_log_entry_key_ordering_is_by_field_tuple():
    k1 = LogEntryKey(Term(2), LogIndex(0))
    k2 = LogEntryKey(Term(2), LogIndex(1))
    assert (k1.term, k1.index) < (k2.term, k2.index)


@pytest.mark.parametrize(
    "value,expected",
    [
        ("n1", True),
        ("node-1", True),
        ("node_one", True),
        ("dc.us-east.1", True),
        ("Node1", True),
        ("", False),
        ("n 1", False),
        ("n/1", False),
        ("n\\1", False),
        ("n#1", False),
    ],
)
def test_is_node_id(value, expected):
    assert is_node_id(value) is expected


def test_is_node_id_rejects_non_strings():
    assert not is_node_id(1)
    assert not is_node_id(None)
    assert not is_node_id(["n1"])
