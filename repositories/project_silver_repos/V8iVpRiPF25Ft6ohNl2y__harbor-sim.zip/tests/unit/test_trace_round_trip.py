"""Round-trip tests for the trace recorder and reader."""
from __future__ import annotations

import io
import json
from pathlib import Path

import pytest
import zstandard as zstd

from harbor_sim.clock import SimClock
from harbor_sim.ids import EventId
from harbor_sim.rng import RngBundle
from harbor_sim.scheduler import Event, Scheduler
from harbor_sim.trace.format import (
    LATEST,
    V1,
    V2,
    EventFrame,
    SnapshotFrame,
    TraceHeader,
    WitnessFrame,
)
from harbor_sim.trace.migrate import migrate_v1_to_v2
from harbor_sim.trace.reader import TraceReader
from harbor_sim.trace.recorder import TraceRecorder


def _header() -> TraceHeader:
    return TraceHeader(
        version=LATEST,
        run_id=1,
        scenario_hash=0xDEADBEEF,
        seed=42,
        started_at_ms=0,
    )


def test_recorder_writes_and_reader_reads(tmp_path: Path):
    path = tmp_path / "out.trace"
    rec = TraceRecorder(path=path)
    rec.open(_header())
    rec.record(Event(id=EventId(1), fire_at_ms=10, tie_break=0, seq=0,
                     kind="tick", target="n1", payload={"x": 1}))
    rec.record(Event(id=EventId(2), fire_at_ms=20, tie_break=0, seq=1,
                     kind="deliver", target="n2", payload={"from": "n1"}))
    rec.close()

    reader = TraceReader(path=path)
    h = reader.header()
    assert h.run_id == 1
    assert h.version == LATEST
    events = list(reader.events())
    assert [(e.fire_at_ms, e.kind, e.target) for e in events] == [
        (10, "tick", "n1"),
        (20, "deliver", "n2"),
    ]


def test_reader_eof_marker_terminates(tmp_path: Path):
    path = tmp_path / "out.trace"
    rec = TraceRecorder(path=path)
    rec.open(_header())
    rec.record(Event(id=EventId(1), fire_at_ms=5, tie_break=0, seq=0,
                     kind="tick", target="n1", payload={}))
    rec.close()
    reader = TraceReader(path=path)
    events = list(reader.events())
    assert len(events) == 1


def test_witness_and_snapshot_round_trip(tmp_path: Path):
    path = tmp_path / "out.trace"
    rec = TraceRecorder(path=path)
    rec.open(_header())
    rec.witness(WitnessFrame(at_ms=100, invariant="agreement",
                             severity="violation", detail={"term": 3}))
    rec.snapshot(SnapshotFrame(node="n1", snapshot_id=7,
                               state={"x": 1}, compaction_index=5,
                               compaction_term=2))
    rec.close()
    reader = TraceReader(path=path)
    wits = list(reader.witnesses())
    snaps = list(reader.snapshots())
    assert len(wits) == 1 and wits[0].invariant == "agreement"
    assert len(snaps) == 1 and snaps[0].snapshot_id == 7


def test_reader_rejects_missing_file(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        TraceReader(path=tmp_path / "nope.trace")


def test_recorder_record_before_open_raises(tmp_path: Path):
    rec = TraceRecorder(path=tmp_path / "x")
    with pytest.raises(RuntimeError, match="opened"):
        rec.record(Event(id=EventId(1), fire_at_ms=0, tie_break=0, seq=0,
                         kind="t", target="n1", payload={}))


def test_recorder_double_open_raises(tmp_path: Path):
    rec = TraceRecorder(path=tmp_path / "x")
    rec.open(_header())
    with pytest.raises(RuntimeError, match="already open"):
        rec.open(_header())


def test_recorder_close_twice_is_ok(tmp_path: Path):
    rec = TraceRecorder(path=tmp_path / "x")
    rec.open(_header())
    rec.close()
    rec.close()


def test_v1_trace_migrates_to_v2(tmp_path: Path):
    # Synthesize a v1 trace: newline-delimited JSON inside zstd.
    v1_lines = [
        json.dumps({"version": V1, "run_id": 5, "scenario_hash": 1, "seed": 0,
                    "started_at_ms": 0}),
        json.dumps({"type": "event", "event_id": 1, "fire_at_ms": 10,
                    "kind": "tick", "target": "n1", "payload": {"x": 1}}),
        json.dumps({"type": "event", "event_id": 2, "fire_at_ms": 20,
                    "kind": "deliver", "target": "n2", "payload": {"from": "n1"}}),
    ]
    raw = ("\n".join(v1_lines) + "\n").encode("utf-8")
    cctx = zstd.ZstdCompressor(level=3)
    compressed = cctx.compress(raw)
    src = tmp_path / "v1.trace"
    src.write_bytes(compressed)

    dst = tmp_path / "v2.trace"
    n = migrate_v1_to_v2(src, dst)
    assert n == 2

    reader = TraceReader(path=dst)
    assert reader.header().version == V2
    events = list(reader.events())
    assert len(events) == 2
    assert events[0].fire_at_ms == 10
    assert events[0].kind == "tick"
    assert events[1].kind == "deliver"


def test_v1_migration_rejects_non_v1_input(tmp_path: Path):
    from harbor_sim.errors import CodecError

    raw = (json.dumps({"version": V2, "run_id": 0, "scenario_hash": 0, "seed": 0,
                        "started_at_ms": 0}) + "\n").encode("utf-8")
    cctx = zstd.ZstdCompressor(level=3)
    src = tmp_path / "x.trace"
    src.write_bytes(cctx.compress(raw))
    with pytest.raises(CodecError, match="not a v1 trace"):
        migrate_v1_to_v2(src, tmp_path / "out.trace")


def test_recorder_can_be_used_as_scheduler_hook(tmp_path: Path):
    # Drive the actual scheduler through the recorder.
    clock = SimClock()
    sched = Scheduler(clock=clock, rng=RngBundle(seed=0))
    rec = TraceRecorder(path=tmp_path / "h.trace")
    rec.open(_header())
    sched.install_hook(rec.record)
    sched.schedule(10, "tick", "n1")
    sched.schedule(20, "tick", "n2")
    sched.run_until(50, lambda ev: None)
    rec.close()

    reader = TraceReader(path=tmp_path / "h.trace")
    events = list(reader.events())
    assert [e.fire_at_ms for e in events] == [10, 20]
