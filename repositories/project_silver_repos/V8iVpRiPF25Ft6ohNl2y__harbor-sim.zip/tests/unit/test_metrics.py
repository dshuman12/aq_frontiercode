from __future__ import annotations

import pytest

from harbor_sim import metrics


@pytest.fixture(autouse=True)
def _reset():
    metrics.reset()
    yield
    metrics.reset()


def test_counter_starts_at_zero():
    c = metrics.counter("foo")
    assert c.value == 0


def test_counter_inc_default_one():
    c = metrics.counter("foo")
    c.inc()
    assert c.value == 1


def test_counter_inc_arbitrary():
    c = metrics.counter("foo")
    c.inc(5)
    c.inc(3)
    assert c.value == 8


def test_same_counter_returned_on_repeat():
    a = metrics.counter("foo")
    b = metrics.counter("foo")
    assert a is b


def test_gauge_set():
    g = metrics.gauge("g")
    g.set(3.14)
    assert g.value == 3.14
    g.set(42)
    assert g.value == 42.0


def test_histogram_observe_and_percentile():
    h = metrics.histogram("h")
    for v in range(100):
        h.observe(v)
    assert abs(h.mean() - 49.5) < 0.5
    assert h.percentile(0.5) == 49
    assert h.percentile(0.95) == 94
    assert h.percentile(0.99) == 98


def test_histogram_empty():
    h = metrics.histogram("h")
    assert h.mean() == 0.0
    assert h.percentile(0.5) == 0.0


def test_histogram_rejects_bad_percentile():
    h = metrics.histogram("h")
    h.observe(1)
    with pytest.raises(ValueError):
        h.percentile(1.5)
    with pytest.raises(ValueError):
        h.percentile(-0.1)


def test_type_mismatch_raises():
    metrics.counter("x")
    with pytest.raises(TypeError):
        metrics.gauge("x")
    with pytest.raises(TypeError):
        metrics.histogram("x")


def test_snapshot_includes_all_kinds():
    metrics.counter("a").inc(3)
    metrics.gauge("b").set(5.0)
    h = metrics.histogram("c")
    for v in [1, 2, 3]:
        h.observe(v)
    snap = metrics.snapshot()
    assert snap["a"]["kind"] == "counter"
    assert snap["a"]["value"] == 3
    assert snap["b"]["kind"] == "gauge"
    assert snap["b"]["value"] == 5.0
    assert snap["c"]["kind"] == "histogram"
    assert snap["c"]["n"] == 3


def test_reset_clears_registry():
    metrics.counter("x").inc()
    metrics.reset()
    assert metrics.snapshot() == {}


def test_timer_records_duration():
    h = metrics.histogram("t")
    with metrics.Timer("t"):
        sum(range(100))
    assert len(h.samples) == 1
    assert h.samples[0] >= 0
