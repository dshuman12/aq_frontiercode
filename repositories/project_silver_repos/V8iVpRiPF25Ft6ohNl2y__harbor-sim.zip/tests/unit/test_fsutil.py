from __future__ import annotations

from pathlib import Path

import pytest

from harbor_sim.fsutil import (
    atomic_write,
    atomic_write_bytes,
    atomic_write_text,
    ensure_dir,
    read_bytes,
    read_text,
    safe_replace,
    walk_files,
)


def test_ensure_dir_creates_nested(tmp_path: Path):
    target = tmp_path / "a" / "b" / "c"
    ensure_dir(target)
    assert target.is_dir()


def test_ensure_dir_is_idempotent(tmp_path: Path):
    target = tmp_path / "x"
    ensure_dir(target)
    ensure_dir(target)
    assert target.is_dir()


def test_atomic_write_bytes_creates_file(tmp_path: Path):
    target = tmp_path / "out.bin"
    atomic_write_bytes(target, b"hello")
    assert target.read_bytes() == b"hello"


def test_atomic_write_bytes_overwrites(tmp_path: Path):
    target = tmp_path / "out.bin"
    target.write_bytes(b"old")
    atomic_write_bytes(target, b"new")
    assert target.read_bytes() == b"new"


def test_atomic_write_bytes_creates_parent(tmp_path: Path):
    target = tmp_path / "nested" / "deep" / "out.bin"
    atomic_write_bytes(target, b"hello")
    assert target.read_bytes() == b"hello"


def test_atomic_write_bytes_leaves_no_tempfiles(tmp_path: Path):
    target = tmp_path / "out.bin"
    atomic_write_bytes(target, b"hello")
    entries = list(tmp_path.iterdir())
    assert len(entries) == 1
    assert entries[0].name == "out.bin"


def test_atomic_write_text(tmp_path: Path):
    target = tmp_path / "out.txt"
    atomic_write_text(target, "hello\nworld\n")
    assert target.read_text() == "hello\nworld\n"


def test_atomic_write_context_manager(tmp_path: Path):
    target = tmp_path / "out.bin"
    with atomic_write(target, mode="wb") as fh:
        fh.write(b"hello")
        fh.write(b" world")
    assert target.read_bytes() == b"hello world"


def test_atomic_write_context_manager_text(tmp_path: Path):
    target = tmp_path / "out.txt"
    with atomic_write(target, mode="w") as fh:
        fh.write("hello\n")
    assert target.read_text() == "hello\n"


def test_atomic_write_rolls_back_on_exception(tmp_path: Path):
    target = tmp_path / "out.bin"
    target.write_bytes(b"original")
    with pytest.raises(RuntimeError):
        with atomic_write(target, mode="wb") as fh:
            fh.write(b"new contents")
            raise RuntimeError("boom")
    assert target.read_bytes() == b"original"
    # No leftover temp files.
    leftovers = [p for p in tmp_path.iterdir() if p.name.endswith(".tmp")]
    assert leftovers == []


def test_atomic_write_rejects_unsupported_mode(tmp_path: Path):
    target = tmp_path / "out.bin"
    with pytest.raises(ValueError, match="unsupported mode"):
        with atomic_write(target, mode="a"):
            pass


def test_safe_replace_moves_files(tmp_path: Path):
    src = tmp_path / "src.bin"
    dst = tmp_path / "dst.bin"
    src.write_bytes(b"hello")
    safe_replace(src, dst)
    assert not src.exists()
    assert dst.read_bytes() == b"hello"


def test_safe_replace_missing_source_raises(tmp_path: Path):
    src = tmp_path / "nope"
    dst = tmp_path / "dst"
    with pytest.raises(FileNotFoundError, match="source missing"):
        safe_replace(src, dst)


def test_safe_replace_creates_dst_parent(tmp_path: Path):
    src = tmp_path / "src.bin"
    dst = tmp_path / "nested" / "deep" / "dst.bin"
    src.write_bytes(b"hello")
    safe_replace(src, dst)
    assert dst.read_bytes() == b"hello"


def test_walk_files_empty_root(tmp_path: Path):
    out = list(walk_files(tmp_path))
    assert out == []


def test_walk_files_missing_root(tmp_path: Path):
    out = list(walk_files(tmp_path / "does-not-exist"))
    assert out == []


def test_walk_files_stable_order(tmp_path: Path):
    for name in ["z", "a", "m"]:
        (tmp_path / name).write_text("x")
    out = [p.name for p in walk_files(tmp_path)]
    assert out == ["a", "m", "z"]


def test_walk_files_recurses(tmp_path: Path):
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "f.txt").write_text("a")
    (tmp_path / "a" / "b").mkdir()
    (tmp_path / "a" / "b" / "g.txt").write_text("b")
    (tmp_path / "c.txt").write_text("c")
    out = [p.relative_to(tmp_path).as_posix() for p in walk_files(tmp_path)]
    assert out == ["a/b/g.txt", "a/f.txt", "c.txt"]


def test_walk_files_filters_by_suffix(tmp_path: Path):
    (tmp_path / "a.yaml").write_text("x")
    (tmp_path / "b.txt").write_text("x")
    (tmp_path / "c.yaml").write_text("x")
    out = [p.name for p in walk_files(tmp_path, suffix=".yaml")]
    assert out == ["a.yaml", "c.yaml"]


def test_read_bytes_text_helpers(tmp_path: Path):
    p = tmp_path / "x"
    p.write_bytes(b"hello")
    assert read_bytes(p) == b"hello"
    p.write_text("world")
    assert read_text(p) == "world"
