"""scenario.expand: full-mesh, star, crash-at, partition-at helpers."""
from __future__ import annotations

import pytest

from harbor_sim.errors import ScenarioReferenceError
from harbor_sim.scenario.expand import (
    add_replica,
    crash_at,
    full_mesh,
    partition_at,
    star,
)
from harbor_sim.scenario.model import NodeSpec, Scenario, WorkloadSpec


def _base(n: int) -> Scenario:
    return Scenario(
        name="t",
        seed=0,
        horizon_ms=1000,
        protocol="raftlite",
        nodes=[NodeSpec(id=f"n{i+1}") for i in range(n)],
        links=[],
        workload=WorkloadSpec(),
    )


def test_full_mesh_adds_all_pairs():
    sc = _base(3)
    full_mesh(sc)
    pairs = {(l.src, l.dst) for l in sc.links}
    assert pairs == {
        ("n1", "n2"), ("n1", "n3"),
        ("n2", "n1"), ("n2", "n3"),
        ("n3", "n1"), ("n3", "n2"),
    }


def test_full_mesh_respects_existing():
    sc = _base(3)
    from harbor_sim.scenario.model import LinkSpec

    sc.links.append(LinkSpec(src="n1", dst="n2",
                              latency_low_ms=100, latency_high_ms=100,
                              bidirectional=False))
    full_mesh(sc)
    n1_n2 = next(l for l in sc.links if l.src == "n1" and l.dst == "n2")
    # The existing link's latency override should be preserved.
    assert n1_n2.latency_low_ms == 100


def test_full_mesh_link_overrides_apply_to_new():
    sc = _base(2)
    full_mesh(sc, latency_low_ms=50, latency_high_ms=80)
    for l in sc.links:
        assert l.latency_low_ms == 50
        assert l.latency_high_ms == 80


def test_star_topology():
    sc = _base(4)
    star(sc, center="n1")
    assert len(sc.links) == 3
    for l in sc.links:
        assert l.src == "n1"
        assert l.dst in {"n2", "n3", "n4"}


def test_star_unknown_center_raises():
    sc = _base(3)
    with pytest.raises(ScenarioReferenceError):
        star(sc, center="ghost")


def test_add_replica_picks_unique_id():
    sc = _base(3)
    spec = add_replica(sc)
    assert spec.id == "n4"
    spec2 = add_replica(sc)
    assert spec2.id == "n5"


def test_add_replica_skips_gaps():
    sc = _base(3)
    sc.nodes.append(NodeSpec(id="n5"))
    spec = add_replica(sc)
    assert spec.id == "n4"


def test_crash_at_appends_failure():
    sc = _base(2)
    crash_at(sc, "n1", at_ms=1000)
    assert len(sc.failures) == 1
    assert sc.failures[0].kind == "crash"
    assert sc.failures[0].target == "n1"


def test_crash_at_with_recover():
    sc = _base(2)
    crash_at(sc, "n1", at_ms=1000, recover_after_ms=3000)
    assert [f.kind for f in sc.failures] == ["crash", "recover"]
    assert sc.failures[1].at_ms == 4000


def test_partition_at():
    sc = _base(2)
    partition_at(sc, "n1", "n2", at_ms=500, duration_ms=2000)
    assert len(sc.failures) == 1
    assert sc.failures[0].kind == "partition"
    assert sc.failures[0].a == "n1"
    assert sc.failures[0].b == "n2"
    assert sc.failures[0].duration_ms == 2000
