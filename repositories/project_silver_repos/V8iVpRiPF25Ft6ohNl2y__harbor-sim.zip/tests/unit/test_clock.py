from __future__ import annotations

import random

import pytest

from harbor_sim.clock import Clock, ClockSkew, Deadline, SimClock, jitter
from harbor_sim.ids import NodeId


def test_simclock_starts_at_zero():
    c = SimClock()
    assert c.now_ms == 0


def test_simclock_advance_forward():
    c = SimClock()
    c.advance_to(100)
    assert c.now_ms == 100
    c.advance_to(150)
    assert c.now_ms == 150


def test_simclock_refuses_to_go_backwards():
    c = SimClock(now_ms=500)
    with pytest.raises(ValueError, match="cannot go backwards"):
        c.advance_to(400)


def test_simclock_advance_to_same_time_is_ok():
    c = SimClock(now_ms=500)
    c.advance_to(500)
    assert c.now_ms == 500


def test_int_conversion():
    c = SimClock(now_ms=42)
    assert int(c) == 42


def test_skew_zero_is_identity():
    s = ClockSkew()
    assert s.adjust(0) == 0
    assert s.adjust(1_000) == 1_000
    assert s.adjust(10_000) == 10_000


def test_skew_positive_offset():
    s = ClockSkew(offset_ms=50)
    assert s.adjust(0) == 50
    assert s.adjust(1_000) == 1_050


def test_skew_negative_offset():
    s = ClockSkew(offset_ms=-25)
    assert s.adjust(1_000) == 975


@pytest.mark.parametrize(
    "drift_ppm,base_ms,expected",
    [
        (0, 1_000_000, 1_000_000),
        (1_000_000, 1_000, 2_000),
        (1_000, 1_000_000, 1_001_000),  # 1ms per second
        (-1_000, 1_000_000, 999_000),
        (100, 999, 999),  # rounding to zero
        (100, 10_000, 10_001),
    ],
)
def test_skew_drift_math(drift_ppm, base_ms, expected):
    s = ClockSkew(drift_ppm=drift_ppm)
    assert s.adjust(base_ms) == expected


def test_skew_offset_and_drift_compose():
    s = ClockSkew(offset_ms=100, drift_ppm=1_000)
    assert s.adjust(1_000_000) == 100 + 1_000_000 + 1_000


def test_clock_now_applies_skew():
    sim = SimClock(now_ms=1_000)
    clk = Clock(NodeId("n1"), skew=ClockSkew(offset_ms=42), _global=sim)
    assert clk.now() == 1_042


def test_clock_now_follows_simclock():
    sim = SimClock()
    clk = Clock(NodeId("n1"), _global=sim)
    assert clk.now() == 0
    sim.advance_to(500)
    assert clk.now() == 500
    sim.advance_to(1_500)
    assert clk.now() == 1_500


def test_clock_elapsed_since():
    sim = SimClock(now_ms=2_000)
    clk = Clock(NodeId("n1"), _global=sim)
    assert clk.elapsed_since(1_500) == 500


def test_clock_bind_swaps_global():
    sim_a = SimClock(now_ms=100)
    sim_b = SimClock(now_ms=300)
    clk = Clock(NodeId("n1"), _global=sim_a)
    assert clk.now() == 100
    clk.bind(sim_b)
    assert clk.now() == 300


def test_clock_repr_includes_skew_sign():
    sim = SimClock(now_ms=1_000)
    pos = Clock(NodeId("n1"), skew=ClockSkew(offset_ms=42), _global=sim)
    neg = Clock(NodeId("n2"), skew=ClockSkew(offset_ms=-10), _global=sim)
    assert "+42ms" in repr(pos)
    assert "-10ms" in repr(neg)


def test_deadline_from_now():
    sim = SimClock(now_ms=1_000)
    clk = Clock(NodeId("n1"), _global=sim)
    d = Deadline.from_now(clk, 500)
    assert d.fire_at_ms == 1_500


def test_deadline_expiry():
    sim = SimClock(now_ms=1_000)
    clk = Clock(NodeId("n1"), _global=sim)
    d = Deadline.from_now(clk, 500)
    assert not d.expired(clk)
    sim.advance_to(1_500)
    assert d.expired(clk)


def test_deadline_remaining():
    sim = SimClock(now_ms=1_000)
    clk = Clock(NodeId("n1"), _global=sim)
    d = Deadline.from_now(clk, 500)
    assert d.remaining(clk) == 500
    sim.advance_to(1_200)
    assert d.remaining(clk) == 300
    sim.advance_to(1_500)
    assert d.remaining(clk) == 0
    sim.advance_to(1_700)
    assert d.remaining(clk) == -200


def test_deadline_respects_skew():
    # A node with positive skew sees its own clock running ahead, so a
    # deadline created from its clock fires at a later global time.
    sim = SimClock(now_ms=1_000)
    skewed = Clock(NodeId("n1"), skew=ClockSkew(offset_ms=200), _global=sim)
    d = Deadline.from_now(skewed, 500)
    assert d.fire_at_ms == 1_700  # local now (1200) + 500


def test_jitter_zero_returns_base():
    rng = random.Random(0)
    assert jitter(100, 0, rng) == 100


def test_jitter_rejects_negative():
    rng = random.Random(0)
    with pytest.raises(ValueError, match="non-negative"):
        jitter(100, -1, rng)


def test_jitter_is_seeded_deterministic():
    rng_a = random.Random(42)
    rng_b = random.Random(42)
    values_a = [jitter(100, 20, rng_a) for _ in range(10)]
    values_b = [jitter(100, 20, rng_b) for _ in range(10)]
    assert values_a == values_b


def test_jitter_range():
    rng = random.Random(42)
    for _ in range(100):
        v = jitter(100, 10, rng)
        assert 90 <= v <= 110


def test_jitter_covers_endpoints():
    # With enough samples, both 90 and 110 should appear.
    rng = random.Random(123)
    seen = {jitter(100, 10, rng) for _ in range(500)}
    assert 90 in seen
    assert 110 in seen
