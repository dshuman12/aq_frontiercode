from __future__ import annotations

from harbor_sim.rng import RngBundle, _derive_seed, shared_pool


def test_derive_seed_is_deterministic():
    a = _derive_seed(42, "scheduler")
    b = _derive_seed(42, "scheduler")
    assert a == b


def test_derive_seed_varies_with_stream_name():
    a = _derive_seed(42, "scheduler")
    b = _derive_seed(42, "transport")
    assert a != b


def test_derive_seed_varies_with_parent():
    a = _derive_seed(42, "scheduler")
    b = _derive_seed(43, "scheduler")
    assert a != b


def test_bundle_stream_same_name_returns_same_object():
    b = RngBundle(seed=1)
    s1 = b.stream("scheduler")
    s2 = b.stream("scheduler")
    assert s1 is s2


def test_bundle_streams_are_independent():
    # Different streams within one bundle don't interfere.
    b = RngBundle(seed=1)
    s_a = b.stream("scheduler")
    s_b = b.stream("transport")
    seq_a_before = [s_a.random() for _ in range(5)]
    [s_b.random() for _ in range(50)]
    s_a2 = b.stream("scheduler")
    # The next draws from "scheduler" depend ONLY on how many times
    # we've drawn from "scheduler", not on draws from siblings.
    b2 = RngBundle(seed=1)
    s_a_fresh = b2.stream("scheduler")
    fresh_seq = [s_a_fresh.random() for _ in range(5)]
    assert seq_a_before == fresh_seq
    # And the next draw from s_a is the 6th in its sequence.
    fresh_seq.append(s_a_fresh.random())
    next_in_original = s_a2.random()
    assert next_in_original == fresh_seq[-1]


def test_bundle_seed_reproduces_streams():
    a = RngBundle(seed=99)
    b = RngBundle(seed=99)
    for name in ("scheduler", "transport", "workload"):
        sa = a.stream(name)
        sb = b.stream(name)
        for _ in range(20):
            assert sa.random() == sb.random()


def test_bundle_seeds_differ_across_parents():
    a = RngBundle(seed=99)
    b = RngBundle(seed=100)
    sa = a.stream("scheduler")
    sb = b.stream("scheduler")
    diffs = [sa.random() != sb.random() for _ in range(50)]
    # Streams with different parents are overwhelmingly likely to
    # produce different values; tolerate up to one collision.
    assert sum(diffs) >= 49


def test_fork_derives_distinct_child():
    parent = RngBundle(seed=42)
    child = parent.fork("workload")
    assert parent.seed != child.seed


def test_fork_is_deterministic():
    a = RngBundle(seed=42)
    b = RngBundle(seed=42)
    fa = a.fork("workload")
    fb = b.fork("workload")
    assert fa.seed == fb.seed
    sa = fa.stream("client-0")
    sb = fb.stream("client-0")
    for _ in range(10):
        assert sa.random() == sb.random()


def test_draw_counts_tick_on_random():
    b = RngBundle(seed=1)
    s = b.stream("scheduler")
    assert b.draw_counts()["scheduler"] == 0
    for _ in range(7):
        s.random()
    assert b.draw_counts()["scheduler"] == 7


def test_draw_counts_tick_through_higher_level_calls():
    # randint and choice ultimately call random()
    b = RngBundle(seed=1)
    s = b.stream("scheduler")
    s.randint(0, 100)
    assert b.draw_counts()["scheduler"] >= 1


def test_draw_counts_are_per_stream():
    b = RngBundle(seed=1)
    a = b.stream("a")
    c = b.stream("c")
    for _ in range(3):
        a.random()
    for _ in range(5):
        c.random()
    counts = b.draw_counts()
    assert counts["a"] == 3
    assert counts["c"] == 5


def test_restore_draw_counts_replays_state():
    # Run a bundle, observe draws, then build a fresh bundle and
    # restore. The next draw from the restored stream should match
    # what we'd see in the original.
    orig = RngBundle(seed=42)
    s = orig.stream("scheduler")
    for _ in range(10):
        s.random()
    counts = orig.draw_counts()
    next_in_orig = s.random()

    restored = RngBundle(seed=42)
    restored.restore_draw_counts(counts)
    next_in_restored = restored.stream("scheduler").random()
    assert next_in_restored == next_in_orig


def test_restore_handles_unused_streams():
    # A bundle whose recorded state has zero-draw streams should still
    # round-trip.
    orig = RngBundle(seed=42)
    orig.stream("scheduler")
    orig.stream("workload")  # never drawn
    counts = orig.draw_counts()
    restored = RngBundle(seed=42)
    restored.restore_draw_counts(counts)
    assert restored.draw_counts() == counts


def test_shared_pool_returns_distinct_instances():
    a = shared_pool(42)
    b = shared_pool(42)
    assert a is not b


def test_shared_pool_is_seeded():
    a = shared_pool(42)
    b = shared_pool(42)
    for _ in range(20):
        assert a.random() == b.random()


def test_shared_pool_does_not_share_state_with_bundles():
    # Bundles must not depend on the global random module's state.
    pool = shared_pool(1)
    pool.random()
    pool.random()
    bundle = RngBundle(seed=1)
    s = bundle.stream("scheduler")
    seq_from_bundle = [s.random() for _ in range(5)]
    # Independent of pool draws above:
    pool2 = shared_pool(1)
    pool2.random()
    pool2.random()
    bundle2 = RngBundle(seed=1)
    s2 = bundle2.stream("scheduler")
    seq2 = [s2.random() for _ in range(5)]
    assert seq_from_bundle == seq2
