"""Tests for the workload generators."""
from __future__ import annotations

from pathlib import Path

import pytest

from harbor_sim.ids import ClientId, NodeId
from harbor_sim.runtime.node import Node
from harbor_sim.runtime.simulator import Simulator
from harbor_sim.transport import LinkConfig
from harbor_sim.workload.kv import KVWorkload
from harbor_sim.workload.propose import ProposeWorkload


def _wire(workload, sim: Simulator, target: NodeId, client_id: NodeId, tmp_path: Path) -> Node:
    node = Node.make(
        node_id=client_id,
        protocol=workload,
        scheduler=sim.scheduler,
        transport=sim.transport,
        rng=sim.rng,
        sim_clock=sim.clock,
        workdir=tmp_path / str(client_id),
    )
    sim.add_node(node)
    sim.transport.add_link(LinkConfig(client_id, target, 1, 2))
    sim.transport.add_link(LinkConfig(target, client_id, 1, 2))
    return node


def test_kv_workload_issues_requests(tmp_path: Path):
    sim = Simulator.make(seed=1, workdir=tmp_path)
    # We don't need a real KV target; just a sink.
    class Sink:
        def __init__(self): self.got = []
        def on_init(self,c): pass
        def on_shutdown(self,c): pass
        def on_timer(self,c,k,p): pass
        def on_message(self,c,m): self.got.append(dict(m.body))
    sink = Sink()
    target_id = NodeId("kv0")
    sim.add_node(Node.make(target_id, sink, sim.scheduler, sim.transport,
                           sim.rng, sim.clock, workdir=tmp_path / "kv0"))

    wl = KVWorkload(
        client_id=ClientId("c1"), target=target_id,
        keys=["a", "b"], interval_ms=10, put_ratio=0.5,
    )
    _wire(wl, sim, target_id, NodeId("c1"), tmp_path)
    sim.boot_all()
    sim.run(horizon_ms=200)
    assert wl.issued()


def test_kv_workload_deterministic_keys(tmp_path: Path):
    # Two identical workloads should pick the same keys.
    def run(seed):
        sim = Simulator.make(seed=seed, workdir=tmp_path / str(seed))
        class Sink:
            def on_init(self,c): pass
            def on_shutdown(self,c): pass
            def on_timer(self,c,k,p): pass
            def on_message(self,c,m): pass
        target_id = NodeId("kv0")
        sim.add_node(Node.make(target_id, Sink(), sim.scheduler, sim.transport,
                               sim.rng, sim.clock, workdir=tmp_path / str(seed) / "kv0"))
        wl = KVWorkload(client_id=ClientId("c1"), target=target_id,
                        keys=["a", "b", "c"], interval_ms=10)
        _wire(wl, sim, target_id, NodeId("c1"), tmp_path / str(seed))
        sim.boot_all()
        sim.run(horizon_ms=200)
        return [(r.kind, r.key) for r in wl.issued()]
    out_a = run(42)
    out_b = run(42)
    assert out_a == out_b


def test_kv_workload_put_ratio_zero_is_all_gets(tmp_path: Path):
    sim = Simulator.make(seed=1, workdir=tmp_path)
    class Sink:
        def on_init(self,c): pass
        def on_shutdown(self,c): pass
        def on_timer(self,c,k,p): pass
        def on_message(self,c,m): pass
    target_id = NodeId("kv0")
    sim.add_node(Node.make(target_id, Sink(), sim.scheduler, sim.transport,
                           sim.rng, sim.clock, workdir=tmp_path / "kv0"))
    wl = KVWorkload(client_id=ClientId("c1"), target=target_id,
                    keys=["a"], interval_ms=10, put_ratio=0.0)
    _wire(wl, sim, target_id, NodeId("c1"), tmp_path)
    sim.boot_all()
    sim.run(horizon_ms=100)
    assert wl.issued()
    assert all(r.kind == "get" for r in wl.issued())


def test_kv_workload_completion_rate_zero_without_replies(tmp_path: Path):
    sim = Simulator.make(seed=1, workdir=tmp_path)
    class Silent:
        def on_init(self,c): pass
        def on_shutdown(self,c): pass
        def on_timer(self,c,k,p): pass
        def on_message(self,c,m): pass  # never replies
    target_id = NodeId("kv0")
    sim.add_node(Node.make(target_id, Silent(), sim.scheduler, sim.transport,
                           sim.rng, sim.clock, workdir=tmp_path / "kv0"))
    wl = KVWorkload(client_id=ClientId("c1"), target=target_id,
                    keys=["a"], interval_ms=10)
    _wire(wl, sim, target_id, NodeId("c1"), tmp_path)
    sim.boot_all()
    sim.run(horizon_ms=100)
    assert wl.completion_rate() == 0.0


def test_propose_workload_seq_monotonic(tmp_path: Path):
    sim = Simulator.make(seed=1, workdir=tmp_path)
    class Sink:
        def __init__(self): self.got=[]
        def on_init(self,c): pass
        def on_shutdown(self,c): pass
        def on_timer(self,c,k,p): pass
        def on_message(self,c,m): self.got.append(dict(m.body))
    target_id = NodeId("n0")
    sim.add_node(Node.make(target_id, Sink(), sim.scheduler, sim.transport,
                           sim.rng, sim.clock, workdir=tmp_path / "n0"))
    wl = ProposeWorkload(client_id=ClientId("c1"), target=target_id, interval_ms=20)
    _wire(wl, sim, target_id, NodeId("c1"), tmp_path)
    sim.boot_all()
    sim.run(horizon_ms=200)
    ids = [p.rid for p in wl.proposals()]
    assert ids == sorted(ids)
    assert wl.accept_rate() == 0.0
