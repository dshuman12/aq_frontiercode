"""Tests for raftlite wire messages."""
from __future__ import annotations

from harbor_sim.ids import LogIndex, NodeId, Term
from harbor_sim.protocols.raftlite.messages import (
    AppendEntries,
    AppendEntriesReply,
    RequestVote,
    RequestVoteReply,
)


def test_request_vote_round_trip():
    rv = RequestVote(
        term=Term(5),
        candidate=NodeId("n1"),
        last_log_index=LogIndex(10),
        last_log_term=Term(4),
    )
    back = RequestVote.from_dict(rv.to_dict())
    assert back == rv


def test_request_vote_reply_round_trip():
    rep = RequestVoteReply(term=Term(5), granted=True, voter=NodeId("n2"))
    back = RequestVoteReply.from_dict(rep.to_dict())
    assert back == rep


def test_append_entries_round_trip():
    msg = AppendEntries(
        term=Term(3),
        leader=NodeId("n1"),
        prev_log_index=LogIndex(10),
        prev_log_term=Term(2),
        entries=[{"t": 3, "i": 11, "d": {"op": "put"}}],
        leader_commit=LogIndex(8),
        leader_now_ms=1234,
    )
    back = AppendEntries.from_dict(msg.to_dict())
    assert back == msg


def test_append_entries_with_no_entries_round_trip():
    msg = AppendEntries(
        term=Term(3),
        leader=NodeId("n1"),
        prev_log_index=LogIndex(0),
        prev_log_term=Term(0),
        entries=[],
        leader_commit=LogIndex(0),
        leader_now_ms=0,
    )
    back = AppendEntries.from_dict(msg.to_dict())
    assert back.entries == []


def test_append_entries_reply_round_trip():
    rep = AppendEntriesReply(
        term=Term(3),
        success=True,
        follower=NodeId("n2"),
        match_index=LogIndex(11),
        follower_now_ms=2000,
    )
    back = AppendEntriesReply.from_dict(rep.to_dict())
    assert back == rep


def test_append_entries_reply_failure_round_trip():
    rep = AppendEntriesReply(
        term=Term(4),
        success=False,
        follower=NodeId("n2"),
        match_index=LogIndex(0),
        follower_now_ms=2000,
    )
    back = AppendEntriesReply.from_dict(rep.to_dict())
    assert back.success is False
    assert int(back.match_index) == 0
