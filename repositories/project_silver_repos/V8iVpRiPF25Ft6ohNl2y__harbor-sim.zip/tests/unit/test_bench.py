"""Tests for the bench harness."""
from __future__ import annotations

from pathlib import Path

import pytest

from harbor_sim.bench.harness import BenchResult, run_suite


REPO = Path(__file__).parent.parent.parent
EXAMPLES = REPO / "examples"


def test_run_quick_suite(tmp_path: Path):
    results = run_suite("quick", workdir=tmp_path, examples_dir=EXAMPLES)
    assert len(results) >= 1
    for r in results:
        assert isinstance(r, BenchResult)
        assert r.events >= 0


def test_run_full_suite_returns_more_cases(tmp_path: Path):
    quick = run_suite("quick", workdir=tmp_path / "q", examples_dir=EXAMPLES)
    full = run_suite("full", workdir=tmp_path / "f", examples_dir=EXAMPLES)
    assert len(full) >= len(quick)


def test_run_unknown_suite_raises(tmp_path: Path):
    with pytest.raises(ValueError, match="unknown suite"):
        run_suite("bogus", workdir=tmp_path, examples_dir=EXAMPLES)


def test_run_suite_skips_missing_files(tmp_path: Path):
    # Point at an empty examples dir; the harness should return an
    # empty result rather than crash.
    fresh = tmp_path / "empty-examples"
    fresh.mkdir()
    results = run_suite("quick", workdir=tmp_path, examples_dir=fresh)
    assert results == []


def test_bench_result_events_per_second():
    r = BenchResult(name="x", horizon_ms=1000, events=100, wall_seconds=0.5)
    assert r.events_per_second() == 200.0


def test_bench_result_zero_wall_returns_inf():
    r = BenchResult(name="x", horizon_ms=1000, events=100, wall_seconds=0)
    import math
    assert math.isinf(r.events_per_second())
