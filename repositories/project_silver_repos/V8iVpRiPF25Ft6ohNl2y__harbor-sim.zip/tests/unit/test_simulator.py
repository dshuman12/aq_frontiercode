"""End-to-end smoke for the runtime: scheduler + transport + nodes."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from harbor_sim.clock import ClockSkew
from harbor_sim.errors import ScenarioReferenceError, SimulationError
from harbor_sim.ids import NodeId
from harbor_sim.runtime.mailbox import IncomingMessage
from harbor_sim.runtime.node import Node
from harbor_sim.runtime.simulator import Simulator
from harbor_sim.transport import LinkConfig


class _EchoProto:
    """A tiny protocol: bounce every received message back to the sender
    once, then go quiet. Useful for testing the runtime plumbing."""

    def __init__(self) -> None:
        self.received: list[IncomingMessage] = []
        self.echoed: set[NodeId] = set()

    def on_init(self, ctx) -> None:
        pass

    def on_message(self, ctx, msg: IncomingMessage) -> None:
        self.received.append(msg)
        if msg.from_node not in self.echoed:
            ctx.send(msg.from_node, "echo", {"of": msg.body})
            self.echoed.add(msg.from_node)

    def on_timer(self, ctx, key: str, payload: dict[str, Any]) -> None:
        pass

    def on_shutdown(self, ctx) -> None:
        pass


def _make_pair(tmp_path: Path, seed: int = 0) -> tuple[Simulator, _EchoProto, _EchoProto]:
    sim = Simulator.make(seed=seed, workdir=tmp_path)
    p1 = _EchoProto()
    p2 = _EchoProto()
    n1 = Node.make(
        node_id=NodeId("n1"),
        protocol=p1,
        scheduler=sim.scheduler,
        transport=sim.transport,
        rng=sim.rng,
        sim_clock=sim.clock,
        workdir=tmp_path / "n1",
    )
    n2 = Node.make(
        node_id=NodeId("n2"),
        protocol=p2,
        scheduler=sim.scheduler,
        transport=sim.transport,
        rng=sim.rng,
        sim_clock=sim.clock,
        workdir=tmp_path / "n2",
    )
    sim.add_node(n1)
    sim.add_node(n2)
    sim.transport.add_link(
        LinkConfig(NodeId("n1"), NodeId("n2"), latency_low_ms=5, latency_high_ms=5)
    )
    sim.transport.add_link(
        LinkConfig(NodeId("n2"), NodeId("n1"), latency_low_ms=5, latency_high_ms=5)
    )
    return sim, p1, p2


def test_simulator_boots_all_nodes(tmp_path: Path):
    sim, _, _ = _make_pair(tmp_path)
    sim.boot_all()
    for n in sim.nodes.values():
        assert n.booted


def test_duplicate_node_raises(tmp_path: Path):
    sim = Simulator.make(seed=0, workdir=tmp_path)
    proto = _EchoProto()
    n1 = Node.make(
        NodeId("n1"), proto, sim.scheduler, sim.transport, sim.rng, sim.clock,
        workdir=tmp_path / "n1",
    )
    n1b = Node.make(
        NodeId("n1"), proto, sim.scheduler, sim.transport, sim.rng, sim.clock,
        workdir=tmp_path / "n1b",
    )
    sim.add_node(n1)
    with pytest.raises(SimulationError, match="duplicate node"):
        sim.add_node(n1b)


def test_get_unknown_raises(tmp_path: Path):
    sim, _, _ = _make_pair(tmp_path)
    with pytest.raises(ScenarioReferenceError):
        sim.get(NodeId("nowhere"))


def test_send_through_simulator(tmp_path: Path):
    sim, p1, p2 = _make_pair(tmp_path)
    sim.boot_all()
    sim.transport.send(NodeId("n1"), NodeId("n2"), "hi", {"v": 1})
    sim.run(horizon_ms=100)
    # n2 receives "hi", echoes to n1. n1 receives echo, echoes back to n2.
    # n2 receives the second echo but doesn't re-echo (n1 already in echoed).
    assert p2.received[0].body == {"v": 1}
    assert p2.received[0].kind == "hi"
    # n1 saw exactly the bounced echo of "hi".
    assert len(p1.received) == 1
    assert p1.received[0].kind == "echo"
    assert p1.received[0].body == {"of": {"v": 1}}


def test_run_returns_event_count(tmp_path: Path):
    sim, _, _ = _make_pair(tmp_path)
    sim.boot_all()
    sim.transport.send(NodeId("n1"), NodeId("n2"), "hi", {})
    n = sim.run(horizon_ms=100)
    # n1->n2 deliver, n2->n1 echo deliver, n1->n2 echo-of-echo deliver
    assert n == 3


def test_partition_drops_traffic(tmp_path: Path):
    sim, p1, p2 = _make_pair(tmp_path)
    sim.boot_all()
    sim.transport.partition_pair(NodeId("n1"), NodeId("n2"))
    sim.transport.send(NodeId("n1"), NodeId("n2"), "hi", {})
    sim.run(horizon_ms=100)
    assert p2.received == []


def test_crash_drops_inbox(tmp_path: Path):
    sim, p1, p2 = _make_pair(tmp_path)
    sim.boot_all()
    sim.transport.send(NodeId("n1"), NodeId("n2"), "hi", {})
    sim.nodes[NodeId("n2")].crash()
    sim.run(horizon_ms=100)
    assert p2.received == []


def test_crash_then_recover(tmp_path: Path):
    sim, p1, p2 = _make_pair(tmp_path)
    sim.boot_all()
    sim.nodes[NodeId("n2")].crash()
    sim.nodes[NodeId("n2")].recover()
    sim.transport.send(NodeId("n1"), NodeId("n2"), "hi", {})
    sim.run(horizon_ms=100)
    # n2 receives "hi" and then n1's reciprocal echo.
    assert len(p2.received) >= 1
    assert p2.received[0].kind == "hi"


def test_fault_event_partitions_links(tmp_path: Path):
    sim, p1, p2 = _make_pair(tmp_path)
    sim.boot_all()
    sim.scheduler.schedule(
        delay_ms=10, kind="fault", target="cluster",
        payload={"fault_kind": "partition", "a": "n1", "b": "n2", "on": True},
    )
    sim.scheduler.schedule(
        delay_ms=20, kind="deliver", target="n2",
        payload={"from": "n1", "kind": "hi", "body": {}, "send_at": 5},
    )
    # Manual send-side: fault fires at 10, deliver at 20. The fault
    # arms the partition before delivery, but the deliver event was
    # already scheduled - the simulator delivers it because faults
    # only affect future sends. Sanity-check that nothing crashes.
    sim.run(horizon_ms=100)


def test_skewed_clock_visible_to_node(tmp_path: Path):
    sim = Simulator.make(seed=0, workdir=tmp_path)
    p = _EchoProto()
    n = Node.make(
        NodeId("n1"), p, sim.scheduler, sim.transport, sim.rng, sim.clock,
        skew=ClockSkew(offset_ms=100),
        workdir=tmp_path / "n1",
    )
    sim.add_node(n)
    sim.boot_all()
    sim.clock.advance_to(50)
    assert n.clock.now() == 150


def test_deterministic_across_two_simulators(tmp_path: Path):
    out_a = _run_scripted(tmp_path / "a", seed=42)
    out_b = _run_scripted(tmp_path / "b", seed=42)
    assert out_a == out_b


def test_different_seeds_diverge(tmp_path: Path):
    out_a = _run_scripted(tmp_path / "a", seed=42)
    out_b = _run_scripted(tmp_path / "b", seed=43)
    assert out_a != out_b


def _run_scripted(workdir: Path, seed: int) -> list[tuple[int, str, str]]:
    sim = Simulator.make(seed=seed, workdir=workdir)
    p1 = _EchoProto()
    p2 = _EchoProto()
    sim.add_node(Node.make(NodeId("n1"), p1, sim.scheduler, sim.transport, sim.rng,
                           sim.clock, workdir=workdir / "n1"))
    sim.add_node(Node.make(NodeId("n2"), p2, sim.scheduler, sim.transport, sim.rng,
                           sim.clock, workdir=workdir / "n2"))
    # Wide latency range so the seeded RNG actually drives ordering.
    sim.transport.add_link(LinkConfig(NodeId("n1"), NodeId("n2"),
                                      latency_low_ms=1, latency_high_ms=50,
                                      reorder=True))
    sim.transport.add_link(LinkConfig(NodeId("n2"), NodeId("n1"),
                                      latency_low_ms=1, latency_high_ms=50,
                                      reorder=True))
    sim.boot_all()
    for i in range(50):
        if i % 2 == 0:
            sim.transport.send(NodeId("n1"), NodeId("n2"), "ping", {"i": i})
        else:
            sim.transport.send(NodeId("n2"), NodeId("n1"), "ping", {"i": i})
    sim.run(horizon_ms=10_000)
    return [
        (m.received_at_ms, str(m.from_node), m.body.get("i", -1)) for m in p1.received
    ] + [
        (m.received_at_ms, str(m.from_node), m.body.get("i", -1)) for m in p2.received
    ]
