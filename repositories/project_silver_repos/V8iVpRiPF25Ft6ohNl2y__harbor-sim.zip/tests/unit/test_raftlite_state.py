"""Tests for raftlite internal state transitions."""
from __future__ import annotations

import pytest

from harbor_sim.ids import LogIndex, NodeId, Term
from harbor_sim.protocols.raftlite.state import RaftliteState, Role


def _state(node: str, peers: list[str]) -> RaftliteState:
    return RaftliteState(
        node=NodeId(node), peers=[NodeId(p) for p in peers]
    )


def test_initial_role_is_follower():
    s = _state("n1", ["n2", "n3"])
    assert s.role == Role.FOLLOWER
    assert int(s.current_term) == 0
    assert s.voted_for is None


def test_become_follower_resets_vote():
    s = _state("n1", ["n2"])
    s.voted_for = NodeId("n2")
    s.become_follower(Term(5))
    assert s.role == Role.FOLLOWER
    assert int(s.current_term) == 5
    assert s.voted_for is None


def test_become_candidate_bumps_term_and_self_votes():
    s = _state("n1", ["n2", "n3"])
    s.become_candidate()
    assert s.role == Role.CANDIDATE
    assert int(s.current_term) == 1
    assert s.voted_for == NodeId("n1")
    assert s.votes_received == {NodeId("n1")}


def test_become_leader_seeds_next_and_match_indexes():
    s = _state("n1", ["n2", "n3"])
    s.become_leader(LogIndex(10))
    assert s.role == Role.LEADER
    assert int(s.next_index[NodeId("n2")]) == 11
    assert int(s.next_index[NodeId("n3")]) == 11
    assert int(s.match_index[NodeId("n2")]) == 0
    assert int(s.match_index[NodeId("n3")]) == 0


@pytest.mark.parametrize(
    "n_peers,want",
    [
        (0, 1),  # single-node "cluster"
        (1, 2),  # 2 nodes -> need 2
        (2, 2),  # 3 nodes -> need 2
        (3, 3),  # 4 nodes -> need 3
        (4, 3),  # 5 nodes -> need 3
        (5, 4),  # 6 nodes -> need 4
        (6, 4),  # 7 nodes -> need 4
    ],
)
def test_quorum_size(n_peers, want):
    s = _state("n1", [f"n{i+2}" for i in range(n_peers)])
    assert s.quorum_size() == want


def test_have_quorum_threshold():
    s = _state("n1", ["n2", "n3"])  # quorum = 2
    assert not s.have_quorum(1)
    assert s.have_quorum(2)
    assert s.have_quorum(3)


def test_majority_match_with_single_node():
    s = _state("n1", [])
    for i in range(1, 6):
        from harbor_sim.storage.log import LogEntry
        s.log.append(LogEntry(term=Term(1), index=LogIndex(i), data={}))
    assert int(s.majority_match()) == 5


def test_majority_match_with_three_node_cluster():
    s = _state("n1", ["n2", "n3"])
    from harbor_sim.storage.log import LogEntry
    for i in range(1, 11):
        s.log.append(LogEntry(term=Term(1), index=LogIndex(i), data={}))
    s.match_index[NodeId("n2")] = LogIndex(8)
    s.match_index[NodeId("n3")] = LogIndex(4)
    # leader has 10, n2 has 8, n3 has 4 -> sorted desc [10, 8, 4],
    # quorum=2, take the 2nd entry = 8.
    assert int(s.majority_match()) == 8


def test_majority_match_with_five_node_cluster():
    s = _state("n1", ["n2", "n3", "n4", "n5"])
    from harbor_sim.storage.log import LogEntry
    for i in range(1, 11):
        s.log.append(LogEntry(term=Term(1), index=LogIndex(i), data={}))
    s.match_index[NodeId("n2")] = LogIndex(9)
    s.match_index[NodeId("n3")] = LogIndex(7)
    s.match_index[NodeId("n4")] = LogIndex(5)
    s.match_index[NodeId("n5")] = LogIndex(3)
    # [10, 9, 7, 5, 3], quorum=3, take 3rd = 7.
    assert int(s.majority_match()) == 7
