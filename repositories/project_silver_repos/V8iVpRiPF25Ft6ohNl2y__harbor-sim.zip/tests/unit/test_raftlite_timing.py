"""Heartbeat/election/lease parameter validation for raftlite."""
from __future__ import annotations

import pytest

from harbor_sim.protocols.raftlite.timing import (
    DEFAULT,
    TimingParams,
    aggressive_timing,
    conservative_timing,
)


def test_default_validates():
    DEFAULT.validate()


def test_aggressive_and_conservative_validate():
    aggressive_timing().validate()
    conservative_timing().validate()


def test_aggressive_faster_than_conservative():
    a = aggressive_timing()
    c = conservative_timing()
    assert a.heartbeat_interval_ms < c.heartbeat_interval_ms
    assert a.election_timeout_min_ms < c.election_timeout_min_ms


def test_validate_rejects_nonpositive_heartbeat():
    bad = TimingParams(heartbeat_interval_ms=0)
    with pytest.raises(ValueError, match="heartbeat_interval"):
        bad.validate()


def test_validate_rejects_inverted_election_range():
    bad = TimingParams(election_timeout_min_ms=300, election_timeout_max_ms=200)
    with pytest.raises(ValueError, match="election_timeout_max_ms"):
        bad.validate()


def test_validate_rejects_heartbeat_geq_election():
    bad = TimingParams(heartbeat_interval_ms=200, election_timeout_min_ms=150)
    with pytest.raises(ValueError, match="heartbeat_interval_ms"):
        bad.validate()


def test_validate_rejects_negative_lease():
    bad = TimingParams(lease_duration_ms=-1)
    with pytest.raises(ValueError, match="lease_duration"):
        bad.validate()


def test_scaled_multiplies_durations():
    t = TimingParams(heartbeat_interval_ms=50, election_timeout_min_ms=150,
                     election_timeout_max_ms=300, lease_duration_ms=100)
    s = t.scaled(2.0)
    assert s.heartbeat_interval_ms == 100
    assert s.election_timeout_min_ms == 300
    assert s.lease_duration_ms == 200


def test_scaled_round_trip():
    t = TimingParams(heartbeat_interval_ms=50, heartbeat_jitter_ms=5,
                     election_timeout_min_ms=150, election_timeout_max_ms=300,
                     lease_duration_ms=100)
    s = t.scaled(0.5).scaled(2.0)
    # Integer scaling may lose precision; allow off-by-one.
    assert abs(s.heartbeat_interval_ms - 50) <= 1
    assert abs(s.election_timeout_min_ms - 150) <= 1
