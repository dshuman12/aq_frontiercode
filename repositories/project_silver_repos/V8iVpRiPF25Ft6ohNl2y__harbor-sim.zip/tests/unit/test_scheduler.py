"""Tests for the discrete-event scheduler."""
from __future__ import annotations

import pytest

from harbor_sim.clock import SimClock
from harbor_sim.errors import DeadlineExceeded
from harbor_sim.rng import RngBundle
from harbor_sim.scheduler import Event, Scheduler


def _sched(seed: int = 0):
    return Scheduler(clock=SimClock(), rng=RngBundle(seed=seed))


def test_fresh_scheduler_starts_at_zero():
    s = _sched()
    assert s.now_ms == 0
    assert s.peek() is None
    assert s.step() is None


def test_schedule_and_step():
    s = _sched()
    s.schedule(100, "tick", "n1")
    s.schedule(200, "tick", "n2")
    e1 = s.step()
    e2 = s.step()
    assert e1 is not None and e1.fire_at_ms == 100
    assert e2 is not None and e2.fire_at_ms == 200
    assert s.step() is None
    assert s.now_ms == 200


def test_schedule_zero_delay():
    s = _sched()
    s.schedule(0, "tick", "n1")
    e = s.step()
    assert e is not None and e.fire_at_ms == 0
    assert s.now_ms == 0


def test_schedule_rejects_negative_delay():
    s = _sched()
    with pytest.raises(ValueError, match="non-negative"):
        s.schedule(-1, "tick", "n1")


def test_schedule_at_target():
    s = _sched()
    s.schedule_at(500, "tick", "n1")
    assert s.peek().fire_at_ms == 500


def test_schedule_at_rejects_past():
    s = _sched()
    s.clock.advance_to(100)
    with pytest.raises(ValueError, match="in the past"):
        s.schedule_at(50, "tick", "n1")


def test_cancel_live_event():
    s = _sched()
    eid = s.schedule(100, "tick", "n1")
    assert s.cancel(eid) is True
    assert s.step() is None


def test_cancel_already_fired_returns_false():
    s = _sched()
    eid = s.schedule(100, "tick", "n1")
    s.step()
    assert s.cancel(eid) is False


def test_cancel_then_schedule_more():
    s = _sched()
    eid = s.schedule(100, "tick", "n1")
    s.cancel(eid)
    s.schedule(200, "tick", "n2")
    e = s.step()
    assert e.fire_at_ms == 200


def test_events_at_same_time_use_tiebreaks():
    # 100 events at the same time should be returned in deterministic
    # order keyed by tiebreak; rerunning with the same seed produces
    # the same order.
    a = _sched(seed=42)
    b = _sched(seed=42)
    for i in range(100):
        a.schedule(0, "tick", f"n{i}")
        b.schedule(0, "tick", f"n{i}")
    order_a = [a.step().target for _ in range(100)]
    order_b = [b.step().target for _ in range(100)]
    assert order_a == order_b


def test_different_seeds_produce_different_orderings():
    a = _sched(seed=1)
    b = _sched(seed=2)
    for i in range(100):
        a.schedule(0, "tick", f"n{i}")
        b.schedule(0, "tick", f"n{i}")
    order_a = [a.step().target for _ in range(100)]
    order_b = [b.step().target for _ in range(100)]
    assert order_a != order_b


def test_clock_only_advances_forward():
    s = _sched()
    s.schedule(50, "tick", "n1")
    s.schedule(100, "tick", "n2")
    s.schedule(150, "tick", "n3")
    times = []
    while True:
        ev = s.step()
        if ev is None:
            break
        times.append(s.now_ms)
    assert times == sorted(times)


def test_peek_does_not_advance():
    s = _sched()
    s.schedule(100, "tick", "n1")
    assert s.peek().fire_at_ms == 100
    assert s.now_ms == 0
    e = s.step()
    assert e.fire_at_ms == 100


def test_run_until_returns_event_count():
    s = _sched()
    for i in range(5):
        s.schedule(100 * (i + 1), "tick", f"n{i}")
    seen = []
    n = s.run_until(300, lambda ev: seen.append(ev))
    assert n == 3
    assert [e.fire_at_ms for e in seen] == [100, 200, 300]


def test_run_until_advances_clock_past_drain():
    s = _sched()
    s.schedule(50, "tick", "n1")
    s.run_until(500, lambda ev: None)
    assert s.now_ms == 500


def test_run_until_advances_clock_when_horizon_short():
    s = _sched()
    s.schedule(1000, "tick", "n1")
    n = s.run_until(500, lambda ev: None)
    assert n == 0
    assert s.now_ms == 500


def test_run_until_inclusive_of_horizon():
    s = _sched()
    s.schedule(500, "tick", "n1")
    n = s.run_until(500, lambda ev: None)
    assert n == 1


def test_drain_exhausts_queue():
    s = _sched()
    for i in range(10):
        s.schedule(100 * (i + 1), "tick", f"n{i}")
    seen = []
    n = s.drain(lambda ev: seen.append(ev))
    assert n == 10
    assert len(seen) == 10


def test_drain_respects_max_events():
    s = _sched()
    for i in range(10):
        s.schedule(100 * (i + 1), "tick", f"n{i}")
    with pytest.raises(DeadlineExceeded):
        s.drain(lambda ev: None, max_events=3)


def test_install_and_remove_hook():
    s = _sched()
    seen: list[Event] = []
    hook = lambda ev: seen.append(ev)
    s.install_hook(hook)
    s.schedule(100, "tick", "n1")
    s.step()
    assert len(seen) == 1
    assert s.remove_hook(hook) is True
    s.schedule(200, "tick", "n2")
    s.step()
    assert len(seen) == 1
    assert s.remove_hook(hook) is False


def test_pending_excludes_cancelled():
    s = _sched()
    eid = s.schedule(100, "tick", "n1")
    s.schedule(200, "tick", "n2")
    assert s.pending() == 2
    s.cancel(eid)
    assert s.pending() == 1


def test_deterministic_across_runs_with_same_seed():
    # Whole-scenario determinism: same seed, same schedule, same order.
    def run():
        s = _sched(seed=99)
        for i in range(50):
            s.schedule(i % 7, "tick", f"n{i}")
        order = []
        while True:
            ev = s.step()
            if ev is None:
                break
            order.append((ev.fire_at_ms, ev.target))
        return order

    assert run() == run()
