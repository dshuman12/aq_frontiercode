"""CLI smoke tests via the click test runner."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from harbor_sim.cli.main import cli


REPO = Path(__file__).parent.parent.parent
EXAMPLES = REPO / "examples"


def test_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "harbor-sim" in result.output


def test_version():
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "harbor-sim" in result.output


def test_run_writes_a_trace(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    trace = tmp_path / "out.trace"
    workdir = tmp_path / "work"
    result = runner.invoke(cli, [
        "run", str(scenario),
        "--trace", str(trace),
        "--workdir", str(workdir),
        "--horizon-ms", "2000",
    ])
    assert result.exit_code == 0, result.output
    assert trace.exists()
    assert trace.stat().st_size > 0


def test_run_missing_trace_arg(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    result = runner.invoke(cli, ["run", str(scenario)])
    assert result.exit_code != 0


def test_inspect_walks_a_trace(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    trace = tmp_path / "out.trace"
    runner.invoke(cli, [
        "run", str(scenario),
        "--trace", str(trace),
        "--workdir", str(tmp_path / "w"),
        "--horizon-ms", "1500",
    ])
    result = runner.invoke(cli, ["inspect", str(trace), "--limit", "5"])
    assert result.exit_code == 0
    assert "trace v" in result.output


def test_inspect_filter_kind(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    trace = tmp_path / "out.trace"
    runner.invoke(cli, [
        "run", str(scenario),
        "--trace", str(trace),
        "--workdir", str(tmp_path / "w"),
        "--horizon-ms", "1500",
    ])
    result = runner.invoke(cli, ["inspect", str(trace), "--filter", "kind=timer"])
    assert result.exit_code == 0


def test_diff_identical_traces(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    a = tmp_path / "a.trace"
    b = tmp_path / "b.trace"
    runner.invoke(cli, ["run", str(scenario), "--trace", str(a),
                        "--workdir", str(tmp_path / "wa"), "--horizon-ms", "1500"])
    runner.invoke(cli, ["run", str(scenario), "--trace", str(b),
                        "--workdir", str(tmp_path / "wb"), "--horizon-ms", "1500"])
    result = runner.invoke(cli, ["diff", str(a), str(b)])
    assert result.exit_code == 0
    assert "match" in result.output


def test_verify_passes_on_clean_trace(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    trace = tmp_path / "out.trace"
    runner.invoke(cli, ["run", str(scenario), "--trace", str(trace),
                        "--workdir", str(tmp_path / "w"), "--horizon-ms", "2000"])
    result = runner.invoke(cli, ["verify", str(trace),
                                  "--invariant", "agreement"])
    assert result.exit_code == 0
    assert "OK" in result.output


def test_verify_unknown_invariant(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    trace = tmp_path / "out.trace"
    runner.invoke(cli, ["run", str(scenario), "--trace", str(trace),
                        "--workdir", str(tmp_path / "w"), "--horizon-ms", "1500"])
    result = runner.invoke(cli, ["verify", str(trace),
                                  "--invariant", "fake"])
    assert result.exit_code != 0


def test_cover_no_failures_emits_message(tmp_path: Path):
    runner = CliRunner()
    scenario = EXAMPLES / "leader-election-stable.yaml"
    trace = tmp_path / "out.trace"
    runner.invoke(cli, ["run", str(scenario), "--trace", str(trace),
                        "--workdir", str(tmp_path / "w"), "--horizon-ms", "1500"])
    result = runner.invoke(cli, ["cover", str(trace)])
    assert result.exit_code == 0
    assert "no failure injections" in result.output


def test_bench_quick():
    runner = CliRunner()
    result = runner.invoke(cli, ["bench", "--suite", "quick"])
    assert result.exit_code == 0
