"""Tests for the error hierarchy.

The tests touch every subclass at least once, including the structured
fields, because the CLI's error handler keys off these and a quiet
regression would make the worst-case user experience much worse.
"""
from __future__ import annotations

import pytest

from harbor_sim.errors import (
    CodecError,
    DeadlineExceeded,
    DivergenceError,
    HarborSimError,
    InvariantViolation,
    ProtocolError,
    QuorumPolicyError,
    ScenarioError,
    ScenarioReferenceError,
    ScenarioSyntaxError,
    ScenarioValidationError,
    SimulationError,
    ToolError,
    UsageError,
    chain_root,
    format_chain,
)


def test_a():
    # Every domain error inherits from the root.
    classes = [
        ScenarioError,
        ScenarioSyntaxError,
        ScenarioValidationError,
        ScenarioReferenceError,
        SimulationError,
        InvariantViolation,
        DeadlineExceeded,
        DivergenceError,
        CodecError,
        ProtocolError,
        QuorumPolicyError,
        ToolError,
        UsageError,
    ]
    for cls in classes:
        assert issubclass(cls, HarborSimError), cls


def test_syntax_error_renders_with_location():
    err = ScenarioSyntaxError("unexpected token", line=14, column=7)
    assert "line 14" in str(err)
    assert "column 7" in str(err)
    assert "unexpected token" in str(err)


def test_syntax_error_without_location():
    err = ScenarioSyntaxError("blank")
    assert "line" not in str(err)


def test_validation_error_path():
    err = ScenarioValidationError("nodes[2].clock_skew_ms", "must be an integer")
    assert "nodes[2].clock_skew_ms" in str(err)


def test_reference_error_carries_kind_and_name():
    err = ScenarioReferenceError("node", "n7")
    assert err.kind == "node"
    assert err.name == "n7"
    assert "n7" in str(err)


def test_invariant_violation_renders_witness():
    err = InvariantViolation(
        name="linearizability",
        detail="read returned a value never written",
        witness={"key": "x", "got": 4, "candidates": "[1, 2]"},
    )
    rendered = str(err)
    assert "linearizability" in rendered
    assert "key=x" in rendered
    assert "got=4" in rendered


def test_invariant_violation_without_witness():
    err = InvariantViolation(name="agreement", detail="two leaders in one term")
    assert "[" not in str(err)


def test_divergence_carries_both_events():
    err = DivergenceError(at_tick=42, expected={"k": 1}, actual={"k": 2})
    assert err.at_tick == 42
    assert err.expected == {"k": 1}
    assert err.actual == {"k": 2}
    assert "42" in str(err)


def test_codec_error_variants():
    bare = CodecError("short read")
    framed = CodecError("checksum mismatch", offset=4096, version=2)
    versioned = CodecError("unknown opcode", version=3)
    assert "offset 4096" in str(framed)
    assert "v2" in str(framed)
    assert "v3" in str(versioned)
    assert "offset" not in str(bare)


def test_quorum_policy_error_carries_numbers():
    err = QuorumPolicyError(op="read", have=2, want=3)
    assert err.have == 2
    assert err.want == 3
    assert "have=2" in str(err)


def test_usage_error_quotes_command():
    err = UsageError("replay", "missing --trace")
    assert "harbor-sim replay" in str(err)


def test_format_chain_walks_cause():
    inner = CodecError("truncated", offset=12)
    try:
        try:
            raise inner
        except CodecError as e:
            raise SimulationError("could not load") from e
    except SimulationError as outer:
        rendered = format_chain(outer)
    assert "SimulationError" in rendered
    assert "CodecError" in rendered
    assert "truncated" in rendered


def test_format_chain_stops_when_suppressed():
    try:
        try:
            raise CodecError("inner")
        except CodecError:
            # Suppress the chained context.
            raise SimulationError("outer") from None
    except SimulationError as e:
        out = format_chain(e)
    assert "outer" in out
    assert "inner" not in out


def test_chain_root_returns_deepest():
    leaf = CodecError("leaf")
    try:
        try:
            try:
                raise leaf
            except CodecError as a:
                raise ProtocolError("mid") from a
        except ProtocolError as b:
            raise SimulationError("top") from b
    except SimulationError as top:
        root = chain_root(top)
    assert root is leaf


@pytest.mark.parametrize(
    "exc,wanted",
    [
        (ScenarioSyntaxError("bad"), "scenario syntax error: bad"),
        (
            ScenarioValidationError("seed", "must be a non-negative integer"),
            "scenario.seed: must be a non-negative integer",
        ),
        (
            ScenarioReferenceError("link", "broken"),
            "scenario references unknown link: 'broken'",
        ),
    ],
)
def test_str_forms(exc, wanted):
    assert str(exc) == wanted
