"""Exception hierarchy for harbor-sim.

The hierarchy is shallow on purpose. Three roots cover almost every
failure mode:

* :class:`ScenarioError` - anything wrong at scenario-load time.
* :class:`SimulationError` - anything that goes wrong while the
  simulator is running. Has a few notable subclasses for invariant
  violations and trace-format mismatches.
* :class:`ToolError` - CLI-side failures (bad arguments, missing files).

A handful of subclasses carry extra structured fields so callers can
introspect failures without parsing message strings. The :func:`format_chain`
helper at the bottom is the canonical way to print a failure with all
its causes; the CLI uses it for every top-level handler.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


class HarborSimError(Exception):
    """Base class for every harbor-sim exception."""


# ---------- scenario load errors ----------


class ScenarioError(HarborSimError):
    """Something is wrong with the scenario document."""


@dataclass
class ScenarioSyntaxError(ScenarioError):
    """The YAML did not parse, or did not parse into a dict at the top
    level. The location is best-effort - PyYAML's error API is fuzzy.
    """

    detail: str
    line: int | None = None
    column: int | None = None

    def __str__(self) -> str:
        loc = ""
        if self.line is not None:
            loc = f" at line {self.line}"
            if self.column is not None:
                loc += f", column {self.column}"
        return f"scenario syntax error{loc}: {self.detail}"


@dataclass
class ScenarioValidationError(ScenarioError):
    """A scenario field is missing or has a wrong type / value."""

    field_path: str
    detail: str

    def __str__(self) -> str:
        return f"scenario.{self.field_path}: {self.detail}"


@dataclass
class ScenarioReferenceError(ScenarioError):
    """A scenario refers to a node, link, or protocol that wasn't
    declared. Carries the offending name so the CLI can suggest a near
    match.
    """

    kind: str
    name: str

    def __str__(self) -> str:
        return f"scenario references unknown {self.kind}: {self.name!r}"


# ---------- simulation runtime errors ----------


class SimulationError(HarborSimError):
    """Something went wrong while stepping the simulator."""


@dataclass
class InvariantViolation(SimulationError):
    """A safety or liveness invariant was violated mid-run.

    The ``witness`` field carries a small structured fragment that the
    invariant checker emits - enough to make the failure reproducible
    without dragging the entire trace into the exception message.
    """

    name: str
    detail: str
    witness: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        if self.witness:
            keys = ", ".join(f"{k}={v}" for k, v in self.witness.items())
            return f"invariant {self.name!r} violated: {self.detail} [{keys}]"
        return f"invariant {self.name!r} violated: {self.detail}"


class DeadlineExceeded(SimulationError):
    """The scheduler advanced past the configured horizon without
    completing the requested workload."""


class DivergenceError(SimulationError):
    """Replay produced a different event than the recording at the same
    logical time. Carries both events for inspection."""

    def __init__(self, at_tick: int, expected: Any, actual: Any) -> None:
        super().__init__(
            f"replay divergence at tick {at_tick}: "
            f"expected={expected!r} actual={actual!r}"
        )
        self.at_tick = at_tick
        self.expected = expected
        self.actual = actual


@dataclass
class CodecError(SimulationError):
    """Trace / snapshot reader couldn't decode a frame. Either the
    on-disk version is newer than this build, or the file is truncated
    or corrupt."""

    detail: str
    offset: int | None = None
    version: int | None = None

    def __str__(self) -> str:
        if self.offset is not None and self.version is not None:
            return (
                f"codec error at offset {self.offset} (frame v{self.version}): "
                f"{self.detail}"
            )
        if self.version is not None:
            return f"codec error (frame v{self.version}): {self.detail}"
        return f"codec error: {self.detail}"


# ---------- protocol-side errors ----------


class ProtocolError(SimulationError):
    """A protocol implementation produced an illegal transition. These
    are bugs in the protocol code, not in the simulator core."""


@dataclass
class QuorumPolicyError(ProtocolError):
    """A quorum policy was asked for a value it couldn't compute (e.g.
    fewer live replicas than the floor allows)."""

    op: str
    have: int
    want: int

    def __str__(self) -> str:
        return f"quorum policy {self.op!r} infeasible: have={self.have}, want={self.want}"


# ---------- CLI side ----------


class ToolError(HarborSimError):
    """CLI command failed for non-runtime reasons."""


@dataclass
class UsageError(ToolError):
    """User passed a bad combination of flags. Bubbles up to click and
    exits with status 2."""

    command: str
    detail: str

    def __str__(self) -> str:
        return f"`harbor-sim {self.command}`: {self.detail}"


# ---------- helpers ----------


def format_chain(exc: BaseException, indent: int = 0) -> str:
    """Render an exception and its ``__cause__`` / ``__context__`` chain
    as a flat string suitable for the CLI.
    """
    pad = "  " * indent
    head = f"{pad}{type(exc).__name__}: {exc}"
    tail = ""
    if exc.__cause__ is not None:
        # `raise X from Y` always shows the cause.
        tail = "\n" + format_chain(exc.__cause__, indent + 1)
    elif exc.__context__ is not None and not exc.__suppress_context__:
        # Implicit chaining only when `from None` wasn't used.
        tail = "\n" + format_chain(exc.__context__, indent + 1)
    return head + tail


def chain_root(exc: BaseException) -> BaseException:
    """Walk to the deepest cause and return it. Used by tests that
    assert on the original failure regardless of how many wrappers it
    picked up on the way out."""
    cur: BaseException = exc
    while True:
        nxt = cur.__cause__ or cur.__context__
        if nxt is None or nxt is cur:
            return cur
        cur = nxt
