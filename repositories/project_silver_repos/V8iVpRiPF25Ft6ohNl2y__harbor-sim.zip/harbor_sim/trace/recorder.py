"""Writes trace files.

The recorder buffers frames into a small in-memory list and flushes
under three conditions: buffer reaches ``flush_every`` frames, the
recorder is closed, or ``flush()`` is called manually. The flush
writes through zstd into the output file.

The recorder's :meth:`record` method matches the scheduler-hook
signature in :class:`~harbor_sim.scheduler.Scheduler` so callers can
plug it in with ``scheduler.install_hook(recorder.record)``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, BinaryIO

import zstandard as zstd

from harbor_sim.codec import FrameType, encode_frame
from harbor_sim.fsutil import ensure_dir
from harbor_sim.scheduler import Event
from harbor_sim.trace.format import (
    LATEST,
    EventFrame,
    SnapshotFrame,
    TraceHeader,
    WitnessFrame,
)


DEFAULT_FLUSH_EVERY = 256


@dataclass
class TraceRecorder:
    path: Path
    flush_every: int = DEFAULT_FLUSH_EVERY
    _buf: list[bytes] = field(default_factory=list)
    _fh: BinaryIO | None = field(default=None, repr=False)
    _compressor: Any = field(default=None, repr=False)
    _writer: Any = field(default=None, repr=False)
    _closed: bool = False
    _wrote_header: bool = False

    def open(self, header: TraceHeader) -> None:
        if self._fh is not None:
            raise RuntimeError("recorder already open")
        ensure_dir(self.path.parent)
        self._fh = open(self.path, "wb")
        self._compressor = zstd.ZstdCompressor(level=3)
        self._writer = self._compressor.stream_writer(self._fh, closefd=False)
        # Header is a META frame at offset 0.
        h = TraceHeader(
            version=LATEST,
            run_id=header.run_id,
            scenario_hash=header.scenario_hash,
            seed=header.seed,
            started_at_ms=header.started_at_ms,
            extra=dict(header.extra),
        )
        self._buf.append(encode_frame(FrameType.HEADER, h.to_dict()))
        self._wrote_header = True

    def record(self, ev: Event) -> None:
        """Hook signature compatible with the scheduler."""
        if not self._wrote_header:
            raise RuntimeError("recorder must be opened before record()")
        ef = EventFrame(
            event_id=int(ev.id),
            fire_at_ms=ev.fire_at_ms,
            kind=ev.kind,
            target=ev.target,
            payload=ev.payload,
        )
        self._buf.append(encode_frame(FrameType.EVENT, ef.to_dict()))
        if len(self._buf) >= self.flush_every:
            self.flush()

    def witness(self, wf: WitnessFrame) -> None:
        self._buf.append(encode_frame(FrameType.WITNESS, wf.to_dict()))

    def snapshot(self, sf: SnapshotFrame) -> None:
        self._buf.append(encode_frame(FrameType.SNAPSHOT, sf.to_dict()))

    def barrier(self, name: str, fields: dict[str, Any] | None = None) -> None:
        self._buf.append(
            encode_frame(FrameType.BARRIER, {"name": name, **(fields or {})})
        )

    def flush(self) -> None:
        if not self._buf:
            return
        if self._writer is None:
            raise RuntimeError("recorder.flush before open")
        for chunk in self._buf:
            self._writer.write(chunk)
        self._buf.clear()
        self._writer.flush()

    def close(self) -> None:
        if self._closed:
            return
        if self._fh is None or self._writer is None:
            raise RuntimeError("recorder.close before open")
        # Final EOF frame so the reader knows where the stream ends
        # cleanly. v1 traces lack this; the reader tolerates the
        # absence.
        self._buf.append(encode_frame(FrameType.EOF, None))
        self.flush()
        self._writer.flush()
        self._writer.close()
        self._fh.close()
        self._closed = True
