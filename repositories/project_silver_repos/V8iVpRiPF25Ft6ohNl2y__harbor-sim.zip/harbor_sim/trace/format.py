"""Trace format dataclasses.

Three things live on disk inside a trace file:

* A :class:`TraceHeader` exactly once, at the start. Carries the run
  ID, the scenario hash, the format version, and the seed.
* :class:`EventFrame` records, one per scheduler event. Carry the
  event's logical time, kind, target, and an opaque payload dict.
* :class:`SnapshotFrame` and :class:`WitnessFrame`, less common.

The v1 format used newline-delimited JSON inside zstd; the v2 format
uses the framed codec from :mod:`harbor_sim.codec`. v1 had three
problems: partial reads were hard to recover from, CRC was per-line
which gave very weak integrity, and witness records had no schema.
v2 fixes all three.

The reader supports both versions; the writer only emits v2.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

V1 = 1
V2 = 2
SUPPORTED = (V1, V2)
LATEST = V2


@dataclass(slots=True)
class TraceHeader:
    version: int
    run_id: int
    scenario_hash: int
    seed: int
    started_at_ms: int
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "run_id": self.run_id,
            "scenario_hash": self.scenario_hash,
            "seed": self.seed,
            "started_at_ms": self.started_at_ms,
            "extra": dict(self.extra),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TraceHeader":
        return cls(
            version=int(d.get("version", LATEST)),
            run_id=int(d.get("run_id", 0)),
            scenario_hash=int(d.get("scenario_hash", 0)),
            seed=int(d.get("seed", 0)),
            started_at_ms=int(d.get("started_at_ms", 0)),
            extra=dict(d.get("extra") or {}),
        )


@dataclass(slots=True)
class EventFrame:
    """The on-disk representation of one scheduler event."""

    event_id: int
    fire_at_ms: int
    kind: str
    target: str
    payload: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.event_id,
            "t": self.fire_at_ms,
            "k": self.kind,
            "to": self.target,
            "p": dict(self.payload),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "EventFrame":
        return cls(
            event_id=int(d.get("id", 0)),
            fire_at_ms=int(d.get("t", 0)),
            kind=str(d.get("k", "")),
            target=str(d.get("to", "")),
            payload=dict(d.get("p") or {}),
        )


@dataclass(slots=True)
class WitnessFrame:
    """A structured invariant-checker observation."""

    at_ms: int
    invariant: str
    severity: str  # "warn" or "violation"
    detail: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "t": self.at_ms,
            "inv": self.invariant,
            "sev": self.severity,
            "d": dict(self.detail),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "WitnessFrame":
        return cls(
            at_ms=int(d.get("t", 0)),
            invariant=str(d.get("inv", "")),
            severity=str(d.get("sev", "warn")),
            detail=dict(d.get("d") or {}),
        )


@dataclass(slots=True)
class SnapshotFrame:
    """A node snapshot recorded in the trace.

    The state is opaque to the trace - it's just an msgpack-able dict.
    """

    node: str
    snapshot_id: int
    state: dict[str, Any]
    compaction_index: int
    compaction_term: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "n": self.node,
            "id": self.snapshot_id,
            "s": dict(self.state),
            "ci": self.compaction_index,
            "ct": self.compaction_term,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "SnapshotFrame":
        return cls(
            node=str(d.get("n", "")),
            snapshot_id=int(d.get("id", 0)),
            state=dict(d.get("s") or {}),
            compaction_index=int(d.get("ci", 0)),
            compaction_term=int(d.get("ct", 0)),
        )
