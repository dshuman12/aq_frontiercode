"""Reads trace files.

The reader is iterable. Each call to :meth:`frames` yields ``(type, payload)``
tuples; the caller dispatches on the type. Convenience iterators
:meth:`events`, :meth:`witnesses`, :meth:`snapshots` decode the
relevant subset directly into the typed frame classes.

v1 / v2 compatibility: the reader detects the format by sniffing the
first frame. If it's a v1 newline-delimited JSON, the reader switches
to a JSON line iterator. Otherwise it goes through the framed codec.
"""
from __future__ import annotations

import io
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import zstandard as zstd

from harbor_sim.codec import (
    FORMAT_VERSION_SUPPORTED,
    FrameType,
    decode_frame,
    iter_frames,
)
from harbor_sim.errors import CodecError
from harbor_sim.trace.format import (
    V1,
    V2,
    EventFrame,
    SnapshotFrame,
    TraceHeader,
    WitnessFrame,
)


@dataclass
class TraceReader:
    path: Path
    _header: TraceHeader | None = None

    def __post_init__(self) -> None:
        if not self.path.exists():
            raise FileNotFoundError(f"trace not found: {self.path}")

    def _open_decompressed(self) -> io.BytesIO:
        """Decompress the whole trace into memory. The traces this code
        produces are at most a few MB - the simplicity is worth more
        than the streaming-decompressor's incremental savings.
        """
        raw = self.path.read_bytes()
        if raw[:4] == b"\x28\xb5\x2f\xfd":  # zstd magic
            decompressor = zstd.ZstdDecompressor()
            # Stream the decompression so we don't need content-size
            # in the frame header (the recorder uses streaming compress
            # which doesn't write the content size).
            data = decompressor.stream_reader(raw).read()
        else:
            data = raw
        return io.BytesIO(data)

    def header(self) -> TraceHeader:
        if self._header is None:
            stream = self._open_decompressed()
            self._header = _read_header(stream)
        return self._header

    def frames(self) -> Iterator[tuple[FrameType, dict]]:
        """Yield ``(frame_type, payload_dict)`` for every frame after
        the header. Header is not yielded; consult :meth:`header`."""
        stream = self._open_decompressed()
        h = _read_header(stream)
        self._header = h
        if h.version == V1:
            yield from _iter_v1_frames(stream)
            return
        for frame in iter_frames(stream):
            yield frame.type, frame.decoded()

    def events(self) -> Iterator[EventFrame]:
        for ftype, payload in self.frames():
            if ftype == FrameType.EVENT:
                yield EventFrame.from_dict(payload)

    def witnesses(self) -> Iterator[WitnessFrame]:
        for ftype, payload in self.frames():
            if ftype == FrameType.WITNESS:
                yield WitnessFrame.from_dict(payload)

    def snapshots(self) -> Iterator[SnapshotFrame]:
        for ftype, payload in self.frames():
            if ftype == FrameType.SNAPSHOT:
                yield SnapshotFrame.from_dict(payload)


def _read_header(stream: io.BytesIO) -> TraceHeader:
    # The framed-codec header is a HEADER frame at offset 0.
    pos = stream.tell()
    frame = decode_frame(stream)
    if frame is not None and frame.type == FrameType.HEADER:
        return TraceHeader.from_dict(frame.decoded())
    # Not a framed-codec trace. Try v1: newline-delimited JSON with
    # the first line being the header.
    stream.seek(pos)
    import json

    line = stream.readline()
    if not line:
        raise CodecError("empty trace")
    try:
        header_dict = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise CodecError(f"could not parse trace header: {e}") from e
    if header_dict.get("version") not in FORMAT_VERSION_SUPPORTED:
        raise CodecError(
            f"unsupported trace version {header_dict.get('version')}",
            version=int(header_dict.get("version", 0)),
        )
    return TraceHeader.from_dict(header_dict)


def _iter_v1_frames(stream: io.BytesIO) -> Iterator[tuple[FrameType, dict]]:
    """v1 trace iterator. One JSON-encoded record per line. The record
    has a ``type`` field that names the v2 FrameType."""
    import json

    type_map = {
        "event": FrameType.EVENT,
        "witness": FrameType.WITNESS,
        "snapshot": FrameType.SNAPSHOT,
        "barrier": FrameType.BARRIER,
    }
    for line in stream:
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise CodecError(f"v1 trace line parse failed: {e}") from e
        type_name = str(rec.pop("type", "event"))
        ftype = type_map.get(type_name, FrameType.EVENT)
        yield ftype, rec
