"""Trace writer, reader, and migration helpers.

A trace is a series of framed records under zstd compression. The
top-level :class:`TraceRecorder` is the writer; :class:`TraceReader`
parses one back; :mod:`harbor_sim.trace.migrate` converts older
format versions on the fly.
"""
from harbor_sim.trace.format import (  # noqa: F401
    TraceHeader,
    EventFrame,
    WitnessFrame,
    SnapshotFrame,
)
from harbor_sim.trace.recorder import TraceRecorder  # noqa: F401
from harbor_sim.trace.reader import TraceReader  # noqa: F401
from harbor_sim.trace.migrate import migrate_v1_to_v2  # noqa: F401
