"""v1 -> v2 trace migration.

Reads a v1 trace and writes a v2 trace with equivalent content. The
v1 format used newline-delimited JSON inside zstd; v2 uses the framed
codec from :mod:`harbor_sim.codec`.

Field-name renames are encoded here. ``event_id`` -> ``id``, ``fire_at_ms``
-> ``t``, ``kind`` -> ``k``, ``target`` -> ``to``, ``payload`` -> ``p``.
"""
from __future__ import annotations

import io
import json
from pathlib import Path

import zstandard as zstd

from harbor_sim.codec import FrameType, encode_frame
from harbor_sim.errors import CodecError
from harbor_sim.fsutil import atomic_write_bytes
from harbor_sim.trace.format import V1, V2, LATEST, TraceHeader


def migrate_v1_to_v2(src: Path, dst: Path) -> int:
    """Convert ``src`` (v1) to ``dst`` (v2). Returns the count of
    frames migrated.
    """
    raw = src.read_bytes()
    if raw[:4] == b"\x28\xb5\x2f\xfd":
        decompressor = zstd.ZstdDecompressor()
        data = decompressor.stream_reader(raw).read()
    else:
        data = raw

    stream = io.BytesIO(data)
    line = stream.readline()
    if not line:
        raise CodecError("empty trace")
    try:
        header_dict = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise CodecError(f"v1 trace header parse failed: {e}") from e
    if int(header_dict.get("version", 0)) != V1:
        raise CodecError(
            f"migrate_v1_to_v2: not a v1 trace (version={header_dict.get('version')})"
        )

    out_buf = io.BytesIO()
    compressor = zstd.ZstdCompressor(level=3)
    writer = compressor.stream_writer(out_buf, closefd=False)

    new_header = TraceHeader(
        version=V2,
        run_id=int(header_dict.get("run_id", 0)),
        scenario_hash=int(header_dict.get("scenario_hash", 0)),
        seed=int(header_dict.get("seed", 0)),
        started_at_ms=int(header_dict.get("started_at_ms", 0)),
        extra={**(header_dict.get("extra") or {}), "migrated_from": "v1"},
    )
    writer.write(encode_frame(FrameType.HEADER, new_header.to_dict()))

    type_map = {
        "event": (FrameType.EVENT, _rename_event_v1_to_v2),
        "witness": (FrameType.WITNESS, _rename_witness_v1_to_v2),
        "snapshot": (FrameType.SNAPSHOT, _rename_snapshot_v1_to_v2),
        "barrier": (FrameType.BARRIER, lambda d: d),
    }
    n = 0
    for raw_line in stream:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        try:
            rec = json.loads(raw_line.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise CodecError(f"v1 line parse failed: {e}") from e
        type_name = str(rec.pop("type", "event"))
        ftype, renamer = type_map.get(type_name, (FrameType.EVENT, lambda d: d))
        writer.write(encode_frame(ftype, renamer(rec)))
        n += 1

    writer.write(encode_frame(FrameType.EOF, None))
    writer.flush()
    writer.close()

    atomic_write_bytes(dst, out_buf.getvalue())
    return n


def _rename_event_v1_to_v2(d: dict) -> dict:
    return {
        "id": int(d.get("event_id", 0)),
        "t": int(d.get("fire_at_ms", 0)),
        "k": str(d.get("kind", "")),
        "to": str(d.get("target", "")),
        "p": dict(d.get("payload") or {}),
    }


def _rename_witness_v1_to_v2(d: dict) -> dict:
    return {
        "t": int(d.get("at_ms", 0)),
        "inv": str(d.get("invariant", "")),
        "sev": str(d.get("severity", "warn")),
        "d": dict(d.get("detail") or {}),
    }


def _rename_snapshot_v1_to_v2(d: dict) -> dict:
    return {
        "n": str(d.get("node", "")),
        "id": int(d.get("snapshot_id", 0)),
        "s": dict(d.get("state") or {}),
        "ci": int(d.get("compaction_index", 0)),
        "ct": int(d.get("compaction_term", 0)),
    }
