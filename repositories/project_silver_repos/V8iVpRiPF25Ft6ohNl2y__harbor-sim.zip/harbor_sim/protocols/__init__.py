"""Protocol implementations bundled with harbor-sim.

Two reference protocols ship in-tree:

* ``raftlite``: leader election + log replication. Not full Raft -
  no joint consensus, no snapshot installation over the wire. It's
  enough to drive the agreement and election-safety invariants and
  to seed task-authoring against the protocol.
* ``quorum_kv``: a Dynamo-style quorum-replicated key-value store
  with configurable read/write quorums.

Adding a third protocol is well-supported - just implement the
:class:`~harbor_sim.runtime.node.ProtocolImpl` interface. The scenario
loader registers protocols by name through :func:`register`.
"""
from typing import Callable, Type

from harbor_sim.runtime.node import ProtocolImpl

_REGISTRY: dict[str, Callable[..., ProtocolImpl]] = {}


def register(name: str, factory: Callable[..., ProtocolImpl]) -> None:
    if name in _REGISTRY:
        raise ValueError(f"protocol already registered: {name!r}")
    _REGISTRY[name] = factory


def lookup(name: str) -> Callable[..., ProtocolImpl]:
    try:
        return _REGISTRY[name]
    except KeyError as e:
        raise KeyError(
            f"unknown protocol: {name!r}; known: {sorted(_REGISTRY)}"
        ) from e


def known() -> list[str]:
    return sorted(_REGISTRY)


# Eager imports register the bundled protocols.
from harbor_sim.protocols.raftlite import factory as _rl_factory  # noqa: E402
from harbor_sim.protocols.quorum_kv import factory as _qkv_factory  # noqa: E402

register("raftlite", _rl_factory)
register("quorum_kv", _qkv_factory)
