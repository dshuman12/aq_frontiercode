"""Internal state for a raftlite node."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from harbor_sim.ids import LogIndex, NodeId, Term
from harbor_sim.storage.log import Log


class Role(Enum):
    FOLLOWER = "follower"
    CANDIDATE = "candidate"
    LEADER = "leader"


@dataclass
class RaftliteState:
    """The full state machine of a raftlite replica."""

    # Persistent.
    node: NodeId
    peers: list[NodeId]
    current_term: Term = field(default_factory=lambda: Term(0))
    voted_for: NodeId | None = None
    log: Log = field(default_factory=Log)

    # Volatile.
    role: Role = Role.FOLLOWER
    commit_index: LogIndex = field(default_factory=lambda: LogIndex(0))
    last_applied: LogIndex = field(default_factory=lambda: LogIndex(0))

    # Leader-only.
    next_index: dict[NodeId, LogIndex] = field(default_factory=dict)
    match_index: dict[NodeId, LogIndex] = field(default_factory=dict)

    # Election bookkeeping.
    votes_received: set[NodeId] = field(default_factory=set)
    election_timeout_ms: int = 0
    last_heard_from_leader_ms: int = 0

    # Lease bookkeeping. A leader's lease is valid until the global
    # logical time stored here, in node-local milliseconds (i.e. after
    # the skew adjustment).
    lease_expires_at_ms: int = 0
    # Per-peer last-confirmed heartbeat. Used to compute a fresh lease
    # when a quorum of peers acks within the heartbeat interval.
    last_acked_heartbeat_ms: dict[NodeId, int] = field(default_factory=dict)

    # Pending client commands awaiting commit. Keyed by (term, index).
    pending_client_replies: dict[tuple[int, int], dict[str, Any]] = field(
        default_factory=dict
    )

    def become_follower(self, term: Term) -> None:
        self.role = Role.FOLLOWER
        self.current_term = term
        self.voted_for = None
        self.votes_received = set()

    def become_candidate(self) -> None:
        self.role = Role.CANDIDATE
        self.current_term = Term(int(self.current_term) + 1)
        self.voted_for = self.node
        self.votes_received = {self.node}

    def become_leader(self, last_log_index: LogIndex) -> None:
        self.role = Role.LEADER
        # Initialize per-peer indexes.
        for peer in self.peers:
            self.next_index[peer] = LogIndex(int(last_log_index) + 1)
            self.match_index[peer] = LogIndex(0)
        self.votes_received = set()

    def quorum_size(self) -> int:
        """Smallest majority of the full cluster (self + peers)."""
        return (len(self.peers) + 1) // 2 + 1

    def have_quorum(self, n: int) -> bool:
        return n >= self.quorum_size()

    def majority_match(self) -> LogIndex:
        """Highest log index replicated on a majority of peers.

        Used by the leader to advance commit-index. Returns the leader's
        own ``last_index`` when the cluster is a single node.
        """
        if not self.peers:
            return self.log.last_index()
        sorted_matches = sorted(
            list(self.match_index.values()) + [self.log.last_index()],
            key=int,
            reverse=True,
        )
        # The N at majority position - quorum_size() entries down.
        return sorted_matches[self.quorum_size() - 1]
