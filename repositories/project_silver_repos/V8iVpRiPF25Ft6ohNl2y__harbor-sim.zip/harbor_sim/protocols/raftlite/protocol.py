"""raftlite protocol implementation.

The protocol handler exposes the four ``ProtocolImpl`` methods. Most
of the interesting logic is in helper methods on :class:`Raftlite`:
:meth:`_start_election`, :meth:`_send_heartbeats`,
:meth:`_handle_append_entries`, :meth:`_advance_commit_index`,
:meth:`_renew_lease`.

Lease handling
--------------

A leader's lease is valid while a quorum of peers has acknowledged a
heartbeat within the lease duration. The lease bound is stored in
``state.lease_expires_at_ms`` and consulted by client-read paths to
decide whether the leader can answer locally.

The lease check is supposed to use the node-local clock (i.e. with
skew applied) - that's how the model surfaces clock-drift bugs.
Skew-aware deadlines are how we exercise the "lease held past expiry
on a positively-skewed clock" failure mode.
"""
from __future__ import annotations

from typing import Any

from harbor_sim.clock import jitter
from harbor_sim.ids import LogIndex, NodeId, Term
from harbor_sim.protocols.raftlite.messages import (
    KIND_APPEND_ENTRIES,
    KIND_APPEND_ENTRIES_REPLY,
    KIND_CLIENT_PROPOSE,
    KIND_CLIENT_REPLY,
    KIND_REQUEST_VOTE,
    KIND_REQUEST_VOTE_REPLY,
    AppendEntries,
    AppendEntriesReply,
    RequestVote,
    RequestVoteReply,
)
from harbor_sim.protocols.raftlite.state import RaftliteState, Role
from harbor_sim.runtime.context import NodeContext
from harbor_sim.runtime.mailbox import IncomingMessage
from harbor_sim.storage.log import LogEntry


HEARTBEAT_INTERVAL_MS = 50
ELECTION_TIMEOUT_MIN_MS = 150
ELECTION_TIMEOUT_MAX_MS = 300
LEASE_DURATION_MS = 100


class Raftlite:
    """One raftlite replica.

    Construction wires the state machine to the node id and its peers.
    Initialization happens in :meth:`on_init`.
    """

    def __init__(self, node: NodeId, peers: list[NodeId]) -> None:
        self.state = RaftliteState(node=node, peers=list(peers))
        self._heartbeat_timer = None
        self._election_timer = None

    # ---------- ProtocolImpl ----------

    def on_init(self, ctx: NodeContext) -> None:
        self._reset_election_timer(ctx)

    def on_message(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        kind = msg.kind
        if kind == KIND_REQUEST_VOTE:
            self._handle_request_vote(ctx, RequestVote.from_dict(msg.body))
        elif kind == KIND_REQUEST_VOTE_REPLY:
            self._handle_request_vote_reply(
                ctx, RequestVoteReply.from_dict(msg.body)
            )
        elif kind == KIND_APPEND_ENTRIES:
            self._handle_append_entries(ctx, AppendEntries.from_dict(msg.body))
        elif kind == KIND_APPEND_ENTRIES_REPLY:
            self._handle_append_entries_reply(
                ctx, AppendEntriesReply.from_dict(msg.body)
            )
        elif kind == KIND_CLIENT_PROPOSE:
            self._handle_client_propose(ctx, msg)

    def on_timer(self, ctx: NodeContext, key: str, payload: dict[str, Any]) -> None:
        if key == "election":
            self._start_election(ctx)
        elif key == "heartbeat":
            self._send_heartbeats(ctx)
            self._reset_heartbeat_timer(ctx)

    def on_shutdown(self, ctx: NodeContext) -> None:
        pass

    # ---------- election ----------

    def _reset_election_timer(self, ctx: NodeContext) -> None:
        if self._election_timer is not None:
            ctx.cancel_timer(self._election_timer)
        rng = ctx.rng.stream("raftlite-" + str(self.state.node))
        timeout = rng.randint(ELECTION_TIMEOUT_MIN_MS, ELECTION_TIMEOUT_MAX_MS)
        self.state.election_timeout_ms = timeout
        self._election_timer = ctx.set_timer(timeout, "election")

    def _reset_heartbeat_timer(self, ctx: NodeContext) -> None:
        if self._heartbeat_timer is not None:
            ctx.cancel_timer(self._heartbeat_timer)
        rng = ctx.rng.stream("raftlite-" + str(self.state.node))
        interval = jitter(HEARTBEAT_INTERVAL_MS, 5, rng)
        self._heartbeat_timer = ctx.set_timer(interval, "heartbeat")

    def _start_election(self, ctx: NodeContext) -> None:
        if self.state.role == Role.LEADER:
            return
        self.state.become_candidate()
        last_idx = self.state.log.last_index()
        last_term = self.state.log.last_term()
        rv = RequestVote(
            term=self.state.current_term,
            candidate=self.state.node,
            last_log_index=last_idx,
            last_log_term=last_term,
        )
        for peer in self.state.peers:
            ctx.send(peer, KIND_REQUEST_VOTE, rv.to_dict())
        self._reset_election_timer(ctx)

    def _handle_request_vote(self, ctx: NodeContext, req: RequestVote) -> None:
        if int(req.term) > int(self.state.current_term):
            self.state.become_follower(req.term)

        granted = False
        if int(req.term) == int(self.state.current_term):
            already_voted = (
                self.state.voted_for is not None
                and self.state.voted_for != req.candidate
            )
            log_ok = self._candidate_log_ok(req.last_log_term, req.last_log_index)
            if not already_voted and log_ok:
                granted = True
                self.state.voted_for = req.candidate
                self._reset_election_timer(ctx)

        reply = RequestVoteReply(
            term=self.state.current_term,
            granted=granted,
            voter=self.state.node,
        )
        ctx.send(req.candidate, KIND_REQUEST_VOTE_REPLY, reply.to_dict())

    def _candidate_log_ok(self, cand_last_term: Term, cand_last_index: LogIndex) -> bool:
        my_term = self.state.log.last_term()
        my_index = self.state.log.last_index()
        if int(cand_last_term) > int(my_term):
            return True
        if int(cand_last_term) == int(my_term) and int(cand_last_index) >= int(my_index):
            return True
        return False

    def _handle_request_vote_reply(
        self, ctx: NodeContext, rep: RequestVoteReply
    ) -> None:
        if int(rep.term) > int(self.state.current_term):
            self.state.become_follower(rep.term)
            return
        if (
            self.state.role != Role.CANDIDATE
            or int(rep.term) != int(self.state.current_term)
        ):
            return
        if rep.granted:
            self.state.votes_received.add(rep.voter)
            if self.state.have_quorum(len(self.state.votes_received)):
                self._become_leader(ctx)

    def _become_leader(self, ctx: NodeContext) -> None:
        self.state.become_leader(self.state.log.last_index())
        # Reset acks; lease starts unestablished.
        self.state.last_acked_heartbeat_ms = {}
        self.state.lease_expires_at_ms = 0
        self._send_heartbeats(ctx)
        self._reset_heartbeat_timer(ctx)

    # ---------- replication ----------

    def _send_heartbeats(self, ctx: NodeContext) -> None:
        if self.state.role != Role.LEADER:
            return
        for peer in self.state.peers:
            self._send_append_entries(ctx, peer)

    def _send_append_entries(self, ctx: NodeContext, peer: NodeId) -> None:
        next_idx = self.state.next_index.get(peer, LogIndex(1))
        prev_idx = LogIndex(int(next_idx) - 1)
        if int(prev_idx) >= int(self.state.log.first_index):
            try:
                prev_term = self.state.log.get(prev_idx).term
            except KeyError:
                prev_term = self.state.log.last_included_term
        elif int(prev_idx) == int(self.state.log.first_index) - 1:
            prev_term = self.state.log.last_included_term
        else:
            prev_term = Term(0)

        entries = []
        if int(next_idx) <= int(self.state.log.last_index()):
            for e in self.state.log.slice(next_idx, LogIndex(int(self.state.log.last_index()) + 1)):
                entries.append({"t": int(e.term), "i": int(e.index), "d": e.data})

        msg = AppendEntries(
            term=self.state.current_term,
            leader=self.state.node,
            prev_log_index=prev_idx,
            prev_log_term=prev_term,
            entries=entries,
            leader_commit=self.state.commit_index,
            leader_now_ms=ctx.now(),
        )
        ctx.send(peer, KIND_APPEND_ENTRIES, msg.to_dict())

    def _handle_append_entries(self, ctx: NodeContext, req: AppendEntries) -> None:
        if int(req.term) > int(self.state.current_term):
            self.state.become_follower(req.term)
        elif int(req.term) < int(self.state.current_term):
            reply = AppendEntriesReply(
                term=self.state.current_term,
                success=False,
                follower=self.state.node,
                match_index=LogIndex(0),
                follower_now_ms=ctx.now(),
            )
            ctx.send(req.leader, KIND_APPEND_ENTRIES_REPLY, reply.to_dict())
            return

        self.state.role = Role.FOLLOWER
        self.state.last_heard_from_leader_ms = ctx.now()
        self._reset_election_timer(ctx)

        # Consistency check.
        ok = self._check_prev_log(req.prev_log_index, req.prev_log_term)
        if not ok:
            reply = AppendEntriesReply(
                term=self.state.current_term,
                success=False,
                follower=self.state.node,
                match_index=LogIndex(0),
                follower_now_ms=ctx.now(),
            )
            ctx.send(req.leader, KIND_APPEND_ENTRIES_REPLY, reply.to_dict())
            return

        # Append entries, truncating any conflicting tail.
        if req.entries:
            first_new = LogIndex(int(req.prev_log_index) + 1)
            self.state.log.truncate_from(first_new)
            for e in req.entries:
                self.state.log.append(
                    LogEntry(term=Term(int(e["t"])), index=LogIndex(int(e["i"])), data=e["d"])
                )

        # Advance commit index.
        if int(req.leader_commit) > int(self.state.commit_index):
            new_commit = LogIndex(
                min(int(req.leader_commit), int(self.state.log.last_index()))
            )
            self.state.commit_index = new_commit
            self._apply_committed()

        reply = AppendEntriesReply(
            term=self.state.current_term,
            success=True,
            follower=self.state.node,
            match_index=self.state.log.last_index(),
            follower_now_ms=ctx.now(),
        )
        ctx.send(req.leader, KIND_APPEND_ENTRIES_REPLY, reply.to_dict())

    def _check_prev_log(self, prev_idx: LogIndex, prev_term: Term) -> bool:
        if int(prev_idx) == 0:
            return True
        if int(prev_idx) < int(self.state.log.first_index):
            return int(prev_term) == int(self.state.log.last_included_term)
        if not self.state.log.contains(prev_idx):
            return False
        entry = self.state.log.get(prev_idx)
        return int(entry.term) == int(prev_term)

    def _handle_append_entries_reply(
        self, ctx: NodeContext, rep: AppendEntriesReply
    ) -> None:
        if int(rep.term) > int(self.state.current_term):
            self.state.become_follower(rep.term)
            return
        if self.state.role != Role.LEADER:
            return
        if rep.success:
            self.state.match_index[rep.follower] = rep.match_index
            self.state.next_index[rep.follower] = LogIndex(int(rep.match_index) + 1)
            self.state.last_acked_heartbeat_ms[rep.follower] = ctx.now()
            self._advance_commit_index()
            self._renew_lease(ctx)
        else:
            # Walk back next_index on failure.
            cur = self.state.next_index.get(rep.follower, LogIndex(1))
            self.state.next_index[rep.follower] = LogIndex(max(1, int(cur) - 1))

    def _advance_commit_index(self) -> None:
        if self.state.role != Role.LEADER:
            return
        majority = self.state.majority_match()
        if int(majority) <= int(self.state.commit_index):
            return
        # Only entries from the current term can be committed by counting.
        try:
            term_at_majority = self.state.log.get(majority).term
        except KeyError:
            return
        if int(term_at_majority) != int(self.state.current_term):
            return
        self.state.commit_index = majority
        self._apply_committed()

    def _apply_committed(self) -> None:
        # Apply is observable via the trace recorder; the protocol
        # only tracks last_applied. The applied state itself lives on
        # whatever the workload generator wired up.
        while int(self.state.last_applied) < int(self.state.commit_index):
            self.state.last_applied = LogIndex(int(self.state.last_applied) + 1)

    def _renew_lease(self, ctx: NodeContext) -> None:
        """Refresh the leader's lease if a quorum of peers has acked
        within the lease duration.

        Lease bound is computed against the most-recent confirmed-by-
        a-quorum heartbeat. Reads served under the lease can avoid a
        round-trip to peers.
        """
        if self.state.role != Role.LEADER:
            return
        now = ctx.scheduler.now_ms
        # Find the most recent timestamp that a quorum of peers has
        # acked at or after.
        ack_times = sorted(self.state.last_acked_heartbeat_ms.values(), reverse=True)
        # Include the leader's own "ack" - the leader trivially confirms.
        ack_times.append(now)
        ack_times.sort(reverse=True)
        # The quorum-th element from the top is the lower bound on the
        # quorum-confirmed time.
        q = self.state.quorum_size()
        if len(ack_times) < q:
            return
        quorum_confirmed_at = ack_times[q - 1]
        # The lease extends LEASE_DURATION_MS past the quorum-confirmed
        # time.
        new_expiry = quorum_confirmed_at + LEASE_DURATION_MS
        if new_expiry > self.state.lease_expires_at_ms:
            self.state.lease_expires_at_ms = new_expiry

    def has_valid_lease(self, ctx: NodeContext) -> bool:
        """Whether the leader's lease is currently in force.

        Consulted by the read path. The lease check uses the local
        (skewed) clock - that's the point of the per-node Clock.
        """
        if self.state.role != Role.LEADER:
            return False
        return ctx.now() < self.state.lease_expires_at_ms

    # ---------- client ----------

    def _handle_client_propose(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        if self.state.role != Role.LEADER:
            # Redirect: tell the client who we last heard from as leader.
            ctx.send(
                msg.from_node,
                KIND_CLIENT_REPLY,
                {
                    "ok": False,
                    "reason": "not_leader",
                    "term": int(self.state.current_term),
                },
            )
            return
        # Append to log, send heartbeats to replicate.
        next_idx = LogIndex(int(self.state.log.last_index()) + 1)
        entry = LogEntry(
            term=self.state.current_term,
            index=next_idx,
            data={"op": msg.body.get("op"), "client": str(msg.from_node)},
        )
        self.state.log.append(entry)
        self._send_heartbeats(ctx)
