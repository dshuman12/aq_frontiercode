from __future__ import annotations

from harbor_sim.ids import NodeId
from harbor_sim.protocols.raftlite.protocol import Raftlite


def factory(node: NodeId, peers: list[NodeId], **kwargs) -> Raftlite:
    return Raftlite(node=node, peers=list(peers))
