"""raftlite: a minimal Raft-style leader election + log replication.

Not the full Raft protocol. Specifically missing:

* Joint consensus / config changes.
* InstallSnapshot RPC. Followers learn about snapshots out-of-band.
* Read-index optimization. Reads go through the leader's log.

What it does:

* Election: random election-timeout, RequestVote RPC, simple majority.
* Replication: AppendEntries RPC with prev-index/term consistency
  check, commit-index propagation.
* Leader lease: a leader holds its lease for the configured lease
  duration after the most recent quorum-confirmed heartbeat. Reads
  during the lease are linearizable without a round-trip.
"""
from harbor_sim.protocols.raftlite.factory import factory  # noqa: F401
from harbor_sim.protocols.raftlite.state import Role, RaftliteState  # noqa: F401
