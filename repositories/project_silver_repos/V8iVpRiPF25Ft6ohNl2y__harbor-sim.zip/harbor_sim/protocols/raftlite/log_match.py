"""Log-matching helpers for raftlite.

The log-matching property is the heart of Raft's safety story: if
two logs contain an entry with the same index and term, they are
identical up to that index. This module factors the consistency
check into testable pieces.
"""
from __future__ import annotations

from harbor_sim.ids import LogIndex, Term
from harbor_sim.storage.log import Log, LogEntry


def prev_log_matches(
    log: Log,
    prev_index: LogIndex,
    prev_term: Term,
) -> bool:
    """Whether the log at ``prev_index`` has term ``prev_term``.

    Three cases:

    * ``prev_index == 0``: trivially matches; this is the bootstrap
      case for the first AppendEntries a leader sends.
    * ``prev_index < first_index``: the entry is in the snapshotted
      prefix. We can only check against ``last_included_term``.
    * ``prev_index >= first_index``: the entry is in the live log.
      Look it up directly.
    """
    if int(prev_index) == 0:
        return True
    if int(prev_index) < int(log.first_index):
        return int(prev_term) == int(log.last_included_term)
    if not log.contains(prev_index):
        return False
    return int(log.get(prev_index).term) == int(prev_term)


def find_conflict_index(log: Log, entries: list[LogEntry]) -> LogIndex | None:
    """Walk ``entries`` against ``log`` from the bottom; return the
    first index where the terms disagree, or None if they all match.

    Used by AppendEntries handling to decide how much of the
    follower's log to truncate.
    """
    for e in entries:
        if not log.contains(e.index):
            return None
        existing = log.get(e.index)
        if int(existing.term) != int(e.term):
            return e.index
    return None


def safe_to_commit(log: Log, index: LogIndex, current_term: Term) -> bool:
    """Whether a leader can commit the entry at ``index``.

    Raft's commit safety: a leader may only count replicas for
    commit purposes if the entry being committed was written under
    the leader's own term. Earlier-term entries get committed
    transitively when a later-term entry above them is committed.
    """
    if not log.contains(index):
        return False
    entry = log.get(index)
    return int(entry.term) == int(current_term)


def lowest_uncommitted_index(log: Log, commit_index: LogIndex) -> LogIndex | None:
    """The lowest index in the log that is past the commit index.
    Returns None if everything is committed."""
    if int(log.last_index()) <= int(commit_index):
        return None
    return LogIndex(int(commit_index) + 1)
