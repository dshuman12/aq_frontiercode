"""Timing parameters for raftlite, isolated so tests can override.

The defaults are tuned for a 3-node LAN-like scenario: heartbeats
every 50ms, election timeout uniform in [150, 300]ms, lease
duration 100ms. These are not real-Raft numbers; real-Raft scales
the election timeout up an order of magnitude.
"""
from __future__ import annotations

from dataclasses import dataclass, replace


@dataclass(slots=True)
class TimingParams:
    heartbeat_interval_ms: int = 50
    heartbeat_jitter_ms: int = 5
    election_timeout_min_ms: int = 150
    election_timeout_max_ms: int = 300
    lease_duration_ms: int = 100
    apply_batch_size: int = 64

    def validate(self) -> None:
        if self.heartbeat_interval_ms <= 0:
            raise ValueError("heartbeat_interval_ms must be positive")
        if self.election_timeout_min_ms <= 0:
            raise ValueError("election_timeout_min_ms must be positive")
        if self.election_timeout_max_ms < self.election_timeout_min_ms:
            raise ValueError("election_timeout_max_ms < min")
        if self.heartbeat_interval_ms >= self.election_timeout_min_ms:
            # Real Raft requires heartbeat_interval << election_timeout
            # so a healthy leader can't be timed out by its own slow
            # heartbeats. We're lenient about it but warn through the
            # error type so the test suite picks it up.
            raise ValueError(
                "heartbeat_interval_ms must be < election_timeout_min_ms"
            )
        if self.lease_duration_ms < 0:
            raise ValueError("lease_duration_ms must be non-negative")

    def scaled(self, factor: float) -> "TimingParams":
        """Return a new TimingParams with every duration scaled by
        ``factor``. Used in tests that want to compress or stretch
        the timeline without recomputing every number by hand."""
        return replace(
            self,
            heartbeat_interval_ms=int(self.heartbeat_interval_ms * factor),
            heartbeat_jitter_ms=int(self.heartbeat_jitter_ms * factor),
            election_timeout_min_ms=int(self.election_timeout_min_ms * factor),
            election_timeout_max_ms=int(self.election_timeout_max_ms * factor),
            lease_duration_ms=int(self.lease_duration_ms * factor),
        )


DEFAULT = TimingParams()


def aggressive_timing() -> TimingParams:
    """Faster timing for short-horizon tests where we don't need
    realistic numbers and want elections to happen quickly."""
    return TimingParams(
        heartbeat_interval_ms=10,
        heartbeat_jitter_ms=2,
        election_timeout_min_ms=30,
        election_timeout_max_ms=60,
        lease_duration_ms=20,
        apply_batch_size=8,
    )


def conservative_timing() -> TimingParams:
    """Slower timing for scenarios where we want elections to be
    rare events. Closer to real-world Raft numbers."""
    return TimingParams(
        heartbeat_interval_ms=200,
        heartbeat_jitter_ms=20,
        election_timeout_min_ms=1_000,
        election_timeout_max_ms=2_000,
        lease_duration_ms=500,
        apply_batch_size=128,
    )
