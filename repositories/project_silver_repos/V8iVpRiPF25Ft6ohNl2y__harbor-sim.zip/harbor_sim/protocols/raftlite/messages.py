"""Wire messages for raftlite.

Kept as plain dataclasses + a (to_dict, from_dict) round-trip rather
than a heavier serialization framework. The transport layer hands the
body around as a dict; these helpers keep the conversion in one place.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from harbor_sim.ids import LogIndex, NodeId, Term


@dataclass(slots=True)
class RequestVote:
    term: Term
    candidate: NodeId
    last_log_index: LogIndex
    last_log_term: Term

    def to_dict(self) -> dict[str, Any]:
        return {
            "term": int(self.term),
            "candidate": str(self.candidate),
            "last_log_index": int(self.last_log_index),
            "last_log_term": int(self.last_log_term),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "RequestVote":
        return cls(
            term=Term(int(d["term"])),
            candidate=NodeId(str(d["candidate"])),
            last_log_index=LogIndex(int(d["last_log_index"])),
            last_log_term=Term(int(d["last_log_term"])),
        )


@dataclass(slots=True)
class RequestVoteReply:
    term: Term
    granted: bool
    voter: NodeId

    def to_dict(self) -> dict[str, Any]:
        return {
            "term": int(self.term),
            "granted": self.granted,
            "voter": str(self.voter),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "RequestVoteReply":
        return cls(
            term=Term(int(d["term"])),
            granted=bool(d["granted"]),
            voter=NodeId(str(d["voter"])),
        )


@dataclass(slots=True)
class AppendEntries:
    term: Term
    leader: NodeId
    prev_log_index: LogIndex
    prev_log_term: Term
    entries: list[dict[str, Any]]  # serialized LogEntry dicts
    leader_commit: LogIndex
    leader_now_ms: int  # leader-local clock, used for lease checks

    def to_dict(self) -> dict[str, Any]:
        return {
            "term": int(self.term),
            "leader": str(self.leader),
            "prev_log_index": int(self.prev_log_index),
            "prev_log_term": int(self.prev_log_term),
            "entries": self.entries,
            "leader_commit": int(self.leader_commit),
            "leader_now_ms": self.leader_now_ms,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "AppendEntries":
        return cls(
            term=Term(int(d["term"])),
            leader=NodeId(str(d["leader"])),
            prev_log_index=LogIndex(int(d["prev_log_index"])),
            prev_log_term=Term(int(d["prev_log_term"])),
            entries=list(d.get("entries") or []),
            leader_commit=LogIndex(int(d["leader_commit"])),
            leader_now_ms=int(d["leader_now_ms"]),
        )


@dataclass(slots=True)
class AppendEntriesReply:
    term: Term
    success: bool
    follower: NodeId
    match_index: LogIndex  # follower's last index on success; ignore on failure
    follower_now_ms: int  # follower-local clock at reply time

    def to_dict(self) -> dict[str, Any]:
        return {
            "term": int(self.term),
            "success": self.success,
            "follower": str(self.follower),
            "match_index": int(self.match_index),
            "follower_now_ms": self.follower_now_ms,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "AppendEntriesReply":
        return cls(
            term=Term(int(d["term"])),
            success=bool(d["success"]),
            follower=NodeId(str(d["follower"])),
            match_index=LogIndex(int(d["match_index"])),
            follower_now_ms=int(d["follower_now_ms"]),
        )


# Kind tags used at the transport layer.
KIND_REQUEST_VOTE = "rv"
KIND_REQUEST_VOTE_REPLY = "rv_rep"
KIND_APPEND_ENTRIES = "ae"
KIND_APPEND_ENTRIES_REPLY = "ae_rep"
KIND_CLIENT_PROPOSE = "cli_propose"
KIND_CLIENT_REPLY = "cli_reply"
