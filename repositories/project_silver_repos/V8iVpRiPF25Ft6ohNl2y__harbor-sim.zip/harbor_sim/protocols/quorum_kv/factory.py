from __future__ import annotations

from harbor_sim.ids import NodeId
from harbor_sim.protocols.quorum_kv.policy import QuorumPolicy
from harbor_sim.protocols.quorum_kv.replica import QuorumKV


def factory(node: NodeId, peers: list[NodeId], **kwargs) -> QuorumKV:
    cluster = len(peers) + 1
    n = int(kwargs.get("n_replicas", cluster))
    r = int(kwargs.get("read_quorum", (n // 2) + 1))
    w = int(kwargs.get("write_quorum", (n // 2) + 1))
    floor = int(kwargs.get("staleness_floor", 0))
    policy = QuorumPolicy(
        n_replicas=n,
        read_quorum=r,
        write_quorum=w,
        staleness_floor=floor,
    )
    return QuorumKV(node=node, peers=list(peers), policy=policy)
