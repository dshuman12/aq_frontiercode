"""Per-replica state for quorum_kv."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from harbor_sim.ids import NodeId
from harbor_sim.protocols.quorum_kv.policy import QuorumPolicy
from harbor_sim.runtime.context import NodeContext
from harbor_sim.runtime.mailbox import IncomingMessage


@dataclass(slots=True)
class VersionedValue:
    """A key-value record with version metadata.

    ``writer`` and ``generation`` together form the per-key version.
    Conflict resolution is last-write-wins by ``(writer, generation)``
    pair, with writer breaking ties so that two writes with the same
    generation produce a deterministic resolution.
    """

    value: Any
    writer: NodeId
    generation: int
    written_at_ms: int

    def vector(self) -> tuple[int, str]:
        return (self.generation, str(self.writer))


KIND_WRITE = "qkv_write"
KIND_WRITE_ACK = "qkv_write_ack"
KIND_READ = "qkv_read"
KIND_READ_REPLY = "qkv_read_reply"
KIND_CLIENT_GET = "qkv_get"
KIND_CLIENT_PUT = "qkv_put"
KIND_CLIENT_REPLY = "qkv_cli_reply"


@dataclass
class QuorumKV:
    """One replica of a quorum-replicated key-value store."""

    node: NodeId
    peers: list[NodeId]
    policy: QuorumPolicy

    # Per-key replicated state.
    store: dict[str, VersionedValue] = field(default_factory=dict)

    # Per-client request bookkeeping. Indexed by request id assigned
    # by the client.
    pending_writes: dict[str, dict[str, Any]] = field(default_factory=dict)
    pending_reads: dict[str, dict[str, Any]] = field(default_factory=dict)

    # Last-write-quorum recording for the staleness check.
    last_write_quorum: dict[str, set[NodeId]] = field(default_factory=dict)

    # Local generation counter for writes originated here.
    _gen: int = 0

    def on_init(self, ctx: NodeContext) -> None:
        pass

    def on_shutdown(self, ctx: NodeContext) -> None:
        pass

    def on_timer(self, ctx: NodeContext, key: str, payload: dict[str, Any]) -> None:
        pass

    def on_message(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        kind = msg.kind
        if kind == KIND_CLIENT_PUT:
            self._handle_client_put(ctx, msg)
        elif kind == KIND_CLIENT_GET:
            self._handle_client_get(ctx, msg)
        elif kind == KIND_WRITE:
            self._handle_write(ctx, msg)
        elif kind == KIND_WRITE_ACK:
            self._handle_write_ack(ctx, msg)
        elif kind == KIND_READ:
            self._handle_read(ctx, msg)
        elif kind == KIND_READ_REPLY:
            self._handle_read_reply(ctx, msg)

    # ---------- writes ----------

    def _handle_client_put(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        body = msg.body
        rid = str(body["rid"])
        key = str(body["key"])
        value = body["value"]
        self._gen += 1
        vv = VersionedValue(
            value=value,
            writer=self.node,
            generation=self._gen,
            written_at_ms=ctx.now(),
        )
        self.pending_writes[rid] = {
            "client": msg.from_node,
            "key": key,
            "vv": vv,
            "acks": {self.node},
        }
        # Apply locally first.
        self._apply_write(key, vv)
        # Fan out to peers.
        for peer in self.peers:
            ctx.send(
                peer,
                KIND_WRITE,
                {
                    "rid": rid,
                    "key": key,
                    "value": value,
                    "writer": str(vv.writer),
                    "generation": vv.generation,
                    "written_at_ms": vv.written_at_ms,
                },
            )

    def _handle_write(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        body = msg.body
        vv = VersionedValue(
            value=body["value"],
            writer=NodeId(str(body["writer"])),
            generation=int(body["generation"]),
            written_at_ms=int(body["written_at_ms"]),
        )
        self._apply_write(str(body["key"]), vv)
        ctx.send(
            msg.from_node,
            KIND_WRITE_ACK,
            {"rid": body["rid"], "from": str(self.node)},
        )

    def _handle_write_ack(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        rid = str(msg.body["rid"])
        pending = self.pending_writes.get(rid)
        if pending is None:
            return
        pending["acks"].add(NodeId(str(msg.body["from"])))
        if len(pending["acks"]) >= self.policy.write_quorum:
            # Quorum reached: record and reply.
            self.last_write_quorum[pending["key"]] = set(pending["acks"])
            client = pending["client"]
            ctx.send(
                client,
                KIND_CLIENT_REPLY,
                {"rid": rid, "ok": True, "kind": "put"},
            )
            del self.pending_writes[rid]

    def _apply_write(self, key: str, vv: VersionedValue) -> None:
        existing = self.store.get(key)
        if existing is None or vv.vector() > existing.vector():
            self.store[key] = vv

    # ---------- reads ----------

    def _handle_client_get(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        body = msg.body
        rid = str(body["rid"])
        key = str(body["key"])
        local = self.store.get(key)
        self.pending_reads[rid] = {
            "client": msg.from_node,
            "key": key,
            "responses": {self.node: local},
        }
        for peer in self.peers:
            ctx.send(peer, KIND_READ, {"rid": rid, "key": key})

    def _handle_read(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        rid = str(msg.body["rid"])
        key = str(msg.body["key"])
        v = self.store.get(key)
        body = {"rid": rid, "from": str(self.node), "found": v is not None}
        if v is not None:
            body.update(
                {
                    "value": v.value,
                    "writer": str(v.writer),
                    "generation": v.generation,
                    "written_at_ms": v.written_at_ms,
                }
            )
        ctx.send(msg.from_node, KIND_READ_REPLY, body)

    def _handle_read_reply(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        rid = str(msg.body["rid"])
        pending = self.pending_reads.get(rid)
        if pending is None:
            return
        peer = NodeId(str(msg.body["from"]))
        if msg.body.get("found", False):
            vv = VersionedValue(
                value=msg.body["value"],
                writer=NodeId(str(msg.body["writer"])),
                generation=int(msg.body["generation"]),
                written_at_ms=int(msg.body["written_at_ms"]),
            )
        else:
            vv = None
        pending["responses"][peer] = vv
        if len(pending["responses"]) >= self.policy.read_quorum:
            # Resolve: pick the highest version across responses.
            resolved = None
            for v in pending["responses"].values():
                if v is None:
                    continue
                if resolved is None or v.vector() > resolved.vector():
                    resolved = v
            client = pending["client"]
            ctx.send(
                client,
                KIND_CLIENT_REPLY,
                {
                    "rid": rid,
                    "ok": True,
                    "kind": "get",
                    "found": resolved is not None,
                    "value": resolved.value if resolved else None,
                    "writer": str(resolved.writer) if resolved else None,
                    "generation": resolved.generation if resolved else None,
                },
            )
            del self.pending_reads[rid]
