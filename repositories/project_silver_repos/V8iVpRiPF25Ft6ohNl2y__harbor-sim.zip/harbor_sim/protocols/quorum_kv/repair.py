"""Anti-entropy / read-repair for quorum_kv.

When a quorum read observes divergent versions across replicas, the
freshest version should be pushed back to the stale ones. This is
"read repair" in the Dynamo sense.

The repair module is a small state machine that the replica calls
into when a read completes. It computes the staleness vector and
issues catch-up writes to the replicas behind. It does NOT block
the read - the read returns to the client immediately.

Future work: a periodic anti-entropy pass that walks every key and
verifies cross-replica agreement. The hooks are present; the timer-
driven sweep isn't wired up.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from harbor_sim.ids import NodeId
from harbor_sim.protocols.quorum_kv.replica import VersionedValue
from harbor_sim.runtime.context import NodeContext


KIND_REPAIR_WRITE = "qkv_repair"


@dataclass
class RepairStats:
    repairs_issued: int = 0
    keys_touched: set[str] = field(default_factory=set)


@dataclass
class ReadRepair:
    """Computes which replicas are stale relative to a quorum read."""

    stats: RepairStats = field(default_factory=RepairStats)

    def maybe_repair(
        self,
        ctx: NodeContext,
        key: str,
        responses: dict[NodeId, VersionedValue | None],
        winner: VersionedValue | None,
    ) -> int:
        """Issue catch-up writes to replicas behind ``winner``. Returns
        the count of repair messages sent."""
        if winner is None:
            return 0
        sent = 0
        for replica, v in responses.items():
            if v is not None and v.vector() >= winner.vector():
                continue
            ctx.send(
                replica,
                KIND_REPAIR_WRITE,
                {
                    "key": key,
                    "value": winner.value,
                    "writer": str(winner.writer),
                    "generation": winner.generation,
                    "written_at_ms": winner.written_at_ms,
                },
            )
            sent += 1
        if sent:
            self.stats.repairs_issued += sent
            self.stats.keys_touched.add(key)
        return sent

    def reset_stats(self) -> None:
        self.stats = RepairStats()


def staleness_vector(
    responses: dict[NodeId, VersionedValue | None],
    winner: VersionedValue | None,
) -> dict[NodeId, int]:
    """How far behind ``winner`` each responder is. Behind-ness is
    measured as the difference in (generation, writer) - we use
    generation alone because the writer tiebreaker is orthogonal.
    """
    if winner is None:
        return {r: 0 for r in responses}
    out = {}
    for r, v in responses.items():
        if v is None:
            out[r] = winner.generation
        else:
            out[r] = max(0, winner.generation - v.generation)
    return out


def consensus_round(
    responses: dict[NodeId, VersionedValue | None],
) -> VersionedValue | None:
    """Pick the freshest version across responses, or None if none had
    any value."""
    winner: VersionedValue | None = None
    for v in responses.values():
        if v is None:
            continue
        if winner is None or v.vector() > winner.vector():
            winner = v
    return winner
