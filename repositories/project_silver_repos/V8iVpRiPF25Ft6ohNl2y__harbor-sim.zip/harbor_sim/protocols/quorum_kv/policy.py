"""Quorum-sizing policy for quorum_kv.

Encapsulates the read/write quorum math and the staleness floor.

The staleness floor is a configurable property of the read path. When
set above zero, a read quorum that fails to overlap with the most
recent write quorum by at least ``staleness_floor`` replicas is
rejected as too stale; the client gets a "retry" rather than a
possibly-out-of-date value.

The floor is computed against the replica IDs that participated in
the latest known write. Implementing it cleanly requires the policy
to know the *live* replica set and the *write-quorum recordings*
from recent writes, both of which the replica layer threads through.

Right now, the policy accepts the floor as configuration and exposes
:meth:`check_staleness` for the replica to call, but the call site in
:mod:`quorum_kv.replica` doesn't invoke it yet. The hooks are present
because the linearizability invariant checker needs to see the policy
witness in the trace.
"""
from __future__ import annotations

from dataclasses import dataclass

from harbor_sim.errors import QuorumPolicyError
from harbor_sim.ids import NodeId


@dataclass(slots=True)
class QuorumPolicy:
    """Read/write quorum policy for one key namespace."""

    n_replicas: int
    read_quorum: int
    write_quorum: int
    staleness_floor: int = 0  # min overlap between read- and last-write-quorum

    def __post_init__(self) -> None:
        if self.n_replicas <= 0:
            raise ValueError(f"n_replicas must be positive, got {self.n_replicas}")
        if not 1 <= self.read_quorum <= self.n_replicas:
            raise ValueError(
                f"read_quorum {self.read_quorum} out of range [1, {self.n_replicas}]"
            )
        if not 1 <= self.write_quorum <= self.n_replicas:
            raise ValueError(
                f"write_quorum {self.write_quorum} out of range [1, {self.n_replicas}]"
            )
        if not 0 <= self.staleness_floor <= self.n_replicas:
            raise ValueError(
                f"staleness_floor {self.staleness_floor} out of "
                f"range [0, {self.n_replicas}]"
            )

    def is_strongly_consistent(self) -> bool:
        return self.read_quorum + self.write_quorum > self.n_replicas

    def write_feasible(self, live_replicas: int) -> bool:
        return live_replicas >= self.write_quorum

    def read_feasible(self, live_replicas: int) -> bool:
        return live_replicas >= self.read_quorum

    def require_write_feasible(self, live: int) -> None:
        if not self.write_feasible(live):
            raise QuorumPolicyError(
                op="write", have=live, want=self.write_quorum
            )

    def require_read_feasible(self, live: int) -> None:
        if not self.read_feasible(live):
            raise QuorumPolicyError(op="read", have=live, want=self.read_quorum)

    def check_staleness(
        self,
        read_set: set[NodeId],
        last_write_set: set[NodeId],
    ) -> bool:
        """Whether a read quorum is fresh enough relative to the most
        recent write quorum.

        ``read_set`` is the set of replicas that responded to the read.
        ``last_write_set`` is the set of replicas that acked the most
        recent successful write.

        Returns True if the read can proceed, False if the staleness
        floor was violated.
        """
        if self.staleness_floor <= 0:
            return True
        overlap = len(read_set & last_write_set)
        return overlap >= self.staleness_floor
