"""quorum_kv: a Dynamo-style quorum-replicated KV store.

Every key has N replicas (configurable). Writes require a write quorum
W of acks; reads require a read quorum R of replicas to respond. When
``R + W > N`` the store is strongly consistent in the no-failure case.

Implementation details:

* Versions are vector-clocks-of-one - a single (writer, generation)
  pair per key. This is enough for last-write-wins reconciliation
  without bringing in true vector clocks.
* Reads at a read quorum take the latest version observed across the
  read set, optionally subject to a staleness floor.
"""
from harbor_sim.protocols.quorum_kv.factory import factory  # noqa: F401
from harbor_sim.protocols.quorum_kv.policy import QuorumPolicy  # noqa: F401
from harbor_sim.protocols.quorum_kv.replica import QuorumKV  # noqa: F401
