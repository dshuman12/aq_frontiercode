"""In-memory transport between nodes.

The transport sits between the protocol layer and the scheduler. It
maintains a graph of links (one direction per link), each with its own
latency model, drop rate, and partition state. Sending a message
schedules a delivery event on the recipient's mailbox.

The latency model is plain: each link has a ``(low, high)``
range and the transport samples uniformly within it on every send. Some
scenarios want a fixed latency; pass ``low == high``.

The reorder behavior is the interesting bit. Sends on a link with
``reorder=True`` get jitter applied at send time so two messages on the
same link can swap. With ``reorder=False`` the transport tracks a per-link
"earliest unblocked time" so message N can never deliver before message
N-1.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from harbor_sim.errors import ScenarioReferenceError
from harbor_sim.ids import NodeId
from harbor_sim.rng import RngBundle
from harbor_sim.scheduler import Scheduler


@dataclass(slots=True)
class LinkConfig:
    """Configuration for one directional link.

    ``latency_ms`` is inclusive on both ends. ``drop_rate`` is a
    probability in [0, 1]; we draw once per message. ``reorder``
    controls whether the per-link FIFO invariant is enforced.
    """

    src: NodeId
    dst: NodeId
    latency_low_ms: int = 5
    latency_high_ms: int = 20
    drop_rate: float = 0.0
    reorder: bool = False
    capacity: int | None = None  # max in-flight messages; None = unlimited


@dataclass
class _LinkState:
    config: LinkConfig
    last_delivery_ms: int = 0
    in_flight: int = 0
    partitioned: bool = False


@dataclass
class Transport:
    """The simulator's network.

    Owned by the :class:`Simulator`. Protocols see a per-node view of
    the transport (via the runtime context) and call ``send`` with a
    destination. The transport routes through the link configured for
    that (src, dst) pair, applying latency, drop, partition, and the
    FIFO invariant.
    """

    scheduler: Scheduler
    rng: RngBundle
    _links: dict[tuple[NodeId, NodeId], _LinkState] = field(default_factory=dict)
    _drops: int = 0
    _sends: int = 0
    _delivered: int = 0

    def add_link(self, cfg: LinkConfig) -> None:
        if cfg.latency_low_ms < 0 or cfg.latency_high_ms < cfg.latency_low_ms:
            raise ValueError(
                f"add_link: bad latency range "
                f"[{cfg.latency_low_ms}, {cfg.latency_high_ms}]"
            )
        if not 0.0 <= cfg.drop_rate <= 1.0:
            raise ValueError(f"add_link: drop_rate out of range: {cfg.drop_rate}")
        key = (cfg.src, cfg.dst)
        self._links[key] = _LinkState(config=cfg)

    def has_link(self, src: NodeId, dst: NodeId) -> bool:
        return (src, dst) in self._links

    def link(self, src: NodeId, dst: NodeId) -> LinkConfig:
        try:
            return self._links[(src, dst)].config
        except KeyError as e:
            raise ScenarioReferenceError(
                "link", f"{src}->{dst}"
            ) from e

    def partition(self, src: NodeId, dst: NodeId, on: bool = True) -> None:
        """Mark the link partitioned (drops everything) or unpartitioned."""
        state = self._links.get((src, dst))
        if state is None:
            raise ScenarioReferenceError("link", f"{src}->{dst}")
        state.partitioned = on

    def partition_pair(self, a: NodeId, b: NodeId, on: bool = True) -> None:
        """Convenience: partition both directions of a node pair."""
        if (a, b) in self._links:
            self.partition(a, b, on)
        if (b, a) in self._links:
            self.partition(b, a, on)

    def send(
        self,
        src: NodeId,
        dst: NodeId,
        kind: str,
        payload: dict[str, Any],
    ) -> int | None:
        """Schedule a message from ``src`` to ``dst``.

        Returns the delivery time on success, None if the message was
        dropped (partition, drop_rate, or capacity exceeded).
        """
        state = self._links.get((src, dst))
        if state is None:
            raise ScenarioReferenceError("link", f"{src}->{dst}")

        self._sends += 1

        if state.partitioned:
            self._drops += 1
            return None

        cfg = state.config
        rng = self.rng.stream("transport")

        if cfg.drop_rate > 0 and rng.random() < cfg.drop_rate:
            self._drops += 1
            return None

        if cfg.capacity is not None and state.in_flight >= cfg.capacity:
            self._drops += 1
            return None

        latency = rng.randint(cfg.latency_low_ms, cfg.latency_high_ms)
        fire_at = self.scheduler.now_ms + latency

        if not cfg.reorder:
            # FIFO: this delivery may not precede the link's last
            # scheduled delivery.
            if fire_at <= state.last_delivery_ms:
                fire_at = state.last_delivery_ms + 1
        state.last_delivery_ms = max(state.last_delivery_ms, fire_at)

        delivery_payload = {
            "from": src,
            "kind": kind,
            "body": payload,
            "send_at": self.scheduler.now_ms,
        }
        self.scheduler.schedule_at(
            fire_at,
            "deliver",
            target=str(dst),
            payload=delivery_payload,
        )
        state.in_flight += 1
        return fire_at

    def on_delivered(self, src: NodeId, dst: NodeId) -> None:
        """Called by the runtime when a delivery event fires; lets the
        transport decrement its in-flight counter."""
        state = self._links.get((src, dst))
        if state is not None and state.in_flight > 0:
            state.in_flight -= 1
        self._delivered += 1

    def stats(self) -> dict[str, int]:
        return {
            "sends": self._sends,
            "drops": self._drops,
            "delivered": self._delivered,
        }

    def links(self) -> list[LinkConfig]:
        """All registered links, in insertion order."""
        return [s.config for s in self._links.values()]


def fan_out(transport: Transport, src: NodeId, dsts: list[NodeId],
            kind: str, payload: dict[str, Any]) -> list[int | None]:
    """Convenience: send the same message to a list of recipients.

    Returns a list of delivery times (or None for drops) in the same
    order as ``dsts``. Used by raft's heartbeat-broadcast and by the
    quorum-KV write path.
    """
    out: list[int | None] = []
    for dst in dsts:
        if not transport.has_link(src, dst):
            out.append(None)
            continue
        out.append(transport.send(src, dst, kind, payload))
    return out
