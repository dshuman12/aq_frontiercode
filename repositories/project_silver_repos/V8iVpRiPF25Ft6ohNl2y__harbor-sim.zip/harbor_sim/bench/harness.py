"""Benchmark harness.

Each suite is a list of (scenario, horizon) pairs. The harness runs
each pair, captures elapsed wall-clock time, and reports
events-per-second along with a small breakdown.

The bench numbers are not comparable across machines (we don't try
to control for CPU frequency or background load). They're useful
for catching local regressions.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

from harbor_sim.scenario.loader import load
from harbor_sim.scenario.materialize import materialize


@dataclass
class BenchResult:
    name: str
    horizon_ms: int
    events: int
    wall_seconds: float

    def events_per_second(self) -> float:
        if self.wall_seconds <= 0:
            return float("inf")
        return self.events / self.wall_seconds


@dataclass
class BenchSuite:
    name: str
    cases: list[tuple[Path, int]]


def _quick_suite(examples_dir: Path) -> BenchSuite:
    return BenchSuite(
        name="quick",
        cases=[
            (examples_dir / "leader-election-stable.yaml", 5_000),
            (examples_dir / "crash-restart-snapshot.yaml", 5_000),
        ],
    )


def _full_suite(examples_dir: Path) -> BenchSuite:
    return BenchSuite(
        name="full",
        cases=[
            (examples_dir / "leader-election-stable.yaml", 30_000),
            (examples_dir / "leader-election-under-partition.yaml", 30_000),
            (examples_dir / "crash-restart-snapshot.yaml", 60_000),
        ],
    )


def run_suite(name: str, workdir: Path, examples_dir: Path) -> list[BenchResult]:
    if name == "quick":
        suite = _quick_suite(examples_dir)
    elif name == "full":
        suite = _full_suite(examples_dir)
    else:
        raise ValueError(f"unknown suite {name!r}")

    out: list[BenchResult] = []
    for case_path, horizon in suite.cases:
        if not case_path.exists():
            continue
        sc = load(case_path)
        sim = materialize(sc, workdir=workdir / sc.name)
        sim.boot_all()
        start = time.perf_counter()
        n = sim.run(horizon_ms=horizon)
        elapsed = time.perf_counter() - start
        out.append(BenchResult(
            name=sc.name,
            horizon_ms=horizon,
            events=n,
            wall_seconds=elapsed,
        ))
    return out
