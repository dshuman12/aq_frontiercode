"""Benchmark harness.

The bench runs a small fixed set of scenarios under a stopwatch
and reports throughput numbers. Used by `harbor-sim bench` and by
the perf-investigation runbook.
"""
from harbor_sim.bench.harness import BenchResult, BenchSuite, run_suite  # noqa: F401
