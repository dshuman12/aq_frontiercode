"""Discrete-event scheduler.

The scheduler is a priority queue keyed by ``(fire_at_ms, tie_break,
seq)`` where ``tie_break`` is a stable per-event integer drawn from
the seeded RNG and ``seq`` is a monotonic counter that disambiguates
events that share the same fire time and tie-break.

Why the three-part key:

  * ``fire_at_ms`` is the only thing that matters semantically.
  * ``tie_break`` exists so that two events scheduled at the same
    millisecond don't always fire in insertion order. Some bugs only
    surface under reordering; without ``tie_break`` they hide behind
    "the leader always heartbeats first".
  * ``seq`` is the final tie-breaker; two events with the same
    ``(fire_at_ms, tie_break)`` are very rare but possible (an
    in-the-loop schedule with no RNG draw), and we want totally
    deterministic ordering anyway.

The scheduler is responsible for advancing the global :class:`SimClock`
each time it dequeues. Nothing else may touch ``SimClock.now_ms``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from sortedcontainers import SortedList

from harbor_sim.clock import SimClock
from harbor_sim.errors import DeadlineExceeded
from harbor_sim.ids import EventId, IdAllocator
from harbor_sim.rng import RngBundle


@dataclass(slots=True)
class Event:
    """A single scheduled event.

    ``payload`` is opaque to the scheduler. The runtime / transport /
    protocol layers interpret it. Carrying it as a free-form dict keeps
    the scheduler decoupled from every consumer.
    """

    id: EventId
    fire_at_ms: int
    tie_break: int
    seq: int
    kind: str  # "tick", "deliver", "timeout", "client", "fault" ...
    target: str  # node id, link id, or a synthetic name
    payload: dict[str, Any] = field(default_factory=dict)

    def key(self) -> tuple[int, int, int]:
        return (self.fire_at_ms, self.tie_break, self.seq)


@dataclass
class Scheduler:
    """The simulator's event loop.

    Construction takes a :class:`SimClock` and an :class:`RngBundle`.
    The bundle's "scheduler" stream is used for tie-breaks.

    The hot path is :meth:`step`. It dequeues one event, advances the
    clock to that event's fire time, and returns the event to the
    caller. The runtime then dispatches it to a handler.

    Cancellation is handled by an "alive" set; cancelled events are
    skipped on dequeue. We don't bother removing them from the sorted
    list because the constant-factor cost of the lookup matches the
    cost of a removal.
    """

    clock: SimClock
    rng: RngBundle
    _queue: SortedList = field(default_factory=lambda: SortedList(key=lambda e: e.key()))
    _ids: IdAllocator = field(default_factory=lambda: IdAllocator("ev"))
    _seq: int = 0
    _alive: set[int] = field(default_factory=set)
    _hooks: list[Callable[[Event], None]] = field(default_factory=list)

    @property
    def now_ms(self) -> int:
        return self.clock.now_ms

    def schedule(
        self,
        delay_ms: int,
        kind: str,
        target: str,
        payload: dict[str, Any] | None = None,
    ) -> EventId:
        """Enqueue an event ``delay_ms`` after the current time.

        Returns the event id for use with :meth:`cancel`. ``delay_ms``
        must be non-negative; zero-delay events are allowed and fire
        on the current tick (after any other zero-delay events scheduled
        before them, with tie-breaks applied).
        """
        if delay_ms < 0:
            raise ValueError(f"schedule: delay must be non-negative, got {delay_ms}")
        eid = EventId(self._ids.alloc())
        tie = self.rng.stream("scheduler").randint(0, 1 << 30)
        seq = self._seq
        self._seq += 1
        ev = Event(
            id=eid,
            fire_at_ms=self.clock.now_ms + delay_ms,
            tie_break=tie,
            seq=seq,
            kind=kind,
            target=target,
            payload=dict(payload or {}),
        )
        self._queue.add(ev)
        self._alive.add(int(eid))
        return eid

    def schedule_at(
        self,
        at_ms: int,
        kind: str,
        target: str,
        payload: dict[str, Any] | None = None,
    ) -> EventId:
        if at_ms < self.clock.now_ms:
            raise ValueError(
                f"schedule_at: target {at_ms} is in the past (now={self.clock.now_ms})"
            )
        return self.schedule(at_ms - self.clock.now_ms, kind, target, payload)

    def cancel(self, eid: EventId) -> bool:
        """Mark an event as cancelled. Returns True if the event was
        live; False if it had already fired or been cancelled."""
        if int(eid) in self._alive:
            self._alive.discard(int(eid))
            return True
        return False

    def step(self) -> Event | None:
        """Dequeue and return the next live event, advancing the clock.

        Returns None if the queue drained without finding a live event.
        """
        while self._queue:
            ev = self._queue.pop(0)
            if int(ev.id) not in self._alive:
                continue
            self._alive.discard(int(ev.id))
            self.clock.advance_to(ev.fire_at_ms)
            for hook in self._hooks:
                hook(ev)
            return ev
        return None

    def peek(self) -> Event | None:
        """Look at the next live event without dequeuing or advancing."""
        for ev in self._queue:
            if int(ev.id) in self._alive:
                return ev
        return None

    def run_until(self, horizon_ms: int, on_event: Callable[[Event], None]) -> int:
        """Drive the queue until either it drains or the next event
        fires past the horizon. Returns the number of events fired.

        Events that fire exactly at the horizon are included. If the
        next-event time exceeds the horizon, the clock is advanced to
        ``horizon_ms`` and the function returns.
        """
        n = 0
        while True:
            nxt = self.peek()
            if nxt is None:
                self.clock.advance_to(horizon_ms)
                return n
            if nxt.fire_at_ms > horizon_ms:
                self.clock.advance_to(horizon_ms)
                return n
            ev = self.step()
            assert ev is not None
            on_event(ev)
            n += 1

    def drain(
        self,
        on_event: Callable[[Event], None],
        max_events: int = 1_000_000,
    ) -> int:
        """Run until the queue drains or ``max_events`` events have
        fired. Raises :class:`DeadlineExceeded` if the cap is hit."""
        n = 0
        while True:
            ev = self.step()
            if ev is None:
                return n
            on_event(ev)
            n += 1
            if n >= max_events:
                raise DeadlineExceeded(
                    f"drain hit {max_events} events without draining the queue"
                )

    def install_hook(self, hook: Callable[[Event], None]) -> None:
        """Register a callback fired on every dequeue, before dispatch.

        Used by the trace recorder. Hooks must not enqueue new events
        synchronously - that's the runtime's job.
        """
        self._hooks.append(hook)

    def remove_hook(self, hook: Callable[[Event], None]) -> bool:
        try:
            self._hooks.remove(hook)
            return True
        except ValueError:
            return False

    def pending(self) -> int:
        """Count of live events still in the queue. Cancelled ones are
        excluded."""
        return sum(1 for ev in self._queue if int(ev.id) in self._alive)
