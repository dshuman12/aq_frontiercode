"""harbor-sim: a deterministic discrete-event simulator for replicated
state machines.

The public surface is small on purpose. Most users go through the CLI or
the :class:`Scenario` / :class:`Simulator` pair. Direct access to the
event scheduler, transport, and node runtime is supported but considered
intermediate-API.
"""
from __future__ import annotations

__version__ = "0.3.1"
__all__ = [
    "__version__",
    "Scenario",
    "Simulator",
    "TraceRecorder",
]


def _lazy(name: str):
    # Avoid importing heavy subsystems on `import harbor_sim`. The CLI in
    # particular wants startup to stay under 50ms.
    if name == "Scenario":
        from harbor_sim.scenario.model import Scenario  # noqa: F401

        return Scenario
    if name == "Simulator":
        from harbor_sim.runtime.simulator import Simulator  # noqa: F401

        return Simulator
    if name == "TraceRecorder":
        from harbor_sim.trace.recorder import TraceRecorder  # noqa: F401

        return TraceRecorder
    raise AttributeError(name)


def __getattr__(name: str):
    return _lazy(name)
