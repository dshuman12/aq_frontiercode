from __future__ import annotations

from pathlib import Path

import click

from harbor_sim.invariants import all_checkers
from harbor_sim.trace.reader import TraceReader


@click.command("verify")
@click.argument("trace", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--invariant", "names", multiple=True,
              help="Invariant name(s) to run. Default: all.")
@click.option("--staleness-floor", type=int, default=0,
              help="Configure the linearizability check's staleness floor.")
def verify(trace: Path, names: tuple[str, ...], staleness_floor: int) -> None:
    """Verify TRACE against invariants."""
    reader = TraceReader(path=trace)
    registry = all_checkers()
    if names:
        unknown = [n for n in names if n not in registry]
        if unknown:
            click.echo(f"unknown invariants: {unknown}", err=True)
            raise click.exceptions.Exit(2)
        registry = {n: registry[n] for n in names}

    instances = []
    for name, cls in registry.items():
        if name == "linearizability":
            instances.append(cls(staleness_floor=staleness_floor))
        else:
            instances.append(cls())

    for ev in reader.events():
        for inst in instances:
            inst.observe(ev)

    for inst in instances:
        inst.finalize()

    total_violations = sum(i.violation_count() for i in instances)
    for inst in instances:
        click.echo(
            f"{inst.name}: {'OK' if inst.passed() else f'FAIL ({inst.violation_count()} violations)'}"
        )
        for w in inst.witnesses():
            click.echo(f"  at {w.at_ms}ms [{w.severity}] {w.detail}")

    if total_violations > 0:
        raise click.exceptions.Exit(1)
