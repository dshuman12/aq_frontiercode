"""harbor-sim's command-line interface.

Entry point lives in :mod:`harbor_sim.cli.main`. Subcommands are each
in their own module so the help-text strings can stay in one place
per command. ``click`` does the argument parsing.
"""
from harbor_sim.cli.main import cli  # noqa: F401
