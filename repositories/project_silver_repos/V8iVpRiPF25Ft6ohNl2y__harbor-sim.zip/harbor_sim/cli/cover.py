"""`harbor-sim cover` - report which failure-injection categories a
trace observed.

This command is half a feature - it lists the failure modes observed
but doesn't compute a coverage score against a scenario's failure
mode set. The scoring half is on TODO.md.
"""
from __future__ import annotations

from pathlib import Path

import click

from harbor_sim.trace.reader import TraceReader


@click.command("cover")
@click.argument("trace", type=click.Path(exists=True, dir_okay=False, path_type=Path))
def cover(trace: Path) -> None:
    """Report failure-mode categories observed in TRACE."""
    reader = TraceReader(path=trace)
    seen: dict[str, int] = {}
    for ev in reader.events():
        if ev.kind != "fault":
            continue
        kind = str(ev.payload.get("fault_kind", "unknown"))
        seen[kind] = seen.get(kind, 0) + 1
    if not seen:
        click.echo("no failure injections observed")
        return
    for k, n in sorted(seen.items()):
        click.echo(f"  {k}: {n}")
