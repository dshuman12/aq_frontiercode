from __future__ import annotations

from pathlib import Path

import click

from harbor_sim.trace.format import EventFrame
from harbor_sim.trace.reader import TraceReader


@click.command("diff")
@click.argument("a", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.argument("b", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--limit", type=int, default=20,
              help="Show at most N divergent events.")
def diff(a: Path, b: Path, limit: int) -> None:
    """Compare two traces and report the first divergent events."""
    ra = list(TraceReader(path=a).events())
    rb = list(TraceReader(path=b).events())
    shown = 0
    for i, (ea, eb) in enumerate(zip(ra, rb)):
        if not _eq(ea, eb):
            click.echo(f"--- a[{i}] {_compact(ea)}")
            click.echo(f"+++ b[{i}] {_compact(eb)}")
            shown += 1
            if shown >= limit:
                break
    if len(ra) != len(rb):
        click.echo(f"length mismatch: a has {len(ra)} events, b has {len(rb)}")
        raise click.exceptions.Exit(1)
    if shown > 0:
        raise click.exceptions.Exit(1)
    click.echo(f"traces match across {len(ra)} events")


def _eq(a: EventFrame, b: EventFrame) -> bool:
    return (a.fire_at_ms, a.kind, a.target, a.payload) == (
        b.fire_at_ms, b.kind, b.target, b.payload
    )


def _compact(e: EventFrame) -> str:
    return f"t={e.fire_at_ms}ms kind={e.kind} to={e.target}"
