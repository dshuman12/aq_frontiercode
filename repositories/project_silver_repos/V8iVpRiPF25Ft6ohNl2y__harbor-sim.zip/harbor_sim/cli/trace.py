"""`harbor-sim trace` - subgroup for trace-format utilities.

Currently exposes one subcommand: ``migrate``.
"""
from __future__ import annotations

from pathlib import Path

import click

from harbor_sim.trace.migrate import migrate_v1_to_v2


@click.group("trace")
def trace() -> None:
    """Trace-format utilities."""


@trace.command("migrate")
@click.argument("src", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.argument("dst", type=click.Path(path_type=Path))
def trace_migrate(src: Path, dst: Path) -> None:
    """Convert a v1 trace SRC to a v2 trace DST."""
    n = migrate_v1_to_v2(src, dst)
    click.echo(f"migrated {n} frames v1 -> v2 -> {dst}")
