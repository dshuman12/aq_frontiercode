"""CLI entry point.

Six subcommands:

* ``run``: load a scenario, run it, write a trace.
* ``replay``: feed a trace back through the simulator, compare.
* ``verify``: walk a trace through the invariant checkers.
* ``diff``: compare two traces event-by-event.
* ``inspect``: structured pretty-print of a trace.
* ``trace migrate``: convert a v1 trace to v2.
* ``cover``: report which failure-injection categories a trace
  observed.
* ``bench``: drive a small built-in benchmark.
"""
from __future__ import annotations

import sys
from pathlib import Path

import click

from harbor_sim import __version__
from harbor_sim.cli import (
    cover as cover_cmd,
    diff as diff_cmd,
    inspect as inspect_cmd,
    replay as replay_cmd,
    run as run_cmd,
    trace as trace_cmd,
    verify as verify_cmd,
)
from harbor_sim.errors import HarborSimError, format_chain


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__, prog_name="harbor-sim")
@click.option("-v", "--verbose", count=True, help="Repeat for more verbosity.")
@click.pass_context
def cli(ctx: click.Context, verbose: int) -> None:
    """harbor-sim: a deterministic distributed-system simulator."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose


cli.add_command(run_cmd.run)
cli.add_command(replay_cmd.replay)
cli.add_command(verify_cmd.verify)
cli.add_command(diff_cmd.diff)
cli.add_command(inspect_cmd.inspect)
cli.add_command(cover_cmd.cover)
cli.add_command(trace_cmd.trace)


@cli.command("bench")
@click.option("--suite", type=click.Choice(["quick", "full"]), default="quick")
def bench(suite: str) -> None:
    """Run a tiny built-in benchmark."""
    click.echo(f"running {suite} bench (placeholder)")


def main(argv: list[str] | None = None) -> int:
    try:
        cli.main(args=argv, standalone_mode=False)
    except click.exceptions.Exit as e:
        return int(e.exit_code)
    except click.UsageError as e:
        click.echo(f"usage: {e}", err=True)
        return 2
    except HarborSimError as e:
        click.echo(format_chain(e), err=True)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
