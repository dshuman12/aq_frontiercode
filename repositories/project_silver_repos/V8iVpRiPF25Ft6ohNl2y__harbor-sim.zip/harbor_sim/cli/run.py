# `harbor-sim run` -- load a scenario, run it, emit a trace.
from __future__ import annotations

from pathlib import Path

import click

from harbor_sim.errors import UsageError
from harbor_sim.hashing import stable_hash
from harbor_sim.scenario.loader import load
from harbor_sim.scenario.materialize import materialize
from harbor_sim.trace.format import LATEST, TraceHeader
from harbor_sim.trace.recorder import TraceRecorder


@click.command("run")
@click.argument("scenario", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--trace", "trace_path", type=click.Path(path_type=Path),
              help="Trace output path. Required.")
@click.option("--workdir", type=click.Path(path_type=Path),
              default=Path(".harbor-runs"), help="Per-node working directory root.")
@click.option("--horizon-ms", type=int, default=None,
              help="Override the scenario's horizon.")
def run(scenario: Path, trace_path: Path | None, workdir: Path, horizon_ms: int | None) -> None:
    """Run SCENARIO and write a trace."""
    if trace_path is None:
        raise UsageError("run", "missing --trace")

    sc = load(scenario)
    sim = materialize(sc, workdir=workdir)
    sim.boot_all()

    recorder = TraceRecorder(path=trace_path)
    header = TraceHeader(
        version=LATEST,
        run_id=int(stable_hash(sc) & ((1 << 31) - 1)),
        scenario_hash=int(stable_hash(sc)),
        seed=sc.seed,
        started_at_ms=0,
        extra={"scenario_name": sc.name, "protocol": sc.protocol},
    )
    recorder.open(header)
    sim.scheduler.install_hook(recorder.record)

    horizon = horizon_ms if horizon_ms is not None else sc.horizon_ms
    n = sim.run(horizon_ms=horizon)
    recorder.close()

    click.echo(f"ran {n} events; trace -> {trace_path}")
