from __future__ import annotations

import re
from pathlib import Path

import click

from harbor_sim.errors import UsageError
from harbor_sim.replay.engine import ReplayEngine


@click.command("replay")
@click.argument("trace", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--scenario", "scenario_path", required=True,
              type=click.Path(exists=True, dir_okay=False, path_type=Path),
              help="Scenario file to materialize.")
@click.option("--workdir", type=click.Path(path_type=Path),
              default=Path(".harbor-replay"),
              help="Working directory for replay.")
@click.option("--until", "until", default=None,
              help='Stop at the given logical time, e.g. "5000ms".')
def replay(trace: Path, scenario_path: Path, workdir: Path, until: str | None) -> None:
    """Replay TRACE against the original scenario."""
    cutoff = _parse_duration(until) if until is not None else None
    engine = ReplayEngine(
        trace_path=trace,
        scenario_text=scenario_path.read_text(encoding="utf-8"),
        workdir=workdir,
    )
    if cutoff is None:
        n = engine.replay()
    else:
        n = engine.replay_until(cutoff)
    click.echo(f"replayed {n} events; trace matches recording")


_DURATION = re.compile(r"^(\d+)(ms|s|min)?$")


def _parse_duration(value: str) -> int:
    m = _DURATION.match(value.strip())
    if m is None:
        raise UsageError("replay", f"could not parse duration: {value!r}")
    n = int(m.group(1))
    unit = m.group(2) or "ms"
    if unit == "ms":
        return n
    if unit == "s":
        return n * 1000
    if unit == "min":
        return n * 60_000
    raise UsageError("replay", f"unsupported duration unit: {unit!r}")
