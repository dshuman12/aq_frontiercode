from __future__ import annotations

from pathlib import Path

import click

from harbor_sim.trace.reader import TraceReader


@click.command("inspect")
@click.argument("trace", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--filter", "filter_str", default=None,
              help="Filter expression like 'kind=deliver,target=n1'.")
@click.option("--limit", type=int, default=50)
def inspect(trace: Path, filter_str: str | None, limit: int) -> None:
    """Inspect TRACE in a human-readable form."""
    reader = TraceReader(path=trace)
    header = reader.header()
    click.echo(
        f"trace v{header.version} run={header.run_id} seed={header.seed} "
        f"scenario_hash={header.scenario_hash:#x}"
    )

    filters: dict[str, str] = {}
    if filter_str:
        for part in filter_str.split(","):
            if "=" not in part:
                continue
            k, v = part.split("=", 1)
            filters[k.strip()] = v.strip()

    shown = 0
    for ev in reader.events():
        if filters:
            if "kind" in filters and ev.kind != filters["kind"]:
                continue
            if "target" in filters and ev.target != filters["target"]:
                continue
        click.echo(
            f"  t={ev.fire_at_ms}ms id={ev.event_id} kind={ev.kind} "
            f"to={ev.target} payload_keys={sorted(ev.payload.keys())}"
        )
        shown += 1
        if shown >= limit:
            click.echo(f"  ... (truncated; {shown} of many)")
            break
    if shown == 0:
        click.echo("  (no matching events)")
