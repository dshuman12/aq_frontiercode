"""Diagnostic helpers usable from a debugger or REPL.

When a scenario goes wrong, the first thing I reach for is one of
these. None of them are on the hot path; all of them are cheap to
call.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from harbor_sim.ids import NodeId
from harbor_sim.runtime.simulator import Simulator


@dataclass
class ClusterSnapshot:
    """A point-in-time snapshot of cluster state. Read-only, for
    inspection. Not the same thing as a :class:`Snapshot` for
    persistence."""

    at_ms: int
    nodes: dict[str, dict[str, Any]]
    transport_stats: dict[str, int]
    queue_pending: int

    def __str__(self) -> str:
        lines = [
            f"cluster @ t={self.at_ms}ms",
            f"  queue pending: {self.queue_pending}",
            f"  transport: {self.transport_stats}",
        ]
        for nid, state in sorted(self.nodes.items()):
            lines.append(f"  {nid}: {state}")
        return "\n".join(lines)


def snapshot_cluster(sim: Simulator) -> ClusterSnapshot:
    nodes = {}
    for nid, node in sim.nodes.items():
        nodes[str(nid)] = _summarize_node(node)
    return ClusterSnapshot(
        at_ms=sim.clock.now_ms,
        nodes=nodes,
        transport_stats=sim.transport.stats(),
        queue_pending=sim.scheduler.pending(),
    )


def _summarize_node(node) -> dict[str, Any]:
    out: dict[str, Any] = {
        "crashed": node.crashed,
        "booted": node.booted,
        "inbox_len": node.mailbox.inbox_len(),
        "outbox_len": node.mailbox.outbox_len(),
        "local_time": node.clock.now(),
    }
    state = getattr(node.protocol, "state", None)
    if state is not None:
        out.update(_summarize_state(state))
    return out


def _summarize_state(state) -> dict[str, Any]:
    # raftlite shape.
    out: dict[str, Any] = {}
    for attr in ("role", "current_term", "voted_for", "commit_index", "last_applied"):
        v = getattr(state, attr, None)
        if v is not None:
            if hasattr(v, "value"):  # enum
                out[attr] = v.value
            else:
                out[attr] = int(v) if isinstance(v, (int, float)) else str(v)
    log = getattr(state, "log", None)
    if log is not None:
        out["log_length"] = log.length()
        out["log_first_index"] = int(log.first_index)
        out["log_last_index"] = int(log.last_index())
    return out


def find_node_by_role(sim: Simulator, role: str) -> list[NodeId]:
    """Return all nodes whose protocol state reports the given role."""
    out = []
    for nid, node in sim.nodes.items():
        state = getattr(node.protocol, "state", None)
        if state is None:
            continue
        r = getattr(state, "role", None)
        if r is None:
            continue
        if hasattr(r, "value") and r.value == role:
            out.append(nid)
        elif str(r) == role:
            out.append(nid)
    return out


def cluster_summary_table(sim: Simulator) -> list[list[str]]:
    """A table of per-node state suitable for pretty-printing."""
    rows = [["node", "role", "term", "commit", "log_last"]]
    for nid, node in sim.nodes.items():
        state = getattr(node.protocol, "state", None)
        if state is None:
            rows.append([str(nid), "-", "-", "-", "-"])
            continue
        role = getattr(state, "role", "-")
        role_str = role.value if hasattr(role, "value") else str(role)
        rows.append([
            str(nid),
            role_str,
            str(getattr(state, "current_term", "-")),
            str(getattr(state, "commit_index", "-")),
            str(getattr(state.log, "last_index", lambda: "-")()) if hasattr(state, "log") else "-",
        ])
    return rows
