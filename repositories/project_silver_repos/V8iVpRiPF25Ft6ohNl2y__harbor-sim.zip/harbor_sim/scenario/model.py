"""Scenario dataclasses."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class NodeSpec:
    id: str
    role: str = "replica"
    clock_skew_ms: int = 0
    clock_drift_ppm: int = 0
    initial_snapshot_id: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class LinkSpec:
    src: str
    dst: str
    latency_low_ms: int = 5
    latency_high_ms: int = 20
    drop_rate: float = 0.0
    reorder: bool = False
    capacity: int | None = None
    bidirectional: bool = True


@dataclass(slots=True)
class FailureSpec:
    """A scheduled fault injection."""

    at_ms: int
    kind: str  # "partition", "crash", "recover"
    target: str = ""   # node id for crash/recover
    a: str = ""         # one side of a partition
    b: str = ""         # other side
    duration_ms: int | None = None
    on: bool = True

    def to_event_payload(self) -> dict[str, Any]:
        out = {"fault_kind": self.kind, "on": self.on}
        if self.a:
            out["a"] = self.a
        if self.b:
            out["b"] = self.b
        return out


@dataclass(slots=True)
class WorkloadSpec:
    kind: str = "noop"  # "kv", "leader_propose", "noop"
    clients: int = 0
    ops_per_client: int = 0
    keys: list[str] = field(default_factory=list)
    value_size_bytes: int = 16
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class Scenario:
    """A parsed, validated scenario."""

    name: str
    seed: int
    horizon_ms: int
    protocol: str
    nodes: list[NodeSpec]
    links: list[LinkSpec]
    failures: list[FailureSpec] = field(default_factory=list)
    workload: WorkloadSpec = field(default_factory=WorkloadSpec)
    protocol_options: dict[str, Any] = field(default_factory=dict)

    def node_ids(self) -> list[str]:
        return [n.id for n in self.nodes]

    def get_node(self, name: str) -> NodeSpec:
        for n in self.nodes:
            if n.id == name:
                return n
        raise KeyError(name)

    def _stable_hash_repr(self) -> dict[str, Any]:
        # Used by hashing.stable_hash to derive the canonical scenario
        # hash. Keep the field order stable across releases.
        return {
            "name": self.name,
            "seed": self.seed,
            "horizon_ms": self.horizon_ms,
            "protocol": self.protocol,
            "nodes": [
                {
                    "id": n.id, "role": n.role,
                    "clock_skew_ms": n.clock_skew_ms,
                    "clock_drift_ppm": n.clock_drift_ppm,
                    "initial_snapshot_id": n.initial_snapshot_id,
                }
                for n in self.nodes
            ],
            "links": [
                {
                    "src": l.src, "dst": l.dst,
                    "latency_low_ms": l.latency_low_ms,
                    "latency_high_ms": l.latency_high_ms,
                    "drop_rate": l.drop_rate,
                    "reorder": l.reorder,
                    "capacity": l.capacity,
                    "bidirectional": l.bidirectional,
                }
                for l in self.links
            ],
            "failures": [
                {
                    "at_ms": f.at_ms, "kind": f.kind, "target": f.target,
                    "a": f.a, "b": f.b, "duration_ms": f.duration_ms, "on": f.on,
                }
                for f in self.failures
            ],
            "workload": {
                "kind": self.workload.kind,
                "clients": self.workload.clients,
                "ops_per_client": self.workload.ops_per_client,
                "keys": list(self.workload.keys),
                "value_size_bytes": self.workload.value_size_bytes,
            },
            "protocol_options": dict(self.protocol_options),
        }
