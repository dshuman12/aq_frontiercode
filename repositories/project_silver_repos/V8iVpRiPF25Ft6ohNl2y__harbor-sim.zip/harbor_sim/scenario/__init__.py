"""Scenario loading.

A scenario is a YAML document describing a cluster, its workload, and
its failure injections. The loader turns YAML into a :class:`Scenario`
dataclass; the materializer turns a Scenario into a running Simulator.
"""
from harbor_sim.scenario.model import Scenario, NodeSpec, LinkSpec, FailureSpec  # noqa: F401
from harbor_sim.scenario.loader import load, load_text  # noqa: F401
from harbor_sim.scenario.materialize import materialize  # noqa: F401
