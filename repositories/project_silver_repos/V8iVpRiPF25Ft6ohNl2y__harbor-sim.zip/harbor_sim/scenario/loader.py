"""YAML -> :class:`Scenario`.

Validation is a series of focused passes rather than a single big
schema. The trade-off: more lines, but each error path raises a
specific :class:`ScenarioValidationError` with a precise field path.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from harbor_sim.errors import (
    ScenarioReferenceError,
    ScenarioSyntaxError,
    ScenarioValidationError,
)
from harbor_sim.ids import is_node_id
from harbor_sim.scenario.model import (
    FailureSpec,
    LinkSpec,
    NodeSpec,
    Scenario,
    WorkloadSpec,
)


def load(path: Path) -> Scenario:
    return load_text(path.read_text(encoding="utf-8"))


def load_text(text: str) -> Scenario:
    try:
        doc = yaml.safe_load(text)
    except yaml.YAMLError as e:
        mark = getattr(e, "problem_mark", None)
        raise ScenarioSyntaxError(
            detail=str(e),
            line=mark.line + 1 if mark else None,
            column=mark.column + 1 if mark else None,
        ) from e

    if not isinstance(doc, dict):
        raise ScenarioSyntaxError(
            detail=f"top-level must be a mapping; got {type(doc).__name__}"
        )

    name = _expect_str(doc, "scenario", default="anonymous")
    seed = _expect_int(doc, "seed", default=0)
    if seed < 0:
        raise ScenarioValidationError("seed", "must be a non-negative integer")
    horizon_ms = _expect_int(doc, "horizon_ms", default=60_000)
    if horizon_ms <= 0:
        raise ScenarioValidationError("horizon_ms", "must be positive")
    protocol = _expect_str(doc, "protocol", default="raftlite")

    nodes = _parse_nodes(doc.get("nodes"))
    links = _parse_links(doc.get("links"))
    workload = _parse_workload(doc.get("workload"))
    failures = _parse_failures(doc.get("failures"))
    protocol_options = doc.get("protocol_options") or {}
    if not isinstance(protocol_options, dict):
        raise ScenarioValidationError("protocol_options", "must be a mapping")

    sc = Scenario(
        name=name,
        seed=seed,
        horizon_ms=horizon_ms,
        protocol=protocol,
        nodes=nodes,
        links=links,
        failures=failures,
        workload=workload,
        protocol_options=protocol_options,
    )
    _validate_references(sc)
    return sc


def _parse_nodes(raw: Any) -> list[NodeSpec]:
    if raw is None:
        raise ScenarioValidationError("nodes", "must be a non-empty list")
    if not isinstance(raw, list) or not raw:
        raise ScenarioValidationError("nodes", "must be a non-empty list")
    out: list[NodeSpec] = []
    seen: set[str] = set()
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ScenarioValidationError(f"nodes[{i}]", "must be a mapping")
        nid = item.get("id")
        if not isinstance(nid, str) or not is_node_id(nid):
            raise ScenarioValidationError(
                f"nodes[{i}].id",
                f"must be a non-empty alphanumeric/-_./ string, got {nid!r}",
            )
        if nid in seen:
            raise ScenarioValidationError(
                f"nodes[{i}].id", f"duplicate node id {nid!r}"
            )
        seen.add(nid)
        role = item.get("role", "replica")
        if not isinstance(role, str):
            raise ScenarioValidationError(f"nodes[{i}].role", "must be a string")
        skew = int(item.get("clock_skew_ms", 0))
        drift = int(item.get("clock_drift_ppm", 0))
        snap_id = item.get("initial_snapshot_id")
        if snap_id is not None and not isinstance(snap_id, int):
            raise ScenarioValidationError(
                f"nodes[{i}].initial_snapshot_id",
                "must be an integer or null",
            )
        extra = {k: v for k, v in item.items()
                 if k not in {"id", "role", "clock_skew_ms",
                              "clock_drift_ppm", "initial_snapshot_id"}}
        out.append(NodeSpec(
            id=nid, role=role,
            clock_skew_ms=skew, clock_drift_ppm=drift,
            initial_snapshot_id=snap_id,
            extra=extra,
        ))
    return out


def _parse_links(raw: Any) -> list[LinkSpec]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ScenarioValidationError("links", "must be a list")
    out: list[LinkSpec] = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ScenarioValidationError(f"links[{i}]", "must be a mapping")
        src = _expect_str(item, "from", path=f"links[{i}].from")
        dst = _expect_str(item, "to", path=f"links[{i}].to")
        lat = item.get("latency_ms", [5, 20])
        if isinstance(lat, int):
            low, high = lat, lat
        elif isinstance(lat, list) and len(lat) == 2:
            low, high = int(lat[0]), int(lat[1])
        else:
            raise ScenarioValidationError(
                f"links[{i}].latency_ms",
                "must be an int or [low, high]",
            )
        if low < 0 or high < low:
            raise ScenarioValidationError(
                f"links[{i}].latency_ms",
                f"out of order or negative: [{low}, {high}]",
            )
        drop = float(item.get("drop_rate", 0.0))
        if not 0.0 <= drop <= 1.0:
            raise ScenarioValidationError(
                f"links[{i}].drop_rate",
                f"must be in [0, 1]; got {drop}",
            )
        reorder = bool(item.get("reorder", False))
        capacity = item.get("capacity")
        if capacity is not None and (not isinstance(capacity, int) or capacity <= 0):
            raise ScenarioValidationError(
                f"links[{i}].capacity",
                "must be a positive integer or null",
            )
        bidir = bool(item.get("bidirectional", True))
        out.append(LinkSpec(
            src=src, dst=dst,
            latency_low_ms=low, latency_high_ms=high,
            drop_rate=drop, reorder=reorder, capacity=capacity,
            bidirectional=bidir,
        ))
    return out


def _parse_workload(raw: Any) -> WorkloadSpec:
    if raw is None:
        return WorkloadSpec()
    if not isinstance(raw, dict):
        raise ScenarioValidationError("workload", "must be a mapping")
    kind = raw.get("kind", "noop")
    clients = int(raw.get("clients", 0))
    if clients < 0:
        raise ScenarioValidationError("workload.clients", "must be non-negative")
    ops = int(raw.get("ops_per_client", 0))
    if ops < 0:
        raise ScenarioValidationError("workload.ops_per_client", "must be non-negative")
    keys = raw.get("keys") or []
    if not isinstance(keys, list):
        raise ScenarioValidationError("workload.keys", "must be a list")
    keys = [str(k) for k in keys]
    extra = {k: v for k, v in raw.items()
             if k not in {"kind", "clients", "ops_per_client", "keys", "value_size_bytes"}}
    return WorkloadSpec(
        kind=str(kind),
        clients=clients,
        ops_per_client=ops,
        keys=keys,
        value_size_bytes=int(raw.get("value_size_bytes", 16)),
        extra=extra,
    )


def _parse_failures(raw: Any) -> list[FailureSpec]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ScenarioValidationError("failures", "must be a list")
    out: list[FailureSpec] = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ScenarioValidationError(f"failures[{i}]", "must be a mapping")
        at = int(item.get("at_ms", 0))
        if at < 0:
            raise ScenarioValidationError(
                f"failures[{i}].at_ms", "must be non-negative"
            )
        kind = _expect_str(item, "kind", path=f"failures[{i}].kind")
        if kind not in {"partition", "crash", "recover"}:
            raise ScenarioValidationError(
                f"failures[{i}].kind",
                f"unknown kind {kind!r}",
            )
        out.append(FailureSpec(
            at_ms=at, kind=kind,
            target=str(item.get("target", "")),
            a=str(item.get("a", "")), b=str(item.get("b", "")),
            duration_ms=item.get("duration_ms"),
            on=bool(item.get("on", True)),
        ))
    return out


def _validate_references(sc: Scenario) -> None:
    known = {n.id for n in sc.nodes}
    for i, l in enumerate(sc.links):
        if l.src not in known:
            raise ScenarioReferenceError("node", l.src)
        if l.dst not in known:
            raise ScenarioReferenceError("node", l.dst)
    for f in sc.failures:
        if f.kind in {"crash", "recover"} and f.target and f.target not in known:
            raise ScenarioReferenceError("node", f.target)
        if f.kind == "partition":
            if f.a and f.a not in known:
                raise ScenarioReferenceError("node", f.a)
            if f.b and f.b not in known:
                raise ScenarioReferenceError("node", f.b)


def _expect_str(d: dict, key: str, default: str | None = None, path: str | None = None) -> str:
    v = d.get(key)
    if v is None:
        if default is not None:
            return default
        raise ScenarioValidationError(path or key, "is required")
    if not isinstance(v, str):
        raise ScenarioValidationError(path or key, f"must be a string; got {type(v).__name__}")
    return v


def _expect_int(d: dict, key: str, default: int | None = None) -> int:
    v = d.get(key)
    if v is None:
        if default is not None:
            return default
        raise ScenarioValidationError(key, "is required")
    if not isinstance(v, int) or isinstance(v, bool):
        raise ScenarioValidationError(key, f"must be an integer; got {type(v).__name__}")
    return v
