"""Scenario expansion helpers.

A scenario's "links" section can be terse. Real configurations often
want full-mesh connectivity between a set of nodes; writing N*(N-1)/2
link entries gets tedious. The expand module offers convenience
helpers that produce expanded scenarios without changing the schema.

These are not used by the loader directly - the loader stays strict
about the on-disk format - but tools and tests can build a Scenario
in code and run it through one of these.
"""
from __future__ import annotations

from harbor_sim.scenario.model import LinkSpec, NodeSpec, Scenario


def full_mesh(scenario: Scenario, **link_overrides) -> Scenario:
    """Add all-pairs links to a scenario whose ``links`` list is empty
    or partial. Existing links are kept; new links use
    ``link_overrides`` for any non-default values.
    """
    existing_pairs: set[tuple[str, str]] = {
        (l.src, l.dst) for l in scenario.links
    }
    for a in scenario.nodes:
        for b in scenario.nodes:
            if a.id == b.id:
                continue
            if (a.id, b.id) in existing_pairs:
                continue
            scenario.links.append(LinkSpec(
                src=a.id, dst=b.id,
                latency_low_ms=int(link_overrides.get("latency_low_ms", 5)),
                latency_high_ms=int(link_overrides.get("latency_high_ms", 20)),
                drop_rate=float(link_overrides.get("drop_rate", 0.0)),
                reorder=bool(link_overrides.get("reorder", False)),
                capacity=link_overrides.get("capacity"),
                bidirectional=False,
            ))
            existing_pairs.add((a.id, b.id))
    return scenario


def star(scenario: Scenario, center: str, **link_overrides) -> Scenario:
    """Add a star topology rooted at ``center``. Useful for testing
    leader-centric failure modes - drop the leader, watch the
    re-election cascade."""
    if not any(n.id == center for n in scenario.nodes):
        from harbor_sim.errors import ScenarioReferenceError

        raise ScenarioReferenceError("node", center)
    for n in scenario.nodes:
        if n.id == center:
            continue
        scenario.links.append(LinkSpec(
            src=center, dst=n.id,
            latency_low_ms=int(link_overrides.get("latency_low_ms", 5)),
            latency_high_ms=int(link_overrides.get("latency_high_ms", 20)),
            bidirectional=True,
        ))
    return scenario


def add_replica(scenario: Scenario, role: str = "replica") -> NodeSpec:
    """Append a fresh replica node with auto-assigned id."""
    existing = {n.id for n in scenario.nodes}
    i = 1
    while f"n{i}" in existing:
        i += 1
    spec = NodeSpec(id=f"n{i}", role=role)
    scenario.nodes.append(spec)
    return spec


def crash_at(scenario: Scenario, node: str, at_ms: int, recover_after_ms: int | None = None) -> None:
    from harbor_sim.scenario.model import FailureSpec

    scenario.failures.append(FailureSpec(
        at_ms=at_ms, kind="crash", target=node,
    ))
    if recover_after_ms is not None:
        scenario.failures.append(FailureSpec(
            at_ms=at_ms + recover_after_ms, kind="recover", target=node,
        ))


def partition_at(scenario: Scenario, a: str, b: str, at_ms: int, duration_ms: int) -> None:
    from harbor_sim.scenario.model import FailureSpec

    scenario.failures.append(FailureSpec(
        at_ms=at_ms, kind="partition", a=a, b=b, duration_ms=duration_ms,
    ))
