"""Turn a Scenario into a running Simulator.

Order matters:

1. Construct the Simulator (scheduler, transport, RNG, snapshot store).
2. For each node, build the protocol (via the registry), apply the
   clock skew, and add it to the simulator.
3. Wire the links.
4. Schedule the failure events.
5. If any node had an ``initial_snapshot_id``, load the snapshot from
   the snapshot store and hand its state to the protocol.

Step 5 is where the protocol picks up a recorded compaction prefix.
The snapshot's :class:`CompactionRecord` carries ``last_included_index``
and ``last_included_term`` - the protocol uses these to set
``log.first_index`` and ``log.last_included_term`` so subsequent
log entries are appended without replaying the snapshotted prefix.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from harbor_sim.clock import ClockSkew
from harbor_sim.ids import LogIndex, NodeId, SnapshotId, Term
from harbor_sim.protocols import lookup as lookup_protocol
from harbor_sim.runtime.node import Node
from harbor_sim.runtime.simulator import Simulator
from harbor_sim.scenario.model import Scenario
from harbor_sim.storage.snapshot import Snapshot
from harbor_sim.transport import LinkConfig


def materialize(scenario: Scenario, workdir: Path) -> Simulator:
    sim = Simulator.make(seed=scenario.seed, workdir=workdir)

    factory = lookup_protocol(scenario.protocol)
    node_ids = [NodeId(n.id) for n in scenario.nodes]
    for spec in scenario.nodes:
        nid = NodeId(spec.id)
        peers = [p for p in node_ids if p != nid]
        proto = factory(node=nid, peers=peers, **scenario.protocol_options)
        skew = ClockSkew(
            offset_ms=spec.clock_skew_ms,
            drift_ppm=spec.clock_drift_ppm,
        )
        node = Node.make(
            node_id=nid,
            protocol=proto,
            scheduler=sim.scheduler,
            transport=sim.transport,
            rng=sim.rng,
            sim_clock=sim.clock,
            skew=skew,
            workdir=workdir / spec.id,
        )
        sim.add_node(node)

        if spec.initial_snapshot_id is not None:
            _apply_initial_snapshot(sim, nid, spec.initial_snapshot_id, proto)

    for spec in scenario.links:
        sim.transport.add_link(LinkConfig(
            src=NodeId(spec.src), dst=NodeId(spec.dst),
            latency_low_ms=spec.latency_low_ms,
            latency_high_ms=spec.latency_high_ms,
            drop_rate=spec.drop_rate,
            reorder=spec.reorder,
            capacity=spec.capacity,
        ))
        if spec.bidirectional:
            sim.transport.add_link(LinkConfig(
                src=NodeId(spec.dst), dst=NodeId(spec.src),
                latency_low_ms=spec.latency_low_ms,
                latency_high_ms=spec.latency_high_ms,
                drop_rate=spec.drop_rate,
                reorder=spec.reorder,
                capacity=spec.capacity,
            ))

    for f in scenario.failures:
        payload = f.to_event_payload()
        sim.scheduler.schedule_at(
            at_ms=f.at_ms,
            kind="fault",
            target=f.target or f.a or "cluster",
            payload=payload,
        )
        # If the failure has a duration and is a partition, schedule
        # its reversal.
        if f.kind == "partition" and f.duration_ms:
            rev = dict(payload)
            rev["on"] = False
            sim.scheduler.schedule_at(
                at_ms=f.at_ms + int(f.duration_ms),
                kind="fault",
                target=f.target or f.a or "cluster",
                payload=rev,
            )

    return sim


def _apply_initial_snapshot(
    sim: Simulator,
    node: NodeId,
    snap_id: int,
    protocol: Any,
) -> None:
    """Load a snapshot from disk and apply it to ``protocol``.

    The protocol is expected to expose a private ``state`` attribute
    with a ``log`` and a way to absorb the state dict. The default
    path here speaks to raftlite's state shape; other protocols can
    override by setting ``protocol.from_snapshot`` to a custom callable.
    """
    snap: Snapshot = sim.snapshots.load(node, SnapshotId(snap_id))
    if hasattr(protocol, "from_snapshot"):
        protocol.from_snapshot(snap)
        return
    state = getattr(protocol, "state", None)
    if state is None:
        return
    # Restore the protocol state fields the snapshot carries.
    for key, value in snap.state.items():
        if hasattr(state, key):
            setattr(state, key, value)
    # Walk the compaction record so the log is sized correctly.
    log = getattr(state, "log", None)
    if log is None:
        return
    log.first_index = LogIndex(int(snap.compaction.last_included_index) + 1)
    log.entries = []
