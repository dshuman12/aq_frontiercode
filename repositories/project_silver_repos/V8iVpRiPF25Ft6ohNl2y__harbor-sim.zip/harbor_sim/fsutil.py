"""Small filesystem helpers.

Most of the simulator's I/O is mediated by these so that test
fixtures can swap them out without monkey-patching `open`. The two
big primitives are :func:`atomic_write_bytes` and :func:`safe_replace`;
both stage writes to a temp file and rename, so a crashed simulator
never leaves a half-written trace where a complete one used to be.
"""
from __future__ import annotations

import contextlib
import os
import tempfile
from pathlib import Path
from typing import Iterator


def ensure_dir(path: Path) -> Path:
    """Create the directory and any parents. No-op if it exists."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def atomic_write_bytes(target: Path, data: bytes) -> None:
    """Write bytes to ``target`` atomically via a temp-file + rename.

    Same directory rename is guaranteed atomic on POSIX, and works on
    Windows because we close the file before the rename. The temp file
    is removed if the rename fails for any reason.
    """
    ensure_dir(target.parent)
    tmp = tempfile.NamedTemporaryFile(
        mode="wb",
        dir=str(target.parent),
        prefix=target.name + ".",
        suffix=".tmp",
        delete=False,
    )
    try:
        tmp.write(data)
        tmp.flush()
        os.fsync(tmp.fileno())
    finally:
        tmp.close()
    try:
        os.replace(tmp.name, target)
    except Exception:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp.name)
        raise


def atomic_write_text(target: Path, data: str, encoding: str = "utf-8") -> None:
    atomic_write_bytes(target, data.encode(encoding))


@contextlib.contextmanager
def atomic_write(target: Path, mode: str = "wb") -> Iterator:
    """A context manager wrapping :func:`atomic_write_bytes`.

    Yields a temp-file handle. On normal exit the file is fsync'd and
    renamed onto ``target``. On exception the temp file is removed.
    """
    if mode not in ("wb", "w"):
        raise ValueError(f"atomic_write: unsupported mode {mode!r}")
    ensure_dir(target.parent)
    tmp = tempfile.NamedTemporaryFile(
        mode=mode,
        dir=str(target.parent),
        prefix=target.name + ".",
        suffix=".tmp",
        delete=False,
        encoding="utf-8" if mode == "w" else None,
    )
    try:
        yield tmp
        tmp.flush()
        os.fsync(tmp.fileno())
        tmp.close()
        os.replace(tmp.name, target)
    except Exception:
        with contextlib.suppress(Exception):
            tmp.close()
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp.name)
        raise


def safe_replace(src: Path, dst: Path) -> None:
    """``os.replace(src, dst)`` with a more useful error message."""
    if not src.exists():
        raise FileNotFoundError(f"safe_replace: source missing: {src}")
    ensure_dir(dst.parent)
    os.replace(src, dst)


def walk_files(root: Path, suffix: str | None = None) -> Iterator[Path]:
    """Recursive file walk. Stable order (sorted at each level).

    Filtering by suffix is convenience: ``walk_files(root, ".yaml")``
    yields the same paths as filtering the unfiltered walk.
    """
    if not root.exists():
        return
    for sub in sorted(root.iterdir(), key=lambda p: p.name):
        if sub.is_dir():
            yield from walk_files(sub, suffix=suffix)
        elif sub.is_file():
            if suffix is None or sub.name.endswith(suffix):
                yield sub


def read_bytes(path: Path) -> bytes:
    return path.read_bytes()


def read_text(path: Path, encoding: str = "utf-8") -> str:
    return path.read_text(encoding=encoding)
