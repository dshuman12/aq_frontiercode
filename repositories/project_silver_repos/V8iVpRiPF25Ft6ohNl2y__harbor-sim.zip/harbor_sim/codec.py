"""Framed encode/decode for the on-disk trace and snapshot formats.

The basic unit is a frame:

    [magic:2][version:2][type:2][len:4][crc32c:4][payload:len]

* ``magic`` is the ASCII bytes ``"HF"`` (Harbor Frame).
* ``version`` is the format version. The reader accepts both v1 and v2;
  the writer always emits v2.
* ``type`` is a small integer enum (see :class:`FrameType`).
* ``len`` is the length of ``payload`` in bytes.
* ``crc32c`` is the Castagnoli CRC of ``payload``.

Frames are encoded with msgpack inside the payload; that's the only
piece of the format that depends on a third-party library. Everything
else is plain struct.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass
from enum import IntEnum
from typing import Any, BinaryIO

import msgpack

from harbor_sim.errors import CodecError
from harbor_sim.hashing import crc32c

MAGIC = b"HF"
HEADER_FMT = ">2sHHIi"  # magic, version, type, length, crc (signed int4 for tooling)
HEADER_SIZE = struct.calcsize(HEADER_FMT)

FORMAT_VERSION_LATEST = 2
FORMAT_VERSION_SUPPORTED = (1, 2)


class FrameType(IntEnum):
    """All frame types known to the codec.

    Adding a new type means bumping :data:`FORMAT_VERSION_LATEST` and
    teaching :mod:`harbor_sim.trace.migrate` how to convert.
    """

    HEADER = 0  # the file header, exactly once at offset 0
    EVENT = 1  # a recorded scheduler event
    SNAPSHOT = 2  # a serialized node snapshot
    BARRIER = 3  # a barrier marker (used by the diff CLI)
    WITNESS = 4  # an invariant-checker witness record
    META = 5  # arbitrary key/value metadata
    EOF = 255  # end-of-stream marker; writer flushes one of these


@dataclass(slots=True)
class Frame:
    """An in-memory frame, after decoding the header but before
    decoding the payload."""

    version: int
    type: FrameType
    payload: bytes

    def decoded(self) -> Any:
        return msgpack.unpackb(self.payload, raw=False, strict_map_key=False)


def encode_frame(frame_type: FrameType, payload_obj: Any) -> bytes:
    """Encode a frame into bytes. The payload is msgpacked."""
    payload = msgpack.packb(payload_obj, use_bin_type=True)
    if len(payload) > 0xFFFFFFFF:
        raise CodecError(f"frame payload too large: {len(payload)} bytes")
    crc = crc32c(payload)
    # struct expects a signed int for "i"; mask to fit.
    crc_signed = crc - 0x1_0000_0000 if crc >= 0x8000_0000 else crc
    header = struct.pack(
        HEADER_FMT, MAGIC, FORMAT_VERSION_LATEST, int(frame_type), len(payload), crc_signed
    )
    return header + payload


def decode_frame(stream: BinaryIO) -> Frame | None:
    """Read one frame from a binary stream.

    Returns None at clean EOF. Raises :class:`CodecError` on any other
    failure (short read, bad magic, version mismatch, CRC mismatch).
    """
    offset = stream.tell()
    header = stream.read(HEADER_SIZE)
    if not header:
        return None
    if len(header) < HEADER_SIZE:
        raise CodecError(
            "short header read at end of stream",
            offset=offset,
        )
    magic, version, type_int, length, crc_signed = struct.unpack(HEADER_FMT, header)
    if magic != MAGIC:
        raise CodecError(
            f"bad magic: expected {MAGIC!r}, got {magic!r}",
            offset=offset,
        )
    if version not in FORMAT_VERSION_SUPPORTED:
        raise CodecError(
            f"unsupported format version {version}; "
            f"this build supports {FORMAT_VERSION_SUPPORTED}",
            offset=offset,
            version=version,
        )
    payload = stream.read(length)
    if len(payload) < length:
        raise CodecError(
            f"short payload read: header announced {length} bytes, got {len(payload)}",
            offset=offset,
            version=version,
        )
    expected_crc = crc_signed if crc_signed >= 0 else crc_signed + 0x1_0000_0000
    actual_crc = crc32c(payload)
    if actual_crc != expected_crc:
        raise CodecError(
            f"crc mismatch: expected {expected_crc:#010x}, "
            f"computed {actual_crc:#010x}",
            offset=offset,
            version=version,
        )
    try:
        frame_type = FrameType(type_int)
    except ValueError:
        raise CodecError(
            f"unknown frame type {type_int}",
            offset=offset,
            version=version,
        ) from None
    return Frame(version=version, type=frame_type, payload=payload)


def iter_frames(stream: BinaryIO):
    """Yield every frame in a stream until EOF.

    Stops at the first :data:`FrameType.EOF` frame. If the stream ends
    without an EOF marker, that's not an error - older traces from
    pre-v2 builds don't have one.
    """
    while True:
        frame = decode_frame(stream)
        if frame is None:
            return
        if frame.type == FrameType.EOF:
            return
        yield frame
