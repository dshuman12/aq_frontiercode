"""Logical clocks.

harbor-sim doesn't read the wall clock. Time is two things:

* A global "now" maintained by the scheduler. It advances in discrete
  millisecond ticks (sub-millisecond resolution is exposed but rarely
  used outside the transport layer).
* A per-node skew that's applied whenever a node asks for the time.

The skew is a real physical-clock model: clocks on different machines
drift at different rates, and protocols that rely on bounded skew need
to be exercised against actual skew. The skew here is a constant
offset plus an optional drift rate. That's not nearly the full clock-
model story but it covers everything Raft-style protocols actually
care about.

One thing to know: every deadline check in protocol code has to go
through the per-node Clock view, not through the global SimClock.
A protocol that reads the global clock skips the skew model and
produces results that look fine in production-style "local clock
only" thinking but mask the bugs the skew model is meant to expose.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from harbor_sim.ids import NodeId


@dataclass
class SimClock:
    """The simulator's global clock. Owned by the scheduler.

    Ticks are integer milliseconds. The scheduler advances ``now_ms``
    when it dequeues the next event; nothing else should mutate it.
    """

    now_ms: int = 0

    def advance_to(self, ms: int) -> None:
        if ms < self.now_ms:
            raise ValueError(
                f"SimClock.advance_to: cannot go backwards "
                f"(now={self.now_ms}, target={ms})"
            )
        self.now_ms = ms

    def __int__(self) -> int:
        return self.now_ms


@dataclass(slots=True)
class ClockSkew:
    """A per-node clock-skew model.

    Two parameters:
      * ``offset_ms``: a constant offset, positive or negative.
      * ``drift_ppm``: parts-per-million drift. 1000 ppm = 1ms / second.

    Both default to zero. Real clocks have skew under ~50ms and drift
    under ~100 ppm; pathological scenarios run drift up to 5000 ppm to
    see what happens.
    """

    offset_ms: int = 0
    drift_ppm: int = 0

    def adjust(self, base_ms: int) -> int:
        """Return the local time on a node when the global clock reads
        ``base_ms``.

        The math is integer arithmetic on purpose: the simulator runs
        on integer ms throughout, and a float here would propagate
        non-determinism into the trace.
        """
        # offset is applied first, then drift on top of base.
        # drift_ppm * base_ms / 1_000_000 = drift_ms after base_ms.
        drift = (self.drift_ppm * base_ms) // 1_000_000
        return base_ms + self.offset_ms + drift


@dataclass(slots=True)
class Clock:
    """A node's view of time.

    Returned by the runtime when a protocol asks for ``ctx.clock``. The
    public surface is just :meth:`now` and :meth:`elapsed_since` -
    everything else should funnel through these so a single change to
    the skew model doesn't ripple through every protocol.
    """

    node: NodeId
    skew: ClockSkew = field(default_factory=ClockSkew)
    _global: SimClock = field(default_factory=SimClock)

    def now(self) -> int:
        """The node-local time in milliseconds, with skew applied."""
        return self.skew.adjust(self._global.now_ms)

    def elapsed_since(self, then_ms: int) -> int:
        return self.now() - then_ms

    def bind(self, global_clock: SimClock) -> None:
        """Attach a Clock to the scheduler's SimClock. Called once
        during node setup. Re-binding is allowed but pointless."""
        self._global = global_clock

    def __repr__(self) -> str:
        return f"Clock({self.node}, now={self.now()}, skew={self.skew.offset_ms:+d}ms)"


@dataclass(slots=True)
class Deadline:
    """A future point in time, in node-local milliseconds.

    Comparison is by absolute time. ``Deadline.from_now(clock, 5000)``
    returns a deadline 5 seconds in the future of the clock that
    created it.
    """

    fire_at_ms: int

    @classmethod
    def from_now(cls, clock: Clock, in_ms: int) -> "Deadline":
        return cls(fire_at_ms=clock.now() + in_ms)

    def expired(self, clock: Clock) -> bool:
        return clock.now() >= self.fire_at_ms

    def remaining(self, clock: Clock) -> int:
        return self.fire_at_ms - clock.now()


def jitter(base_ms: int, jitter_ms: int, rng) -> int:
    """Compute a jittered delay. ``rng`` must support :meth:`randint`.

    Returned value is ``base_ms + uniform(-jitter_ms, jitter_ms)``.
    Used by election-timeout and heartbeat-interval logic. Pulled into
    a module-level function so tests can verify the distribution
    without monkey-patching protocol internals.
    """
    if jitter_ms < 0:
        raise ValueError(f"jitter_ms must be non-negative, got {jitter_ms}")
    if jitter_ms == 0:
        return base_ms
    return base_ms + rng.randint(-jitter_ms, jitter_ms)
