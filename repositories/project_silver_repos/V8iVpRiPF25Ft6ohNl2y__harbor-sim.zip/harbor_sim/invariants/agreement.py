"""Agreement invariant.

No two distinct nodes are leaders in the same term. Implemented by
watching the recorded events for protocol-emitted "became_leader"
hints; the protocol records one of these when a node transitions to
LEADER role.
"""
from __future__ import annotations

from dataclasses import field

from harbor_sim.invariants.base import InvariantChecker
from harbor_sim.trace.format import EventFrame


class AgreementChecker(InvariantChecker):
    def __init__(self) -> None:
        super().__init__(name="agreement")
        self._leader_per_term: dict[int, str] = {}

    def observe(self, ev: EventFrame) -> None:
        if ev.kind != "became_leader":
            return
        term = int(ev.payload.get("term", -1))
        node = str(ev.payload.get("node", ""))
        if term < 0 or not node:
            return
        prior = self._leader_per_term.get(term)
        if prior is None:
            self._leader_per_term[term] = node
            return
        if prior != node:
            self.record_witness(
                at_ms=ev.fire_at_ms,
                detail={
                    "term": term,
                    "first_leader": prior,
                    "second_leader": node,
                },
                severity="violation",
            )
