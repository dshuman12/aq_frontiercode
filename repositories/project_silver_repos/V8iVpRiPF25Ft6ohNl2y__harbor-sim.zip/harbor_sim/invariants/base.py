"""Shared invariant-checker base."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator

from harbor_sim.trace.format import EventFrame, WitnessFrame


@dataclass
class InvariantChecker:
    """Common state for a streaming invariant checker.

    Subclasses override :meth:`observe` and call :meth:`record_witness`
    when something fishy comes up. The default :meth:`finalize` does
    nothing; checkers with end-of-stream conclusions override it.
    """

    name: str
    _witnesses: list[WitnessFrame] = field(default_factory=list)
    _violations: int = 0

    def observe(self, ev: EventFrame) -> None:
        raise NotImplementedError

    def finalize(self) -> None:
        pass

    def record_witness(
        self,
        at_ms: int,
        detail: dict,
        severity: str = "violation",
    ) -> None:
        self._witnesses.append(
            WitnessFrame(
                at_ms=at_ms,
                invariant=self.name,
                severity=severity,
                detail=dict(detail),
            )
        )
        if severity == "violation":
            self._violations += 1

    def witnesses(self) -> Iterator[WitnessFrame]:
        return iter(self._witnesses)

    def violation_count(self) -> int:
        return self._violations

    def passed(self) -> bool:
        return self._violations == 0
