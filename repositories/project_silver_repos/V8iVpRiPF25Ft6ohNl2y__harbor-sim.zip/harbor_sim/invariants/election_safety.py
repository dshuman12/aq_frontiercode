"""Election-safety invariant.

A committed log entry at index ``i`` must remain at index ``i`` for all
subsequent terms. If a later leader's commit at the same index carries
a different (term, command) pair, the invariant has been violated.

Implemented as a per-node-per-index map of committed entries with a
single-shot mismatch check.
"""
from __future__ import annotations

from harbor_sim.invariants.base import InvariantChecker
from harbor_sim.trace.format import EventFrame


class ElectionSafetyChecker(InvariantChecker):
    def __init__(self) -> None:
        super().__init__(name="election_safety")
        # Key: log index; value: (term, command_hash) tuple of the first
        # commit observed at that index across the cluster.
        self._committed: dict[int, tuple[int, str]] = {}

    def observe(self, ev: EventFrame) -> None:
        if ev.kind != "commit":
            return
        idx = int(ev.payload.get("index", -1))
        term = int(ev.payload.get("term", -1))
        op = str(ev.payload.get("op", ""))
        if idx < 0 or term < 0:
            return
        prior = self._committed.get(idx)
        if prior is None:
            self._committed[idx] = (term, op)
            return
        prior_term, prior_op = prior
        if (term, op) != prior:
            self.record_witness(
                at_ms=ev.fire_at_ms,
                detail={
                    "index": idx,
                    "prior_term": prior_term,
                    "prior_op": prior_op,
                    "later_term": term,
                    "later_op": op,
                },
                severity="violation",
            )
