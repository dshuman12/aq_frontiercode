"""Invariant checkers.

Three checkers ship in-tree:

* :class:`~harbor_sim.invariants.agreement.AgreementChecker` -
  no two leaders in the same term.
* :class:`~harbor_sim.invariants.election_safety.ElectionSafetyChecker` -
  log entries committed at index i don't get clobbered by a later term.
* :class:`~harbor_sim.invariants.linearizability.LinearizabilityChecker` -
  for the KV protocol, every read returns a value previously written
  by a concurrent or earlier client.

Each checker exposes :meth:`observe` (fed every recorded event) and
:meth:`witnesses` (yields any :class:`WitnessFrame` records the
checker emitted). The CLI verifies a trace by walking it through every
registered checker and asserting no violations.
"""
from harbor_sim.invariants.agreement import AgreementChecker  # noqa: F401
from harbor_sim.invariants.election_safety import (  # noqa: F401
    ElectionSafetyChecker,
)
from harbor_sim.invariants.linearizability import (  # noqa: F401
    LinearizabilityChecker,
)


def all_checkers():
    return {
        "agreement": AgreementChecker,
        "election_safety": ElectionSafetyChecker,
        "linearizability": LinearizabilityChecker,
    }
