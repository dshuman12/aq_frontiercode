"""Linearizability checker for the KV protocol.

Implements a simple read-set check: for every read R returning value v
of key k, there must be a write W of (k, v) such that W's response
completed before R was issued, OR W was concurrent with R.

This is the staleness-floor check, computed against the protocol's
recorded last-write quorum and the read's response set. If the floor
is configured non-zero and the overlap is too small, that's the read-
side equivalent of "stale read despite quorum".

The checker keeps per-key witnesses keyed by request id. The CLI
verifier walks the witnesses to produce a structured report; tests
typically just assert :meth:`passed`.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from harbor_sim.invariants.base import InvariantChecker
from harbor_sim.trace.format import EventFrame


@dataclass
class _WriteRecord:
    rid: str
    key: str
    value: object
    writer: str
    generation: int
    completed_at_ms: int
    write_quorum: set[str] = field(default_factory=set)


class LinearizabilityChecker(InvariantChecker):
    def __init__(self, staleness_floor: int = 0) -> None:
        super().__init__(name="linearizability")
        self.staleness_floor = staleness_floor
        # Latest known value per key, indexed by (writer, generation).
        self._writes_by_key: dict[str, list[_WriteRecord]] = {}

    def observe(self, ev: EventFrame) -> None:
        if ev.kind == "kv_write_complete":
            self._observe_write(ev)
        elif ev.kind == "kv_read_complete":
            self._observe_read(ev)

    def _observe_write(self, ev: EventFrame) -> None:
        p = ev.payload
        rec = _WriteRecord(
            rid=str(p.get("rid", "")),
            key=str(p.get("key", "")),
            value=p.get("value"),
            writer=str(p.get("writer", "")),
            generation=int(p.get("generation", 0)),
            completed_at_ms=ev.fire_at_ms,
            write_quorum=set(p.get("write_quorum") or []),
        )
        self._writes_by_key.setdefault(rec.key, []).append(rec)

    def _observe_read(self, ev: EventFrame) -> None:
        p = ev.payload
        key = str(p.get("key", ""))
        value = p.get("value")
        writer = str(p.get("writer", ""))
        generation = int(p.get("generation", 0))
        read_set = set(p.get("read_set") or [])
        # Does a write record exist with this value?
        candidates = self._writes_by_key.get(key, [])
        match = None
        for w in candidates:
            if w.writer == writer and w.generation == generation and w.value == value:
                match = w
                break
        if match is None:
            self.record_witness(
                at_ms=ev.fire_at_ms,
                detail={
                    "kind": "no_matching_write",
                    "key": key,
                    "value": str(value),
                    "writer": writer,
                    "generation": generation,
                },
                severity="violation",
            )
            return
        # Staleness floor: read-set should overlap the write-quorum
        # by at least ``staleness_floor``.
        if self.staleness_floor <= 0:
            return
        overlap = len(read_set & match.write_quorum)
        if overlap < self.staleness_floor:
            self.record_witness(
                at_ms=ev.fire_at_ms,
                detail={
                    "kind": "staleness_floor_violation",
                    "key": key,
                    "read_set": sorted(read_set),
                    "last_write_set": sorted(match.write_quorum),
                    "overlap": overlap,
                    "required": self.staleness_floor,
                },
                severity="violation",
            )
