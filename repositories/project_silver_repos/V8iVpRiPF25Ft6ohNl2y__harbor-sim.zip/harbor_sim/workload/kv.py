"""KV workload generator.

A KVWorkload acts as a client to the quorum_kv protocol. It sets a
recurring timer that emits one operation per tick: a PUT with
probability ``put_ratio`` or a GET otherwise. Keys are drawn from a
configurable key space; values are short byte strings.

The generator tracks every issued request and its eventual reply so
tests can assert on completion rates and read consistency without
plumbing assertions back through the simulator.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from harbor_sim.ids import ClientId, NodeId
from harbor_sim.runtime.context import NodeContext
from harbor_sim.runtime.mailbox import IncomingMessage


@dataclass
class _IssuedRequest:
    rid: str
    kind: str  # "put" or "get"
    key: str
    value: Any
    issued_at_ms: int
    completed_at_ms: int | None = None
    result: dict[str, Any] | None = None


@dataclass
class KVWorkload:
    """One synthetic KV client."""

    client_id: ClientId
    target: NodeId
    keys: list[str]
    put_ratio: float = 0.5
    interval_ms: int = 25
    value_size_bytes: int = 16
    _gen: int = 0
    _issued: dict[str, _IssuedRequest] = field(default_factory=dict)

    def on_init(self, ctx: NodeContext) -> None:
        ctx.set_timer(self.interval_ms, "kv-tick")

    def on_shutdown(self, ctx: NodeContext) -> None:
        pass

    def on_timer(self, ctx: NodeContext, key: str, payload: dict[str, Any]) -> None:
        if key != "kv-tick":
            return
        rng = ctx.rng.stream(f"workload-{self.client_id}")
        op_key = rng.choice(self.keys) if self.keys else "x"
        is_put = rng.random() < self.put_ratio
        rid = self._next_rid()
        if is_put:
            value = self._fake_value(rng)
            self._issued[rid] = _IssuedRequest(
                rid=rid, kind="put", key=op_key, value=value, issued_at_ms=ctx.now()
            )
            ctx.send(
                self.target, "qkv_put",
                {"rid": rid, "key": op_key, "value": value},
            )
        else:
            self._issued[rid] = _IssuedRequest(
                rid=rid, kind="get", key=op_key, value=None, issued_at_ms=ctx.now()
            )
            ctx.send(
                self.target, "qkv_get",
                {"rid": rid, "key": op_key},
            )
        ctx.set_timer(self.interval_ms, "kv-tick")

    def on_message(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        if msg.kind != "qkv_cli_reply":
            return
        rid = str(msg.body.get("rid", ""))
        req = self._issued.get(rid)
        if req is None:
            return
        req.completed_at_ms = ctx.now()
        req.result = dict(msg.body)

    def _next_rid(self) -> str:
        self._gen += 1
        return f"{self.client_id}-{self._gen}"

    def _fake_value(self, rng) -> bytes:
        return bytes(rng.randint(0, 255) for _ in range(self.value_size_bytes))

    def issued(self) -> list[_IssuedRequest]:
        return list(self._issued.values())

    def completion_rate(self) -> float:
        if not self._issued:
            return 0.0
        done = sum(1 for r in self._issued.values() if r.completed_at_ms is not None)
        return done / len(self._issued)

    def reads_with_value(self) -> list[_IssuedRequest]:
        return [
            r for r in self._issued.values()
            if r.kind == "get" and r.result is not None
            and r.result.get("found")
        ]
