"""Workload generators.

A workload generator emits client requests against a protocol. It
runs as a synthetic node in the simulator - same dispatch machinery
as a real protocol node - but doesn't replicate any state. Its only
job is to drive PUTs and GETs (for the KV protocol) or PROPOSE
operations (for raftlite).

Two generators ship:

* :class:`~harbor_sim.workload.kv.KVWorkload` - random PUTs and GETs
  over a configurable key space.
* :class:`~harbor_sim.workload.propose.ProposeWorkload` - sends
  client_propose to whichever node it's wired to. Used for raftlite
  scenarios.
"""
from harbor_sim.workload.kv import KVWorkload  # noqa: F401
from harbor_sim.workload.propose import ProposeWorkload  # noqa: F401
