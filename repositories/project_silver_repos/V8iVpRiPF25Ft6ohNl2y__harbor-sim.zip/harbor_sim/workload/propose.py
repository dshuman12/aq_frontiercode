"""Propose workload for raftlite scenarios.

Sends one client_propose at a configurable interval. Used to exercise
log replication and commit-index propagation under failure injection.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from harbor_sim.ids import ClientId, NodeId
from harbor_sim.runtime.context import NodeContext
from harbor_sim.runtime.mailbox import IncomingMessage


@dataclass
class _Proposal:
    rid: int
    issued_at_ms: int
    completed_at_ms: int | None = None
    accepted: bool | None = None


@dataclass
class ProposeWorkload:
    client_id: ClientId
    target: NodeId
    interval_ms: int = 100
    _seq: int = 0
    _proposals: dict[int, _Proposal] = field(default_factory=dict)

    def on_init(self, ctx: NodeContext) -> None:
        ctx.set_timer(self.interval_ms, "propose-tick")

    def on_shutdown(self, ctx: NodeContext) -> None:
        pass

    def on_timer(self, ctx: NodeContext, key: str, payload: dict[str, Any]) -> None:
        if key != "propose-tick":
            return
        rid = self._seq
        self._seq += 1
        self._proposals[rid] = _Proposal(rid=rid, issued_at_ms=ctx.now())
        ctx.send(self.target, "cli_propose", {"op": {"id": rid}})
        ctx.set_timer(self.interval_ms, "propose-tick")

    def on_message(self, ctx: NodeContext, msg: IncomingMessage) -> None:
        if msg.kind != "cli_reply":
            return
        # The protocol doesn't include the rid in the reply currently;
        # treat the most recent uncompleted proposal as completing.
        ok = bool(msg.body.get("ok", False))
        for prop in sorted(self._proposals.values(), key=lambda p: p.rid, reverse=True):
            if prop.completed_at_ms is None:
                prop.completed_at_ms = ctx.now()
                prop.accepted = ok
                break

    def proposals(self) -> list[_Proposal]:
        return list(self._proposals.values())

    def accept_rate(self) -> float:
        if not self._proposals:
            return 0.0
        done = [p for p in self._proposals.values() if p.completed_at_ms is not None]
        if not done:
            return 0.0
        return sum(1 for p in done if p.accepted) / len(done)
