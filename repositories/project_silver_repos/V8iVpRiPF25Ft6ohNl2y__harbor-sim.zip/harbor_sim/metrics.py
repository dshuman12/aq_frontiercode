"""In-process metrics.

A tiny counters-and-gauges registry. Used by the simulator to track
sends/receives/drops per scenario without taking a dependency on a
real metrics library.

The registry is global per process and reset between simulator
instances. Tests that care about isolation should call
:func:`reset` in a fixture.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from threading import RLock
from typing import Any


@dataclass
class _Counter:
    value: int = 0

    def inc(self, n: int = 1) -> None:
        self.value += n


@dataclass
class _Gauge:
    value: float = 0.0

    def set(self, v: float) -> None:
        self.value = float(v)


@dataclass
class _Histogram:
    samples: list[float] = field(default_factory=list)

    def observe(self, v: float) -> None:
        self.samples.append(float(v))

    def percentile(self, p: float) -> float:
        if not self.samples:
            return 0.0
        s = sorted(self.samples)
        if not 0 <= p <= 1:
            raise ValueError(f"percentile p must be in [0, 1], got {p}")
        idx = int(p * (len(s) - 1))
        return s[idx]

    def mean(self) -> float:
        if not self.samples:
            return 0.0
        return sum(self.samples) / len(self.samples)


_registry: dict[str, Any] = {}
_lock = RLock()


def reset() -> None:
    with _lock:
        _registry.clear()


def counter(name: str) -> _Counter:
    with _lock:
        c = _registry.get(name)
        if c is None:
            c = _Counter()
            _registry[name] = c
        if not isinstance(c, _Counter):
            raise TypeError(f"metric {name!r} is not a counter")
        return c


def gauge(name: str) -> _Gauge:
    with _lock:
        g = _registry.get(name)
        if g is None:
            g = _Gauge()
            _registry[name] = g
        if not isinstance(g, _Gauge):
            raise TypeError(f"metric {name!r} is not a gauge")
        return g


def histogram(name: str) -> _Histogram:
    with _lock:
        h = _registry.get(name)
        if h is None:
            h = _Histogram()
            _registry[name] = h
        if not isinstance(h, _Histogram):
            raise TypeError(f"metric {name!r} is not a histogram")
        return h


def snapshot() -> dict[str, Any]:
    """Return a serializable snapshot of every metric in the registry."""
    with _lock:
        out: dict[str, Any] = {}
        for name, m in _registry.items():
            if isinstance(m, _Counter):
                out[name] = {"kind": "counter", "value": m.value}
            elif isinstance(m, _Gauge):
                out[name] = {"kind": "gauge", "value": m.value}
            elif isinstance(m, _Histogram):
                out[name] = {
                    "kind": "histogram",
                    "n": len(m.samples),
                    "mean": m.mean(),
                    "p50": m.percentile(0.5),
                    "p95": m.percentile(0.95),
                    "p99": m.percentile(0.99),
                }
        return out


class Timer:
    """Context manager: records wall-clock elapsed seconds into a
    histogram on exit."""

    def __init__(self, hist_name: str) -> None:
        self.hist = histogram(hist_name)
        self._start = 0.0

    def __enter__(self) -> "Timer":
        self._start = time.perf_counter()
        return self

    def __exit__(self, *exc: object) -> None:
        self.hist.observe(time.perf_counter() - self._start)
