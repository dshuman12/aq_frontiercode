"""Replay engine.

Drives a recorded scenario through the simulator while comparing each
emitted event against the recording. Divergence is fatal - either the
simulator is non-deterministic (a real bug) or the trace is for a
different scenario.

Operating modes:

* ``replay()``: full replay; the simulator runs to horizon and the
  output trace is compared event-by-event against the input.
* ``replay_until(cutoff_ms)``: replay stops at the cutoff. The
  resulting trace is compared against the input prefix only.

The cutoff path consumes the same scheduler RNG stream as the full
path. Because the scheduler advances its RNG on every ``schedule``
call (tie-break draw), a cutoff that omits part of the timeline
draws a different number of values than the full run did when the
draws are folded back into the shared pool. The fix is to fork the
RNG into per-subsystem streams; see ADR 0011.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

from harbor_sim.errors import DivergenceError
from harbor_sim.scenario.loader import load_text
from harbor_sim.scenario.materialize import materialize
from harbor_sim.trace.format import EventFrame
from harbor_sim.trace.reader import TraceReader


@dataclass
class ReplayEngine:
    trace_path: Path
    scenario_text: str
    workdir: Path
    _events: list[EventFrame] = field(default_factory=list)

    def __post_init__(self) -> None:
        reader = TraceReader(self.trace_path)
        self._events = list(reader.events())

    def replay(self) -> int:
        return self._replay_to(cutoff_ms=None)

    def replay_until(self, cutoff_ms: int) -> int:
        return self._replay_to(cutoff_ms=cutoff_ms)

    def _replay_to(self, cutoff_ms: int | None) -> int:
        scenario = load_text(self.scenario_text)
        sim = materialize(scenario, workdir=self.workdir)
        sim.boot_all()

        produced: list[EventFrame] = []

        def hook(ev) -> None:
            produced.append(EventFrame(
                event_id=int(ev.id),
                fire_at_ms=ev.fire_at_ms,
                kind=ev.kind,
                target=ev.target,
                payload=ev.payload,
            ))

        sim.scheduler.install_hook(hook)
        horizon = cutoff_ms if cutoff_ms is not None else scenario.horizon_ms
        sim.run(horizon_ms=horizon)

        # Compare against the recorded prefix.
        for i, prod in enumerate(produced):
            if i >= len(self._events):
                break
            rec = self._events[i]
            if not _events_equal(prod, rec):
                raise DivergenceError(
                    at_tick=i, expected=rec.to_dict(), actual=prod.to_dict()
                )
        return len(produced)


def _events_equal(a: EventFrame, b: EventFrame) -> bool:
    if a.fire_at_ms != b.fire_at_ms:
        return False
    if a.kind != b.kind or a.target != b.target:
        return False
    # Payload comparison is lenient: keys that vary across runs in
    # non-meaningful ways (timing-only fields like send_at) are
    # excluded from the comparison.
    ignore = {"send_at", "leader_now_ms", "follower_now_ms"}
    pa = {k: v for k, v in a.payload.items() if k not in ignore}
    pb = {k: v for k, v in b.payload.items() if k not in ignore}
    return pa == pb
