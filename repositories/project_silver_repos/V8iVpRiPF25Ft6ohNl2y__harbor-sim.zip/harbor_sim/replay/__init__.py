"""Replay a recorded trace deterministically.

The replay engine takes a trace, materializes the original scenario,
and walks the events back through the runtime. It honors a
``--until`` cutoff: replay stops at the chosen logical time, with
the simulator in the state it would have been at exactly that tick.

Determinism contract: a complete replay of trace T produces a trace
byte-identical to T. A truncated replay of T with cutoff C produces
a trace byte-identical to the prefix of T up to C.

The cutoff guarantee currently has a known gap - the scheduler's RNG
stream isn't forked per subsystem, so a cutoff replay consumes a
different number of RNG draws than the prefix did. There's an ADR
about it.
"""
from harbor_sim.replay.engine import ReplayEngine  # noqa: F401
