"""Seeded random number streams.

The simulator's determinism guarantee hangs off this module. Every
non-determinism source - tie-breaking in the scheduler, latency draws
in transport, election-timeout jitter in protocols, workload-generator
key picks - draws from a stream returned here.

Two designs are worth distinguishing:

  Single shared stream
      All consumers share one Random. Simple, fast. Vulnerable to
      replay drift: if a replay stops early or processes events in a
      slightly different order, every subsequent draw shifts because
      the consumed-count diverges.

  Per-subsystem streams
      Each consumer owns a Random derived from a stream key. Replay
      drift on one stream doesn't affect others. The cost is the
      seeding ceremony.

This module currently implements the single-shared design (in
:class:`RngBundle`), with the per-stream surface declared but not yet
wired through the rest of the codebase. There's an ADR proposing the
migration; see `docs/adr/0011-rng-streams.md`.

The split-streams API is consumed today only by tests that want
deterministic generators independent of simulator state.
"""
from __future__ import annotations

import hashlib
import random
import struct
from dataclasses import dataclass, field


def _derive_seed(parent_seed: int, stream: str) -> int:
    """Mix a string label into a 64-bit seed.

    Uses BLAKE2b because it's stdlib, fast, and deterministic across
    Python versions and platforms. The output is folded down to 64 bits
    because Python's Random takes any int but stores extra entropy
    silently and we want repeatability across builds.
    """
    h = hashlib.blake2b(digest_size=8)
    h.update(struct.pack(">Q", parent_seed & ((1 << 64) - 1)))
    h.update(b"\x00")
    h.update(stream.encode("utf-8"))
    return int.from_bytes(h.digest(), "big")


@dataclass
class RngBundle:
    """A collection of seeded streams keyed by name.

    Streams are created lazily on first :meth:`stream` call. The seed
    derivation is stable - the same parent seed and stream name yield
    the same Random across runs, across machines, and across Python
    point releases.

    The bundle exposes a :meth:`fork` method that constructs a child
    bundle whose streams are derived from the parent's seed mixed with
    a label. Forks are how the simulator hands "owned" RNG to subsystems
    without giving them write access to siblings.
    """

    seed: int
    _streams: dict[str, random.Random] = field(default_factory=dict)
    _draw_counts: dict[str, int] = field(default_factory=dict)

    def stream(self, name: str) -> random.Random:
        if name in self._streams:
            return self._streams[name]
        derived = _derive_seed(self.seed, name)
        rng = _CountingRandom(derived, self, name)
        self._streams[name] = rng
        self._draw_counts[name] = 0
        return rng

    def fork(self, label: str) -> "RngBundle":
        child_seed = _derive_seed(self.seed, f"@fork:{label}")
        return RngBundle(seed=child_seed)

    def draw_counts(self) -> dict[str, int]:
        """Snapshot of how many times each stream has been drawn from.

        Used by the trace recorder to serialize RNG state at snapshot
        boundaries.
        """
        return dict(self._draw_counts)

    def restore_draw_counts(self, counts: dict[str, int]) -> None:
        """Re-create streams and advance them by the recorded counts.

        Restoration is straightforward when a stream was used: derive
        the seed, then call ``random()`` ``count`` times. Not the
        fastest design - O(count) instead of O(log count) - but it's
        the only one that doesn't depend on Random's internal state
        format, which has shifted between Python releases.
        """
        for name, count in counts.items():
            rng = self.stream(name)
            for _ in range(count):
                rng.random()


class _CountingRandom(random.Random):
    """A Random subclass that ticks the bundle's draw count on each
    primitive call.

    Only ``random()`` is overridden, because every other Random method
    (``randint``, ``choice``, etc.) eventually goes through ``random()``.
    That holds on CPython 3.11 and 3.12.
    """

    def __init__(self, seed: int, bundle: RngBundle, name: str) -> None:
        super().__init__(seed)
        self._bundle = bundle
        self._name = name

    def random(self) -> float:
        v = super().random()
        self._bundle._draw_counts[self._name] = (
            self._bundle._draw_counts.get(self._name, 0) + 1
        )
        return v


def shared_pool(seed: int) -> random.Random:
    """The legacy single-stream API.

    Returned Random is independent of any RngBundle. Used by code
    paths that haven't migrated to streams yet. New code should prefer
    :meth:`RngBundle.stream`.
    """
    return random.Random(seed)
