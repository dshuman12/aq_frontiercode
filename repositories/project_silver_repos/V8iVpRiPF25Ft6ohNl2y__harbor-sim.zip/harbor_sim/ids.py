"""Strongly-typed identifiers.

Every domain object - node, link, replica, event, term, log entry - gets
its own ID type, all of them thin wrappers around int or str. This is
mildly tedious but pays off in two places: mypy catches a lot of cross-
wiring mistakes early, and the trace format can encode IDs in a compact
form because the type tag tells the decoder how to interpret the bytes.

Construction goes through factory functions (``new_event_id`` etc.) so
that the simulator's deterministic counter is the only source of ID
values during a run. The bare ``EventId(123)`` form is allowed for
tests, scenario loaders, and trace replay - anywhere the value
originates outside the live counter.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import NewType

# ---------- string IDs (declared by users) ----------

NodeId = NewType("NodeId", str)
LinkId = NewType("LinkId", str)
ProtocolId = NewType("ProtocolId", str)
ClientId = NewType("ClientId", str)


def is_node_id(s: object) -> bool:
    """Loose check used by the scenario loader before it casts."""
    return isinstance(s, str) and bool(s) and all(_is_id_char(c) for c in s)


def _is_id_char(c: str) -> bool:
    return c.isalnum() or c in "-_."


# ---------- integer IDs (allocated by the simulator) ----------

EventId = NewType("EventId", int)
ReplicaId = NewType("ReplicaId", int)
LogIndex = NewType("LogIndex", int)
Term = NewType("Term", int)
SnapshotId = NewType("SnapshotId", int)
RunId = NewType("RunId", int)


@dataclass
class IdAllocator:
    """A deterministic monotonic counter.

    The simulator owns one allocator per ID kind. Two simulator runs
    started with the same scenario+seed produce identical ID sequences;
    that's what makes traces diffable.

    Resetting is allowed only between scenarios; calling :meth:`reset`
    mid-run breaks the trace.
    """

    name: str
    _next: int = 0

    def alloc(self) -> int:
        v = self._next
        self._next += 1
        return v

    def peek(self) -> int:
        return self._next

    def reset(self, to: int = 0) -> None:
        if to < 0:
            raise ValueError(f"IdAllocator({self.name}).reset: negative value {to}")
        self._next = to

    def __repr__(self) -> str:
        return f"IdAllocator({self.name!r}, next={self._next})"


# ---------- composite keys ----------


@dataclass(frozen=True, slots=True)
class ReplicaRef:
    """A pair of (node, replica index) addressing one replica on one
    node. Many protocols use this rather than bare NodeId because they
    pin multiple replicas onto one node."""

    node: NodeId
    replica: ReplicaId

    def __str__(self) -> str:
        return f"{self.node}#{self.replica}"


@dataclass(frozen=True, slots=True)
class LogEntryKey:
    """Identifies a single log entry in (term, index) space."""

    term: Term
    index: LogIndex

    def __str__(self) -> str:
        return f"T{self.term}/I{self.index}"
