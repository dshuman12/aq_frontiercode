"""Deterministic content hashes.

The simulator hashes a lot: trace frames carry CRCs, snapshots carry
digests, the scenario loader hashes the canonical YAML to derive a
deterministic run-id. Three flavors:

* :func:`crc32c` - 32-bit CRC32C. Fast. Used for trace-frame integrity.
  Implemented in pure Python because the only widely available wheels
  bundle a C extension and the determinism of the chosen polynomial
  matters more than the speed.
* :func:`blake_hash` - 64-bit BLAKE2b folded down. Used for digests
  that need cryptographic-ish strength but only need to fit in 8 bytes.
* :func:`stable_hash` - structural hash over a Python value. Used to
  fingerprint scenarios and replicas; the recursion handles dicts,
  lists, tuples, frozensets, and a small set of primitives.

What this module does NOT do:

  Python's built-in ``hash()`` is salted between runs. ``stable_hash``
  produces the same bytes across runs and Python builds.
"""
from __future__ import annotations

import hashlib
import struct
from typing import Any

_CRC32C_POLY = 0x82F63B78
_CRC32C_TABLE: list[int] = []


def _build_crc32c_table() -> None:
    for i in range(256):
        c = i
        for _ in range(8):
            c = (c >> 1) ^ (_CRC32C_POLY if (c & 1) else 0)
        _CRC32C_TABLE.append(c & 0xFFFFFFFF)


_build_crc32c_table()


def crc32c(data: bytes, seed: int = 0) -> int:
    """Compute CRC32C (Castagnoli polynomial) over the given bytes.

    The seed parameter is for chained / streaming use: pass the result
    of one call as the seed of the next, with the same effect as
    concatenating the inputs first.
    """
    c = seed ^ 0xFFFFFFFF
    for b in data:
        c = (c >> 8) ^ _CRC32C_TABLE[(c ^ b) & 0xFF]
    return c ^ 0xFFFFFFFF


def blake_hash(data: bytes, size: int = 8) -> bytes:
    """BLAKE2b digest, ``size`` bytes (1..64). Default 8 bytes."""
    if not 1 <= size <= 64:
        raise ValueError(f"blake_hash size must be in [1, 64], got {size}")
    return hashlib.blake2b(data, digest_size=size).digest()


def blake_hash_int(data: bytes) -> int:
    """Same as :func:`blake_hash` with size=8, but returned as int."""
    return int.from_bytes(blake_hash(data, size=8), "big")


def stable_hash(value: Any) -> int:
    """Structural 64-bit hash of a Python value.

    Supports None, bool, int, float, str, bytes, lists, tuples,
    dicts, frozensets, and any object exposing a ``_stable_hash_repr``
    method. Sets and dicts are hashed in sorted-key order so the
    output doesn't depend on insertion order.

    Floats are tricky: NaN hashes to a fixed sentinel; signed zeros
    hash to the same value as positive zero.
    """
    return blake_hash_int(_stable_repr(value))


def _stable_repr(value: Any) -> bytes:
    if value is None:
        return b"N"
    if value is True:
        return b"T"
    if value is False:
        return b"F"
    if isinstance(value, int):
        return b"I" + str(value).encode("ascii") + b";"
    if isinstance(value, float):
        if value != value:  # NaN
            return b"f:nan"
        if value == 0.0:
            return b"f:0"
        return b"f:" + struct.pack(">d", value)
    if isinstance(value, str):
        b = value.encode("utf-8")
        return b"S" + struct.pack(">I", len(b)) + b
    if isinstance(value, bytes):
        return b"B" + struct.pack(">I", len(value)) + value
    if isinstance(value, (list, tuple)):
        marker = b"L" if isinstance(value, list) else b"P"
        parts = [marker, struct.pack(">I", len(value))]
        for item in value:
            parts.append(_stable_repr(item))
        return b"".join(parts)
    if isinstance(value, dict):
        items = sorted(value.items(), key=lambda kv: _stable_repr(kv[0]))
        parts = [b"D", struct.pack(">I", len(items))]
        for k, v in items:
            parts.append(_stable_repr(k))
            parts.append(_stable_repr(v))
        return b"".join(parts)
    if isinstance(value, frozenset):
        items = sorted(value, key=_stable_repr)
        parts = [b"H", struct.pack(">I", len(items))]
        for item in items:
            parts.append(_stable_repr(item))
        return b"".join(parts)
    if hasattr(value, "_stable_hash_repr"):
        return b"X" + _stable_repr(value._stable_hash_repr())
    raise TypeError(
        f"stable_hash: unsupported type {type(value).__name__} for value {value!r}"
    )
