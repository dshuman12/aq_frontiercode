"""Durable storage for protocol state.

Two top-level abstractions:

* :class:`~harbor_sim.storage.log.Log` - an append-only log keyed by
  (term, index). Each protocol replicates one. The log knows how to
  truncate from a given index, append in bulk, and produce a compact
  representation for snapshotting.
* :class:`~harbor_sim.storage.snapshot.Snapshot` - a typed wrapper
  around a serialized protocol state plus the log entries it covers.

Both use the codec module to serialize. The on-disk layout is one file
per (node, log) and one file per snapshot.
"""
from harbor_sim.storage.log import Log, LogEntry  # noqa: F401
from harbor_sim.storage.snapshot import (  # noqa: F401
    CompactionRecord,
    Snapshot,
    SnapshotStore,
)
