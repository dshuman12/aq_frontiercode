"""Snapshot storage.

A snapshot is the serialized state of a protocol on one node, together
with the (term, index) of the last log entry it covers and an optional
"compaction record" telling the runtime which earlier log entries were
compacted out when the snapshot was taken.

The compaction record matters more than it might look. When a node
restarts from a snapshot, it needs to know what range of log indexes
the snapshot represents so the log it loads on top doesn't replay
already-applied entries. Without the record, the runtime treats the
log as starting at index 1 and replays everything - which gets you
duplicate applies, which surfaces as an invariant violation in the
linearizability checker but only after a confusing chain of indirection.

The compaction record is bundled with the snapshot on disk. The
scenario loader, which is responsible for materializing nodes at
startup, is supposed to read the record alongside the snapshot blob
and hand both to the protocol. (This is the load-time path; the
snapshot-take path on a running node always emits both.)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import msgpack

from harbor_sim.errors import CodecError
from harbor_sim.fsutil import atomic_write_bytes, ensure_dir
from harbor_sim.ids import LogIndex, NodeId, SnapshotId, Term


@dataclass(slots=True)
class CompactionRecord:
    """Bookkeeping describing what a snapshot replaced.

    Stored alongside the snapshot blob. Carries:

    * ``last_included_index``: the highest log index covered by the
      snapshot.
    * ``last_included_term``: the term of that entry.
    * ``compacted_count``: how many log entries the snapshot replaced.

    The triple is enough to reconstruct a Log that starts at
    ``last_included_index + 1`` with the right :attr:`first_index`
    and :attr:`last_included_term`.
    """

    last_included_index: LogIndex
    last_included_term: Term
    compacted_count: int

    def serialize(self) -> bytes:
        return msgpack.packb(
            {
                "lii": int(self.last_included_index),
                "lit": int(self.last_included_term),
                "n": self.compacted_count,
            },
            use_bin_type=True,
        )

    @classmethod
    def deserialize(cls, blob: bytes) -> "CompactionRecord":
        raw = msgpack.unpackb(blob, raw=False, strict_map_key=False)
        return cls(
            last_included_index=LogIndex(int(raw["lii"])),
            last_included_term=Term(int(raw["lit"])),
            compacted_count=int(raw["n"]),
        )


@dataclass(slots=True)
class Snapshot:
    """A serialized protocol state plus the compaction record describing
    what log range it covers."""

    id: SnapshotId
    node: NodeId
    state: dict[str, Any]
    compaction: CompactionRecord
    created_at_ms: int

    def serialize(self) -> bytes:
        return msgpack.packb(
            {
                "id": int(self.id),
                "node": str(self.node),
                "state": self.state,
                "compaction": {
                    "lii": int(self.compaction.last_included_index),
                    "lit": int(self.compaction.last_included_term),
                    "n": self.compaction.compacted_count,
                },
                "created_at_ms": self.created_at_ms,
            },
            use_bin_type=True,
        )

    @classmethod
    def deserialize(cls, blob: bytes) -> "Snapshot":
        try:
            raw = msgpack.unpackb(blob, raw=False, strict_map_key=False)
        except (
            msgpack.exceptions.UnpackException,
            msgpack.exceptions.ExtraData,
            ValueError,
        ) as e:
            raise CodecError(f"snapshot deserialize: {e}") from e
        if not isinstance(raw, dict) or "state" not in raw:
            raise CodecError("snapshot deserialize: missing state field")
        comp_raw = raw.get("compaction") or {}
        compaction = CompactionRecord(
            last_included_index=LogIndex(int(comp_raw.get("lii", 0))),
            last_included_term=Term(int(comp_raw.get("lit", 0))),
            compacted_count=int(comp_raw.get("n", 0)),
        )
        return cls(
            id=SnapshotId(int(raw.get("id", 0))),
            node=NodeId(str(raw.get("node", ""))),
            state=raw.get("state", {}),
            compaction=compaction,
            created_at_ms=int(raw.get("created_at_ms", 0)),
        )


@dataclass
class SnapshotStore:
    """A directory of snapshots indexed by node + snapshot id.

    Path layout::

        <root>/<node>/<snapshot_id>.snap
        <root>/<node>/<snapshot_id>.compaction
    """

    root: Path
    _index: dict[NodeId, list[SnapshotId]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        ensure_dir(self.root)
        self._rescan()

    def _rescan(self) -> None:
        self._index.clear()
        if not self.root.exists():
            return
        for node_dir in sorted(self.root.iterdir(), key=lambda p: p.name):
            if not node_dir.is_dir():
                continue
            ids = []
            for f in sorted(node_dir.glob("*.snap")):
                try:
                    ids.append(SnapshotId(int(f.stem)))
                except ValueError:
                    continue
            self._index[NodeId(node_dir.name)] = ids

    def save(self, snap: Snapshot) -> None:
        node_dir = self.root / str(snap.node)
        ensure_dir(node_dir)
        snap_path = node_dir / f"{int(snap.id)}.snap"
        comp_path = node_dir / f"{int(snap.id)}.compaction"
        atomic_write_bytes(snap_path, snap.serialize())
        atomic_write_bytes(comp_path, snap.compaction.serialize())
        self._index.setdefault(snap.node, []).append(snap.id)

    def load(self, node: NodeId, snap_id: SnapshotId) -> Snapshot:
        snap_path = self.root / str(node) / f"{int(snap_id)}.snap"
        if not snap_path.exists():
            raise FileNotFoundError(f"no snapshot {snap_id} for node {node}")
        return Snapshot.deserialize(snap_path.read_bytes())

    def load_compaction(
        self, node: NodeId, snap_id: SnapshotId
    ) -> CompactionRecord | None:
        """Load the standalone compaction record for a snapshot, if one
        was written separately. Returns None if the file is missing -
        callers can fall back to the record inside the snapshot blob."""
        comp_path = self.root / str(node) / f"{int(snap_id)}.compaction"
        if not comp_path.exists():
            return None
        return CompactionRecord.deserialize(comp_path.read_bytes())

    def latest_for(self, node: NodeId) -> SnapshotId | None:
        ids = self._index.get(node, [])
        if not ids:
            return None
        return max(ids, key=int)

    def list_for(self, node: NodeId) -> list[SnapshotId]:
        return list(self._index.get(node, []))
