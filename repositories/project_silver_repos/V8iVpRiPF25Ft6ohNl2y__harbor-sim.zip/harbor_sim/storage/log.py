"""Append-only log.

Each protocol that replicates state owns one ``Log``. The log is keyed
by (term, index) but indexes the entries by index alone since indexes
are dense from the log's start. Entries before the first stored index
are conceptually present-in-the-snapshot - the log tracks
``first_index`` so callers can query "what's the earliest index I can
read?" without needing to know about the snapshot.

The log is in-memory by default; persistence is the caller's job. A
helper :func:`serialize` / :func:`deserialize` round-trips the log
through msgpack for snapshotting.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterator

import msgpack

from harbor_sim.errors import ProtocolError
from harbor_sim.ids import LogEntryKey, LogIndex, Term


@dataclass(slots=True)
class LogEntry:
    """One log entry.

    ``term`` and ``index`` together identify the entry within a single
    log. ``data`` is whatever the protocol wants to persist - for raft-
    lite it's a serialized client command; for quorum-KV it's a
    (key, value, write-id) triple.
    """

    term: Term
    index: LogIndex
    data: dict[str, Any]

    def key(self) -> LogEntryKey:
        return LogEntryKey(self.term, self.index)


@dataclass
class Log:
    """An append-only log with truncation and snapshot support."""

    entries: list[LogEntry] = field(default_factory=list)
    first_index: LogIndex = field(default_factory=lambda: LogIndex(1))
    last_included_term: Term = field(default_factory=lambda: Term(0))

    def append(self, entry: LogEntry) -> None:
        """Append an entry. The entry's index must be ``last_index + 1``
        (or ``first_index`` if the log is empty)."""
        expected = self.last_index() + 1 if self.entries else self.first_index
        if int(entry.index) != int(expected):
            raise ProtocolError(
                f"log.append: index gap. expected {expected}, got {entry.index}"
            )
        self.entries.append(entry)

    def append_many(self, entries: list[LogEntry]) -> None:
        for e in entries:
            self.append(e)

    def last_index(self) -> LogIndex:
        if self.entries:
            return self.entries[-1].index
        return LogIndex(int(self.first_index) - 1)

    def last_term(self) -> Term:
        if self.entries:
            return self.entries[-1].term
        return self.last_included_term

    def length(self) -> int:
        return len(self.entries)

    def get(self, index: LogIndex) -> LogEntry:
        """Get the entry at ``index``. Raises :class:`KeyError` if the
        index is outside the stored range. Use :meth:`contains` first
        if you don't want the raise behavior."""
        if int(index) < int(self.first_index):
            raise KeyError(
                f"log.get: index {index} predates first_index {self.first_index}"
            )
        offset = int(index) - int(self.first_index)
        if offset >= len(self.entries):
            raise KeyError(
                f"log.get: index {index} past last_index {self.last_index()}"
            )
        return self.entries[offset]

    def contains(self, index: LogIndex) -> bool:
        if int(index) < int(self.first_index):
            return False
        offset = int(index) - int(self.first_index)
        return offset < len(self.entries)

    def slice(self, low: LogIndex, high: LogIndex) -> list[LogEntry]:
        """Half-open slice ``[low, high)``. Empty if low >= high.

        Indexes outside the stored range are clamped silently rather
        than raised - callers iterating over a follower's log shouldn't
        need to bracket every call with a contains check.
        """
        if int(low) >= int(high):
            return []
        lo = max(int(low), int(self.first_index))
        hi = min(int(high), int(self.last_index()) + 1)
        if lo >= hi:
            return []
        lo_off = lo - int(self.first_index)
        hi_off = hi - int(self.first_index)
        return list(self.entries[lo_off:hi_off])

    def truncate_from(self, index: LogIndex) -> int:
        """Drop entries at index and beyond. Returns the count of
        entries removed. Used when a leader's log diverges and the
        follower needs to roll back."""
        if int(index) <= int(self.last_index()):
            offset = max(0, int(index) - int(self.first_index))
            removed = len(self.entries) - offset
            del self.entries[offset:]
            return removed
        return 0

    def compact(self, through: LogIndex, term: Term) -> int:
        """Drop entries up to and including ``through`` and advance
        :attr:`first_index`. ``term`` is the term of the last entry
        being dropped; it becomes :attr:`last_included_term`.

        Returns the number of entries compacted away.
        """
        if int(through) < int(self.first_index):
            return 0
        offset = int(through) - int(self.first_index) + 1
        offset = min(offset, len(self.entries))
        if offset == 0:
            return 0
        del self.entries[:offset]
        self.first_index = LogIndex(int(through) + 1)
        self.last_included_term = term
        return offset

    def __iter__(self) -> Iterator[LogEntry]:
        return iter(self.entries)


def serialize(log: Log) -> bytes:
    return msgpack.packb(
        {
            "first_index": int(log.first_index),
            "last_included_term": int(log.last_included_term),
            "entries": [
                {"t": int(e.term), "i": int(e.index), "d": e.data} for e in log.entries
            ],
        },
        use_bin_type=True,
    )


def deserialize(blob: bytes) -> Log:
    raw = msgpack.unpackb(blob, raw=False, strict_map_key=False)
    log = Log(
        first_index=LogIndex(int(raw["first_index"])),
        last_included_term=Term(int(raw["last_included_term"])),
    )
    log.entries = [
        LogEntry(term=Term(int(e["t"])), index=LogIndex(int(e["i"])), data=e["d"])
        for e in raw["entries"]
    ]
    return log
