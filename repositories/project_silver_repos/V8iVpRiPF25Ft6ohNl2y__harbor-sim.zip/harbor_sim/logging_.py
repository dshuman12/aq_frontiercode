"""A tiny structured logger.

The simulator emits a lot of low-level events ("scheduler dequeued
e=42", "transport dropped m=17 on link l1->l2") and the stdlib logging
module is too noisy for it - every line costs an attribute lookup and
a format-string parse even when the level filters it out.

This logger is a thin wrapper that:

  * caches enabled-ness on level changes;
  * builds the record as a dict, never a formatted string, so consumers
    that want JSON output don't pay the format-then-parse round-trip;
  * routes through a single :class:`Sink` that the CLI can swap.

It is NOT a replacement for the stdlib in projects that don't have
this specific hot-path concern.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Callable, TextIO


class Level(IntEnum):
    TRACE = 5
    DEBUG = 10
    INFO = 20
    WARN = 30
    ERROR = 40
    SILENT = 100


@dataclass
class LogRecord:
    """A single log event. The :attr:`fields` dict carries everything
    structured; :attr:`message` is the human-readable summary."""

    level: Level
    message: str
    fields: dict[str, Any]


class Sink:
    """Receives :class:`LogRecord` instances."""

    def write(self, record: LogRecord) -> None:
        raise NotImplementedError


class TextSink(Sink):
    """Renders records as one line of human-readable text."""

    def __init__(self, stream: TextIO | None = None) -> None:
        self.stream = stream or sys.stderr

    def write(self, record: LogRecord) -> None:
        prefix = record.level.name.lower().ljust(5)
        bits = " ".join(f"{k}={v}" for k, v in record.fields.items())
        if bits:
            print(f"[{prefix}] {record.message} {bits}", file=self.stream)
        else:
            print(f"[{prefix}] {record.message}", file=self.stream)


class JsonSink(Sink):
    """Renders records as one line of JSON.

    Doesn't depend on the stdlib json module's full surface - the
    record shape is small enough that a hand-rolled formatter avoids
    a recursive import problem that bit me once. Stays simple."""

    def __init__(self, stream: TextIO | None = None) -> None:
        self.stream = stream or sys.stderr

    def write(self, record: LogRecord) -> None:
        import json

        out = {"lvl": record.level.name, "msg": record.message}
        out.update(record.fields)
        self.stream.write(json.dumps(out, sort_keys=True) + "\n")


class NullSink(Sink):
    """Drops everything. Used in tests."""

    def write(self, record: LogRecord) -> None:
        pass


_global_level = Level.INFO
_global_sink: Sink = TextSink()


def set_level(level: Level) -> None:
    global _global_level
    _global_level = level


def get_level() -> Level:
    return _global_level


def set_sink(sink: Sink) -> None:
    global _global_sink
    _global_sink = sink


def get_sink() -> Sink:
    return _global_sink


def log(level: Level, message: str, **fields: Any) -> None:
    if level < _global_level:
        return
    _global_sink.write(LogRecord(level=level, message=message, fields=fields))


def trace(message: str, **fields: Any) -> None:
    log(Level.TRACE, message, **fields)


def debug(message: str, **fields: Any) -> None:
    log(Level.DEBUG, message, **fields)


def info(message: str, **fields: Any) -> None:
    log(Level.INFO, message, **fields)


def warn(message: str, **fields: Any) -> None:
    log(Level.WARN, message, **fields)


def error(message: str, **fields: Any) -> None:
    log(Level.ERROR, message, **fields)


def with_context(**ctx: Any) -> Callable[..., None]:
    """Return a logger that merges ``ctx`` into every record's fields.

    Used by subsystems to prefix logs with a node id, replica index,
    or similar. Cheaper than a custom adapter class.
    """

    def emit(level: Level, message: str, **fields: Any) -> None:
        merged = dict(ctx)
        merged.update(fields)
        log(level, message, **merged)

    return emit
