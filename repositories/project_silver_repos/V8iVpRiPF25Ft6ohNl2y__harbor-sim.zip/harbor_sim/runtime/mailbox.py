"""Per-node mailbox.

Two queues:

* The inbox is for messages that have arrived from the network and are
  waiting for the protocol to process them.
* The outbox is for messages the protocol has produced but the
  transport hasn't picked up yet. It's there so the protocol can be a
  pure function over inbox-and-state - the runtime drains the outbox
  after each call.

Both queues are bounded; overflow is a hard error rather than a silent
drop. Tests can dial the cap up if they need to drive a node hard.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque

from harbor_sim.errors import SimulationError
from harbor_sim.ids import NodeId


DEFAULT_CAP = 4096


@dataclass(slots=True)
class IncomingMessage:
    """A message that has arrived at a node."""

    from_node: NodeId
    kind: str
    body: dict[str, Any]
    received_at_ms: int


@dataclass(slots=True)
class OutgoingMessage:
    """A message produced by a protocol awaiting transport pickup."""

    to_node: NodeId
    kind: str
    body: dict[str, Any]


@dataclass
class Mailbox:
    """A node's incoming/outgoing message queues."""

    node: NodeId
    cap: int = DEFAULT_CAP
    inbox: Deque[IncomingMessage] = field(default_factory=deque)
    outbox: Deque[OutgoingMessage] = field(default_factory=deque)

    def push_in(self, msg: IncomingMessage) -> None:
        if len(self.inbox) >= self.cap:
            raise SimulationError(
                f"mailbox.inbox overflow on {self.node!r}: cap={self.cap}"
            )
        self.inbox.append(msg)

    def pop_in(self) -> IncomingMessage | None:
        if not self.inbox:
            return None
        return self.inbox.popleft()

    def push_out(self, msg: OutgoingMessage) -> None:
        if len(self.outbox) >= self.cap:
            raise SimulationError(
                f"mailbox.outbox overflow on {self.node!r}: cap={self.cap}"
            )
        self.outbox.append(msg)

    def drain_out(self) -> list[OutgoingMessage]:
        out = list(self.outbox)
        self.outbox.clear()
        return out

    def inbox_len(self) -> int:
        return len(self.inbox)

    def outbox_len(self) -> int:
        return len(self.outbox)

    def clear(self) -> None:
        self.inbox.clear()
        self.outbox.clear()
