"""The top-level Simulator.

Owns the scheduler, transport, snapshot store, and every Node. Drives
the event loop. Stateless once constructed - all mutable state lives
on its owned subsystems.

Typical flow::

    sim = Simulator.from_scenario(scenario)
    sim.boot_all()
    sim.run(horizon_ms=60_000, on_event=recorder.record)
    sim.shutdown_all()
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from harbor_sim.clock import SimClock
from harbor_sim.errors import ScenarioReferenceError, SimulationError
from harbor_sim.ids import NodeId
from harbor_sim.rng import RngBundle
from harbor_sim.runtime.mailbox import IncomingMessage
from harbor_sim.runtime.node import Node
from harbor_sim.scheduler import Event, Scheduler
from harbor_sim.storage.snapshot import SnapshotStore
from harbor_sim.transport import Transport


@dataclass
class Simulator:
    """A whole simulation."""

    clock: SimClock
    rng: RngBundle
    scheduler: Scheduler
    transport: Transport
    snapshots: SnapshotStore
    nodes: dict[NodeId, Node] = field(default_factory=dict)
    booted: bool = False
    _event_count: int = 0

    @classmethod
    def make(cls, seed: int, workdir: Path | None = None) -> "Simulator":
        clock = SimClock()
        rng = RngBundle(seed=seed)
        sched = Scheduler(clock=clock, rng=rng)
        trans = Transport(scheduler=sched, rng=rng)
        snap_root = workdir or Path(".harbor-runs") / "snapshots"
        snaps = SnapshotStore(root=snap_root)
        return cls(
            clock=clock,
            rng=rng,
            scheduler=sched,
            transport=trans,
            snapshots=snaps,
        )

    def add_node(self, node: Node) -> None:
        if node.id in self.nodes:
            raise SimulationError(f"duplicate node id {node.id!r}")
        self.nodes[node.id] = node

    def get(self, node_id: NodeId) -> Node:
        try:
            return self.nodes[node_id]
        except KeyError as e:
            raise ScenarioReferenceError("node", str(node_id)) from e

    def boot_all(self) -> None:
        for node in self.nodes.values():
            node.boot()
        self.booted = True

    def shutdown_all(self) -> None:
        for node in self.nodes.values():
            node.shutdown()

    def dispatch(self, ev: Event) -> None:
        """Send one dequeued event to whichever subsystem owns it.

        Three event kinds reach the dispatcher:

        * ``"deliver"`` - a network delivery; the message goes into the
          recipient's inbox and we step the node once.
        * ``"timer"`` - a per-node timer; the node's protocol gets the
          ``on_timer`` callback.
        * ``"fault"`` - a scenario-driven fault injection (partition,
          crash, recover); handled inline.
        """
        if ev.kind == "deliver":
            self._dispatch_deliver(ev)
        elif ev.kind == "timer":
            self._dispatch_timer(ev)
        elif ev.kind == "fault":
            self._dispatch_fault(ev)
        else:
            # Unknown events are ignored - they may be hook-only tags
            # from the trace recorder or the workload generator.
            return

    def _dispatch_deliver(self, ev: Event) -> None:
        dst = NodeId(ev.target)
        node = self.nodes.get(dst)
        if node is None:
            return
        payload = ev.payload
        msg = IncomingMessage(
            from_node=NodeId(payload["from"]),
            kind=str(payload["kind"]),
            body=dict(payload.get("body") or {}),
            received_at_ms=self.scheduler.now_ms,
        )
        # Bookkeeping for the transport.
        self.transport.on_delivered(msg.from_node, dst)
        node.deliver(msg)
        node.step_one()

    def _dispatch_timer(self, ev: Event) -> None:
        dst = NodeId(ev.target)
        node = self.nodes.get(dst)
        if node is None:
            return
        key = str(ev.payload.get("timer_key", ""))
        payload = {k: v for k, v in ev.payload.items() if k != "timer_key"}
        node.on_timer(key, payload)

    def _dispatch_fault(self, ev: Event) -> None:
        kind = str(ev.payload.get("fault_kind", ""))
        if kind == "partition":
            a = NodeId(str(ev.payload["a"]))
            b = NodeId(str(ev.payload["b"]))
            on = bool(ev.payload.get("on", True))
            self.transport.partition_pair(a, b, on)
        elif kind == "crash":
            target = NodeId(ev.target)
            self.nodes[target].crash()
        elif kind == "recover":
            target = NodeId(ev.target)
            self.nodes[target].recover()
        else:
            return

    def run(
        self,
        horizon_ms: int,
        on_event: Callable[[Event], None] | None = None,
    ) -> int:
        """Drive the event loop until the clock reaches ``horizon_ms``
        (or the queue drains, whichever comes first).

        Returns the number of events dispatched. ``on_event`` is called
        AFTER dispatch so a recorder can see the resulting state.
        """
        if not self.booted:
            self.boot_all()

        def step(ev: Event) -> None:
            self.dispatch(ev)
            self._event_count += 1
            if on_event is not None:
                on_event(ev)

        return self.scheduler.run_until(horizon_ms, step)

    def event_count(self) -> int:
        return self._event_count
