"""A node in the simulated cluster.

A node owns:

* an :class:`~harbor_sim.runtime.mailbox.Mailbox`
* a per-node :class:`~harbor_sim.clock.Clock`
* a protocol instance (whatever the scenario specified)
* a working directory on disk for snapshots and logs (lazily created)

Lifecycle:

  1. ``boot()``: protocol gets ``on_init(ctx)``.
  2. for each delivered or timer event: protocol gets the appropriate
     handler call, then the outbox is drained through the transport.
  3. ``shutdown()``: protocol gets ``on_shutdown(ctx)``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from harbor_sim.clock import Clock, ClockSkew, SimClock
from harbor_sim.ids import NodeId
from harbor_sim.rng import RngBundle
from harbor_sim.runtime.context import NodeContext
from harbor_sim.runtime.mailbox import IncomingMessage, Mailbox
from harbor_sim.scheduler import Scheduler
from harbor_sim.transport import Transport


class ProtocolImpl(Protocol):
    """The interface every protocol implementation honors."""

    def on_init(self, ctx: NodeContext) -> None: ...

    def on_message(self, ctx: NodeContext, msg: IncomingMessage) -> None: ...

    def on_timer(self, ctx: NodeContext, key: str, payload: dict[str, Any]) -> None: ...

    def on_shutdown(self, ctx: NodeContext) -> None: ...


@dataclass
class Node:
    """One node in the simulated cluster."""

    id: NodeId
    clock: Clock
    mailbox: Mailbox
    protocol: ProtocolImpl
    scheduler: Scheduler
    transport: Transport
    rng: RngBundle
    workdir: Path
    booted: bool = False
    crashed: bool = False
    _ctx: NodeContext | None = field(default=None, repr=False)

    @classmethod
    def make(
        cls,
        node_id: NodeId,
        protocol: ProtocolImpl,
        scheduler: Scheduler,
        transport: Transport,
        rng: RngBundle,
        sim_clock: SimClock,
        skew: ClockSkew | None = None,
        workdir: Path | None = None,
    ) -> "Node":
        clock = Clock(node=node_id, skew=skew or ClockSkew(), _global=sim_clock)
        mailbox = Mailbox(node=node_id)
        wd = workdir or Path(".harbor-runs") / str(node_id)
        return cls(
            id=node_id,
            clock=clock,
            mailbox=mailbox,
            protocol=protocol,
            scheduler=scheduler,
            transport=transport,
            rng=rng,
            workdir=wd,
        )

    def context(self) -> NodeContext:
        if self._ctx is None:
            self._ctx = NodeContext(
                node=self.id,
                clock=self.clock,
                rng=self.rng,
                scheduler=self.scheduler,
                transport=self.transport,
                mailbox=self.mailbox,
            )
        return self._ctx

    def boot(self) -> None:
        if self.booted:
            return
        self.protocol.on_init(self.context())
        self._flush_outbox()
        self.booted = True

    def shutdown(self) -> None:
        if not self.booted or self.crashed:
            return
        self.protocol.on_shutdown(self.context())
        self._flush_outbox()

    def crash(self) -> None:
        """Mark the node crashed. Subsequent events are dropped until
        :meth:`recover` is called."""
        self.crashed = True
        self.mailbox.clear()

    def recover(self) -> None:
        self.crashed = False

    def deliver(self, msg: IncomingMessage) -> None:
        if self.crashed:
            return
        self.mailbox.push_in(msg)

    def step_one(self) -> bool:
        """Dispatch one message from the inbox. Returns False if the
        inbox was empty.

        Crashed nodes silently skip the step. Booted = False also
        skips (you should call :meth:`boot` first).
        """
        if self.crashed or not self.booted:
            return False
        msg = self.mailbox.pop_in()
        if msg is None:
            return False
        self.protocol.on_message(self.context(), msg)
        self._flush_outbox()
        return True

    def on_timer(self, key: str, payload: dict[str, Any]) -> None:
        if self.crashed or not self.booted:
            return
        self.protocol.on_timer(self.context(), key, payload)
        self._flush_outbox()

    def _flush_outbox(self) -> None:
        for out in self.mailbox.drain_out():
            if not self.transport.has_link(self.id, out.to_node):
                continue
            self.transport.send(self.id, out.to_node, out.kind, out.body)
