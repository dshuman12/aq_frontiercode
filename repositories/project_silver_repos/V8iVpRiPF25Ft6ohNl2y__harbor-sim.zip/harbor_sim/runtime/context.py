"""The per-tick context handed to a protocol on every dispatch.

A protocol's main entry point looks like::

    def on_message(ctx: NodeContext, msg: IncomingMessage) -> None: ...
    def on_timer(ctx: NodeContext, key: str) -> None: ...

``ctx`` is the *only* thing the protocol can touch besides its own
state. It owns the clock, the RNG, the scheduler (for setting timers),
and the outbox (for sending messages). Protocols that reach around the
context - say, by reading the global SimClock directly - lose the
skew model and the per-stream RNG fork. Don't do that.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from harbor_sim.clock import Clock
from harbor_sim.ids import NodeId
from harbor_sim.rng import RngBundle
from harbor_sim.runtime.mailbox import Mailbox, OutgoingMessage
from harbor_sim.scheduler import Scheduler
from harbor_sim.transport import Transport


@dataclass
class NodeContext:
    """The handle a protocol receives on every tick."""

    node: NodeId
    clock: Clock
    rng: RngBundle
    scheduler: Scheduler
    transport: Transport
    mailbox: Mailbox

    def send(self, to: NodeId, kind: str, body: dict[str, Any]) -> None:
        """Queue a message in the outbox. The runtime hands the outbox
        off to the transport at the end of the dispatch."""
        self.mailbox.push_out(OutgoingMessage(to_node=to, kind=kind, body=body))

    def set_timer(self, delay_ms: int, key: str, payload: dict[str, Any] | None = None):
        """Schedule a timer event addressed to this node."""
        payload = dict(payload or {})
        payload["timer_key"] = key
        return self.scheduler.schedule(
            delay_ms,
            kind="timer",
            target=str(self.node),
            payload=payload,
        )

    def cancel_timer(self, eid) -> bool:
        return self.scheduler.cancel(eid)

    def now(self) -> int:
        """Node-local time in milliseconds. Goes through the skewed
        clock - protocols MUST use this, not the global SimClock."""
        return self.clock.now()
