# Code of Conduct

Be kind. Assume the other person is acting in good faith. If you can
phrase a critique in a way that's about the code rather than the
person, do that.

If somebody else isn't being kind to you, tell me at
asifhammad84@gmail.com and I'll handle it.
