# Runbook: invariant violation

`harbor-sim verify` reported one or more violations. The violation
witnesses are structured; this runbook is how to decode them.

## Reading the witness

A typical witness:

```
linearizability: FAIL (1 violations)
  at 8420ms [violation] {'kind': 'staleness_floor_violation',
    'key': 'x', 'read_set': ['n3', 'n4'],
    'last_write_set': ['n1', 'n2'], 'overlap': 0, 'required': 1}
```

What this says:

* The check that fired was `linearizability`.
* The triggering event was at logical time 8420ms.
* The violation kind is `staleness_floor_violation`.
* The read at issue saw responses from n3 and n4.
* The most recent successful write quorum was n1 and n2.
* Overlap is 0; floor required 1.

If you're surprised this fired, the question is usually "what is
the read-set supposed to look like under our N/R/W?"

Worked example: N=3, R=2, W=2 with floor=0. R+W=4 > N=3, so the
no-floor configuration is strongly consistent in the no-failure
case. Under partition, a read quorum can land entirely in the
partition opposite the most recent write quorum. R=2 of {n3, n4}
when the write went to {n1, n2} is exactly that case. Setting
floor=1 surfaces it.

## Per-invariant guidance

* `agreement`: two leaders in one term. Almost always a clock-skew
  or election-timer bug; check whether the witness's terms align
  with a partition event.
* `election_safety`: a commit at index I has a different
  (term, op) than an earlier commit at the same index. This is a
  log-matching bug. The commit-index propagation path is the
  usual suspect.
* `linearizability`: as above. Either no-matching-write (the read
  saw a value that was never written) or staleness-floor-violation
  (the read returned a value but the read-set didn't overlap the
  write-set enough).

## What to do next

1. Save the trace under `examples/regressions/`.
2. Re-run with `--invariant <name>` and `-v` to get more context.
3. If you can reduce the reproducer to a smaller scenario, the
   fuzzer can take it from here.

Don't fix without a reproducer. The first three "fixes" you try
will probably mask the bug rather than resolve it.
