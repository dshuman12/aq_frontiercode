# Runbook: replay divergence

A `harbor-sim replay` errored with `DivergenceError`. The replay
produced an event that doesn't match the recording at the same
tick. This means either:

1. The simulator is non-deterministic at some point in this
   scenario.
2. The trace was recorded with a different version of the code.
3. The scenario file changed between record and replay.

## Triage

First check (3): the trace's `scenario_hash` should match what
the current scenario hashes to. Run:

```
harbor-sim inspect <trace> | head -1
```

Compare against:

```
python -c "from harbor_sim.scenario.loader import load; \
           from harbor_sim.hashing import stable_hash; \
           print(hex(stable_hash(load('<scenario>'))))"
```

If they differ, you're replaying against a different scenario.
Either find the right scenario file or re-record.

Second, (2): check the trace header for the version field. If it's
v1, run `harbor-sim trace migrate` first. The replay engine doesn't
read v1 directly.

Third, (1): the divergence tick tells you where to look. Run

```
harbor-sim inspect <trace> --filter t=<divergence_tick>
```

and compare against what the replay produced. The diff CLI is
useful here if you have both traces:

```
harbor-sim run <scenario> --trace /tmp/replay.trace
harbor-sim diff <recorded.trace> /tmp/replay.trace
```

The first divergent event usually points at the bug.

## Common causes

* A protocol read the global SimClock instead of the per-node
  Clock. The ms-level difference is invisible at most ticks but
  surfaces when scenarios have non-zero skew.
* A protocol used `dict.items()` and depended on insertion order
  that's different across Python builds. Not actually a problem
  on 3.7+, but a subtle source of variation if any dict was built
  with a different code path.
* The trace recorder's flush boundary moved. Pre-v0.3.0, the
  recorder flushed every event; v0.3.0 batches.

## If it's a real non-determinism bug

Pin a minimum reproducer:

1. Find the smallest scenario that reproduces.
2. Reduce the horizon to just past the divergence tick.
3. Save the scenario under `examples/regressions/` with a name
   like `0007-leader-lease-skew.yaml`.
4. Add it to the conformance corpus by regenerating hashes.

The conformance corpus is the most reliable place to keep
determinism regressions caught.
