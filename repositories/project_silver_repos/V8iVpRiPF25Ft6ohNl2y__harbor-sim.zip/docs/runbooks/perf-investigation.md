# Runbook: simulator running slow

The bench output is worse than yesterday. Or a scenario that used
to finish in 30 seconds is now taking 3 minutes. This is what I
do, in this order.

## Quick triage

1. Run `harbor-sim bench --suite quick` and note the numbers.
2. Run `git log --oneline | head` and see if anything plausible
   landed recently.
3. `python -X importtime -m harbor_sim --help 2>&1 | sort -k2 -n -r | head -20`.
   If the import time has bloated, that's the culprit.

## Common slowdowns

### Trace recording

The recorder buffers up to `flush_every` frames before writing.
If you set this too low, write amplification kills throughput.
The default 256 is conservative; bumping to 1024 helps for
scenarios with >50k events.

Watch for:

```python
TraceRecorder(path=..., flush_every=1)
```

This shows up in old tests that wanted to inspect frames mid-run.
Almost never the right setting in production.

### Scheduler queue size

`sortedcontainers.SortedList` is O(log n) for insert and O(log n)
for pop. For a scenario with 1M events that's manageable but
non-trivial. If you've got cancelled events accumulating, they
chew memory without being removed - the dequeue path skips them.

Use:

```python
sim.scheduler.pending()
```

mid-run to see how many live events are in flight. If it's
unbounded growth, the protocol is probably leaking timers.

### Protocol-internal allocations

The biggest per-iteration allocation cost is in the AppendEntries
builder - it copies entries into a list of dicts on every send.
For a leader sending to N followers per heartbeat, that's
N copies. For most workloads this is fine; for benchmark scenarios
with 1000+ replicas it matters.

### zstd compression level

The recorder uses level 3 by default. Level 1 is ~3x faster and
produces traces ~15% larger. Level 9 produces traces ~10% smaller
than level 3 but takes 5x as long. Don't touch this without
profiling.

## When you've actually found something

Add a benchmark under `tools/bench/` and commit it before any
fix. The regression catches itself next time.

The bench harness has a `--baseline` flag that records the
current numbers; subsequent runs report deltas.
