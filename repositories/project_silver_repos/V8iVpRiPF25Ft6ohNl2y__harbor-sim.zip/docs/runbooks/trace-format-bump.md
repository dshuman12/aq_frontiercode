# Runbook: bumping the trace format

The trace format has had two versions: v1 (legacy, newline-delimited
JSON) and v2 (current, framed codec). When the time comes to ship
v3, follow this checklist. ADR-0007 has the rationale.

## Steps

1. Add a `V3 = 3` constant in `harbor_sim/trace/format.py` and
   update `SUPPORTED` and `LATEST`.
2. Decide what changed. Most v2->v3 bumps are field additions or
   renames; if you're changing the frame envelope itself, ADR-0007
   is required reading.
3. Update the writer (`harbor_sim/trace/recorder.py`) to emit v3.
   The reader keeps reading v2 + v3.
4. Add `migrate_v2_to_v3` in `harbor_sim/trace/migrate.py`. Even if
   the changes feel trivial, write the migration - the
   conformance suite needs it.
5. Add a one-line CLI subcommand for the new migration:
   `harbor-sim trace migrate-v2 <src> <dst>`. Or extend the existing
   one with a `--target` flag if the version chain is getting long.
6. Regenerate the conformance hashes:
   ```
   python -m tools.regen_conformance --confirm
   ```
   The script atomically writes the new hashes. The diff should
   match exactly the scenarios listed in `tests/conformance/manifest.json`.
7. Commit the migration test alongside the format change.
8. Update CHANGELOG.

## What to break and what not to

* The reader MUST accept the previous version forever. Even if
  we drop v1 from the writer in a future release, the v1 path in
  the reader stays.
* The migration tool MUST be one-shot: v1 -> v2, v2 -> v3, etc.
  No magic v1 -> v3 chains in code; the user chains them via
  the CLI.

## When NOT to bump

If you're tempted to bump because you want to add a single field
to one event type's payload, don't. Payloads inside frames are
opaque to the codec. Add the field, update the reader's typed
frame class, ship it. The format version doesn't change.

A version bump is justified when the frame envelope changes,
when an existing field's semantics change (rare), or when a
typed frame class's required keys change.
