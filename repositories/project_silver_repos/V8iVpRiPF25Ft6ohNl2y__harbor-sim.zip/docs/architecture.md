# Architecture

The bird's-eye view: a single-process discrete-event simulator whose
job is to drive a cluster of replicated state machines through a
deterministic event timeline. Every decision the simulator makes -
when an event fires, what order ties break, which message gets
dropped on a 5% drop link - is sourced from a seeded RNG, so two
runs of the same scenario produce byte-identical traces.

This document is the long-form companion to the bullet list in
`README.md`. If you've read both, the README has the layout and this
file has the rationale.

## Layers

```
              +----------------------------+
              |  cli/                      |  user surface
              +-------------+--------------+
                            |
              +-------------v--------------+
              |  scenario/   replay/       |  workflow
              +-------------+--------------+
                            |
              +-------------v--------------+
              |  protocols/  invariants/   |  domain
              |  trace/                    |
              +-------------+--------------+
                            |
              +-------------v--------------+
              |  runtime/                  |  per-node engine
              +-------------+--------------+
                            |
              +-------------v--------------+
              |  scheduler  transport      |  cluster engine
              |  storage                   |
              +-------------+--------------+
                            |
              +-------------v--------------+
              |  clock  rng  codec         |  primitives
              |  hashing  fsutil           |
              +----------------------------+
```

The line between "cluster engine" and "per-node engine" is the
seam I most often want to draw differently. The runtime owns a
per-node mailbox and dispatches messages to a single protocol;
the scheduler doesn't know anything about nodes. That split lets
us swap protocols without touching the scheduler, and swap the
scheduler without touching the protocols. It also makes a
non-trivial cross-cutting fix easy to spot: a fix that has to
plumb a field through both layers is a fix worth thinking twice
about.

## Determinism, in detail

The simulator is deterministic if and only if every source of
non-determinism is seeded from the scenario's seed. There are five:

1. Scheduler tie-breaks. When two events fire at the same logical
   millisecond, the order is determined by the `tie_break` field
   on each event, which is drawn from the scheduler's RNG stream
   at schedule time.
2. Transport latency. Each `send()` draws a uniform sample from
   the link's latency range. The draw goes through the transport's
   RNG stream.
3. Transport drop. A separate draw decides whether the message is
   dropped. Same stream as latency.
4. Protocol-internal jitter. Raft-lite's election timeout is
   uniform within a range; the draw goes through a per-node
   protocol stream.
5. Workload generation. The workload generator (driver of client
   PUT/GETs) draws keys and values from its own stream.

The bundle in `harbor_sim/rng.py` declares all five streams. Each
is derived from the parent seed using BLAKE2b - so the same
scenario+seed yields the same per-stream seed regardless of how
many other streams were created in between.

What this does NOT yet provide: stream-level independence. The
scheduler's stream and the transport's stream are separate, but
inside a single run, "scheduler" draws and "transport" draws are
serialized by the order in which the simulator calls them. If a
replay stops early and then continues, the resumed stream has
consumed N draws while the original had consumed M, M != N. This
is the gap behind ADR-0011.

## On-disk formats

Three.

The trace lives at `.trace` (or `.jsonl.zst` if it's a legacy v1
file). v2 is framed records with CRC32C, msgpack payloads, all
under zstd. v1 is read-only; the migration tool converts.

The snapshot is two files - `.snap` for the state blob and
`.compaction` for the sidecar. The sidecar carries the compaction
record: `(last_included_index, last_included_term, compacted_count)`.
You can recover the sidecar from the main blob, but keeping it
standalone lets the scenario loader read just the prefix without
unpacking the full state.

And the scenario YAML, read-only and human-edited. The schema
lives in `scenario/loader.py`.

The trace format is the one most likely to evolve. The codec module
supports both v1 and v2 already, and ADR-0007 describes the rules
for adding v3 if and when.

## Where protocols plug in

`harbor_sim/runtime/node.py` defines a Protocol interface. Two
implementations ship in-tree:

* `protocols/raftlite/` is a leader-elect + log-replicate. Around
  600 LoC of state machine + 200 LoC of message types. Doesn't
  implement joint consensus or InstallSnapshot.
* `protocols/quorum_kv/` is a Dynamo-style replicated KV. Around
  400 LoC including the read/write quorum machinery.

A third protocol would slot in next to these without modifying the
runtime. The registry in `protocols/__init__.py` is a name -> factory
map; scenarios reference the protocol by name.

## What I'd do differently

The scheduler's event ordering uses a SortedList from
`sortedcontainers`. Fine for this scale, but for a real Jepsen-
style fuzz harness driving millions of events, a specialized heap
with O(1) cancellation would be nicer. The current code tags a
cancelled event as not-alive and skips it on dequeue, which is
correct but chews memory under heavy cancellation.

The protocol-to-runtime contract leaks the scheduler. A protocol can
call `ctx.scheduler.schedule(...)` directly, which is too much rope -
it lets a protocol bypass the per-node mailbox. The right shape is a
`ctx.set_timer` and nothing else. I left scheduler on the context
during the rewrite because too many call sites use it directly.

The invariant checkers run after the trace is recorded. That's fine
for a debugging tool but it means scenarios that produce 10M events
also consume 10M events worth of memory in the checker (the
linearizability checker is the worst offender). Streaming checks
would scale.

## Things that worked out

The codec. The framed format is small, recovers cleanly from
truncation, and the v1 -> v2 migration tool was easy to write because
the new format wasn't trying to be backwards-compatible at the byte
level.

The scenario hash. `harbor_sim/hashing.py:stable_hash` is the kind of
function that pays for itself in tools. Use it for the trace's
scenario-hash field; the diff tool uses it to confirm two traces
came from the same scenario before comparing event-by-event.

The clock skew model. Two parameters (offset, drift) cover the
failure modes Raft-style protocols actually care about, and they
compose with the per-node Clock view such that protocols ignoring
the skew get caught by tests that pass a non-zero skew.
