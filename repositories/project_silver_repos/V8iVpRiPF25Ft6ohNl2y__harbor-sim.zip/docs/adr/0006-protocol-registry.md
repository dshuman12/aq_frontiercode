# ADR 0006: Protocol registry

Status: accepted, 2026-01-20

## Context

Two protocols ship in-tree today. A third or fourth is plausible
within the next year. Scenarios reference protocols by name. The
registration mechanism has to be:

* Eager: scenarios should fail fast when a name doesn't resolve,
  not on the first message the protocol tries to handle.
* Pluggable: a downstream user with their own protocol shouldn't
  need to fork the codebase to register it.

## Decision

A module-level dict in `protocols/__init__.py`. `register(name,
factory)` adds an entry; `lookup(name)` reads. The two in-tree
protocols register themselves on first import of the package.

Downstream users register their own protocols by importing
`harbor_sim.protocols` and calling `register`.

## Consequences

Simple. Fast. The registry is two functions and a dict.

The catch: registration is import-side-effect. If you import
`harbor_sim.protocols` twice in two test processes, the second
import is a no-op (Python caches the module), so re-registration
isn't an issue. But code that wants to *replace* a registered
protocol can't - the registry rejects double-registers.

This is deliberate. The "replace" use case is rare and easily
worked around by registering under a different name.

## Alternatives considered

* Entry points. Powerful but requires a real install step.
* Subclass-discovery via `__init_subclass__`. Magic, hard to
  reason about.
* A YAML registry file. Pointless indirection.
