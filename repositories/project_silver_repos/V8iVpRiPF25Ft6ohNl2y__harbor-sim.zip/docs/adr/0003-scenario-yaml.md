# ADR 0003: YAML for scenarios

Status: accepted, 2025-12-12

## Context

Scenarios describe a cluster, a workload, and a failure-injection
schedule. They need to be hand-edited, version-controlled, diff'd,
and parsed by a tool. The shape is naturally hierarchical (nodes,
links, failures) with small amounts of free-form metadata.

## Decision

YAML, parsed with `yaml.safe_load`. Strict validation in the loader;
errors return :class:`ScenarioValidationError` with a field path.

## Consequences

YAML is forgiving to write and unforgiving to parse. The validator
in `scenario/loader.py` is wordy as a result - every field gets a
type check, every reference gets resolved, every numeric range
gets a bound check. That's the price.

The other costs:

* Whitespace bugs. Most are caught by the parser; the rest, by the
  validator.
* No native dates. We never need them - all times are integer
  milliseconds.

The gain is hand-editability. Setting up a scenario takes a minute.
Diffs of scenario changes read cleanly.

## Alternatives considered

* TOML. Tried it on a Friday; tables-of-tables for the nodes/links
  layout felt fighty. Put YAML back on Monday.
* JSON. Comment-less, quote-heavy, no.
* Python files (importable as modules). Powerful and gross.
* A custom DSL. Considered seriously, rejected on tooling cost.
