# ADR 0013: raftlite is not full Raft

Status: accepted, 2026-01-04

## Context

The in-tree raft implementation needs to be enough to exercise
the agreement and election-safety invariants under partition,
clock skew, and crash-restart. Implementing the full Raft spec
is a meaningful undertaking; the simulator framework matters more
than this particular protocol.

## Decision

raftlite implements:

* Leader election with random timeout.
* Log replication via AppendEntries.
* Commit-index propagation.
* Leader lease (for read-without-roundtrip).

raftlite does NOT implement:

* Joint consensus (configuration changes).
* InstallSnapshot RPC. Followers learn about snapshots out-of-band.
* Read-index for stale-read avoidance under partition.
* Pre-vote phase.

## Consequences

The protocol is around 700 LoC instead of an order of magnitude
more. The invariants we care about (agreement, election safety,
log matching under crash) all work. Configuration-change bugs
aren't testable; nor are split-vote pathologies that pre-vote
would prevent.

If we ever need to author tasks against those, full Raft becomes
a separate protocol implementation rather than a refactor of
this one.

## Alternatives considered

* Full Raft. Worth a quarter of work. Not blocked on it.
* Multi-Paxos. Different shape entirely. Maybe a future protocol.
* Pull in a third-party library. Defeats the point of having
  test-fodder protocols I can break and observe.
