# ADR 0008: Clock skew model

Status: accepted, 2026-02-04

## Context

Raft-style protocols make assumptions about clock skew between
nodes. Some are explicit (lease durations expect bounded skew),
many are implicit. We want to exercise those assumptions.

The skew model has to be:

* Deterministic. Same scenario, same skew, same trace.
* Per-node. Different nodes have different skews; that's the whole
  point.
* Simple. Two parameters or less, ideally.

## Decision

Two parameters: offset (constant ms) and drift (parts-per-million,
applied as a linear function of base time). The model is integer
arithmetic throughout - no float drift to corrupt the trace.

The `Clock` view on each node applies its skew when the protocol
asks for "now". Protocols that go around the Clock and read the
SimClock directly skip the skew model entirely.

## Consequences

Tests that pass non-zero skew through the scenario catch protocol
code paths that bypass the Clock. The pattern that breaks: a
deadline check that uses the global SimClock instead of the node's
Clock. That happens to be an easy mistake to make - especially
when the deadline is shared across nodes - and the model lets a
single test scenario surface it.

The model is naive. Real clocks have a noise floor, occasional
step adjustments, leap seconds. None of those matter for the
agreement / election-safety properties we exercise.

## Alternatives considered

* No skew model. The protocol code looks fine; bugs surface only
  in production.
* Full clock-drift model (offset, drift, noise, step events). More
  realistic but harder to tune for tests. Tests want to step over
  a discontinuity precisely; the simple model lets them.
