# ADR 0010: Streaming invariant checkers

Status: accepted, 2026-03-22

## Context

Invariant checks fall into two shapes:

* Streaming: O(1) memory per checker, see one event, update state,
  optionally record a witness.
* Whole-trace: load the full event list, do batch analysis, emit
  witnesses.

The whole-trace shape is more flexible but doesn't scale - the
linearizability checker on a 1M-event trace would consume a lot
of memory.

## Decision

Every checker implements a streaming interface: `observe(event)`
on each event, `finalize()` at the end. State is the checker's own
concern. Witnesses are recorded as they're observed.

The base class `InvariantChecker` provides the witness machinery
and the violation counter.

## Consequences

The linearizability checker is the most complex - it has to keep
per-key write-set indexes. We accept the memory cost in exchange
for the streaming API; whole-trace alternatives weren't significantly
simpler.

The streaming shape lets the CLI's `verify` command interleave
checking with reading - we don't have to materialize the whole
event list.

## Alternatives considered

* Whole-trace API only. Simpler to implement, doesn't scale.
* A hybrid: streaming for most, batch for linearizability. Two
  APIs to maintain. Not worth it.
