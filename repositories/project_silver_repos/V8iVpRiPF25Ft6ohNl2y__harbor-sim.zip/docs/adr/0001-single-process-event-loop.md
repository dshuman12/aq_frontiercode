# ADR 0001: Single-process event loop

Status: accepted, 2025-12-04

## Context

Distributed-system simulators come in two shapes. One uses real
threads (or async tasks) to model real concurrency; bugs that
emerge are real concurrency bugs. The other uses a single-threaded
discrete-event scheduler; non-determinism comes from a seeded RNG
and replay is byte-identical.

Both have a place. Real-thread simulators are explicit about race
conditions; you don't have to enumerate every possible interleaving
because the OS does it for you. Discrete-event simulators are honest
about reproducibility; you get the same bug twice and you can bisect
across days of trace.

The deciding question is which bugs are worth catching.

## Decision

A single-process discrete-event scheduler with a logical clock.
One event fires at a time. The clock advances only when an event
is dequeued. Nothing in the codebase reads the wall clock.

## Consequences

Reproducibility is the headline. A trace plus a seed plus a
scenario file completely determines the run. Bisecting across
months of accumulated test failures works; replaying any of them
works; inspecting the state at any tick works.

The cost: race conditions that emerge from real preemption don't
show up here. The protocols themselves are single-threaded, so this
is fine, but harbor-sim can't validate a real-world server's
locking. That's not the goal.

## Alternatives considered

* trio/asyncio with deterministic clock. Workable but the event
  ordering is implicit in the framework's scheduler. Overriding it
  is more work than the abstraction is worth.
* gevent. Same problem with extra OS plumbing.
* A Jepsen-style integration test against real binaries. Different
  tool; this one doesn't replace it, and isn't trying to.
