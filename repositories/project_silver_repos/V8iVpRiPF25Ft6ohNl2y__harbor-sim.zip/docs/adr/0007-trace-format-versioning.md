# ADR 0007: Trace format versioning

Status: accepted, 2026-03-10

## Context

The v1 trace format was newline-delimited JSON inside zstd. It
worked but had three painful properties: partial reads were hard
to recover from, integrity was per-line (no per-frame CRC), and
the schema for witness records grew haphazardly.

v2 was always going to happen. The interesting question is what
the migration story looks like.

## Decision

The trace reader accepts both v1 and v2. The writer always emits
v2. A dedicated `harbor-sim trace migrate <src> <dst>` command
converts v1 to v2 on demand. v1 traces are read-only.

The rule for future format bumps:

1. Add a new frame version to `harbor_sim/trace/format.py`.
2. Update the writer to emit it.
3. Update the reader to accept it AND the previous version.
4. Update `harbor_sim/trace/migrate.py` to convert old to new.
5. Regenerate the conformance hashes.
6. Commit a migration test.

Steps 4 and 6 catch half the format-change bugs. Skipping them
because the bump feels trivial has cost me an evening more than
once.

## Consequences

Two readers in the codebase, one writer. The maintenance cost is
in the reader's switch on version - small.

The conformance suite freezes the byte representation of v2
traces for a set of canonical scenarios. A v3 bump regenerates
these.

## Alternatives considered

* No backwards compat. Toss the v1 traces. Painful for anyone
  with stored traces.
* Run-time bridge: hold v1 traces in their original format and
  apply a translation layer at read. That's what the current
  reader does for the small overlap, but a v3 bump would create
  N-1 bridges. The migration tool keeps the bridge count at one.
