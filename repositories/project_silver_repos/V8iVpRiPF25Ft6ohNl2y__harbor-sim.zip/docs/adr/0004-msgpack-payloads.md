# ADR 0004: msgpack inside frames

Status: accepted, 2026-01-09

## Context

The trace's framed format needs a payload codec. Options on the
table:

* JSON. Ubiquitous. Slow at scale. Doesn't preserve int vs. float
  cleanly.
* msgpack. Small, fast, lossless for the int range we use.
* CBOR. Functionally equivalent to msgpack for our usage. Slightly
  less widely supported in Python tooling.
* Custom binary. Pointlessly bespoke.

## Decision

msgpack inside each frame's payload. The outer frame still has its
own header (magic, version, type, length, CRC); the payload is
opaque msgpack bytes.

## Consequences

Read performance is excellent. Write performance is excellent.
The trace files are roughly 40% the size of the equivalent JSONL,
even before zstd. Combined with zstd, traces are ~10% the size of
the v1 newline-delimited JSON.

The cost: a typo in a hand-rolled trace is harder to debug than
in JSON. We rarely hand-write traces; the cost is small.

## Alternatives considered

See above. Also considered protobuf - rejected because the schema
boilerplate per frame type is more than the benefit for our two
real frame shapes (event, witness).
