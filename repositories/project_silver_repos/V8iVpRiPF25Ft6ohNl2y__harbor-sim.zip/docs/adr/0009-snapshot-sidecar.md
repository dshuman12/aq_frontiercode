# ADR 0009: Snapshot compaction sidecar

Status: accepted, 2026-02-18

## Context

A snapshot file contains the protocol state plus the compaction
record (last_included_index, last_included_term, compacted_count).
The compaction record is small; the state can be large.

The scenario loader, when it sees `initial_snapshot_id` on a node,
needs to read both to materialize the node correctly. The state
needs to be unpacked and handed to the protocol; the compaction
record needs to be applied to the log so the protocol's
`first_index` and `last_included_term` are right.

If only one of those happens, the protocol can replay the
snapshotted prefix from the log it loads on top, producing
duplicate applies that surface in linearizability witnesses much
later.

## Decision

Write the compaction record both inside the snapshot blob and as a
standalone sidecar file. Layout:

```
<root>/<node>/<snap_id>.snap       <- state + compaction
<root>/<node>/<snap_id>.compaction <- just the compaction record
```

The sidecar is recoverable from the main blob, but its existence
lets the scenario loader read it without unpacking the full state.

## Consequences

Two writes per snapshot save. Two reads per scenario start, when
an initial snapshot is configured. The cost is negligible -
compaction records are well under 1KB.

The benefit: the loader can fail fast if the compaction record is
corrupt or missing, before paying the cost of unpacking the
state.

## Alternatives considered

* Embed-only. Faster writes, but the loader has to unpack the
  full state to read the prefix.
* Sidecar-only. Faster reads, but the snapshot file is no longer
  self-describing.

Embed + sidecar is the only option that keeps both properties.
