# ADR 0015: Distributed fuzzer (WIP)

Status: draft, on hold

## Context

The in-tree fuzzer under `tools/fuzz/` is deterministic - same
seed, same scenario set, same failure modes triggered. It runs
on a single machine in a single process.

A real Jepsen-style harness would run many scenarios in parallel
across machines, share a corpus of failing seeds, and dedupe
witnesses. Not close to that.

## Decision

Not yet decided. Picking up later.

The skeleton question I keep getting stuck on: a distinct binary
that drives harbor-sim as a library, or a CLI subcommand that
knows how to shard? Both work. The binary is more honest about
the separation; the subcommand is more discoverable.

Probably the binary. Then the fuzzer can carry its own
configuration without complicating the simulator's CLI. But the
subcommand keeps the "one tool" mental model for users.

(picking up later)

## Open questions

* Corpus format. Could reuse traces. Could use a smaller "seed
  catalog" with only the (scenario_hash, seed, witness) tuples.
* Coverage signal. The current cover command lists observed
  failure modes; the fuzzer would want a way to score new seeds
  by whether they exercised an unobserved combination.
* Storage. Traces are small enough that storing every failing
  seed's trace is fine for a small corpus, painful at scale.

## Consequences

Until this lands, the fuzzer stays single-process. Plenty of bugs
have surfaced that way; the distributed shape is for when bugs
stop being easy to find.

## Alternatives considered

Many. None compelling enough to write up yet.
