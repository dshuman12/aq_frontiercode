# ADR template

Status: template

## Context

What problem motivated this decision?

## Decision

What did we end up doing? In one sentence or three short paragraphs.

## Consequences

What does this make easier, harder, or impossible?

## Alternatives considered

What did we reject and why?
