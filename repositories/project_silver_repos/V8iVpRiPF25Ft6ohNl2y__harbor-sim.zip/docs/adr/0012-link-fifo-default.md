# ADR 0012: FIFO links by default

Status: accepted, 2026-04-03

## Context

The transport's per-link latency model samples uniformly within
a range. With a wide range, two messages on the same link can
swap - the second draws a lower latency than the first.

Real networks are mostly FIFO at the transport layer. Reordering
happens at the application layer (parallel connections, retries)
not within a single TCP socket. The simulator's default should
reflect that.

## Decision

`LinkConfig.reorder` defaults to `False`. Sends on the same link
are clamped to monotonic delivery times. Scenarios that want
reordering set `reorder: true` explicitly.

## Consequences

Most scenarios get realistic FIFO behavior for free. The handful
of scenarios that want to fuzz reordering set the flag.

There's a subtle cost: the clamping pushes a late-arriving message
forward in time, which means the link's effective latency depends
on the recent send rate. Tests that count per-link drops have to
account for the clamp.

## Alternatives considered

* Reorder on by default. Catches more bugs in protocols but
  produces unrealistic traces; the agreement invariant has to
  tolerate ordering changes that wouldn't happen in production.
* Per-link choice with no default. Forces scenario authors to
  pick. Annoying for the common case.
