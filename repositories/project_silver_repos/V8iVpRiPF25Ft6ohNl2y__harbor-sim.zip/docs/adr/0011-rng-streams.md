# ADR 0011: Per-subsystem RNG streams

Status: proposed, on hold

## Context

The simulator's determinism guarantee says that the same scenario,
the same seed, produces the same trace. That holds today for full
runs. It does NOT hold for cutoff replays.

The problem: the scheduler, the transport, and protocol-internal
jitter all draw from streams in the bundle. The bundle's stream
API isolates them at the seed level - different streams have
different derived seeds - but the *draw count* on the
`scheduler` stream in a full run differs from its draw count at
the same logical time in a cutoff replay, because the full run
schedules events that the cutoff doesn't see.

The result: a cutoff replay leaves the scheduler stream at a
different state than the full-run replay at the same tick. Any
subsequent draw diverges.

## Decision (proposed)

Fork the bundle once per subsystem at startup, and serialize each
subsystem's draw count into the trace at snapshot boundaries.
Replay seeds the per-subsystem streams from the recorded counts.

The fork primitive already exists in `harbor_sim/rng.py`. The wiring
work is in three places:

1. The simulator passes a forked bundle to each subsystem at
   construction time.
2. The scheduler and transport take their own bundle, not the
   global one.
3. The trace recorder serializes the per-stream draw counts on
   every snapshot frame.

## Consequences

Cutoff replay becomes byte-deterministic across boundaries. The
trace gets slightly larger - a few hundred bytes per snapshot
frame for the recorded counts.

Open question: how granular are streams? Per-subsystem (scheduler,
transport, workload) is the obvious split. Per-node-per-protocol
might be necessary if a single subsystem proves too coarse. I
don't know yet.

## Alternatives considered

* Save the full RNG state at snapshot boundaries. Works, but the
  Random state format has shifted between Python releases - we'd
  be promising that traces are portable across Python versions,
  which we currently can be. Not worth losing.
* Make the cutoff replay re-draw to the boundary from scratch.
  Defeats the cutoff's purpose.
