# ADR 0002: NewType IDs

Status: accepted, 2025-12-08

## Context

Many strings and ints across the codebase share types but not
meaning. A NodeId is a string; so is a key in the KV store. An
EventId is an int; so is a LogIndex; so is a Term. Confusing them
costs hours, and mypy's bare `str` and `int` say nothing about
which.

## Decision

Every domain identifier gets a `NewType` alias. They're erased at
runtime (no per-instance overhead) but distinct in the type
checker.

## Consequences

mypy catches "passed a NodeId where a LinkId was expected" at
parse time. There's no runtime overhead. The cost is some boilerplate
at construction time (`NodeId("n1")` rather than just `"n1"`).

A handful of test files have to construct these explicitly. The
ergonomic loss is real but mild.

## Alternatives considered

* Frozen dataclasses for IDs. Heavier, more allocations, and the
  ergonomics are worse - you can't put a dataclass in an msgpack
  payload without a converter.
* No types. We started here. Made debugging painful.
