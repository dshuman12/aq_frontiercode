# ADR 0005: PYTHONPATH instead of `pip install -e .`

Status: accepted, 2026-01-15

## Context

The Dockerfile that builds the project for CI and for downstream
test harnesses needs the package importable. The natural reach is
`pip install -e .`. There's a problem - some downstream harnesses
parse the Dockerfile statically and reject editable installs.

## Decision

The Dockerfile copies the project to `/app` and sets `ENV PYTHONPATH=/app`.
No editable install, no setuptools at runtime. `pip install -r requirements.txt`
handles the third-party deps.

## Consequences

Runtime imports work. The CLI script registered in `pyproject.toml`
isn't on PATH without an install, but the entrypoint lives at
`harbor_sim.cli.main` and can be invoked as `python -m harbor_sim`
- which is what the harness does.

For local development, `pip install -e .` still works fine; it's
just not what the Docker image does.

## Alternatives considered

* `pip install --no-deps -e .`. Still flagged by the harness.
* Build a wheel and install it. More moving parts, same result.
* Skip the Dockerfile and run tests on the host. Defeats the
  purpose of having a reproducible image.
