# ADR 0014: CLI subcommand shape

Status: accepted, 2026-04-12

## Context

The CLI surface is six core commands (run, replay, verify, diff,
inspect, cover) plus a small subgroup for trace utilities. The
choice is between flat (`harbor-sim trace-migrate`) and grouped
(`harbor-sim trace migrate`).

## Decision

Flat for the core commands. Grouped for trace utilities under
`harbor-sim trace`. The current single trace subcommand is
`migrate`, but we expect to add `dump`, `verify`, and `compact`
later, and the group keeps the namespace clean.

## Consequences

Help text reads naturally. Tab completion works without
contortion. The cost is one extra layer of Click decorators in
the trace subcommand file.

## Alternatives considered

* Fully flat. Fine currently, gets messy after 8+ commands.
* Fully grouped. Forces a top-level group choice for everything,
  which is annoying for the common `run` and `replay` cases.
