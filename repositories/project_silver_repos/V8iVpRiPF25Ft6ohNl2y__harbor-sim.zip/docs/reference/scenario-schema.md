# Scenario schema

A scenario file is a YAML document with the following top-level
keys. Required keys are marked *required*; the rest have defaults.

## Top level

| Key | Type | Default | Notes |
|---|---|---|---|
| `scenario` | str | `"anonymous"` | Human-readable name. |
| `seed` | int | 0 | Non-negative. Drives every RNG stream. |
| `horizon_ms` | int | 60000 | Must be > 0. |
| `protocol` | str | `"raftlite"` | Must be registered. |
| `nodes` | list | *required* | At least one entry. |
| `links` | list | `[]` | Each entry connects two nodes. |
| `failures` | list | `[]` | Scheduled fault injections. |
| `workload` | dict | `{kind: noop}` | Client-side traffic generator. |
| `protocol_options` | dict | `{}` | Passed to the protocol factory. |

## Nodes

| Key | Type | Default | Notes |
|---|---|---|---|
| `id` | str | *required* | Alphanumeric/-_./, non-empty, unique. |
| `role` | str | `"replica"` | Hint for protocol-specific roles. |
| `clock_skew_ms` | int | 0 | Positive or negative. |
| `clock_drift_ppm` | int | 0 | Parts per million. |
| `initial_snapshot_id` | int|null | null | Load this snapshot on boot. |

## Links

Each link is one-directional unless `bidirectional: true`.

| Key | Type | Default | Notes |
|---|---|---|---|
| `from` | str | *required* | Must reference a declared node. |
| `to` | str | *required* | Must reference a declared node. |
| `latency_ms` | int or [low, high] | `[5, 20]` | |
| `drop_rate` | float | 0.0 | In [0, 1]. |
| `reorder` | bool | false | Disable FIFO. |
| `capacity` | int|null | null | Max in-flight messages. |
| `bidirectional` | bool | true | Add the reverse link too. |

## Failures

| `kind` | required extra keys |
|---|---|
| `partition` | `a`, `b`, optional `duration_ms` |
| `crash` | `target` |
| `recover` | `target` |

| Key | Type | Default | Notes |
|---|---|---|---|
| `at_ms` | int | *required* | Must be non-negative. |
| `kind` | str | *required* | One of the above. |
| `target` | str | "" | Node id, for crash/recover. |
| `a`, `b` | str | "" | For partition. |
| `duration_ms` | int|null | null | If set, partition reverses after. |
| `on` | bool | true | Used for explicit unpartition. |

## Workload

| Key | Type | Default | Notes |
|---|---|---|---|
| `kind` | str | `"noop"` | `"kv"`, `"leader_propose"`, `"noop"`. |
| `clients` | int | 0 | Number of client actors. |
| `ops_per_client` | int | 0 | |
| `keys` | list[str] | `[]` | If empty, generated. |
| `value_size_bytes` | int | 16 | |
