# harbor-sim

A small deterministic simulator for replicated state machines. You
describe a cluster, a workload, and a set of failure injections in a
YAML scenario file; harbor-sim runs the cluster under a logical clock,
emits a structured trace, and checks the trace against your invariants.

This is a personal project. It started as a way to convince myself that
a Raft implementation I was reading was actually correct under network
partitions, and it grew once I realized the discrete-event scheduler
underneath was useful on its own.

## What it is not

This is not a real distributed system. No sockets, no threads, no
async - one process, one event loop, time advances in discrete ticks.

It is also not Jepsen. Jepsen drives real binaries through real
failure injection. harbor-sim drives Python implementations through
a fake network.

And it's not a test framework. It writes traces; you write the
asserts.

## Install

```
pip install -r requirements.txt
export PYTHONPATH=$PWD
harbor-sim --help
```

Python 3.11+ only. The wheel publishes nothing right now; the package
is consumed via `PYTHONPATH` because the in-tree CLI is what matters.

## A 60-second tour

Drop a YAML scenario in `examples/`:

```yaml
scenario: leader-election-under-partition
seed: 42
horizon_ms: 60000
nodes:
  - { id: n1, role: replica, clock_skew_ms: 0 }
  - { id: n2, role: replica, clock_skew_ms: 50 }
  - { id: n3, role: replica, clock_skew_ms: -25 }
links:
  - { from: n1, to: n2, latency_ms: [5, 20] }
  - { from: n2, to: n3, latency_ms: [5, 20] }
  - { from: n1, to: n3, latency_ms: [5, 20] }
protocol: raftlite
workload:
  kind: kv
  clients: 2
  ops_per_client: 200
failures:
  - { at_ms: 5000, kind: partition, between: [n1, [n2, n3]], duration_ms: 8000 }
```

Then:

```
harbor-sim run examples/leader-election-under-partition.yaml \
    --trace out/trace.jsonl.zst
harbor-sim verify out/trace.jsonl.zst --invariant agreement
harbor-sim replay out/trace.jsonl.zst --until 10000ms
```

The trace is line-oriented JSONL inside zstd. You can read it with
`zstd -d | head`; the format is documented under `docs/reference/trace-format.md`.

## Architecture

The pieces that matter (in rough dependency order):

- `harbor_sim/clock.py` and `harbor_sim/rng.py` - logical time and
  seeded RNG streams.
- `harbor_sim/scheduler.py` - the discrete-event priority queue.
- `harbor_sim/transport.py` - the in-memory network. Latency, drop,
  reorder, partition.
- `harbor_sim/runtime/` - the per-node mailbox + per-replica state.
- `harbor_sim/protocols/raftlite/` - leader election and log
  replication.
- `harbor_sim/protocols/quorum_kv/` - quorum-replicated key-value
  store.
- `harbor_sim/storage/` - durable log and snapshot store.
- `harbor_sim/trace/` - writer, reader, frame format.
- `harbor_sim/invariants/` - safety + liveness checkers.
- `harbor_sim/scenario/` - YAML loader, validator, expander.
- `harbor_sim/cli/` - the command surface.

`docs/architecture.md` is the long-form version of this with the
rationale behind each split.

## Determinism

Every scheduler decision draws from a seeded RNG. Every "wall-clock"
value comes from the logical clock. The same scenario+seed produces a
byte-identical trace across machines, Python versions, and ID-allocator
orderings. This is the only non-negotiable property of the simulator -
if a change breaks it, the change is wrong.

Determinism is enforced by the conformance suite under
`tests/conformance/`, which hashes trace bytes from a fixed set of
scenarios and checks the hashes match.

## Status

The simulator works on the scenarios in `examples/`. Raft-lite passes
its agreement and election-safety invariants under partition and crash
injection. The quorum-KV protocol passes linearizability checks for
read/write workloads at quorum size 2 of 3 and 3 of 5; larger
configurations are slower than they should be and there's an open
issue under TODO.md about the scratch-buffer reuse in the apply loop.

Two sharp edges to know about:

- Trace format v1 (legacy) is read-only. Writers always emit v2. The
  migration helper lives at `harbor_sim/trace/migrate.py`. If you have
  v1 traces from before the 0.2 release, run `harbor-sim trace migrate`
  before any other command.
- The replay engine respects `--until` but the implementation currently
  doesn't split the RNG into per-subsystem streams, so a truncated
  replay can diverge from a full replay in the scheduler. There's an
  ADR proposing the fix.

## License

MIT. See `LICENSE`.
