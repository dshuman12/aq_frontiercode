"""Scenario mutation."""
from __future__ import annotations

import random
from copy import deepcopy
from typing import Iterator

from harbor_sim.scenario.model import (
    FailureSpec,
    LinkSpec,
    NodeSpec,
    Scenario,
    WorkloadSpec,
)


def generate(seed: int, protocol: str = "raftlite") -> Iterator[Scenario]:
    """Generate an infinite sequence of scenarios from a single seed.

    The first scenario is a small balanced 3-node cluster; subsequent
    scenarios are progressively more pathological - more clock skew,
    more partition activity, wider latency ranges.
    """
    rng = random.Random(seed)
    base = _balanced_3node(seed, protocol)
    yield base
    while True:
        yield mutate_scenario(base, rng)


def mutate_scenario(base: Scenario, rng: random.Random) -> Scenario:
    sc = deepcopy(base)
    mutators = [
        _add_skew,
        _widen_latency,
        _add_partition,
        _add_crash_recover,
        _flip_reorder,
    ]
    chosen = rng.sample(mutators, k=rng.randint(1, len(mutators)))
    for fn in chosen:
        fn(sc, rng)
    return sc


def _balanced_3node(seed: int, protocol: str) -> Scenario:
    nodes = [NodeSpec(id=f"n{i + 1}", role="replica") for i in range(3)]
    links: list[LinkSpec] = []
    for a in nodes:
        for b in nodes:
            if a.id != b.id:
                links.append(
                    LinkSpec(
                        src=a.id, dst=b.id,
                        latency_low_ms=5, latency_high_ms=20,
                        bidirectional=False,
                    )
                )
    return Scenario(
        name="fuzz-base",
        seed=seed,
        horizon_ms=30_000,
        protocol=protocol,
        nodes=nodes,
        links=links,
        failures=[],
        workload=WorkloadSpec(kind="noop"),
    )


def _add_skew(sc: Scenario, rng: random.Random) -> None:
    target = rng.choice(sc.nodes)
    target.clock_skew_ms = rng.randint(-200, 200)


def _widen_latency(sc: Scenario, rng: random.Random) -> None:
    target = rng.choice(sc.links)
    target.latency_high_ms = max(
        target.latency_high_ms, target.latency_low_ms + rng.randint(10, 100)
    )


def _add_partition(sc: Scenario, rng: random.Random) -> None:
    if len(sc.nodes) < 2:
        return
    a, b = rng.sample(sc.nodes, 2)
    sc.failures.append(FailureSpec(
        at_ms=rng.randint(500, 20_000),
        kind="partition",
        a=a.id, b=b.id,
        duration_ms=rng.randint(1_000, 5_000),
    ))


def _add_crash_recover(sc: Scenario, rng: random.Random) -> None:
    target = rng.choice(sc.nodes)
    at = rng.randint(500, 15_000)
    sc.failures.append(FailureSpec(at_ms=at, kind="crash", target=target.id))
    sc.failures.append(FailureSpec(
        at_ms=at + rng.randint(1_000, 5_000),
        kind="recover", target=target.id,
    ))


def _flip_reorder(sc: Scenario, rng: random.Random) -> None:
    target = rng.choice(sc.links)
    target.reorder = not target.reorder
