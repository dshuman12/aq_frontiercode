"""Drive scenarios and report invariant violations."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from harbor_sim.invariants import all_checkers
from harbor_sim.scenario.materialize import materialize
from harbor_sim.scenario.model import Scenario
from harbor_sim.trace.format import EventFrame


@dataclass
class FuzzResult:
    scenario_name: str
    seed: int
    events: int
    violations_by_invariant: dict[str, int] = field(default_factory=dict)

    def passed(self) -> bool:
        return all(v == 0 for v in self.violations_by_invariant.values())


def run_fuzz(scenario: Scenario, workdir: Path) -> FuzzResult:
    sim = materialize(scenario, workdir=workdir)
    sim.boot_all()

    checkers = [cls() for cls in all_checkers().values()]

    def hook(ev) -> None:
        ef = EventFrame(
            event_id=int(ev.id),
            fire_at_ms=ev.fire_at_ms,
            kind=ev.kind,
            target=ev.target,
            payload=ev.payload,
        )
        for c in checkers:
            c.observe(ef)

    sim.scheduler.install_hook(hook)
    n = sim.run(horizon_ms=scenario.horizon_ms)
    for c in checkers:
        c.finalize()

    return FuzzResult(
        scenario_name=scenario.name,
        seed=scenario.seed,
        events=n,
        violations_by_invariant={c.name: c.violation_count() for c in checkers},
    )
