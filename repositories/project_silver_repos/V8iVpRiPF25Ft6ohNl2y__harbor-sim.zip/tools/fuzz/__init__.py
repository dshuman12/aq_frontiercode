"""A deterministic scenario fuzzer.

Generates scenarios from a seed corpus, runs them, and reports any
invariant violations. Single-process; the distributed shape is on
hold (ADR-0015).

The interesting bit is :func:`mutate_scenario` - given a base
scenario, it produces a sequence of mutations that are likely to
expose bugs in the protocol implementations. Some are obvious
(toggle the partition between any two nodes, add clock skew),
others less so (re-order failures, increase the latency range
to widen the reorder window).
"""
from tools.fuzz.generator import generate, mutate_scenario  # noqa: F401
from tools.fuzz.runner import run_fuzz  # noqa: F401
