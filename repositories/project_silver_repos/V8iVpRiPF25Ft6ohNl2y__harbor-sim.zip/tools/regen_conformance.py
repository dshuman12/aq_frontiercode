"""Regenerate the conformance hashes.

The conformance suite freezes byte-level trace hashes for a curated
set of scenarios. When a planned format bump or determinism change
lands, this script regenerates the hashes. The regenerated file is
written atomically so a crash mid-write doesn't leave a half-updated
manifest.

Run with --confirm to actually write; the default is dry-run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
from pathlib import Path

from harbor_sim.hashing import stable_hash
from harbor_sim.scenario.loader import load
from harbor_sim.scenario.materialize import materialize
from harbor_sim.trace.format import LATEST, TraceHeader
from harbor_sim.trace.recorder import TraceRecorder


REPO = Path(__file__).parent.parent
CONFORMANCE = REPO / "tests" / "conformance" / "manifest.json"
EXAMPLES = REPO / "examples"


def hash_trace(path: Path) -> str:
    return hashlib.blake2b(path.read_bytes(), digest_size=16).hexdigest()


def regenerate(confirm: bool) -> int:
    entries = []
    with tempfile.TemporaryDirectory() as tmpdir:
        td = Path(tmpdir)
        for scenario_file in sorted(EXAMPLES.glob("*.yaml")):
            sc = load(scenario_file)
            sim = materialize(sc, workdir=td / sc.name)
            sim.boot_all()
            trace_path = td / f"{sc.name}.trace"
            rec = TraceRecorder(path=trace_path)
            rec.open(TraceHeader(
                version=LATEST,
                run_id=int(stable_hash(sc) & 0x7FFF_FFFF),
                scenario_hash=int(stable_hash(sc)),
                seed=sc.seed,
                started_at_ms=0,
            ))
            sim.scheduler.install_hook(rec.record)
            sim.run(horizon_ms=min(sc.horizon_ms, 5_000))
            rec.close()
            entries.append({
                "scenario": scenario_file.name,
                "scenario_hash": hex(int(stable_hash(sc))),
                "trace_hash": hash_trace(trace_path),
            })

    manifest = {"version": LATEST, "entries": entries}
    if not confirm:
        print(json.dumps(manifest, indent=2))
        return 0

    CONFORMANCE.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFORMANCE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(manifest, indent=2) + "\n")
    tmp.replace(CONFORMANCE)
    print(f"wrote {CONFORMANCE} ({len(entries)} entries)")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--confirm", action="store_true")
    args = parser.parse_args()
    return regenerate(confirm=args.confirm)


if __name__ == "__main__":
    sys.exit(main())
