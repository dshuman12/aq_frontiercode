---
name: Feature request
about: Something you wish harbor-sim could do.
---

## What problem does this solve?

Be concrete. "It would be nice to have X" is harder to act on than
"I wanted to do Y and ended up writing Z, which is annoying because W."

## Sketch of the surface

If you have a sense of what the API or CLI should look like, paste it
here. Pseudo-code is fine.

## Workarounds you've tried
