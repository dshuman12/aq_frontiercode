---
name: Bug report
about: Something behaves differently than you expected.
---

## What I expected

## What actually happened

## Minimal reproducer

A scenario file plus seed, ideally. Or a shell transcript.

## Version

`harbor-sim --version` output.
