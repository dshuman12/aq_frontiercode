## What

A one-paragraph summary of what this changes.

## Why

Link an issue, or describe the problem in 2-3 sentences.

## Notes for the reviewer

Anything subtle. Anything that should be tested but isn't.
Anything I'd like a second opinion on.

## Checklist

- [ ] Tests pass: `pytest`
- [ ] Lint passes: `ruff check`
- [ ] If the trace format changed, ADR-0007 was followed
- [ ] CHANGELOG updated if user-visible
