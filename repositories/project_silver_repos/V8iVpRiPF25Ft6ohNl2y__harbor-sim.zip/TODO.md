# TODO

Grab-bag. Stuff I want to fix or look into when I get a spare evening.
The order is roughly priority but mostly aspirational.

- The replay engine's `--until T` mode advances the scheduler's RNG
  past T even when we stopped early. So two replays of the same trace
  with different `--until` values produce divergent RNG state and the
  scheduler picks different events. Fix is to fork the RNG into per-
  subsystem streams (scheduler, transport, workload) so the per-stream
  draw count is bounded by what each stream consumed. Touches `rng.py`,
  `replay/engine.py`, the recorder so streams are serialized into the
  trace, and the verify CLI.

- `quorum_kv/policy.py` doesn't enforce a staleness floor on read
  quorums. A read can complete against a quorum that doesn't overlap
  the latest write quorum, returning a stale value. There's a config
  field for it (`staleness_floor`) which is silently ignored. The fix
  needs to thread the floor through the policy, the replica, and the
  linearizability checker so it can witness the violation.

- Trace migrate is one-shot (v1 -> v2). When v3 lands I'd want a
  generic stepped migration: register every (from, to) pair and let
  the CLI chain them.

- DXF...wait, wrong project. Scratch that.

- `clock.py` skew handling has a subtle bug where the lease-renewal
  path in raft-lite consults the local clock instead of the skewed
  clock. Negative skew makes a leader hold its lease past expiry; the
  invariant checker doesn't catch it because the witness frame uses
  the skewed time. Tests cover only zero-skew so it has stayed hidden.
  Fix is to consult the skewed clock everywhere a deadline is checked.

- Snapshot compaction record (`storage/snapshot.py`) is dropped on
  scenario reload. When a node crashes and the simulator restarts it
  from a snapshot, the log compaction record is silently lost, which
  means the post-snapshot log entries get replayed from index 0 and
  the apply path duplicates them. The symptom shows up in the
  invariant checker as a duplicate-apply.

- Levenberg-Marquardt scratch buffer reuse - oh wait, also wrong
  project. Looked at chassis too long this morning.

- Inspector's `--filter` syntax should support OR. Right now it only
  ANDs across keys.

- Conformance hashes regen flow is too manual. `tools/regen_conformance.py`
  exists but doesn't atomically write; if it crashes halfway through
  you end up with a half-updated hashes.json.

- I keep meaning to write a docs page on the difference between the
  scheduler's "logical tick" and the clock's "logical ms". They are
  not the same thing and the codebase isn't always clear about which
  is which.

- `cli/cover.py` is half a feature. The plan was to compute trace
  coverage against a scenario's failure-mode set. The framework is
  there but it doesn't actually score - it just lists the failure modes
  it observed. Picking up later.
