# Contributing

This is a personal project. There isn't a contribution process in the
formal sense - if you want to send a patch or open an issue, please do,
but I don't have a roadmap to align against and I make no promises
about turnaround.

What follows is more of a working-with-the-codebase guide than a
contribution policy. If you have to dig into a subsystem, this should
shorten the time it takes to figure out what's safe to change.

## Running the suite

```
pip install -r requirements.txt
export PYTHONPATH=$PWD
pytest
```

That should be enough. The full suite runs in about 90 seconds on a
laptop; the slowest tests are in `tests/conformance/` and you can skip
them with `pytest -m 'not slow'` while iterating.

If you need a faster inner loop:

```
pytest tests/unit -x -q
```

`-x` bails on the first failure. `-q` cuts the noise. Add `-n auto` if
you have pytest-xdist installed (it's in `requirements.txt`).

## What the layout means

The top-level layout is:

```
harbor_sim/         the library
tests/              unit + integration + conformance
examples/           example scenarios (consumed by tests too)
docs/               architecture, runbooks, ADRs, reference docs
tools/              one-off scripts (fuzzer, trace inspector)
scripts/            CI-side helpers
```

Inside `harbor_sim/`, the dependency order is roughly:

1. errors, ids
2. clock, rng, codec
3. fsutil, hashing, logging
4. scheduler, transport
5. storage, snapshot
6. runtime (mailbox, node, replica)
7. protocols (raftlite, quorum_kv)
8. trace (recorder, reader, migrate)
9. invariants
10. scenario (model, loader, validator, expand)
11. replay
12. cli

If your change crosses more than two layers, that's usually a sign that
either the abstraction is wrong or you're combining two changes. Split
them.

## Determinism is the only non-negotiable

The conformance suite freezes trace bytes for a curated set of
scenarios. If your change moves any of those hashes, the change is
wrong, or the change is a deliberate format break and you owe a
migration. There's no third option.

If you need to bump the trace format, follow the recipe in
`docs/adr/0007-trace-format-versioning.md`. Short version:

1. Add a new frame version to `harbor_sim/trace/format.py`.
2. Update the writer to emit it.
3. Update the reader to accept it AND the previous version.
4. Update `harbor_sim/trace/migrate.py` to convert old to new.
5. Regenerate the conformance hashes with `tools/regen_conformance.py`.
6. Commit the migration test along with the format change.

Steps 4 and 6 catch about half the format-change bugs. Skipping them
because the bump feels trivial has cost me an evening more than once.

## Style

- Type hints on every public function. Inside private helpers, optional
  but encouraged.
- Errors raised as the typed exceptions in `harbor_sim/errors.py`. No
  bare `Exception`, no `RuntimeError`.
- One module = one concept. If `mailbox.py` is growing a second concept
  inside it, split before the file passes ~400 lines.
- Tests live under `tests/unit/test_<module>.py`. Cross-module tests
  live under `tests/integration/`. Long-running ones under
  `tests/conformance/`.

I use `ruff format` for layout. `ruff check` for lint. Both run cleanly
on every commit; if they don't, that's the first thing to fix.

## Commit hygiene

Mixed style on purpose. The history is what I'd write on a given
evening - sometimes terse, sometimes verbose, occasionally with a
parenthetical about why the obvious approach didn't work. Don't
normalize.

What I do try to keep consistent:

- One logical change per commit. Reverting a bad commit shouldn't drag
  out half a feature.
- The body explains why, not what. The diff explains what.
- If a commit fixes a bug that had a test, the test belongs in the
  same commit. If it fixes a bug that didn't have a test, the test
  belongs in a follow-up.

## Things I'd accept a patch for happily

- Better invariant checkers. The current set covers agreement,
  election safety, and linearizability for the quorum-KV. A real
  Jepsen-style read-your-writes checker would be welcome.
- Cleaner scenario YAML. The v2 format is OK but the `failures:` block
  reads like it was designed by accretion (it was).
- Performance work on the trace writer. Right now it allocates per
  event; a writer that batches into 4KB frames and amortizes the zstd
  call would help.

## Things I'm cool on

- Adding more protocols. Two is enough to exercise the framework.
  Three is nicer but is its own can of worms.
- Replacing the priority queue with something fancier. `sortedcontainers`
  is fine. The hot path isn't here.
- Removing the YAML scenario format in favor of TOML or JSON. I tried
  TOML on a Friday afternoon and put it back on Monday.

## A note on the fuzzer

`tools/fuzz/` has a deterministic fuzzer that generates scenarios,
runs them, and verifies invariants. It's how most of the corner-case
bugs in the codebase have been found. Run it with `python -m tools.fuzz`
and a seed; it doesn't write to disk unless you pass `--save-on-fail`.

If you're hunting a bug and have no reproducer, that's the place to
start.
