// jest config. runs in band, single worker, alphabetical sequencer.
// determinism: maxWorkers: 1 prevents cross-test races; the setup file
// freezes Date / Math.random / timers and any test that touches them
// throws.

/** @type {import('jest').Config} */
module.exports = {
  testEnvironment: 'node',
  setupFiles: ['<rootDir>/jest.setup.cjs'],
  testMatch: [
    '<rootDir>/core/**/*.spec.ts',
    '<rootDir>/modules/**/*.spec.ts',
    '<rootDir>/tools/**/*.spec.ts',
    '<rootDir>/tests/**/*.spec.ts',
  ],
  transform: {
    '^.+\\.ts$': [
      '@swc/jest',
      {
        jsc: {
          parser: { syntax: 'typescript' },
          target: 'es2022',
          loose: false,
        },
        sourceMaps: true,
      },
    ],
  },
  moduleNameMapper: {
    '^@silt/(.*)$': '<rootDir>/$1/src/index.ts',
  },
  testSequencer: '<rootDir>/scripts/jest-sequencer.cjs',
  maxWorkers: 1,
  cache: false,
  bail: false,
  verbose: false,
};
