# silt

Reverse-mode automatic differentiation in TypeScript. Tape-based,
deterministic, zero runtime dependencies.

## What it does

Given a TypeScript function over `Scalar` and `Tensor` values, silt
records the operations onto a tape during a forward pass and walks the
tape backward to compute gradients. The supported op surface includes
elementary arithmetic, trigonometric and hyperbolic functions,
exponential and logarithmic ops, comparisons (with subgradients),
reductions, broadcasting, matrix multiply, and a handful of activation
functions used in small neural nets.

The intended scope is research and teaching code -- gradient-based
curve fitting, hand-rolled networks under ~10k parameters, pendulum
control, implicit-function differentiation. Not a TensorFlow
replacement.

## Determinism contract

Every test in this repository is deterministic. Same input, same output
bits, every run, every machine. Specifically:

- No `Math.random`, `Date.now`, `new Date()`, `setTimeout`,
  `setImmediate`, or `process.hrtime` in `core/` or `modules/` source.
  An eslint rule and a jest setup shim enforce this; tests that touch
  any of those throw `silt determinism: ...`.
- All reductions go through `core/determinism/orderedReduce` with
  Kahan compensation, so cross-platform sum order is irrelevant for
  bit-equality.
- The PRNG is `core/random/Mulberry32`, seeded explicitly. There is
  no global PRNG; every sampling primitive takes a `Mulberry32`
  argument.
- The CI runs the test suite twice and fails if any byte of stdout
  differs between runs.

## Quick start

```ts
import { tape } from '@silt/core-tape';
import { add, mul } from '@silt/ops-elementary';
import { sin } from '@silt/ops-trig';
import { backward } from '@silt/backward';

const t = tape();
const x = t.leaf(2.0);
const y = t.leaf(3.0);
// f = sin(x*y) + x
const f = add(t, sin(t, mul(t, x, y)), x);

const grads = backward(t, f);
// grads.get(x) -> df/dx
// grads.get(y) -> df/dy
```

The same machinery works for tensor inputs (rank up to ~4) via
`@silt/core-types/tensor` and the broadcasting / matrix op modules.

## Layout

The codebase is a pnpm workspace split into three groups:

- `core/` - foundational layers always imported by everything else:
  types, errors, fp helpers, determinism utilities, the seeded PRNG,
  the tape data structure, and a graph adapter over the tape.
- `modules/` - the actual autodiff: ops (about 50 of them), the
  forward eval engine, the backward walker, gradient-checking, the
  jacobian and hessian utilities, optimizers, and the binary
  serializer.
- `tools/` - REPL, microbenchmark harness, the custom eslint rule
  that enforces the determinism contract.

There is also `examples/` for tutorial-flavored end-to-end usage and
`tests/` for cross-module integration scenarios and the conformance
corpus.

## Why?

I wanted an autodiff library small enough to read in an afternoon,
deterministic enough to use in a paper-replication harness, and
TypeScript-native so the gradient code can sit next to the rest of the
research project without a Python boundary. PyTorch and JAX are great
but the bar for understanding what they do under the hood is high. silt
is the opposite trade: small surface, fully visible internals, no
operator fusion, no GPU, no distributed.

## Building

```
pnpm install --frozen-lockfile
pnpm build
pnpm test
```

`pnpm test:twice` runs the suite twice in series and is what CI uses
to verify the determinism contract.

## Status

Pre-1.0. The op surface and the tape format are stable; serializer
format is at v3 and may bump again before 1.0. See `CHANGELOG.md`.

## License

MIT.
