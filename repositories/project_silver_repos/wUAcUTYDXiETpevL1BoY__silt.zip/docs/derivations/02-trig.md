# Trig and inverse-trig partials

Standard textbook derivatives. Pinned here so reviewers can verify
silt's backward functions against a reference.

## sin / cos / tan

  d/dx sin(x) = cos(x)
  d/dx cos(x) = -sin(x)
  d/dx tan(x) = sec^2(x) = 1 + tan^2(x) = 1 + v^2 where v = tan(x)

The 1 + v^2 form avoids recomputing sec when the forward output is
already on hand. silt's preferred pattern; see ctxFn vs ctx-from-output
discussion in core/tape README.

## asin / acos / atan

  d/dx asin(x) = 1 / sqrt(1 - x^2)    domain: |x| < 1
  d/dx acos(x) = -1 / sqrt(1 - x^2)   domain: |x| < 1
  d/dx atan(x) = 1 / (1 + x^2)        domain: all real x

## atan2(y, x)

The two-argument arctangent. Useful for computing angle from a
vector (y, x) without quadrant ambiguity.

  d/dy atan2(y, x) =  x / (x^2 + y^2)
  d/dx atan2(y, x) = -y / (x^2 + y^2)

The denominator is the squared magnitude of (y, x); for unit vectors
the partials are just (x, -y).

The tricky part of atan2 is that its forward output ranges over
(-pi, pi] across all four quadrants of (y, x). The derivative
expressions above are the same in every quadrant -- the formula
doesn't care which branch atan2 picks, because it's locally
differentiable away from the origin. Reviewers occasionally ask
about quadrant-dependent sign flips in the backward; the answer is
that there aren't any. See `modules/ops-trig/src/atan2.ts` for the
implementation.
