# Matrix op partials

silt's matrix layer composes scalar ops, so the partials below come
from the chain rule applied to the underlying mul + sum tree. There
is no dedicated "matmul backward" -- the forward graph is enough,
and the existing scalar ops handle backward.

## matmul

For C = A @ B with shapes (m x k) and (k x n) -> (m x n):

  C_ij = sum_l A_il * B_lj

Partials:

  dC_ij / dA_il = B_lj
  dC_ij / dB_lj = A_il

For the gradient flowing back through C:

  dL/dA = (dL/dC) @ B^T
  dL/dB = A^T @ (dL/dC)

This is standard. Verify by writing C as a sum-of-products tree and
applying the chain rule scalar by scalar.

## transpose

A pure rearrangement. No floating-point work. The "gradient through
transpose" is itself a transpose of the upstream gradient, which is
what you'd expect.

## trace, diag

  trace(A) = sum_i A_ii
  d trace(A) / d A_ii = 1, d trace(A) / d A_ij = 0 for i != j

So the gradient of trace flows only into the diagonal entries.

  diag is a no-op selector at the matrix-of-NodeIds level.

## det

  det(A) for n x n A is the signed sum of n! permutation products
  (by Laplace expansion). Differentiation of each product gives
  (n-1)! products, summing to give the cofactor matrix:

  d det(A) / d A_ij = adj(A)_ji = cofactor(A)_ij

For an invertible A this is also `det(A) * (A^{-1})^T`. silt's
implementation builds the Laplace expansion directly so the
gradient comes from the existing mul/add backward functions;
A^{-1} never enters the backward path.

For numerical robustness on larger matrices LU with pivoting is
preferable, but pivot selection is non-differentiable. Fix is a
TODO; silt's current det is intended for n <= 6.
