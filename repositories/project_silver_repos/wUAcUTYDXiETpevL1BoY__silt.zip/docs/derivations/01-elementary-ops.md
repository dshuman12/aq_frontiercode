# Elementary op partials

Each op file in `modules/ops-elementary/` carries a one-liner derivation
in its header comment. Collected here for reference.

## add(x, y) = x + y

  d/dx = 1, d/dy = 1

## sub(x, y) = x - y

  d/dx = 1, d/dy = -1

## mul(x, y) = x*y

  d/dx = y, d/dy = x  (product rule)

## div(x, y) = x/y

  d/dx = 1/y
  d/dy = -x/y^2  (quotient rule, y != 0)

## neg(x) = -x

  d/dx = -1

## abs(x) = |x|

  d/dx = sign(x); subgradient at 0 chosen as 0 for determinism.

## sign(x) = -1 / 0 / +1

  d/dx = 0 almost everywhere. Subgradient at 0 also chosen as 0.

## min(x, y), max(x, y)

  d/dx = 1 if x is the chosen one, else 0.
  At ties: 0.5 to each.

  Tie handling: any (a, 1-a) split with a in [0, 1] is a valid sub-
  gradient. (0.5, 0.5) is the symmetric choice.
