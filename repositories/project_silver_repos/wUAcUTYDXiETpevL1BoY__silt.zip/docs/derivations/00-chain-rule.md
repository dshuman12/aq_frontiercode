# Reverse-mode AD via the chain rule

The reverse-mode pass implements the chain rule:

For a scalar output `L` that depends on intermediates
`v_1, v_2, ..., v_N`, with each `v_i = f_i(v_{j} : j < i)`, the gradient
of `L` w.r.t. any leaf `x_k` is

  dL/dx_k  =  sum over paths v_k -> ... -> L of  (product of local
  partials along each path)

The naive per-path enumeration is exponential. Reverse-mode collapses
this into a linear-time accumulator:

  bar(v_i) := dL / d(v_i)

with the recurrence

  bar(v_j) = sum over consumers i of v_j of  bar(v_i) * d(v_i)/d(v_j)

walked once from the output back to the leaves.

In silt, the recurrence is implemented in `modules/backward/walker.ts`.
The "for each consumer" iteration is implicit in the tape walk: at
node `i`, the walker reads `bar(v_i)` and distributes `bar(v_i) *
d(v_i)/d(v_j)` to each input `j`. By the time the walker reaches `j`,
all of its consumers have already contributed.

The local partial `d(v_i)/d(v_j)` is what each op's backward function
returns -- one number per input. silt's BackwardFn signature is
exactly:

  (inputs, outGrad, outValue, ctx) => [partial_for_each_input]

so the walker's job is just bookkeeping.

## Why insertion order works as topo order

The tape is append-only: a new node's inputs must already exist on
the tape when it's appended. Therefore, for any two nodes i and j, if
j is in i's input set, then j was appended before i and j.id < i.id.
Walking from highest id to lowest id therefore visits each node
strictly after all its consumers, which is the property the chain
rule needs.

## What about diamond patterns?

If `v_2 = f(v_0)` and `v_3 = g(v_0)` and `v_4 = h(v_2, v_3)`, then v_0
contributes to v_4 along two paths. Both paths' contributions arrive
at v_0 because v_2 and v_3 each accumulate into v_0 as the walker
visits them. This is just summation: `bar(v_0)` accumulates
`bar(v_2) * df/dv_0` from v_2 and then `bar(v_3) * dg/dv_0` from v_3.

## What about constants?

Const nodes have no inputs, so the walker visits them but distributes
no gradient. Their gradient slot in the accumulator stays at zero
(which is correct: there's nothing to differentiate w.r.t.).
