# Reduction partials

## sum

  sum(x_1, ..., x_n) -> partials are all 1.

## mean

  mean = sum / n -> partials are all 1/n.

## prod

  prod = x_1 * x_2 * ... * x_n
  d prod / d x_i = prod / x_i  when x_i != 0

For zero x_i the analytic partial is the product of the other inputs.
silt computes this using prefix and suffix products in O(n), avoiding
divide-by-zero entirely.

## min / max (variadic)

Gradient flows only to the (first) argmin / argmax. Tie-breaking by
input index is deterministic. This makes the backward correct as a
subgradient at smooth points and chooses one of the valid subgradient
options at non-smooth points.

## argmax

argmax is a discrete selector. Gradient is identically zero. Callers
that need to backprop through "select index then look up value" should
use a soft selector (like softmax + dot product) instead.
