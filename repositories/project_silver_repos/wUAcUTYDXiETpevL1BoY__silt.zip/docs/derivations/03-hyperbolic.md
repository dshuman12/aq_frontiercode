# Hyperbolic-trig partials

  d/dx sinh(x) = cosh(x)
  d/dx cosh(x) = sinh(x)
  d/dx tanh(x) = 1 - tanh^2(x) = 1 - v^2

  d/dx asinh(x) = 1 / sqrt(x^2 + 1)
  d/dx acosh(x) = 1 / sqrt(x^2 - 1)   (x >= 1)
  d/dx atanh(x) = 1 / (1 - x^2)        (|x| < 1)

The 1 - v^2 form for tanh's derivative is the dual to tan's 1 + v^2.
Both come from the same Pythagorean-style identity.
