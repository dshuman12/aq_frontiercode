# Architecture

This document is the high-level map of how silt's pieces fit together.
Read it once, then refer back when changing the tape format or the op
registration protocol.

## Layers

silt is structured as four layers, bottom-up:

```
+-------------------------------------------------------+
| tools/      apps + dev tooling (REPL, bench, lint)    |
+-------------------------------------------------------+
| modules/    op zoo + walkers + algorithms             |
|             (forward / backward / gradcheck / ops-*)  |
+-------------------------------------------------------+
| core/       data model: tape, graph, types, fp,       |
|             determinism utilities, RNG                |
+-------------------------------------------------------+
| (jest / TypeScript / pnpm)                            |
+-------------------------------------------------------+
```

Each layer can only depend downward. `core/` has no internal cross-deps
except where listed in the dep graph below.

## Dep graph (selected)

```
core/types ----+
core/errors ---+
core/fp ----+  +-- core/tape -- core/graph -- modules/forward
            |  |                              modules/backward
core/determinism --- modules/ops-reductions --+
core/random  -- (used only by tools / tests)
                                              |
modules/ops-elementary --+                    |
modules/ops-trig --------+                    |
modules/ops-exponential -+--> modules/ops-pieces (composes)
modules/ops-comparison --+
modules/ops-hyperbolic --+
                          \
                           \-> modules/ops-matrix (composes)

modules/backward + modules/forward = the autodiff core.
modules/gradcheck depends on backward + forward + ops-*.
modules/jacobian and modules/hessian depend on backward.
modules/optimizers is parameter-vector-only, no tape coupling.
modules/serialize encodes/decodes a tape independently of ops.
modules/lazy and modules/visualize are thin wrappers around the tape.
```

## The tape

The tape is the pivotal data structure. It's an append-only array of
nodes, each storing:

- `id` (1-based; 0 is a sentinel)
- `op` (one of ~50 OpKind values)
- `inputs` (list of NodeIds that feed this node)
- `value` (forward eval result, populated on append)
- `ctx` (per-op intermediate state used by backward; opaque to the tape)
- `handler` (the OpHandler used at append time)

Tape insertion order is total-ordered, which means insertion order is
also a topological order. This is the single most important invariant
in the codebase: anything in `modules/` that walks the tape can rely
on it. Changing to a non-insertion-order representation would force
updates to all of `modules/backward`, `modules/forward`, and
`modules/serialize`.

## Forward eval

Eager. When a caller writes `add(t, x, y)`, the `add` op computes
`vals[x] + vals[y]` immediately and stores the result on the new node.
There is no separate "compile" step. This trades efficiency (no graph
optimization) for transparency (you can read the tape after every line
and see actual numbers).

Re-evaluation (when a leaf value changes) goes through `replay()` in
`@silt/core-tape`, which walks the tape in insertion order and calls
each node's `handler.evalFn` with its inputs' updated values.

## Backward

Reverse-mode AD, walked once per `backward(t, output)` call. Algorithm
is the textbook reverse pass:

1. Allocate a Float64Array of size `tape.size() + 1`, gradient
   accumulator.
2. Set `grad[output] = 1` (or a user-supplied seed).
3. For each node from last to first:
   - Skip leaves and consts (no inputs to distribute to).
   - Skip if upstream grad is exactly 0 (no path from this node to the
     output that contributes).
   - Look up the node's backward function in the op registry.
   - Call it with stored input values, the node's accumulated upstream
     grad, the node's forward value, and the per-op ctx.
   - Add the returned partials to each input's slot in the accumulator.

Determinism: insertion-order reverse walk + Float64Array arithmetic =
bit-exact across runs. Whether the *value* is correct depends on the
op's backward function, but whether two runs produce the same bits
does not.

## The op registry

The handler/registry split is silt's main extensibility seam. To add
a new op:

1. Pick a unique `OpKind` string (add it to `core/types/node-id.ts`).
2. In a `modules/ops-*` package, write the forward in an `OpHandler`
   (`evalFn` + optional `ctxFn`).
3. Write the backward as a `BackwardFn`.
4. Register the backward in that package's `register.ts`.
5. Export a builder function (`add`, `sin`, etc.) that calls
   `tape.append(opKind, inputs, handler)`.

Because the registry is global, importing the module is sufficient for
the registration to take effect. Test files often use side-effect-only
imports for this purpose.

## Determinism contract

See `README.md` for the contract itself. The places to look in the
code:

- `jest.setup.cjs` -- the global frozen-clock shim
- `tools/lint-rules/src/no-nondeterminism.ts` -- the source-text scanner
- `core/determinism/Kahan.ts` -- compensated sum
- `core/random/Mulberry32.ts` -- the only sanctioned PRNG
- `tests/conformance/grad-corpus.json` -- the bit-exact reference

## Known sharp edges

These are issues I know about but haven't fixed (yet). See `TODO.md`
for the live list; this section is the architectural-level summary.

1. **Hessian non-symmetry through where(...)**: First-order grad is
   correct, but second-order via FD-of-grad picks up a small asymmetry
   when the function uses `where` or `cond`. Not a correctness blocker
   for first-order optimization.
2. **Gradcheck inner-loop allocation**: O(n) fresh arrays per gradcheck
   call. ~12% perf hit on the synthetic suite. FIXME-tagged.
3. **`adam` reset semantics**: `resetAdamState` zeros the iteration
   counter, which means the bias-correction factor restarts from
   step 1. Surprising for callers expecting step continuity across
   reset; the API should probably grow a "soft" reset that preserves
   `t`.
4. **Serializer V2 -> V3 migrator**: tools/migrate doesn't exist yet.
   v2 tapes from before 0.5.0 cannot be loaded.

These are listed in `docs/notes/` with longer explanations where
relevant.
