# JVP (forward) mode -- WIP

Status: paused (2026-04-12)

silt is currently reverse-mode only. Reverse mode is the right pick
for our usual case (scalar loss, many parameters). For Jacobian-vector
products of a multi-output function, forward mode is more efficient
when there are fewer inputs than outputs.

I started a forward-mode prototype in late March. The plan was:

1. Add a `Dual` type in `core/types/dual.ts`: `{ value: number, tangent: number }`.
2. Promote each op to a "dual" version that propagates both. For most
   ops the dual op is a one-liner: e.g., `dualSin({v, t}) = {sin(v), cos(v) * t}`.
3. Run a forward-mode JVP by initializing one input's tangent to 1 and
   propagating through the dual ops.
4. For Jacobians of m-output, n-input functions: pick whichever is
   cheaper -- m reverse passes or n forward passes.

The first three steps work. Got as far as having a `core/types/dual.ts`
sketch and a fork of `modules/ops-elementary` that uses dual numbers.
The integration story is where I

(stuck here. The issue: silt's Tape is fundamentally a scalar-value
container. To support both modes cleanly the tape needs to store
either a number or a `Dual`, which means either:

(a) make the tape generic over its scalar type, or
(b) keep two parallel tapes per computation, or
(c) interpret tangent as "secondary value" stored separately on each
    node, opt-in.

I lean toward (c) but I haven't designed the API. The state of the
prototype is on a side branch I never merged. If I come back to this
the right entry point is

TODO: pick this back up, write up the (a)/(b)/(c) decision tree.
