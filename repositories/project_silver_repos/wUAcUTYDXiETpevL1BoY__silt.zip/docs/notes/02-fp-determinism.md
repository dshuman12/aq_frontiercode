# Floating-point determinism

silt's determinism contract says: same input, same output bits, every
run, every machine. This note explains why that's a non-trivial promise
and what makes it hold (or fail).

## Where bits diverge in the absence of care

1. **Reduction order.** `(a + b) + c != a + (b + c)` in IEEE-754. A
   parallel reduction picks a tree topology; a sequential reduction
   picks a left-fold. Different machines (and different JS engines,
   sometimes) pick different orders. Result: the same input list of
   floats can sum to different doubles on different runs.

2. **Operator fusion.** Some math libraries fuse `a*b + c` into a
   fused-multiply-add (FMA). FMA is more accurate (one rounding
   instead of two), but the result differs from non-fused. Whether
   FMA fires depends on the hardware and whether the compiler
   recognized the pattern. JS engines don't expose FMA at all in
   userland, so this isn't a problem in V8/Node. It would be in C.

3. **libm transcendentals.** Math.sin / Math.exp / Math.tanh are
   defined to be "implementation-defined" by ECMAScript. Glibc, BSD
   libm, Apple libm, Microsoft CRT all give answers within 1 or 2
   ULPs of correctly-rounded but they don't always match each other.
   This is the one source of nondeterminism silt does NOT fully
   pin: a tanh value computed on Linux may differ in the last bit
   from the same tanh value on macOS.

   The conformance corpus (`tests/conformance/grad-corpus.json`)
   tolerates up to 16 ULPs to absorb this. The "test twice and diff"
   CI gate always runs on the same machine within a CI job, so libm
   is consistent across the two runs.

4. **Subnormal behavior.** Some hardware has flush-to-zero modes; JS
   doesn't expose any way to enable them, so it's not a concern here.

## What silt does to pin determinism

- Reductions go through `core/determinism/orderedSum` (Kahan-
  compensated, left-fold). No parallel reduction, no SIMD batching.
- The PRNG is `core/random/Mulberry32`, explicit seed required, no
  global state.
- The lint rule blocks `Math.random` / `Date.now` / timers from
  appearing in core/ or modules/, so timing-dependent and
  randomness-dependent code never sneaks in.
- The jest setup file freezes Date and Math.random at the test
  process level, so a forgotten use shows up as a thrown error.
- The CI workflow runs the test suite twice and diffs the outputs.

## What's not promised

- libm transcendental bit-exactness across platforms. The corpus
  allows up to 16 ULPs.
- Bit-exactness against reference implementations in PyTorch / JAX
  for the same operation. Those use FMA + GPU + different reduction
  trees, so their bits will differ even when their values are
  correct.

## What's worth investigating

For stronger cross-platform determinism the option is to ship a
silt-internal libm-equivalent for the half-dozen functions where it
matters (sin, cos, exp, log, tanh, sigmoid). Lots of work and probably
not worth it at silt's scope.
