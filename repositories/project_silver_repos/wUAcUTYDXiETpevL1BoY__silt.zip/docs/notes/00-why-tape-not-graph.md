# Why a flat tape, not a Graph<Node, Edge>

A graph object with explicit nodes-and-edges feels more "right" for
autodiff -- after all, the whole point is that you're computing on a
DAG. So why is silt's tape just a flat array with input lists?

A few reasons.

## 1. Insertion order is a topological order

You can't reference a node that doesn't exist yet, so when you append
a new op, all of its inputs are already on the tape. This means
walking the array from start to end is forward-topological, and
walking from end to start is reverse-topological. No separate sort
needed; no Kahn's algorithm; no DFS coloring; no cycle handling
because cycles are unrepresentable.

A general Graph<Node, Edge> would let you set up a graph and then
sort it. silt's tape skips the sort step by construction.

## 2. Cache locality

Backward walk is the hot path. Every node visit does:
- read upstream grad from a Float64Array (sequential)
- read input values (random access into a small fixed-size array)
- call into a backward function
- write output partials (random access into the grad array)

The Float64Array sits in a single contiguous allocation, so the grad
reads/writes are very cache-friendly. A Map<NodeId, GradEntry> would
not be.

## 3. Snapshot is free

Snapshot = remember `tape.size()`. Restore = `tape.length = size + 1`.
Both operations are constant-time and constant-allocation.

## 4. Earlier prototype used closures

For about a week in late November I had a closure-based version, where
each "node" was a JavaScript function that stored its inputs by lexical
capture. The forward pass was just calling the closure; the backward
pass was a curried thing that walked back through captured references.
It looked clever and had bad memory behavior on long graphs (V8
couldn't optimize the closure layout). The flat-array version is
boring and 5x faster on the curve-fit benchmark. Pinning a paper
elegance vs. throughput tradeoff that I want to remember.
