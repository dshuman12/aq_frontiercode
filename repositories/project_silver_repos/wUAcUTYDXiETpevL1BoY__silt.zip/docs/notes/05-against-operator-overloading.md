# Why no operator overloading

silt's call sites look like:

```ts
const z = add(t, x, y);
```

not like:

```ts
const z = x + y;  // would require operator overloading on Scalar
```

TypeScript doesn't support operator overloading at all. Even if it did,
the design isn't clear here:

1. The first argument to every op is the tape. Operator overloading
   would have to either thread the tape via a global (gross), via a
   per-Scalar back-reference (memory overhead), or just disallow ops
   between Scalars from different tapes (which is the right answer
   but doesn't fit the operator-overload mental model neatly).

2. silt deliberately keeps the tape explicit so you can see, at the
   call site, which tape an op is going on. In a multi-tape scenario
   (e.g. two parallel computations, or a snapshot/restore), being
   explicit is a feature.

3. The `add(t, x, y)` form is uglier but boring code is good. Anyone
   skimming the code knows what's happening.

PyTorch and JAX use operator overloading (Python supports it) and pay
the cost in implicit-tape global state. JAX's `jax.grad(f)(x)` works
by tracing f(x) under a thread-local "is the tracer active?" flag.
silt is small enough not to need that kind of cleverness, and the
explicit form is fine.

If silt ever grows a Tensor type, the same convention sticks:
explicit `t` first, no `__add__` magic.
