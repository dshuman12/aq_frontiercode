# Jacobian vs Hessian: when each is cheap

Reverse mode is cheapest when output dim is much smaller than input
dim. Forward mode (which silt does not yet have, see 03-WIP-jvp-mode)
is cheapest when input dim is small and output dim is large.

For Jacobians:

- m outputs, n inputs.
- Reverse mode: m backward passes -> O(m * cost_of_forward).
- Forward mode: n forward passes -> O(n * cost_of_forward).
- Reverse beats forward when m < n (the common case for ML losses).
- Forward beats reverse when m > n (uncommon outside ODE sensitivities).

silt's `jacobian` implementation does m reverse passes. For functions
where forward would be cheaper, you'd want JVP mode.

For Hessians:

- The Hessian of a scalar function is n x n.
- Forward-over-reverse: n JVPs, each over a reverse pass. O(n) total
  cost, optimal.
- Reverse-over-forward: same as above by symmetry.
- Reverse-over-reverse: n^2 cost. Worst.
- FD-of-grad (silt's current approach): 2n reverse passes, then n^2
  divides. O(n) total cost, similar to forward-over-reverse but with
  worse precision.

silt's Hessian is FD-of-grad because it's simple and good enough for
n in the dozens. For n in the hundreds, the precision starts hurting
(you're doing FD on numbers that are themselves O(eps) accurate, so
the second-order error grows). This is on the TODO for a "proper"
forward-over-reverse via JVP mode.
