# Notes on checkpointing

silt does not currently implement gradient checkpointing (the JAX/PT
trick where you trade memory for compute by re-running forward chunks
during backward instead of caching them).

For the workloads silt targets -- networks under 10k parameters, ODE
rollouts of a few hundred steps -- the full tape comfortably fits in
memory. A 100k-node tape is ~5 MB of node records plus the float64
forward values; not worth the engineering cost of checkpointing.

If silt ever grows to handle larger problems, the natural place to
add this is `core/tape/`: split the tape into segments, allow segment
boundaries to be marked as "checkpoints", drop intermediate values
between checkpoints after forward, re-run forward locally during
backward.

The catch: op handlers are stateful (they store ctx). Dropping a
value means re-deriving ctx during backward, which means calling the
handler again. The current handler protocol is set up for this --
evalFn is pure, ctxFn is pure -- so the change is mostly plumbing
rather than redesign. Just not yet motivated.
