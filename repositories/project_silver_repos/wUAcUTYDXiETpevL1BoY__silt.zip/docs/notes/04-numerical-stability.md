# Numerical stability notes

A grab-bag of things to be careful about when using silt for real
numerical work.

## softmax and log-sum-exp

The naive forms `exp(x_i) / sum_j exp(x_j)` and `log(sum_i exp(x_i))`
overflow when any x_i is large positive (e.g. 1000). silt's
implementations subtract `max(xs)` before exponentiating, which
stabilizes both. See `modules/ops-pieces/src/softmax.ts` and
`log-sum-exp.ts`.

If you need cross-entropy loss you should always go through
`logSumExp(logits) - logits[label]` rather than `-log(softmax(logits)[label])`,
because the latter has a `log(small_number)` step that loses precision
even with the stabilized softmax.

## sigmoid

For x < 0 the form `exp(x) / (1 + exp(x))` avoids overflow. For x >= 0
the form `1 / (1 + exp(-x))` avoids underflow. silt's sigmoid picks
the right form based on input sign automatically.

## sqrt near zero

`d/dx sqrt(x) = 1 / (2 * sqrt(x))` blows up as x -> 0. If your
optimization is squashing parameters toward 0 through a sqrt, expect
NaNs. Add a tiny epsilon: `sqrt(x + 1e-12)` is the standard hack.

## log near zero or negative

`log(x)` returns -Inf at 0 and NaN below. silt does not guard against
this; if you compute `log(probability)` and a probability is exactly
0, you get -Inf, and any subsequent op produces NaN. Most often the
fix is to not compute `log(0)` -- use logSumExp upstream.

## div near zero

Same story as log. silt does not guard.

## pow with non-positive base + non-integer exponent

`pow(b, e)` for b <= 0 and non-integer e is NaN in IEEE-754, and the
gradient w.r.t. e is genuinely undefined (would require complex
numbers). silt returns NaN explicitly in `powBackward` for this case
rather than producing a wrong value silently.

## tan near pi/2

`tan(x)` blows up at multiples of pi/2. silt doesn't guard. If you're
using tan in an optimization and the optimum drives an input toward
pi/2, you'll see your loss explode. Common fix: parameterize the
input through atan to bound it to a finite range.
