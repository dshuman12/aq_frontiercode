// REPL state object. The actual stdin loop is in main.ts; this class
// is the pure tape-state machine.
//
// Operates on a single tape with a name table. Output is plain text.

import { Tape } from '@silt/core-tape';
import type { NodeId } from '@silt/core-types';
import { backward } from '@silt/backward';
import { add, sub, mul, div, neg, abs } from '@silt/ops-elementary';
import { sin, cos, tan, atan } from '@silt/ops-trig';
import { exp, log, sqrt } from '@silt/ops-exponential';
import { type Command, parseLine } from './parse.js';

const SCALAR_OP_BUILDERS: Record<string, (t: Tape, args: NodeId[]) => NodeId> = {
  add: (t, a) => add(t, a[0]!, a[1]!),
  sub: (t, a) => sub(t, a[0]!, a[1]!),
  mul: (t, a) => mul(t, a[0]!, a[1]!),
  div: (t, a) => div(t, a[0]!, a[1]!),
  neg: (t, a) => neg(t, a[0]!),
  abs: (t, a) => abs(t, a[0]!),
  sin: (t, a) => sin(t, a[0]!),
  cos: (t, a) => cos(t, a[0]!),
  tan: (t, a) => tan(t, a[0]!),
  atan: (t, a) => atan(t, a[0]!),
  exp: (t, a) => exp(t, a[0]!),
  log: (t, a) => log(t, a[0]!),
  sqrt: (t, a) => sqrt(t, a[0]!),
};

const HELP = `silt REPL
  :leaf <name> <value>            new leaf
  :op <op> <name> <inputs...>     apply op (add, sub, mul, ..., sin, cos, exp, ...)
  :grad <output>                  backward from output, print grads
  :show                           list current nodes
  :reset                          start over
  :help                           this message
  :quit                           exit
`;

export class Repl {
  private _tape: Tape = new Tape();
  private _names = new Map<string, NodeId>();

  handleLine(line: string): { output: string; quit: boolean } {
    const cmd = parseLine(line);
    if (cmd.kind === 'error') return { output: `error: ${cmd.message}`, quit: false };
    return this._handle(cmd);
  }

  private _handle(cmd: Command): { output: string; quit: boolean } {
    switch (cmd.kind) {
      case 'leaf': {
        const id = this._tape.leaf(cmd.value);
        this._names.set(cmd.name, id);
        return { output: `${cmd.name} = leaf(${cmd.value}) -> n${id}`, quit: false };
      }
      case 'op': {
        const builder = SCALAR_OP_BUILDERS[cmd.op];
        if (!builder) return { output: `error: unknown op '${cmd.op}'`, quit: false };
        const inputs: NodeId[] = [];
        for (const name of cmd.inputs) {
          const id = this._names.get(name);
          if (id === undefined) return { output: `error: unknown name '${name}'`, quit: false };
          inputs.push(id);
        }
        try {
          const id = builder(this._tape, inputs);
          this._names.set(cmd.name, id);
          return {
            output: `${cmd.name} = ${cmd.op}(${cmd.inputs.join(', ')}) = ${this._tape.valueOf(id).toFixed(6)} -> n${id}`,
            quit: false,
          };
        } catch (e) {
          return { output: `error: ${(e as Error).message}`, quit: false };
        }
      }
      case 'grad': {
        const out = this._names.get(cmd.output);
        if (out === undefined) return { output: `error: unknown name '${cmd.output}'`, quit: false };
        try {
          const grads = backward(this._tape, out);
          const lines: string[] = [`grads w.r.t. ${cmd.output}:`];
          // Sort by name for stable output
          const entries = [...this._names.entries()].sort((a, b) =>
            a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0,
          );
          for (const [name, id] of entries) {
            const g = grads.get(id);
            if (g !== 0) lines.push(`  ${name} (n${id}): ${g.toFixed(6)}`);
          }
          return { output: lines.join('\n'), quit: false };
        } catch (e) {
          return { output: `error: ${(e as Error).message}`, quit: false };
        }
      }
      case 'show': {
        const lines: string[] = [`tape size = ${this._tape.size()}`];
        const entries = [...this._names.entries()].sort((a, b) =>
          a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0,
        );
        for (const [name, id] of entries) {
          const node = this._tape.get(id);
          lines.push(
            `  ${name} (n${id}, ${node.op}): ${node.value === null ? '?' : node.value.toFixed(6)}`,
          );
        }
        return { output: lines.join('\n'), quit: false };
      }
      case 'reset': {
        this._tape = new Tape();
        this._names.clear();
        return { output: 'tape reset', quit: false };
      }
      case 'quit':
        return { output: 'bye.', quit: true };
      case 'help':
        return { output: HELP, quit: false };
    }
  }
}
