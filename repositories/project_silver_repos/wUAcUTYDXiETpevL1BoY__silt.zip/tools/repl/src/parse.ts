// REPL command parser.

export type Command =
  | { kind: 'leaf'; name: string; value: number }
  | { kind: 'op'; op: string; name: string; inputs: string[] }
  | { kind: 'grad'; output: string }
  | { kind: 'show' }
  | { kind: 'reset' }
  | { kind: 'quit' }
  | { kind: 'help' };

export function parseLine(line: string): Command | { kind: 'error'; message: string } {
  const trimmed = line.trim();
  if (trimmed === '') return { kind: 'error', message: 'empty line' };
  const parts = trimmed.split(/\s+/);
  const head = parts[0]!;
  switch (head) {
    case ':leaf': {
      if (parts.length !== 3) {
        return { kind: 'error', message: 'usage: :leaf <name> <value>' };
      }
      const v = Number(parts[2]);
      if (Number.isNaN(v)) {
        return { kind: 'error', message: `not a number: ${parts[2]}` };
      }
      return { kind: 'leaf', name: parts[1]!, value: v };
    }
    case ':op': {
      if (parts.length < 4) {
        return { kind: 'error', message: 'usage: :op <op> <name> <input1> [<input2> ...]' };
      }
      return {
        kind: 'op',
        op: parts[1]!,
        name: parts[2]!,
        inputs: parts.slice(3),
      };
    }
    case ':grad': {
      if (parts.length !== 2) return { kind: 'error', message: 'usage: :grad <output>' };
      return { kind: 'grad', output: parts[1]! };
    }
    case ':show':
      return { kind: 'show' };
    case ':reset':
      return { kind: 'reset' };
    case ':quit':
    case ':q':
    case ':exit':
      return { kind: 'quit' };
    case ':help':
    case ':h':
    case '?':
      return { kind: 'help' };
    default:
      return { kind: 'error', message: `unknown command: ${head}` };
  }
}
