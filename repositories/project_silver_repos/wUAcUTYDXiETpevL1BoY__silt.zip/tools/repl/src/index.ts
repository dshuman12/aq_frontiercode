// Tiny tape-builder REPL. Useful when I want to scribble an op graph
// at the prompt and see grads.
//
// Commands:
//   :leaf <name> <value>   create a leaf
//   :op <op> <name> <inputs...>  apply an op, naming the result
//   :grad <output>         backward from <output>, print all grads
//   :show                  list nodes with values
//   :reset                 wipe the tape
//   :quit                  exit

export { Repl } from './repl.js';
export { parseLine, type Command } from './parse.js';
