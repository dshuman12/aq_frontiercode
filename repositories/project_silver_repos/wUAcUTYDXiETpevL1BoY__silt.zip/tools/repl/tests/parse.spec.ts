import { parseLine } from '../src/parse.js';

describe('parseLine', () => {
  it(':leaf', () => {
    const r = parseLine(':leaf x 1.5');
    expect(r).toEqual({ kind: 'leaf', name: 'x', value: 1.5 });
  });

  it(':leaf with bad number', () => {
    const r = parseLine(':leaf x notanumber');
    expect(r.kind).toBe('error');
  });

  it(':leaf with wrong arg count', () => {
    expect(parseLine(':leaf x').kind).toBe('error');
    expect(parseLine(':leaf x 1 2').kind).toBe('error');
  });

  it(':op two args', () => {
    expect(parseLine(':op add z x y')).toEqual({
      kind: 'op',
      op: 'add',
      name: 'z',
      inputs: ['x', 'y'],
    });
  });

  it(':op single arg', () => {
    expect(parseLine(':op sin s x')).toEqual({
      kind: 'op',
      op: 'sin',
      name: 's',
      inputs: ['x'],
    });
  });

  it(':op needs at least one input', () => {
    expect(parseLine(':op add z').kind).toBe('error');
  });

  it(':grad', () => {
    expect(parseLine(':grad out')).toEqual({ kind: 'grad', output: 'out' });
  });

  it(':show / :reset / :quit / :help / aliases', () => {
    expect(parseLine(':show').kind).toBe('show');
    expect(parseLine(':reset').kind).toBe('reset');
    expect(parseLine(':quit').kind).toBe('quit');
    expect(parseLine(':q').kind).toBe('quit');
    expect(parseLine(':exit').kind).toBe('quit');
    expect(parseLine(':help').kind).toBe('help');
    expect(parseLine(':h').kind).toBe('help');
    expect(parseLine('?').kind).toBe('help');
  });

  it('refuses unknown command', () => {
    expect(parseLine(':frobnicate').kind).toBe('error');
  });

  it('handles whitespace tolerance', () => {
    expect(parseLine('   :leaf   x   1.5   ')).toEqual({ kind: 'leaf', name: 'x', value: 1.5 });
  });

  it('refuses empty', () => {
    expect(parseLine('').kind).toBe('error');
  });
});
