import { Repl } from '../src/repl.js';

describe('Repl session', () => {
  it('builds tape via :leaf and :op', () => {
    const r = new Repl();
    expect(r.handleLine(':leaf x 2').output).toContain('n1');
    expect(r.handleLine(':leaf y 3').output).toContain('n2');
    const o = r.handleLine(':op add z x y');
    expect(o.output).toContain('5');
  });

  it(':grad reports partials', () => {
    const r = new Repl();
    r.handleLine(':leaf x 2');
    r.handleLine(':leaf y 3');
    r.handleLine(':op mul z x y');
    const out = r.handleLine(':grad z').output;
    expect(out).toContain('x');
    expect(out).toContain('3'); // dz/dx = y = 3
    expect(out).toContain('y');
    expect(out).toContain('2'); // dz/dy = x = 2
  });

  it(':show lists current names', () => {
    const r = new Repl();
    r.handleLine(':leaf x 1');
    r.handleLine(':leaf y 2');
    const out = r.handleLine(':show').output;
    expect(out).toContain('tape size = 2');
    expect(out).toContain('x');
    expect(out).toContain('y');
  });

  it(':reset clears state', () => {
    const r = new Repl();
    r.handleLine(':leaf x 1');
    r.handleLine(':reset');
    expect(r.handleLine(':show').output).toContain('size = 0');
  });

  it(':quit signals exit', () => {
    const r = new Repl();
    expect(r.handleLine(':quit').quit).toBe(true);
  });

  it('errors on unknown name', () => {
    const r = new Repl();
    expect(r.handleLine(':op add z x y').output).toContain('error');
  });

  it('errors on unknown op', () => {
    const r = new Repl();
    r.handleLine(':leaf x 1');
    expect(r.handleLine(':op frobnicate y x').output).toContain('error');
  });

  it('errors on :grad of unknown name', () => {
    expect(new Repl().handleLine(':grad z').output).toContain('error');
  });

  it(':help responds', () => {
    expect(new Repl().handleLine(':help').output).toContain('REPL');
  });
});
