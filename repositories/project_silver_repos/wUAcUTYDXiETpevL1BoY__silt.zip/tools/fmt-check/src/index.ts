// Round-trip checker for the tape serializer. Encodes a tape, decodes,
// checks that node count + per-node forward values are bit-identical.
//
// Used by CI in the nightly job and by tools/migrate during version
// upgrades to gate that the migrator preserves semantics.

import type { Tape } from '@silt/core-tape';
import { encodeTape, decodeTape } from '@silt/serialize';
import { bitsEqual } from '@silt/core-fp';

export interface RoundTripReport {
  passed: boolean;
  reason?: string;
  sizeOriginal: number;
  sizeRoundTrip: number;
  firstDivergence?: { id: number; original: number; roundTrip: number };
}

export function checkRoundTrip(t: Tape): RoundTripReport {
  const buf = encodeTape(t);
  const t2 = decodeTape(buf);
  if (t.size() !== t2.size()) {
    return {
      passed: false,
      reason: `size mismatch: ${t.size()} vs ${t2.size()}`,
      sizeOriginal: t.size(),
      sizeRoundTrip: t2.size(),
    };
  }
  for (let i = 1; i <= t.size(); i++) {
    const orig = t.get(i as never).value;
    const round = t2.get(i as never).value;
    if (orig === null || round === null) {
      if (orig !== round) {
        return {
          passed: false,
          reason: `null/value mismatch at n${i}`,
          sizeOriginal: t.size(),
          sizeRoundTrip: t2.size(),
        };
      }
      continue;
    }
    if (!bitsEqual(orig, round)) {
      return {
        passed: false,
        reason: `bit-divergence at n${i}`,
        sizeOriginal: t.size(),
        sizeRoundTrip: t2.size(),
        firstDivergence: { id: i, original: orig, roundTrip: round },
      };
    }
  }
  return { passed: true, sizeOriginal: t.size(), sizeRoundTrip: t2.size() };
}
