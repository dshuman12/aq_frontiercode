import { Tape } from '@silt/core-tape';
import { add, mul } from '@silt/ops-elementary';
import { sin } from '@silt/ops-trig';
import { exp, log } from '@silt/ops-exponential';
import { checkRoundTrip } from '../src/index.js';

describe('checkRoundTrip', () => {
  it('passes on empty tape', () => {
    const r = checkRoundTrip(new Tape());
    expect(r.passed).toBe(true);
    expect(r.sizeOriginal).toBe(0);
    expect(r.sizeRoundTrip).toBe(0);
  });

  it('passes on a single-leaf tape', () => {
    const t = new Tape();
    t.leaf(2.5);
    expect(checkRoundTrip(t).passed).toBe(true);
  });

  it('passes on a chain of supported ops', () => {
    const t = new Tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = mul(t, x, y);
    const w = add(t, z, x);
    const u = sin(t, w);
    void u;
    expect(checkRoundTrip(t).passed).toBe(true);
  });

  it('passes on exp / log', () => {
    const t = new Tape();
    const x = t.leaf(1.5);
    log(t, exp(t, x));
    expect(checkRoundTrip(t).passed).toBe(true);
  });

  it('preserves bit-exact float64 values', () => {
    const t = new Tape();
    // Awkward floats that show up where rounding matters.
    t.leaf(0.1 + 0.2);
    t.leaf(Math.PI);
    t.leaf(Number.EPSILON);
    const r = checkRoundTrip(t);
    expect(r.passed).toBe(true);
  });

  it('reports size on roundtrip', () => {
    const t = new Tape();
    for (let i = 0; i < 10; i++) t.leaf(i);
    const r = checkRoundTrip(t);
    expect(r.sizeOriginal).toBe(10);
    expect(r.sizeRoundTrip).toBe(10);
  });
});
