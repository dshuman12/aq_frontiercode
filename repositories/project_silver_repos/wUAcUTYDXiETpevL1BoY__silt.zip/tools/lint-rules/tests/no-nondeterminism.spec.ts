import { scanForNondeterminism } from '../src/no-nondeterminism.js';

describe('scanForNondeterminism', () => {
  it('flags Math.random', () => {
    const f = scanForNondeterminism('a.ts', 'const x = Math.random();');
    expect(f).toHaveLength(1);
    expect(f[0]!.symbol).toBe('Math.random');
  });

  it('flags Date.now', () => {
    const f = scanForNondeterminism('a.ts', 'const t = Date.now();');
    expect(f).toHaveLength(1);
    expect(f[0]!.symbol).toBe('Date.now');
  });

  it('flags new Date() with no args', () => {
    const f = scanForNondeterminism('a.ts', 'const d = new Date();');
    expect(f).toHaveLength(1);
    expect(f[0]!.symbol).toBe('new Date()');
  });

  it('does not flag new Date(123) (with arg)', () => {
    const f = scanForNondeterminism('a.ts', 'const d = new Date(123);');
    expect(f).toHaveLength(0);
  });

  it('flags setTimeout', () => {
    const f = scanForNondeterminism('a.ts', 'setTimeout(() => {}, 0);');
    expect(f).toHaveLength(1);
  });

  it('flags setInterval', () => {
    const f = scanForNondeterminism('a.ts', 'setInterval(() => {}, 100);');
    expect(f).toHaveLength(1);
  });

  it('flags setImmediate', () => {
    const f = scanForNondeterminism('a.ts', 'setImmediate(() => {});');
    expect(f).toHaveLength(1);
  });

  it('flags process.hrtime', () => {
    const f = scanForNondeterminism('a.ts', 'const h = process.hrtime();');
    expect(f).toHaveLength(1);
  });

  it('skips contents of // line comments', () => {
    const f = scanForNondeterminism('a.ts', '// Math.random was banned for a reason');
    expect(f).toHaveLength(0);
  });

  it('skips contents of /* block comments */', () => {
    const f = scanForNondeterminism('a.ts', '/* Math.random would go here */');
    expect(f).toHaveLength(0);
  });

  it('skips string-literal contents', () => {
    const f = scanForNondeterminism('a.ts', `const s = 'Math.random not actually called';`);
    expect(f).toHaveLength(0);
  });

  it('handles backtick strings', () => {
    const f = scanForNondeterminism('a.ts', 'const s = `Math.random not called`;');
    expect(f).toHaveLength(0);
  });

  it('reports correct line and column', () => {
    const src = `// line one
// line two
const x = Math.random();
// line four`;
    const f = scanForNondeterminism('a.ts', src);
    expect(f).toHaveLength(1);
    expect(f[0]!.line).toBe(3);
    expect(f[0]!.column).toBeGreaterThan(0);
  });

  it('finds multiple matches in same file', () => {
    const src = `const a = Math.random();
const b = Date.now();
setTimeout(() => {}, 0);`;
    const f = scanForNondeterminism('a.ts', src);
    expect(f).toHaveLength(3);
  });
});
