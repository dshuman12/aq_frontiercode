// silt's custom lint rules. Currently:
//   - no-nondeterminism: bans Math.random / Date.now / new Date() /
//     setTimeout / setImmediate / process.hrtime in core/ and modules/.
//
// The rules are written as pure source-text scanners rather than as
// proper @typescript-eslint AST visitors. Reason: it keeps the rule
// dependency-free and the rule itself trivial to audit. Real eslint
// rules would be cleaner but require @typescript-eslint/utils, which
// pulls in a transitive dep we can avoid.

export { scanForNondeterminism, type Finding } from './no-nondeterminism.js';
export { lintRepo, type LintReport } from './lint-repo.js';
