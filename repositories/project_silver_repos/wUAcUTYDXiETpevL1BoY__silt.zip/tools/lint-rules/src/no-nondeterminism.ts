// Source-text scanner for sources of nondeterminism.
//
// We look for textual patterns rather than AST nodes:
//   - "Math.random"
//   - "Date.now"
//   - "new Date(" not followed immediately by a numeric arg
//   - "setTimeout(" / "setInterval(" / "setImmediate("
//   - "process.hrtime"
//
// False positives are possible (e.g. inside a string literal). The
// rule excludes anything inside /* ... */ or // comment lines and
// inside string literals. That covers ~99% of real code.

export interface Finding {
  filePath: string;
  line: number;
  column: number;
  symbol: string;
  message: string;
}

const BANNED: Array<{ pattern: RegExp; symbol: string; message: string }> = [
  {
    pattern: /\bMath\s*\.\s*random\s*\(/g,
    symbol: 'Math.random',
    message: 'silt determinism: use core/random/Mulberry32 with an explicit seed',
  },
  {
    pattern: /\bDate\s*\.\s*now\s*\(/g,
    symbol: 'Date.now',
    message: 'silt determinism: no clock in core/modules',
  },
  {
    pattern: /\bnew\s+Date\s*\(\s*\)/g,
    symbol: 'new Date()',
    message: 'silt determinism: no clock in core/modules',
  },
  {
    pattern: /\bsetTimeout\s*\(/g,
    symbol: 'setTimeout',
    message: 'silt determinism: no timers in core/modules',
  },
  {
    pattern: /\bsetInterval\s*\(/g,
    symbol: 'setInterval',
    message: 'silt determinism: no timers in core/modules',
  },
  {
    pattern: /\bsetImmediate\s*\(/g,
    symbol: 'setImmediate',
    message: 'silt determinism: no timers in core/modules',
  },
  {
    pattern: /\bprocess\s*\.\s*hrtime\b/g,
    symbol: 'process.hrtime',
    message: 'silt determinism: no clock in core/modules',
  },
];

// Strip line and block comments, plus string-literal contents. We
// don't fully parse TS; we approximate.
function strip(text: string): string {
  // Block comments
  let out = text.replace(/\/\*[\s\S]*?\*\//g, (m) => ' '.repeat(m.length));
  // Line comments
  out = out.replace(/\/\/[^\n]*/g, (m) => ' '.repeat(m.length));
  // String literals: ', ", `
  out = out.replace(/'([^'\\\n]|\\.)*'/g, (m) => "'" + ' '.repeat(m.length - 2) + "'");
  out = out.replace(/"([^"\\\n]|\\.)*"/g, (m) => '"' + ' '.repeat(m.length - 2) + '"');
  out = out.replace(/`([^`\\]|\\.)*`/g, (m) => '`' + ' '.repeat(m.length - 2) + '`');
  return out;
}

export function scanForNondeterminism(filePath: string, source: string): Finding[] {
  const stripped = strip(source);
  const findings: Finding[] = [];
  for (const rule of BANNED) {
    rule.pattern.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = rule.pattern.exec(stripped)) !== null) {
      const idx = m.index;
      const before = stripped.slice(0, idx);
      const line = before.split('\n').length;
      const lastNl = before.lastIndexOf('\n');
      const column = lastNl === -1 ? idx + 1 : idx - lastNl;
      findings.push({
        filePath,
        line,
        column,
        symbol: rule.symbol,
        message: rule.message,
      });
    }
  }
  return findings;
}
