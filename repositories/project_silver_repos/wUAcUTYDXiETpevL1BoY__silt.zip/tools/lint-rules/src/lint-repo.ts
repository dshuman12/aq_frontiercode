// Walk core/ and modules/ source trees, scan each .ts file for
// nondeterminism violations, return a LintReport.
//
// This is the entry point used by the CI lint step.

import * as fs from 'node:fs';
import * as path from 'node:path';
import { scanForNondeterminism, type Finding } from './no-nondeterminism.js';

export interface LintReport {
  filesScanned: number;
  findings: Finding[];
  passed: boolean;
}

const SCANNED_ROOTS = ['core', 'modules'];
const EXCLUDED_DIRS = new Set(['node_modules', 'dist', '.tsbuildinfo', 'tests', 'test-setup']);

export function lintRepo(repoRoot: string): LintReport {
  const findings: Finding[] = [];
  let filesScanned = 0;
  for (const root of SCANNED_ROOTS) {
    const abs = path.join(repoRoot, root);
    if (!fs.existsSync(abs)) continue;
    walk(abs, (filePath) => {
      if (!filePath.endsWith('.ts') || filePath.endsWith('.spec.ts')) return;
      const src = fs.readFileSync(filePath, 'utf8');
      const f = scanForNondeterminism(filePath, src);
      findings.push(...f);
      filesScanned++;
    });
  }
  return { filesScanned, findings, passed: findings.length === 0 };
}

function walk(dir: string, visit: (filePath: string) => void): void {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  // Sort for deterministic traversal.
  entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
  for (const e of entries) {
    if (EXCLUDED_DIRS.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      walk(full, visit);
    } else if (e.isFile()) {
      visit(full);
    }
  }
}
