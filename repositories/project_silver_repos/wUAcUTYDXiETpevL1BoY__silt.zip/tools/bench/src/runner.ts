// Runs each bench case, returns timing stats.
//
// We run each case `iter` times, drop the worst 10% (warm-up + outliers),
// then report mean / median / p99 in nanoseconds per call.

export interface BenchCase {
  name: string;
  setup?: () => void;
  fn: () => void;
  iter?: number;
}

export interface BenchResult {
  name: string;
  iter: number;
  meanNs: number;
  medianNs: number;
  p99Ns: number;
  totalNs: number;
}

export function runBench(cases: BenchCase[]): BenchResult[] {
  const out: BenchResult[] = [];
  for (const c of cases) {
    const iter = c.iter ?? 1000;
    if (c.setup) c.setup();
    // warmup -- discarded
    for (let i = 0; i < Math.min(50, iter); i++) c.fn();
    const samples = new Array<number>(iter);
    for (let i = 0; i < iter; i++) {
      const t0 = process.hrtime.bigint();
      c.fn();
      const t1 = process.hrtime.bigint();
      samples[i] = Number(t1 - t0);
    }
    samples.sort((a, b) => a - b);
    // drop worst 10%
    const cut = Math.floor(iter * 0.9);
    const trimmed = samples.slice(0, cut);
    let total = 0;
    for (const s of trimmed) total += s;
    const meanNs = total / trimmed.length;
    const medianNs = trimmed[Math.floor(trimmed.length / 2)]!;
    const p99Ns = trimmed[Math.floor(trimmed.length * 0.99)] ?? trimmed[trimmed.length - 1]!;
    out.push({ name: c.name, iter, meanNs, medianNs, p99Ns, totalNs: total });
  }
  return out;
}
