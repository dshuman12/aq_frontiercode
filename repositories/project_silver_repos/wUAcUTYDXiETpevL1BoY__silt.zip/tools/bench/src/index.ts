// Microbenchmark harness for silt.
//
// Note: bench code is the ONE place in this repo that's allowed to
// touch process.hrtime / performance.now. The eslint rule excludes
// tools/. Runs in a separate process from tests.

export { runBench, type BenchCase, type BenchResult } from './runner.js';
export { reportText, reportJson } from './report.js';
