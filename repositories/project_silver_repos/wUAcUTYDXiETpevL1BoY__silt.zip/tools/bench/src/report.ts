import type { BenchResult } from './runner.js';

export function reportText(results: BenchResult[]): string {
  const lines: string[] = [];
  lines.push('name'.padEnd(40) + 'iter'.padStart(10) + 'mean(ns)'.padStart(14) + 'median(ns)'.padStart(14) + 'p99(ns)'.padStart(14));
  lines.push('-'.repeat(92));
  for (const r of results) {
    lines.push(
      r.name.padEnd(40) +
        String(r.iter).padStart(10) +
        r.meanNs.toFixed(0).padStart(14) +
        r.medianNs.toFixed(0).padStart(14) +
        r.p99Ns.toFixed(0).padStart(14),
    );
  }
  return lines.join('\n');
}

export function reportJson(results: BenchResult[]): string {
  return JSON.stringify({ benches: results }, null, 2);
}
