// Bench entry point. Run via `pnpm --filter @silt/tools-bench start`.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul } from '@silt/ops-elementary';
import { sin, cos } from '@silt/ops-trig';
import { exp } from '@silt/ops-exponential';
import { runBench, type BenchCase } from './runner.js';
import { reportText, reportJson } from './report.js';

const cases: BenchCase[] = [
  {
    name: 'tape-build/100-ops',
    iter: 5000,
    fn: () => {
      const t = new Tape();
      let acc = t.leaf(1);
      const c = t.const(0.1);
      for (let i = 0; i < 100; i++) {
        acc = add(t, acc, c);
      }
    },
  },
  {
    name: 'forward+backward/sin-chain-50',
    iter: 2000,
    fn: () => {
      const t = new Tape();
      let acc = t.leaf(0.5);
      for (let i = 0; i < 50; i++) acc = sin(t, acc);
      backward(t, acc);
    },
  },
  {
    name: 'forward+backward/x*y+sin(x)',
    iter: 5000,
    fn: () => {
      const t = new Tape();
      const x = t.leaf(0.5);
      const y = t.leaf(0.7);
      const out = add(t, mul(t, x, y), sin(t, x));
      backward(t, out);
    },
  },
  {
    name: 'forward/exp-cos-100',
    iter: 2000,
    fn: () => {
      const t = new Tape();
      let acc = t.leaf(0.1);
      for (let i = 0; i < 100; i++) acc = exp(t, cos(t, acc));
    },
  },
];

const args = process.argv.slice(2);
const results = runBench(cases);
if (args.includes('--json')) {
  process.stdout.write(reportJson(results) + '\n');
} else {
  process.stdout.write(reportText(results) + '\n');
}
