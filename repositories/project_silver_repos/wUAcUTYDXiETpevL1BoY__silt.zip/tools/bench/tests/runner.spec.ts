import { runBench } from '../src/runner.js';
import { reportText, reportJson } from '../src/report.js';

describe('runBench', () => {
  it('runs each case and returns timing stats', () => {
    // bench code is allowed to use real timing inside its own tests
    // because tools/ is exempt from the determinism rule. But the
    // jest setup still freezes hrtime by default, so we explicitly
    // allow it here.
    (globalThis as { allowNondeterminism?: () => void }).allowNondeterminism?.();
    try {
      const results = runBench([
        {
          name: 'noop',
          iter: 100,
          fn: () => {},
        },
      ]);
      expect(results).toHaveLength(1);
      expect(results[0]!.iter).toBe(100);
      expect(results[0]!.meanNs).toBeGreaterThanOrEqual(0);
    } finally {
      (globalThis as { revertNondeterminism?: () => void }).revertNondeterminism?.();
    }
  });

  it('honors per-case iter override', () => {
    (globalThis as { allowNondeterminism?: () => void }).allowNondeterminism?.();
    try {
      const r = runBench([{ name: 'x', iter: 50, fn: () => {} }]);
      expect(r[0]!.iter).toBe(50);
    } finally {
      (globalThis as { revertNondeterminism?: () => void }).revertNondeterminism?.();
    }
  });
});

describe('report', () => {
  it('reportText emits header + rows', () => {
    const text = reportText([
      { name: 'x', iter: 100, meanNs: 50, medianNs: 45, p99Ns: 70, totalNs: 5000 },
    ]);
    expect(text).toContain('name');
    expect(text).toContain('mean(ns)');
    expect(text).toContain('x');
  });

  it('reportJson is parseable', () => {
    const j = reportJson([
      { name: 'x', iter: 1, meanNs: 1, medianNs: 1, p99Ns: 1, totalNs: 1 },
    ]);
    expect(JSON.parse(j).benches).toHaveLength(1);
  });
});
