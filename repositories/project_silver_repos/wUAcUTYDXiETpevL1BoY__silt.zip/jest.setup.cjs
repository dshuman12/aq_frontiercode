// Determinism shim. Loaded before every test file.
//
// We freeze the things that vary across runs:
//   - Date.now() and new Date() with no args
//   - Math.random()
//   - setTimeout / setInterval / setImmediate
//   - process.hrtime / performance.now
//
// Tests that genuinely need timing or randomness must opt in by calling
// allowNondeterminism() in beforeAll and revertNondeterminism() in
// afterAll. The opt-in is intentionally noisy.

const FROZEN_TIME_MS = 1700000000000; // 2023-11-14T22:13:20Z
const FROZEN_HRTIME = [1234567, 0];

const realDateNow = Date.now.bind(Date);
const realDate = global.Date;
const realMathRandom = Math.random.bind(Math);
const realSetTimeout = global.setTimeout;
const realSetInterval = global.setInterval;
const realSetImmediate = global.setImmediate;
const realHrtime = process.hrtime;
const realPerfNow = global.performance ? global.performance.now.bind(global.performance) : null;

let frozen = true;

function throwOnUse(name) {
  return function () {
    if (frozen) {
      const e = new Error(
        `silt determinism: ${name}() called from a test. ` +
          `If this is intentional, call allowNondeterminism() in beforeAll.`,
      );
      // mark so we can grep this in CI
      e.code = 'SILT_NONDETERMINISM';
      throw e;
    }
    return realMathRandom();
  };
}

Math.random = throwOnUse('Math.random');

Date.now = function () {
  if (frozen) return FROZEN_TIME_MS;
  return realDateNow();
};

global.Date = class extends realDate {
  constructor(...args) {
    if (args.length === 0 && frozen) {
      super(FROZEN_TIME_MS);
    } else {
      super(...args);
    }
  }
  static now() {
    if (frozen) return FROZEN_TIME_MS;
    return realDateNow();
  }
};

global.setTimeout = function () {
  if (frozen) {
    throw new Error('silt determinism: setTimeout disabled in tests');
  }
  return realSetTimeout.apply(this, arguments);
};
global.setInterval = function () {
  if (frozen) {
    throw new Error('silt determinism: setInterval disabled in tests');
  }
  return realSetInterval.apply(this, arguments);
};
global.setImmediate = function () {
  if (frozen) {
    throw new Error('silt determinism: setImmediate disabled in tests');
  }
  return realSetImmediate.apply(this, arguments);
};

process.hrtime = function () {
  if (frozen) return FROZEN_HRTIME.slice();
  return realHrtime.apply(this, arguments);
};

if (global.performance && realPerfNow) {
  global.performance.now = function () {
    if (frozen) return 0;
    return realPerfNow();
  };
}

global.allowNondeterminism = function () {
  frozen = false;
};
global.revertNondeterminism = function () {
  frozen = true;
};
