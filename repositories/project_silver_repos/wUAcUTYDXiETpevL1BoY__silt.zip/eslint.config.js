// Flat config. Uses @typescript-eslint plus a small custom rule set
// from tools/lint-rules/ that enforces the determinism contract.
//
// The bans on Math.random / Date.now / setTimeout etc. apply only to
// core/ and modules/ source. tools/ and tests/ are exempt because the
// REPL needs real timing and the test setup file installs the stubs.

import tseslint from '@typescript-eslint/eslint-plugin';
import tsparser from '@typescript-eslint/parser';
import globals from 'globals';

export default [
  {
    files: ['**/*.ts'],
    languageOptions: {
      parser: tsparser,
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: 'module',
      },
      globals: { ...globals.node },
    },
    plugins: {
      '@typescript-eslint': tseslint,
    },
    rules: {
      'no-unused-vars': 'off',
      '@typescript-eslint/no-unused-vars': [
        'error',
        { argsIgnorePattern: '^_', varsIgnorePattern: '^_' },
      ],
      '@typescript-eslint/no-explicit-any': 'warn',
      '@typescript-eslint/consistent-type-imports': 'error',
      eqeqeq: ['error', 'always'],
      'no-var': 'error',
      'prefer-const': 'error',
    },
  },
  {
    files: ['core/**/*.ts', 'modules/**/*.ts'],
    ignores: ['**/*.spec.ts', '**/test-setup/**'],
    rules: {
      'no-restricted-globals': [
        'error',
        { name: 'setTimeout', message: 'silt determinism: no timers in core/modules' },
        { name: 'setInterval', message: 'silt determinism: no timers in core/modules' },
        { name: 'setImmediate', message: 'silt determinism: no timers in core/modules' },
      ],
      'no-restricted-properties': [
        'error',
        { object: 'Math', property: 'random', message: 'silt determinism: use core/random/Mulberry32 with an explicit seed' },
        { object: 'Date', property: 'now', message: 'silt determinism: no clock in core/modules' },
        { object: 'process', property: 'hrtime', message: 'silt determinism: no clock in core/modules' },
      ],
    },
  },
  {
    ignores: ['**/dist/**', '**/node_modules/**', 'tests/conformance/**/*.json'],
  },
];
