# TODO

A grab-bag of things I want to do but haven't. Not promises, not a
roadmap. Some of these are real bugs, some are speculative.

- [ ] gradcheck inner loop allocates a fresh array per dimension. For
      a 50-dim grad-check that's 50 allocs. Reusable scratch buffer
      should cut it. Bench shows ~12% time savings on the synthetic
      suite. (FIXME tagged in `modules/gradcheck/finite-diff.ts`)
- [ ] tape format v3 wrote node IDs as 53-bit; the v2 -> v3 migrator
      in `tools/migrate` doesn't yet handle the case where a v2 tape
      had >2^32 nodes (which shouldn't happen but should be a clear
      error rather than silent corruption)
- [ ] `lazy` mode currently materializes the whole tape on first
      backward call. A finer-grained "materialize only what's needed
      for these output nodes" would be nice but I don't have a
      concrete use-case driving it
- [ ] `optimizers/lbfgs` only supports unconstrained minimization.
      Adding box-bounds (L-BFGS-B) is straightforward; I just haven't
      needed it yet
- [ ] `hessian` builds the full dense matrix even for diagonal-heavy
      problems. A sparse-diagonal mode would help large MLPs but
      that's outside the "small networks" framing
- [ ] `visualize` outputs Graphviz dot. SVG export would be nicer for
      the README; deferred
- [ ] documentation: I keep meaning to write the "how forward-over-
      reverse computes Hessians" derivation in
      `docs/derivations/08-higher-order.md`. The math is in my head,
      not on paper
- [ ] CI: add a node 22 matrix entry. Currently only node 20.12.2.
      The test suite passes on 22 but I haven't pinned the
      matrix entry
- [ ] benchmark suite is sensitive to CPU thermals -- numbers vary
      ~5% on my laptop between cold and warm runs. Adding a warmup
      phase would make the regression-tracking less noisy
- [ ] the `cond` op's gradient routing through the unselected branch
      currently routes a literal zero. This is correct for first-
      order grads but causes the hessian to be non-symmetric in
      compositions involving `where(...)`. I have a sketch of a fix
      but haven't validated it; the symmetry violation is small
      enough that it doesn't break the existing optimizers
- [ ] add an op-fusion pass for chained elementwise ops? PyTorch does
      it; jax has explicit jit. silt probably shouldn't, given the
      "small surface, transparent internals" framing. Noting here so
      I remember the answer was no
