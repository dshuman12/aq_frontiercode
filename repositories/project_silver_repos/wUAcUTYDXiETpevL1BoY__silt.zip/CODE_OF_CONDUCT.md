# Code of Conduct

Be kind. Assume good faith. Don't be cruel.

If you have a problem with how someone in this project (currently just
the maintainer) is behaving, email asifhammad84@gmail.com with
specifics. I'll take it seriously.

This document is short on purpose. The longer version is "the standard
expectations of a small open-source project apply here" -- no
harassment, no discrimination, no personal attacks, blameless
post-mortems if anything goes wrong technically.
