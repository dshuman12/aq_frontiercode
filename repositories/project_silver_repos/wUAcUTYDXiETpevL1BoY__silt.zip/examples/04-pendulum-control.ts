// Toy pendulum-control example. Uses silt to differentiate a fixed-
// horizon rollout cost w.r.t. a parameterized control gain.
//
// Dynamics: theta'' = -g/L sin(theta) - k*theta'  (linear damping)
// We pick k via gradient descent to minimize integrated angular
// energy over a 100-step rollout.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul, sub } from '@silt/ops-elementary';
import { sin } from '@silt/ops-trig';
import { sumReduce } from '@silt/ops-reductions';
import { sgd } from '@silt/optimizers';

const N_STEPS = 100;
const dt = 0.05;
const G_OVER_L = 9.8;

let k = 0.1;

for (let outer = 0; outer < 50; outer++) {
  const t = new Tape();
  const kNode = t.leaf(k);
  // initial state: theta = 0.5, omega = 0
  let theta: import('@silt/core-types').NodeId = t.leaf(0.5);
  let omega: import('@silt/core-types').NodeId = t.leaf(0.0);
  const energies: import('@silt/core-types').NodeId[] = [];
  const dtN = t.const(dt);
  const gOverL = t.const(G_OVER_L);

  for (let i = 0; i < N_STEPS; i++) {
    const sinTh = sin(t, theta);
    const accel = sub(t, mul(t, t.const(-1), mul(t, gOverL, sinTh)), mul(t, kNode, omega));
    omega = add(t, omega, mul(t, accel, dtN));
    theta = add(t, theta, mul(t, omega, dtN));
    energies.push(mul(t, theta, theta));
  }
  const cost = sumReduce(t, ...energies);
  const grads = backward(t, cost);
  const g = grads.get(kNode);
  process.stdout.write(`iter ${outer}: k=${k.toFixed(4)}, cost=${t.valueOf(cost).toFixed(4)}, dC/dk=${g.toFixed(4)}\n`);
  sgd(new Float64Array([k]), new Float64Array([g]), { lr: 0.001 });
  k = k - 0.001 * g;
}
process.stdout.write(`final k = ${k}\n`);
