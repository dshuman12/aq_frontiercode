// Manual Newton step on a 1D problem.
//
// Find root of f(x) = x^3 - 2x - 5 using x_{n+1} = x_n - f / f'.
// silt provides f'.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { mul, sub } from '@silt/ops-elementary';

let x = 2.0;
for (let step = 0; step < 10; step++) {
  const t = new Tape();
  const xn = t.leaf(x);
  // f = x^3 - 2x - 5
  const x2 = mul(t, xn, xn);
  const x3 = mul(t, x2, xn);
  const f = sub(t, sub(t, x3, mul(t, t.const(2), xn)), t.const(5));
  const grads = backward(t, f);
  const fVal = t.valueOf(f);
  const fp = grads.get(xn);
  process.stdout.write(`step ${step}: x=${x.toFixed(8)}, f(x)=${fVal.toFixed(8)}, f'(x)=${fp.toFixed(4)}\n`);
  x = x - fVal / fp;
}
process.stdout.write(`final root estimate: ${x}\n`);
