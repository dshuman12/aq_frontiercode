// Tiny MLP on the XOR problem. 2-4-1 with tanh activation.
// 17 parameters, 1000 epochs, ~5s runtime on a laptop.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul, sub } from '@silt/ops-elementary';
import { tanhAct } from '@silt/ops-pieces';
import { sumReduce } from '@silt/ops-reductions';
import { sgd } from '@silt/optimizers';
import { Mulberry32, sampleUniform } from '@silt/core-random';

const HIDDEN = 4;
const N_PARAMS = 2 * HIDDEN + HIDDEN + HIDDEN + 1;

const X = [
  [0, 0],
  [0, 1],
  [1, 0],
  [1, 1],
];
const Y = [0, 1, 1, 0];

const rng = new Mulberry32(1234);
const params = new Float64Array(N_PARAMS);
for (let i = 0; i < N_PARAMS; i++) params[i] = sampleUniform(rng, -0.5, 0.5);

for (let epoch = 0; epoch < 1000; epoch++) {
  const t = new Tape();
  const p = Array.from({ length: N_PARAMS }, (_, i) => t.leaf(params[i]!));
  const losses: import('@silt/core-types').NodeId[] = [];
  for (let n = 0; n < X.length; n++) {
    const x0 = t.const(X[n]![0]!);
    const x1 = t.const(X[n]![1]!);
    const yT = t.const(Y[n]!);
    const hidden: import('@silt/core-types').NodeId[] = [];
    for (let j = 0; j < HIDDEN; j++) {
      const z = add(t, add(t, mul(t, x0, p[j]!), mul(t, x1, p[HIDDEN + j]!)), p[2 * HIDDEN + j]!);
      hidden.push(tanhAct(t, z));
    }
    const v2 = 3 * HIDDEN;
    let dot = mul(t, hidden[0]!, p[v2]!);
    for (let j = 1; j < HIDDEN; j++) dot = add(t, dot, mul(t, hidden[j]!, p[v2 + j]!));
    const pred = add(t, dot, p[v2 + HIDDEN]!);
    const err = sub(t, pred, yT);
    losses.push(mul(t, err, err));
  }
  const loss = sumReduce(t, ...losses);
  if (epoch % 100 === 0) process.stdout.write(`epoch ${epoch}: loss=${t.valueOf(loss).toFixed(5)}\n`);
  const grads = backward(t, loss);
  const g = new Float64Array(N_PARAMS);
  for (let i = 0; i < N_PARAMS; i++) g[i] = grads.get(p[i]!);
  sgd(params, g, { lr: 0.1 });
}
