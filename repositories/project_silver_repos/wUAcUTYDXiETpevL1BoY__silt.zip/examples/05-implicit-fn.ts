// Implicit-function example: differentiate the root of g(x; a) = 0
// w.r.t. parameter a, without ever computing the root in closed form.
//
// Equation: x^2 + a*x - 1 = 0 ; root x*(a) = (-a + sqrt(a^2 + 4)) / 2.
// dx*/da = (-1 + a / sqrt(a^2 + 4)) / 2.
//
// We compute the same dx*/da via Newton's method (which uses silt for
// f'(x)) and the implicit function theorem.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul, sub } from '@silt/ops-elementary';

function g(t: Tape, x: import('@silt/core-types').NodeId, a: import('@silt/core-types').NodeId): import('@silt/core-types').NodeId {
  // x^2 + a*x - 1
  return sub(t, add(t, mul(t, x, x), mul(t, a, x)), t.const(1));
}

const aValue = 1.5;
let xValue = 1.0;

// Newton's method using silt for the derivative.
for (let step = 0; step < 50; step++) {
  const t = new Tape();
  const xn = t.leaf(xValue);
  const an = t.leaf(aValue);
  const out = g(t, xn, an);
  const grads = backward(t, out);
  const f = t.valueOf(out);
  const fp = grads.get(xn);
  if (Math.abs(f) < 1e-12) break;
  xValue = xValue - f / fp;
}
process.stdout.write(`Root x* at a=${aValue}: ${xValue.toFixed(10)}\n`);

// Now compute dx*/da via implicit-function theorem:
//   g(x*, a) = 0 -> dx/da = -dg/da / dg/dx
const t = new Tape();
const xN = t.leaf(xValue);
const aN = t.leaf(aValue);
const gOut = g(t, xN, aN);
const grads = backward(t, gOut);
const dgdx = grads.get(xN);
const dgda = grads.get(aN);
const implicitDxDa = -dgda / dgdx;

const closedForm = (-1 + aValue / Math.sqrt(aValue * aValue + 4)) / 2;
process.stdout.write(`dx*/da via silt:        ${implicitDxDa.toFixed(10)}\n`);
process.stdout.write(`dx*/da closed form:     ${closedForm.toFixed(10)}\n`);
