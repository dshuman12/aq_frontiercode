// Fit y = a*x + b to a tiny dataset using gradient descent.
//
// Run: pnpm tsx examples/01-curve-fit.ts

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul, sub } from '@silt/ops-elementary';
import { sumReduce } from '@silt/ops-reductions';
import { sgd } from '@silt/optimizers';

const xs = [0, 1, 2, 3, 4, 5];
const ys = [1.1, 2.9, 5.0, 7.2, 9.0, 11.1]; // y ~ 2x + 1 + noise

const params = new Float64Array([0, 0]); // [a, b]

for (let step = 0; step < 200; step++) {
  const t = new Tape();
  const a = t.leaf(params[0]!);
  const b = t.leaf(params[1]!);
  const losses: import('@silt/core-types').NodeId[] = [];
  for (let i = 0; i < xs.length; i++) {
    const xi = t.const(xs[i]!);
    const yi = t.const(ys[i]!);
    const pred = add(t, mul(t, a, xi), b);
    const err = sub(t, pred, yi);
    losses.push(mul(t, err, err));
  }
  const loss = sumReduce(t, ...losses);
  const grads = backward(t, loss);
  sgd(params, new Float64Array([grads.get(a), grads.get(b)]), { lr: 0.01 });
  if (step % 20 === 0) {
    process.stdout.write(`step ${step}: loss=${t.valueOf(loss).toFixed(4)}, a=${params[0]!.toFixed(3)}, b=${params[1]!.toFixed(3)}\n`);
  }
}
process.stdout.write(`final: a=${params[0]!.toFixed(3)}, b=${params[1]!.toFixed(3)}\n`);
