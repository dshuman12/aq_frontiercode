# Contributing to silt

This is a solo project, but the contribution flow is documented in case
that ever changes.

## Setup

```
pnpm install --frozen-lockfile
pnpm build
pnpm test
```

You need Node 20.10+ and pnpm 9. CI runs against Node 20.12.2; if your
local Node differs, you may see slightly different stack traces but
the test suite must pass identically (that's the whole point of the
determinism contract).

## The determinism contract

Read `README.md` first if you haven't. Every PR that adds source code
to `core/` or `modules/` MUST:

1. Pass `pnpm lint`. The custom lint rule `no-nondeterminism` will
   reject `Math.random`, `Date.now`, `new Date()`, `setTimeout`,
   `setImmediate`, and `process.hrtime`.
2. Pass `pnpm test:twice`. CI runs the suite twice and diffs results.
   Anything that fails the diff is a determinism regression.
3. If your change adds a new op, the op MUST come with:
   - A forward implementation in the appropriate `modules/ops-*` module
   - A backward implementation in the same file
   - A `gradcheck` test asserting backward agrees with finite-
     difference at 1e-7 tolerance
   - At least one bit-exact entry in `tests/conformance/grad-corpus.json`

## Structure of an op

Every op file follows the same shape:

```ts
// modules/ops-trig/sin.ts

import type { Tape } from '@silt/core-tape';
import type { Scalar, NodeId } from '@silt/core-types';

export function sin(t: Tape, x: NodeId): NodeId {
  return t.append('sin', [x], (vals) => Math.sin(vals[0]!));
}

export function sinBackward(_inputs: number[], outputGrad: number, ctx: number[]): number[] {
  // d/dx sin(x) = cos(x); we use ctx[0] = stored input value.
  return [outputGrad * Math.cos(ctx[0]!)];
}
```

The forward function takes a tape and node IDs, returns a new node ID.
The backward function takes the stored input values, the output's
gradient, and op-specific context (typically the stored input values
again; other ops store partial intermediates), returns gradients to
propagate to each input.

Keep both functions in the same file. The op registry in
`modules/backward/op-registry.ts` ties them together by op kind.

## Test layout

Each module has its own `tests/` directory that mirrors `src/`. Test
files end in `.spec.ts`. Use `describe()` + `it()`; jest's other
conventions (`test.each`, etc.) are fine but most existing files use
`it`. The full suite runs in a single jest process via
`maxWorkers: 1` -- this is the test culture for determinism, not a
performance choice.

When you add a finite-difference gradient check, follow the existing
pattern in `modules/gradcheck/tests/sin.spec.ts`:

```ts
const epsilon = 1e-7;
for (const x of [0.1, 0.5, 1.0, -0.3, 2.7]) {
  const fd = (Math.sin(x + epsilon) - Math.sin(x - epsilon)) / (2 * epsilon);
  expect(forwardThenBackward(x)).toBeCloseTo(fd, 6);
}
```

`toBeCloseTo(fd, 6)` asserts agreement to 6 decimal places, which is
the right precision for a 1e-7 FD step.

## Commits and PRs

This is a solo repo so I just push to main. If that ever changes:

- Branch off `main`, branch name should be a short slug
- Keep commits focused; "add atan2 backward" not "various changes"
- Lowercase imperative subject lines, no `feat:` / `fix:` prefix
- Reference issues with `(#NN)` at the end of the subject if relevant

## License

By contributing you agree to license under MIT (`LICENSE`).
