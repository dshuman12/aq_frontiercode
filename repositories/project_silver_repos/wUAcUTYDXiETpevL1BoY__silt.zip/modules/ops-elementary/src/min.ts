// min(x, y) = whichever is smaller.
// d/dx = 1 if x < y else 0
// d/dy = 1 if y < x else 0
// On equality x == y we route 0.5 to each (matches what JAX does);
// strictly speaking any (a, 1-a) split is a valid subgradient.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const minHandler: OpHandler = {
  evalFn: (i) => Math.min(i[0]!, i[1]!),
  ctxFn: (i) => [i[0]!, i[1]!] as const,
};

export const minBackward: BackwardFn = (_inputs, gOut, _v, ctx) => {
  const [a, b] = ctx as readonly [number, number];
  if (a < b) return [gOut, 0];
  if (b < a) return [0, gOut];
  return [gOut * 0.5, gOut * 0.5];
};

export function min(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('min', [a, b], minHandler);
}
