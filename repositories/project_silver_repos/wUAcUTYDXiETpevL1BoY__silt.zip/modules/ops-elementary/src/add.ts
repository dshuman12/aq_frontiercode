// add(x, y) = x + y
// d/dx = 1 ; d/dy = 1
//
// No ctx needed: the partials are constant.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const addHandler: OpHandler = {
  evalFn: (i) => i[0]! + i[1]!,
};

export const addBackward: BackwardFn = (_inputs, gOut) => [gOut, gOut];

export function add(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('add', [a, b], addHandler);
}
