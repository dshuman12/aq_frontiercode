// neg(x) = -x ; d/dx = -1

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const negHandler: OpHandler = {
  evalFn: (i) => -i[0]!,
};

export const negBackward: BackwardFn = (_inputs, gOut) => [-gOut];

export function neg(t: Tape, a: NodeId): NodeId {
  return t.append('neg', [a], negHandler);
}
