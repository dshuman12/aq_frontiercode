// sign(x) = -1 / 0 / +1
// Gradient is zero almost everywhere; the discontinuity at 0 is
// formally a delta function which we cannot represent. We return 0
// for the subgradient. Callers using sign() in a loss should expect
// no useful gradient signal through it.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const signHandler: OpHandler = {
  evalFn: (i) => Math.sign(i[0]!),
};

export const signBackward: BackwardFn = (_inputs, _gOut) => [0];

export function sign(t: Tape, a: NodeId): NodeId {
  return t.append('sign', [a], signHandler);
}
