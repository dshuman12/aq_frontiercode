// div(x, y) = x / y
// d/dx = 1/y ; d/dy = -x / y^2
//
// Domain: y == 0 returns +/- Infinity from JS's IEEE-754 division.
// We don't add a runtime check; gradient at y == 0 is undefined and
// callers who care should add their own guard.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const divHandler: OpHandler = {
  evalFn: (i) => i[0]! / i[1]!,
  ctxFn: (i) => [i[0]!, i[1]!] as const,
};

export const divBackward: BackwardFn = (_inputs, gOut, _v, ctx) => {
  const [x, y] = ctx as readonly [number, number];
  return [gOut / y, (-gOut * x) / (y * y)];
};

export function div(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('div', [a, b], divHandler);
}
