// max(x, y) = whichever is larger.
// Symmetric to min: gradient routes to whichever input is larger,
// with 0.5/0.5 split on equality.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const maxHandler: OpHandler = {
  evalFn: (i) => Math.max(i[0]!, i[1]!),
  ctxFn: (i) => [i[0]!, i[1]!] as const,
};

export const maxBackward: BackwardFn = (_inputs, gOut, _v, ctx) => {
  const [a, b] = ctx as readonly [number, number];
  if (a > b) return [gOut, 0];
  if (b > a) return [0, gOut];
  return [gOut * 0.5, gOut * 0.5];
};

export function max(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('max', [a, b], maxHandler);
}
