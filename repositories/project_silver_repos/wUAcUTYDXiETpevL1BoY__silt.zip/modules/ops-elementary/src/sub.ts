// sub(x, y) = x - y
// d/dx = 1 ; d/dy = -1

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const subHandler: OpHandler = {
  evalFn: (i) => i[0]! - i[1]!,
};

export const subBackward: BackwardFn = (_inputs, gOut) => [gOut, -gOut];

export function sub(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('sub', [a, b], subHandler);
}
