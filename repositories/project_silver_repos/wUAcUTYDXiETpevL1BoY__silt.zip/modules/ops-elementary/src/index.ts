// Importing this module registers all elementary ops with the
// backward registry. Tests can `import '@silt/ops-elementary';` for
// the side-effect alone.

import './register.js';

export { add } from './add.js';
export { sub } from './sub.js';
export { mul } from './mul.js';
export { div } from './div.js';
export { neg } from './neg.js';
export { abs } from './abs.js';
export { sign } from './sign.js';
export { min } from './min.js';
export { max } from './max.js';
