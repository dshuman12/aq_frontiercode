// abs(x) = |x|
// d/dx = sign(x), with the subgradient at x == 0 conventionally taken
// to be 0 (the centered choice). Other choices (-1, +1) are also
// valid subgradients; we pin 0 so backward is deterministic.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const absHandler: OpHandler = {
  evalFn: (i) => Math.abs(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const absBackward: BackwardFn = (_inputs, gOut, _v, ctx) => {
  const x = ctx as number;
  if (x > 0) return [gOut];
  if (x < 0) return [-gOut];
  // x == 0: subgradient
  return [0];
};

export function abs(t: Tape, a: NodeId): NodeId {
  return t.append('abs', [a], absHandler);
}
