// Registers all elementary backward functions. This file is imported
// by index.ts for its side effect.

import { registerBackward } from '@silt/backward';
import { addBackward } from './add.js';
import { subBackward } from './sub.js';
import { mulBackward } from './mul.js';
import { divBackward } from './div.js';
import { negBackward } from './neg.js';
import { absBackward } from './abs.js';
import { signBackward } from './sign.js';
import { minBackward } from './min.js';
import { maxBackward } from './max.js';

registerBackward('add', addBackward);
registerBackward('sub', subBackward);
registerBackward('mul', mulBackward);
registerBackward('div', divBackward);
registerBackward('neg', negBackward);
registerBackward('abs', absBackward);
registerBackward('sign', signBackward);
registerBackward('min', minBackward);
registerBackward('max', maxBackward);
