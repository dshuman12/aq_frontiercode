// mul(x, y) = x * y
// d/dx = y ; d/dy = x
//
// We stash the input pair as ctx so backward doesn't need to re-read
// from the tape. Saves one t.valueOf() lookup per backward call -- not
// huge in isolation but the pattern matters when we get to matmul.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const mulHandler: OpHandler = {
  evalFn: (i) => i[0]! * i[1]!,
  ctxFn: (i) => [i[0]!, i[1]!] as const,
};

export const mulBackward: BackwardFn = (_inputs, gOut, _v, ctx) => {
  const [a, b] = ctx as readonly [number, number];
  return [gOut * b, gOut * a];
};

export function mul(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('mul', [a, b], mulHandler);
}
