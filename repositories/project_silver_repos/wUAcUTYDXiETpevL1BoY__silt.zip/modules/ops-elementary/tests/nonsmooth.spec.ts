import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { abs, sign, min, max } from '../src/index.js';

describe('abs', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(abs(t, t.leaf(-3)))).toBe(3);
    expect(t.valueOf(abs(t, t.leaf(3)))).toBe(3);
    expect(t.valueOf(abs(t, t.leaf(0)))).toBe(0);
  });

  it('backward at positive x: +1', () => {
    const t = tape();
    const x = t.leaf(2);
    const g = backward(t, abs(t, x));
    expect(g.get(x)).toBe(1);
  });

  it('backward at negative x: -1', () => {
    const t = tape();
    const x = t.leaf(-2);
    const g = backward(t, abs(t, x));
    expect(g.get(x)).toBe(-1);
  });

  it('backward at zero: subgradient = 0', () => {
    const t = tape();
    const x = t.leaf(0);
    const g = backward(t, abs(t, x));
    expect(g.get(x)).toBe(0);
  });
});

describe('sign', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(sign(t, t.leaf(3)))).toBe(1);
    expect(t.valueOf(sign(t, t.leaf(-3)))).toBe(-1);
    expect(t.valueOf(sign(t, t.leaf(0)))).toBe(0);
  });

  it('backward is zero everywhere', () => {
    for (const x of [-3, 0, 3]) {
      const t = tape();
      const a = t.leaf(x);
      const g = backward(t, sign(t, a));
      expect(g.get(a)).toBe(0);
    }
  });
});

describe('min', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(min(t, t.leaf(2), t.leaf(5)))).toBe(2);
  });

  it('routes gradient to the smaller input', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(5);
    const g = backward(t, min(t, x, y));
    expect(g.get(x)).toBe(1);
    expect(g.get(y)).toBe(0);
  });

  it('splits 50/50 on tie', () => {
    const t = tape();
    const x = t.leaf(3);
    const y = t.leaf(3);
    const g = backward(t, min(t, x, y));
    expect(g.get(x)).toBe(0.5);
    expect(g.get(y)).toBe(0.5);
  });
});

describe('max', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(max(t, t.leaf(2), t.leaf(5)))).toBe(5);
  });

  it('routes gradient to the larger input', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(5);
    const g = backward(t, max(t, x, y));
    expect(g.get(x)).toBe(0);
    expect(g.get(y)).toBe(1);
  });

  it('splits 50/50 on tie', () => {
    const t = tape();
    const x = t.leaf(7);
    const y = t.leaf(7);
    const g = backward(t, max(t, x, y));
    expect(g.get(x)).toBe(0.5);
    expect(g.get(y)).toBe(0.5);
  });
});
