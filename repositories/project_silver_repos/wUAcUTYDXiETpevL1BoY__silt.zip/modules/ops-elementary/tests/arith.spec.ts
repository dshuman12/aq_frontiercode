import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, sub, mul, div, neg } from '../src/index.js';

describe('add', () => {
  it('forward', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = add(t, x, y);
    expect(t.valueOf(z)).toBe(5);
  });

  it('backward: both partials are 1', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = add(t, x, y);
    const g = backward(t, z);
    expect(g.get(x)).toBe(1);
    expect(g.get(y)).toBe(1);
  });

  it('chain: add of add', () => {
    const t = tape();
    const x = t.leaf(1);
    const y = t.leaf(2);
    const w = t.leaf(3);
    const a = add(t, x, y);
    const b = add(t, a, w);
    expect(t.valueOf(b)).toBe(6);
    const g = backward(t, b);
    expect(g.get(x)).toBe(1);
    expect(g.get(y)).toBe(1);
    expect(g.get(w)).toBe(1);
  });
});

describe('sub', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(sub(t, t.leaf(5), t.leaf(3)))).toBe(2);
  });

  it('backward: +1 and -1', () => {
    const t = tape();
    const x = t.leaf(5);
    const y = t.leaf(3);
    const z = sub(t, x, y);
    const g = backward(t, z);
    expect(g.get(x)).toBe(1);
    expect(g.get(y)).toBe(-1);
  });
});

describe('mul', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(mul(t, t.leaf(3), t.leaf(4)))).toBe(12);
  });

  it('backward: product rule', () => {
    const t = tape();
    const x = t.leaf(3);
    const y = t.leaf(4);
    const z = mul(t, x, y);
    const g = backward(t, z);
    expect(g.get(x)).toBe(4);
    expect(g.get(y)).toBe(3);
  });

  it('chain: x*x backward gives 2x', () => {
    const t = tape();
    const x = t.leaf(5);
    const z = mul(t, x, x);
    const g = backward(t, z);
    expect(g.get(x)).toBe(10);
  });
});

describe('div', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(div(t, t.leaf(6), t.leaf(2)))).toBe(3);
  });

  it('backward: quotient rule', () => {
    const t = tape();
    const x = t.leaf(6);
    const y = t.leaf(2);
    const z = div(t, x, y);
    const g = backward(t, z);
    expect(g.get(x)).toBe(0.5); // 1/y
    expect(g.get(y)).toBe(-1.5); // -x/y^2 = -6/4
  });

  it('handles negative denominator', () => {
    const t = tape();
    const x = t.leaf(6);
    const y = t.leaf(-2);
    const z = div(t, x, y);
    expect(t.valueOf(z)).toBe(-3);
    const g = backward(t, z);
    expect(g.get(x)).toBe(-0.5);
    expect(g.get(y)).toBe(-1.5);
  });
});

describe('neg', () => {
  it('forward', () => {
    expect((() => {
      const t = tape();
      return t.valueOf(neg(t, t.leaf(7)));
    })()).toBe(-7);
  });

  it('backward: -1', () => {
    const t = tape();
    const x = t.leaf(7);
    const g = backward(t, neg(t, x));
    expect(g.get(x)).toBe(-1);
  });
});

describe('FD checks across the elementary set', () => {
  // Finite-difference check: backward should match (f(x+e) - f(x-e)) / 2e.
  // We compose two ops so the chain rule actually gets exercised.
  const epsilon = 1e-7;
  const places = 6;

  it('mul + add chain matches FD', () => {
    // f(x, y) = x*y + x ; df/dx = y + 1 ; df/dy = x
    const f = (x: number, y: number) => x * y + x;
    const fdx = (x: number, y: number) =>
      (f(x + epsilon, y) - f(x - epsilon, y)) / (2 * epsilon);
    const fdy = (x: number, y: number) =>
      (f(x, y + epsilon) - f(x, y - epsilon)) / (2 * epsilon);

    for (const x of [0.5, 1, -1, 2.7]) {
      for (const y of [0.3, -0.3, 4.0]) {
        const t = tape();
        const a = t.leaf(x);
        const b = t.leaf(y);
        const out = add(t, mul(t, a, b), a);
        const g = backward(t, out);
        expect(g.get(a)).toBeCloseTo(fdx(x, y), places);
        expect(g.get(b)).toBeCloseTo(fdy(x, y), places);
      }
    }
  });

  it('div FD check', () => {
    const f = (x: number, y: number) => x / y;
    const fdx = (x: number, y: number) =>
      (f(x + epsilon, y) - f(x - epsilon, y)) / (2 * epsilon);
    const fdy = (x: number, y: number) =>
      (f(x, y + epsilon) - f(x, y - epsilon)) / (2 * epsilon);

    for (const x of [1.0, 3.7, -2.5]) {
      for (const y of [0.4, -1.2, 5.0]) {
        const t = tape();
        const a = t.leaf(x);
        const b = t.leaf(y);
        const out = div(t, a, b);
        const g = backward(t, out);
        expect(g.get(a)).toBeCloseTo(fdx(x, y), places);
        expect(g.get(b)).toBeCloseTo(fdy(x, y), places);
      }
    }
  });
});
