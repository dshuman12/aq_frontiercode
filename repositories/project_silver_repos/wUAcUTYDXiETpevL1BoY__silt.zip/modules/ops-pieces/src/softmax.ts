// softmax over a list of NodeIds. Returns one NodeId per input.
//
// We compose this from primitive ops (max, sub, exp, sum, div) so the
// gradient comes from the existing backward pieces. The classic
// "subtract max for numerical stability" trick is in there.
//
// Formally:
//   softmax(x)_i = exp(x_i - max(x)) / sum_j exp(x_j - max(x))

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { sub, div } from '@silt/ops-elementary';
import { exp } from '@silt/ops-exponential';
import { maxReduce, sumReduce } from '@silt/ops-reductions';
import { broadcast } from '@silt/ops-broadcasting';

export function softmax(t: Tape, xs: readonly NodeId[]): NodeId[] {
  if (xs.length === 0) {
    throw new RangeError('softmax: needs at least one input');
  }
  const maxX = maxReduce(t, ...xs);
  const shifted = xs.map((x) => sub(t, x, maxX));
  const exps = shifted.map((x) => exp(t, x));
  const denom = sumReduce(t, ...exps);
  // We don't actually use the broadcast() helper here -- the same
  // denom is shared across all outputs by reusing its NodeId, which
  // is exactly what broadcast does.
  void broadcast;
  return exps.map((e) => div(t, e, denom));
}
