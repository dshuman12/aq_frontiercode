// relu(x) = max(0, x). Implemented as a primitive op with subgradient
// 0 at x = 0 (the conventional choice).

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const reluHandler: OpHandler = {
  evalFn: (i) => Math.max(0, i[0]!),
  ctxFn: (i) => i[0]!,
};

export const reluBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [x > 0 ? gOut : 0];
};

export function relu(t: Tape, a: NodeId): NodeId {
  return t.append('relu', [a], reluHandler);
}
