import { registerBackward } from '@silt/backward';
import '@silt/ops-elementary';
import '@silt/ops-exponential';
import '@silt/ops-reductions';
import '@silt/ops-broadcasting';
import { reluBackward } from './relu.js';
import { sigmoidBackward } from './sigmoid.js';
import { tanhActBackward } from './tanh-act.js';

registerBackward('relu', reluBackward);
registerBackward('sigmoid', sigmoidBackward);
registerBackward('tanh-act', tanhActBackward);
// softmax and log-sum-exp don't have their own op kind; they compose
// from registered primitives.
