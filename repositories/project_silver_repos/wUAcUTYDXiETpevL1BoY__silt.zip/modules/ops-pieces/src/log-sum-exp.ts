// logSumExp(xs) = log(sum_i exp(x_i))
//
// Numerically stable form:
//   m = max(xs)
//   logSumExp = m + log(sum_i exp(x_i - m))
//
// Composed from primitives so the gradient is automatic.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { add, sub } from '@silt/ops-elementary';
import { exp, log } from '@silt/ops-exponential';
import { maxReduce, sumReduce } from '@silt/ops-reductions';

export function logSumExp(t: Tape, xs: readonly NodeId[]): NodeId {
  if (xs.length === 0) {
    throw new RangeError('logSumExp: needs at least one input');
  }
  const m = maxReduce(t, ...xs);
  const shifted = xs.map((x) => sub(t, x, m));
  const exps = shifted.map((x) => exp(t, x));
  const summed = sumReduce(t, ...exps);
  return add(t, m, log(t, summed));
}
