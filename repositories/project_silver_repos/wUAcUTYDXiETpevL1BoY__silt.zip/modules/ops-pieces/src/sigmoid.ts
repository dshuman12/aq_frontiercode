// sigmoid(x) = 1 / (1 + exp(-x))
// d/dx = sigmoid(x) * (1 - sigmoid(x)) = v * (1 - v)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const sigmoidHandler: OpHandler = {
  evalFn: (i) => {
    const x = i[0]!;
    if (x >= 0) {
      const z = Math.exp(-x);
      return 1 / (1 + z);
    }
    // Numerically stable form for x < 0.
    const z = Math.exp(x);
    return z / (1 + z);
  },
};

export const sigmoidBackward: BackwardFn = (_i, gOut, v) => [gOut * v * (1 - v)];

export function sigmoid(t: Tape, a: NodeId): NodeId {
  return t.append('sigmoid', [a], sigmoidHandler);
}
