// tanhAct: same as @silt/ops-hyperbolic/tanh but registered as a
// distinct op kind ('tanh-act') so net code can be written in terms
// of activations without coupling to the hyperbolic-trig module.
//
// d/dx = 1 - tanh(x)^2 = 1 - v^2

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const tanhActHandler: OpHandler = {
  evalFn: (i) => Math.tanh(i[0]!),
};

export const tanhActBackward: BackwardFn = (_i, gOut, v) => [gOut * (1 - v * v)];

export function tanhAct(t: Tape, a: NodeId): NodeId {
  return t.append('tanh-act', [a], tanhActHandler);
}
