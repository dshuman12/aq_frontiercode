// Activation / loss-piece functions used by neural net code.

import './register.js';

export { relu } from './relu.js';
export { sigmoid } from './sigmoid.js';
export { tanhAct } from './tanh-act.js';
export { softmax } from './softmax.js';
export { logSumExp } from './log-sum-exp.js';
