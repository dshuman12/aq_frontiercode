import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { relu, sigmoid, tanhAct, softmax, logSumExp } from '../src/index.js';

describe('relu', () => {
  it('forward', () => {
    const t = new Tape();
    expect(t.valueOf(relu(t, t.leaf(2)))).toBe(2);
    expect(t.valueOf(relu(t, t.leaf(-2)))).toBe(0);
    expect(t.valueOf(relu(t, t.leaf(0)))).toBe(0);
  });

  it('backward at positive x = 1', () => {
    const t = new Tape();
    const x = t.leaf(2);
    expect(backward(t, relu(t, x)).get(x)).toBe(1);
  });

  it('backward at negative x = 0', () => {
    const t = new Tape();
    const x = t.leaf(-2);
    expect(backward(t, relu(t, x)).get(x)).toBe(0);
  });

  it('subgradient at 0 is 0', () => {
    const t = new Tape();
    const x = t.leaf(0);
    expect(backward(t, relu(t, x)).get(x)).toBe(0);
  });
});

describe('sigmoid', () => {
  it('forward at 0 is 0.5', () => {
    const t = new Tape();
    expect(t.valueOf(sigmoid(t, t.leaf(0)))).toBeCloseTo(0.5, 12);
  });

  it('forward bounded by 0 and 1', () => {
    const t = new Tape();
    expect(t.valueOf(sigmoid(t, t.leaf(100)))).toBeCloseTo(1, 12);
    expect(t.valueOf(sigmoid(t, t.leaf(-100)))).toBeCloseTo(0, 12);
  });

  it('numerically stable for large negative input', () => {
    const t = new Tape();
    const v = t.valueOf(sigmoid(t, t.leaf(-700)));
    expect(Number.isFinite(v)).toBe(true);
    expect(v).toBeGreaterThanOrEqual(0);
  });

  it('backward grad at 0 is 0.25', () => {
    const t = new Tape();
    const x = t.leaf(0);
    expect(backward(t, sigmoid(t, x)).get(x)).toBeCloseTo(0.25, 12);
  });
});

describe('tanhAct', () => {
  it('forward at 0 is 0', () => {
    const t = new Tape();
    expect(t.valueOf(tanhAct(t, t.leaf(0)))).toBe(0);
  });

  it('backward grad at 0 is 1', () => {
    const t = new Tape();
    const x = t.leaf(0);
    expect(backward(t, tanhAct(t, x)).get(x)).toBeCloseTo(1, 12);
  });
});

describe('softmax', () => {
  it('forward sums to 1', () => {
    const t = new Tape();
    const xs = [t.leaf(1), t.leaf(2), t.leaf(3)];
    const probs = softmax(t, xs);
    let sum = 0;
    for (const p of probs) sum += t.valueOf(p);
    expect(sum).toBeCloseTo(1, 12);
  });

  it('forward is non-negative', () => {
    const t = new Tape();
    const xs = [t.leaf(-1), t.leaf(0), t.leaf(1)];
    const probs = softmax(t, xs);
    for (const p of probs) expect(t.valueOf(p)).toBeGreaterThanOrEqual(0);
  });

  it('uniform input produces uniform output', () => {
    const t = new Tape();
    const xs = [t.leaf(5), t.leaf(5), t.leaf(5), t.leaf(5)];
    const probs = softmax(t, xs);
    for (const p of probs) expect(t.valueOf(p)).toBeCloseTo(0.25, 12);
  });

  it('numerically stable on large inputs', () => {
    const t = new Tape();
    const xs = [t.leaf(1000), t.leaf(1001), t.leaf(1002)];
    const probs = softmax(t, xs);
    for (const p of probs) {
      const v = t.valueOf(p);
      expect(Number.isFinite(v)).toBe(true);
      expect(v).toBeGreaterThan(0);
    }
  });

  it('refuses empty input', () => {
    expect(() => softmax(new Tape(), [])).toThrow(RangeError);
  });
});

describe('logSumExp', () => {
  it('forward matches log(sum(exp))', () => {
    const t = new Tape();
    const xs = [t.leaf(1), t.leaf(2), t.leaf(3)];
    const ref = Math.log(Math.exp(1) + Math.exp(2) + Math.exp(3));
    expect(t.valueOf(logSumExp(t, xs))).toBeCloseTo(ref, 12);
  });

  it('numerically stable on huge inputs', () => {
    const t = new Tape();
    const xs = [t.leaf(1000), t.leaf(1001)];
    const v = t.valueOf(logSumExp(t, xs));
    expect(Number.isFinite(v)).toBe(true);
    expect(v).toBeGreaterThan(1000);
    expect(v).toBeLessThan(1003);
  });

  it('refuses empty input', () => {
    expect(() => logSumExp(new Tape(), [])).toThrow(RangeError);
  });
});
