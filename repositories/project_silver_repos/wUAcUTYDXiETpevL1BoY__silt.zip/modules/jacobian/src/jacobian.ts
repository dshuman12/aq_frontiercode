import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';

// Returns J where J[i][j] = d outputs[i] / d leaves[j].
export function jacobian(
  t: Tape,
  outputs: readonly NodeId[],
  leaves: readonly NodeId[],
): number[][] {
  const J: number[][] = [];
  for (let i = 0; i < outputs.length; i++) {
    J.push(jacobianRow(t, outputs[i]!, leaves));
  }
  return J;
}

// Single row: gradient of one output w.r.t. all leaves.
export function jacobianRow(
  t: Tape,
  output: NodeId,
  leaves: readonly NodeId[],
): number[] {
  const grads = backward(t, output);
  const row = new Array<number>(leaves.length);
  for (let j = 0; j < leaves.length; j++) row[j] = grads.get(leaves[j]!);
  return row;
}
