// Jacobian: matrix of partials d_y_i / d_x_j over multiple outputs.
//
// Implementation: for each output, do a backward pass and read the
// gradient w.r.t. each leaf. This is M backwards for an M-output
// function. The earlier vmap-of-grad sketch was meant to share work
// across outputs but the current per-output implementation is simpler
// and the bench shows it's competitive on small problems.

export { jacobian, jacobianRow } from './jacobian.js';
