import { Tape } from '@silt/core-tape';
import { add, mul } from '@silt/ops-elementary';
import { sin, cos } from '@silt/ops-trig';
import { jacobian, jacobianRow } from '../src/index.js';

describe('jacobian', () => {
  it('linear map: y = Wx -> J is W', () => {
    // y_0 = 2*x_0 + 3*x_1
    // y_1 = x_0 - x_1
    const t = new Tape();
    const x0 = t.leaf(1);
    const x1 = t.leaf(2);
    const c2 = t.const(2);
    const c3 = t.const(3);
    const y0 = add(t, mul(t, c2, x0), mul(t, c3, x1));
    const y1 = add(t, x0, mul(t, t.const(-1), x1));
    const J = jacobian(t, [y0, y1], [x0, x1]);
    expect(J[0]).toEqual([2, 3]);
    expect(J[1]).toEqual([1, -1]);
  });

  it('jacobianRow returns one row', () => {
    const t = new Tape();
    const x = t.leaf(0.5);
    const out = sin(t, x);
    expect(jacobianRow(t, out, [x])[0]).toBeCloseTo(Math.cos(0.5), 12);
  });

  it('nonlinear: y_0 = sin(x), y_1 = cos(x)', () => {
    const t = new Tape();
    const x = t.leaf(0.3);
    const y0 = sin(t, x);
    const y1 = cos(t, x);
    const J = jacobian(t, [y0, y1], [x]);
    expect(J[0]![0]).toBeCloseTo(Math.cos(0.3), 12);
    expect(J[1]![0]).toBeCloseTo(-Math.sin(0.3), 12);
  });

  it('size matches outputs x leaves', () => {
    const t = new Tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.leaf(3);
    const out = add(t, add(t, a, b), c);
    const J = jacobian(t, [out], [a, b, c]);
    expect(J).toHaveLength(1);
    expect(J[0]).toHaveLength(3);
  });
});
