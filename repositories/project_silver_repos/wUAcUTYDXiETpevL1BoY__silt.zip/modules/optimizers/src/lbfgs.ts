// L-BFGS limited-memory quasi-Newton. We implement the two-loop
// recursion (Nocedal 1980).
//
// State holds m most recent (s_k, y_k, rho_k) triples in ring buffers.
// This is a minimal, unconstrained implementation -- L-BFGS-B (with
// box bounds) is on the TODO list.

export interface LBFGSOptions {
  // History size. Default 5.
  m?: number;
  // Step size. Default 1.0.
  lr?: number;
  // Persistent state.
  state: LBFGSState;
}

export interface LBFGSState {
  // Ring buffers of size m
  s: Float64Array[];
  y: Float64Array[];
  rho: number[];
  // Last gradient seen, used to compute y_k = grad - prevGrad
  prevGrad: Float64Array | null;
  // Last params seen, used to compute s_k = params - prevParams
  prevParams: Float64Array | null;
  // Position in ring buffer
  cursor: number;
  // Filled count (<= m)
  count: number;
}

export function newLBFGSState(_n: number, m = 5): LBFGSState {
  return {
    s: new Array(m).fill(null) as Float64Array[],
    y: new Array(m).fill(null) as Float64Array[],
    rho: new Array(m).fill(0),
    prevGrad: null,
    prevParams: null,
    cursor: 0,
    count: 0,
  };
}

export function lbfgs(
  params: Float64Array,
  grads: Float64Array,
  opts: LBFGSOptions,
): void {
  const m = opts.m ?? 5;
  const lr = opts.lr ?? 1.0;
  const state = opts.state;
  const n = params.length;
  if (grads.length !== n) {
    throw new RangeError('lbfgs: grads/params length mismatch');
  }

  // 1. If we have a prevGrad, store the new (s, y) pair.
  if (state.prevGrad !== null && state.prevParams !== null) {
    const sNew = new Float64Array(n);
    const yNew = new Float64Array(n);
    for (let i = 0; i < n; i++) {
      sNew[i] = params[i]! - state.prevParams[i]!;
      yNew[i] = grads[i]! - state.prevGrad[i]!;
    }
    let dot = 0;
    for (let i = 0; i < n; i++) dot += sNew[i]! * yNew[i]!;
    if (dot > 1e-30) {
      state.s[state.cursor] = sNew;
      state.y[state.cursor] = yNew;
      state.rho[state.cursor] = 1 / dot;
      state.cursor = (state.cursor + 1) % m;
      if (state.count < m) state.count += 1;
    }
  }

  // 2. Two-loop recursion to compute search direction q = -H * grad.
  const q = new Float64Array(n);
  for (let i = 0; i < n; i++) q[i] = grads[i]!;
  const alpha = new Array<number>(state.count).fill(0);

  // Walk from newest to oldest.
  for (let k = state.count - 1; k >= 0; k--) {
    const idx = (state.cursor - 1 - (state.count - 1 - k) + m) % m;
    const s = state.s[idx]!;
    const y = state.y[idx]!;
    const rho = state.rho[idx]!;
    let sq = 0;
    for (let i = 0; i < n; i++) sq += s[i]! * q[i]!;
    alpha[k] = rho * sq;
    for (let i = 0; i < n; i++) q[i]! -= alpha[k]! * y[i]!;
  }

  // Initial Hessian approximation: scaled identity.
  let gamma = 1;
  if (state.count > 0) {
    const idx = (state.cursor - 1 + m) % m;
    const s = state.s[idx]!;
    const y = state.y[idx]!;
    let sy = 0;
    let yy = 0;
    for (let i = 0; i < n; i++) {
      sy += s[i]! * y[i]!;
      yy += y[i]! * y[i]!;
    }
    if (yy > 1e-30) gamma = sy / yy;
  }
  for (let i = 0; i < n; i++) q[i] = q[i]! * gamma;

  // Walk from oldest to newest.
  for (let k = 0; k < state.count; k++) {
    const idx = (state.cursor - 1 - (state.count - 1 - k) + m) % m;
    const s = state.s[idx]!;
    const y = state.y[idx]!;
    const rho = state.rho[idx]!;
    let yq = 0;
    for (let i = 0; i < n; i++) yq += y[i]! * q[i]!;
    const beta = rho * yq;
    for (let i = 0; i < n; i++) q[i]! += s[i]! * (alpha[k]! - beta);
  }

  // 3. Update params: x = x - lr * q. Save prev.
  state.prevParams = new Float64Array(params);
  state.prevGrad = new Float64Array(grads);
  for (let i = 0; i < n; i++) params[i]! -= lr * q[i]!;
}

void newLBFGSState;
