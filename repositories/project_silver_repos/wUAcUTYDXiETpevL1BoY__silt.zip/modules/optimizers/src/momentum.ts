// SGD with classical momentum.

export interface MomentumOptions {
  lr: number;
  beta: number;
  // Persistent velocity state. Caller owns it; size must match params.
  velocity: Float64Array;
}

export function momentum(
  params: Float64Array,
  grads: Float64Array,
  opts: MomentumOptions,
): void {
  if (params.length !== grads.length || params.length !== opts.velocity.length) {
    throw new RangeError('momentum: params/grads/velocity length mismatch');
  }
  const { lr, beta, velocity } = opts;
  for (let i = 0; i < params.length; i++) {
    velocity[i] = beta * velocity[i]! + grads[i]!;
    params[i]! -= lr * velocity[i]!;
  }
}
