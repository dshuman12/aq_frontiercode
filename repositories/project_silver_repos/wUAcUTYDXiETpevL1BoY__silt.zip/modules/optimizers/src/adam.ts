// Adam (Kingma & Ba 2014).
//
// State carries first and second moment estimates plus the iteration
// counter `t` used for bias correction.

export interface AdamOptions {
  lr: number;
  beta1: number;
  beta2: number;
  epsilon: number;
  state: AdamState;
}

export interface AdamState {
  m: Float64Array;
  v: Float64Array;
  t: number;
}

export function adam(
  params: Float64Array,
  grads: Float64Array,
  opts: AdamOptions,
): void {
  const { lr, beta1, beta2, epsilon, state } = opts;
  if (
    params.length !== grads.length ||
    params.length !== state.m.length ||
    params.length !== state.v.length
  ) {
    throw new RangeError('adam: parameter/state length mismatch');
  }
  state.t += 1;
  const bc1 = 1 - Math.pow(beta1, state.t);
  const bc2 = 1 - Math.pow(beta2, state.t);
  for (let i = 0; i < params.length; i++) {
    const g = grads[i]!;
    state.m[i] = beta1 * state.m[i]! + (1 - beta1) * g;
    state.v[i] = beta2 * state.v[i]! + (1 - beta2) * g * g;
    const mHat = state.m[i]! / bc1;
    const vHat = state.v[i]! / bc2;
    params[i]! -= (lr * mHat) / (Math.sqrt(vHat) + epsilon);
  }
}

// Build a fresh AdamState sized for `n` parameters.
export function newAdamState(n: number): AdamState {
  return {
    m: new Float64Array(n),
    v: new Float64Array(n),
    t: 0,
  };
}

// Reset moment estimates and the iteration counter. The counter going
// back to 0 is convenient for resuming a fresh problem on the same
// parameter vector. Note that this means `currentStep` reported by
// the next call will be 1, not 1 + the previous count.
export function resetAdamState(state: AdamState): void {
  state.m.fill(0);
  state.v.fill(0);
  state.t = 0;
}

export function currentStep(state: AdamState): number {
  return state.t;
}

void newAdamState;
void resetAdamState;
void currentStep;
