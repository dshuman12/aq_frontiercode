// Plain stochastic gradient descent. Stateless.

export interface SGDOptions {
  lr: number;
}

export function sgd(params: Float64Array, grads: Float64Array, opts: SGDOptions): void {
  if (params.length !== grads.length) {
    throw new RangeError(`sgd: params/grads length mismatch ${params.length} vs ${grads.length}`);
  }
  const lr = opts.lr;
  for (let i = 0; i < params.length; i++) {
    params[i]! -= lr * grads[i]!;
  }
}
