// Optimizers operate on plain Float64Array parameter vectors.
// They consume a gradient and produce an in-place update.
//
// silt does NOT couple optimizers to the tape: the typical training
// loop builds a fresh tape per step, calls backward(), reads grads
// into a plain array, hands them to the optimizer, and reads back
// updated params. This decoupling lets the same optimizer drive
// gradient-based search problems that don't use a tape at all
// (e.g. gradcheck-driven calibration).

export { sgd, type SGDOptions } from './sgd.js';
export { momentum, type MomentumOptions } from './momentum.js';
export { adam, type AdamOptions, type AdamState } from './adam.js';
export { lbfgs, type LBFGSOptions } from './lbfgs.js';
