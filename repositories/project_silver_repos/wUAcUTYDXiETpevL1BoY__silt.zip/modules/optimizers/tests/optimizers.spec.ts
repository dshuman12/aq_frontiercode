import { sgd } from '../src/sgd.js';
import { momentum } from '../src/momentum.js';
import { adam } from '../src/adam.js';
import { lbfgs } from '../src/lbfgs.js';

describe('sgd', () => {
  it('takes a step in the negative-grad direction', () => {
    const params = new Float64Array([1, 2, 3]);
    const grads = new Float64Array([0.1, 0.2, 0.3]);
    sgd(params, grads, { lr: 0.5 });
    expect(Array.from(params)).toEqual([0.95, 1.9, 2.85]);
  });

  it('zero grads = no movement', () => {
    const params = new Float64Array([1, 2, 3]);
    sgd(params, new Float64Array([0, 0, 0]), { lr: 0.5 });
    expect(Array.from(params)).toEqual([1, 2, 3]);
  });

  it('errors on length mismatch', () => {
    expect(() =>
      sgd(new Float64Array([1, 2]), new Float64Array([0.1]), { lr: 0.1 }),
    ).toThrow(RangeError);
  });

  it('converges on a 1D quadratic', () => {
    // f(x) = 0.5 * x^2 ; df/dx = x ; minimum at 0
    const params = new Float64Array([10]);
    for (let step = 0; step < 200; step++) {
      sgd(params, new Float64Array([params[0]!]), { lr: 0.1 });
    }
    expect(Math.abs(params[0]!)).toBeLessThan(1e-6);
  });
});

describe('momentum', () => {
  it('uses velocity buffer', () => {
    const params = new Float64Array([1, 1]);
    const velocity = new Float64Array([0, 0]);
    momentum(params, new Float64Array([1, 1]), { lr: 0.1, beta: 0.9, velocity });
    // velocity becomes 1, 1 ; params decrease by 0.1
    expect(velocity[0]).toBe(1);
    expect(params[0]).toBeCloseTo(0.9, 12);
  });

  it('errors on length mismatch', () => {
    expect(() =>
      momentum(new Float64Array(2), new Float64Array(2), {
        lr: 0.1,
        beta: 0.9,
        velocity: new Float64Array(3),
      }),
    ).toThrow(RangeError);
  });
});

describe('adam', () => {
  it('takes a step', () => {
    const params = new Float64Array([1]);
    const m = new Float64Array([0]);
    const v = new Float64Array([0]);
    adam(params, new Float64Array([1]), {
      lr: 0.1,
      beta1: 0.9,
      beta2: 0.999,
      epsilon: 1e-8,
      state: { m, v, t: 0 },
    });
    expect(params[0]).toBeLessThan(1);
  });

  it('iteration counter increments', () => {
    const state = { m: new Float64Array(1), v: new Float64Array(1), t: 0 };
    const params = new Float64Array([0.5]);
    adam(params, new Float64Array([0.1]), {
      lr: 0.01,
      beta1: 0.9,
      beta2: 0.999,
      epsilon: 1e-8,
      state,
    });
    expect(state.t).toBe(1);
    adam(params, new Float64Array([0.1]), {
      lr: 0.01,
      beta1: 0.9,
      beta2: 0.999,
      epsilon: 1e-8,
      state,
    });
    expect(state.t).toBe(2);
  });

  it('converges on 1D quadratic', () => {
    const params = new Float64Array([10]);
    const state = { m: new Float64Array(1), v: new Float64Array(1), t: 0 };
    for (let step = 0; step < 1000; step++) {
      adam(params, new Float64Array([params[0]!]), {
        lr: 0.1,
        beta1: 0.9,
        beta2: 0.999,
        epsilon: 1e-8,
        state,
      });
    }
    expect(Math.abs(params[0]!)).toBeLessThan(1e-3);
  });
});

describe('lbfgs', () => {
  it('takes initial step (steepest descent first iter)', () => {
    const params = new Float64Array([5, 5]);
    const state = {
      s: [],
      y: [],
      rho: [],
      prevGrad: null,
      prevParams: null,
      cursor: 0,
      count: 0,
    } as never;
    lbfgs(params, new Float64Array([1, 1]), { state });
    expect(params[0]).toBeLessThan(5);
    expect(params[1]).toBeLessThan(5);
  });

  it('converges on 2D quadratic faster than SGD', () => {
    // f(x, y) = x^2 + y^2 ; minimum at origin
    const params = new Float64Array([3, 4]);
    const state = {
      s: new Array(5).fill(null),
      y: new Array(5).fill(null),
      rho: new Array(5).fill(0),
      prevGrad: null,
      prevParams: null,
      cursor: 0,
      count: 0,
    } as never;
    for (let i = 0; i < 30; i++) {
      const grads = new Float64Array([2 * params[0]!, 2 * params[1]!]);
      lbfgs(params, grads, { state, lr: 0.5 });
    }
    expect(Math.abs(params[0]!)).toBeLessThan(1e-3);
    expect(Math.abs(params[1]!)).toBeLessThan(1e-3);
  });
});
