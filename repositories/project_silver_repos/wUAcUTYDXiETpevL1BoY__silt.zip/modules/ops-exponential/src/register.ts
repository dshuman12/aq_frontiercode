import { registerBackward } from '@silt/backward';
import { expBackward } from './exp.js';
import { logBackward } from './log.js';
import { log1pBackward } from './log1p.js';
import { expm1Backward } from './expm1.js';
import { powBackward } from './pow.js';
import { sqrtBackward } from './sqrt.js';
import { cbrtBackward } from './cbrt.js';

registerBackward('exp', expBackward);
registerBackward('log', logBackward);
registerBackward('log1p', log1pBackward);
registerBackward('expm1', expm1Backward);
registerBackward('pow', powBackward);
registerBackward('sqrt', sqrtBackward);
registerBackward('cbrt', cbrtBackward);
