// cbrt(x) = x^(1/3) ; d/dx = 1 / (3 * x^(2/3)) = 1 / (3 * v^2)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const cbrtHandler: OpHandler = {
  evalFn: (i) => Math.cbrt(i[0]!),
};

export const cbrtBackward: BackwardFn = (_i, gOut, v) => [gOut / (3 * v * v)];

export function cbrt(t: Tape, a: NodeId): NodeId {
  return t.append('cbrt', [a], cbrtHandler);
}
