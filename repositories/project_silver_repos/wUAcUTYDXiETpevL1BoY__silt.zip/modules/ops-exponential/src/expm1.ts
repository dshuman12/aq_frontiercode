// expm1(x) = exp(x) - 1 ; d/dx = exp(x) = forward + 1

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const expm1Handler: OpHandler = {
  evalFn: (i) => Math.expm1(i[0]!),
};

export const expm1Backward: BackwardFn = (_i, gOut, v) => [gOut * (v + 1)];

export function expm1(t: Tape, a: NodeId): NodeId {
  return t.append('expm1', [a], expm1Handler);
}
