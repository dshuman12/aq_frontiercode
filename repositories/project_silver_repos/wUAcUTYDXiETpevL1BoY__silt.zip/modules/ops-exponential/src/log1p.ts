// log1p(x) = log(1 + x) ; d/dx = 1 / (1 + x)
// More accurate than log(1 + x) for small x.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const log1pHandler: OpHandler = {
  evalFn: (i) => Math.log1p(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const log1pBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [gOut / (1 + x)];
};

export function log1p(t: Tape, a: NodeId): NodeId {
  return t.append('log1p', [a], log1pHandler);
}
