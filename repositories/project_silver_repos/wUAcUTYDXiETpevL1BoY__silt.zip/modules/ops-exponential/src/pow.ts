// pow(base, exp) = base^exp
// Partials:
//   d/dbase = exp * base^(exp - 1)
//   d/dexp  = base^exp * log(base) = v * log(base)
//
// The d/dexp expression requires base > 0. For base <= 0 the gradient
// w.r.t. exp is undefined or non-real; we return NaN in that case
// rather than silently lying.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const powHandler: OpHandler = {
  evalFn: (i) => Math.pow(i[0]!, i[1]!),
  ctxFn: (i) => [i[0]!, i[1]!] as const,
};

export const powBackward: BackwardFn = (_i, gOut, v, ctx) => {
  const [base, expVal] = ctx as readonly [number, number];
  const dBase = expVal * Math.pow(base, expVal - 1);
  const dExp = base > 0 ? v * Math.log(base) : Number.NaN;
  return [gOut * dBase, gOut * dExp];
};

export function pow(t: Tape, base: NodeId, exp: NodeId): NodeId {
  return t.append('pow', [base, exp], powHandler);
}
