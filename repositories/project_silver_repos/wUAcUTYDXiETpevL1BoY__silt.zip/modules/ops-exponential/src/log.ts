// log(x) (natural) ; d/dx = 1/x

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const logHandler: OpHandler = {
  evalFn: (i) => Math.log(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const logBackward: BackwardFn = (_i, gOut, _v, ctx) => [gOut / (ctx as number)];

export function log(t: Tape, a: NodeId): NodeId {
  return t.append('log', [a], logHandler);
}
