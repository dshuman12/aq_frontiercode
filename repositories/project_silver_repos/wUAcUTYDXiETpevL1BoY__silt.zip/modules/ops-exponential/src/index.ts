import './register.js';

export { exp } from './exp.js';
export { log } from './log.js';
export { log1p } from './log1p.js';
export { expm1 } from './expm1.js';
export { pow } from './pow.js';
export { sqrt } from './sqrt.js';
export { cbrt } from './cbrt.js';

// Earlier prototype: a "scaled exp" (expm2 = e^x - 2). Kept the math
// here in case I come back to it; the forward is fine but the backward
// has a sign issue that I never tracked down. Out of scope.
//
// const expm2Handler = {
//   evalFn: (i) => Math.exp(i[0]!) - 2,
//   ctxFn: (i) => Math.exp(i[0]!),
// };
// const expm2Backward = (_i, gOut, _v, ctx) => [-gOut * (ctx as number)];
