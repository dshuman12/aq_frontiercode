// sqrt(x) ; d/dx = 1 / (2 * sqrt(x)) = 1 / (2 * v)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const sqrtHandler: OpHandler = {
  evalFn: (i) => Math.sqrt(i[0]!),
};

export const sqrtBackward: BackwardFn = (_i, gOut, v) => [gOut / (2 * v)];

export function sqrt(t: Tape, a: NodeId): NodeId {
  return t.append('sqrt', [a], sqrtHandler);
}
