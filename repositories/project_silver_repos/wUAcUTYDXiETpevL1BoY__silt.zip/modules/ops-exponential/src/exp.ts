// exp(x) ; d/dx = exp(x). The forward output IS the derivative; we
// don't need separate ctx.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const expHandler: OpHandler = {
  evalFn: (i) => Math.exp(i[0]!),
};

export const expBackward: BackwardFn = (_i, gOut, v) => [gOut * v];

export function exp(t: Tape, a: NodeId): NodeId {
  return t.append('exp', [a], expHandler);
}
