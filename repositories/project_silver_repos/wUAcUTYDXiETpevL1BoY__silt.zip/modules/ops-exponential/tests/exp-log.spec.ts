import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { exp, log, log1p, expm1, sqrt, cbrt } from '../src/index.js';

const epsilon = 1e-7;
const places = 6;

function fdCheck(
  f: (x: number) => number,
  bldr: (t: ReturnType<typeof tape>, x: number) => number,
  xs: number[],
): void {
  for (const x of xs) {
    const fd = (f(x + epsilon) - f(x - epsilon)) / (2 * epsilon);
    const t = tape();
    const a = t.leaf(x);
    const out = bldr(t, a as never);
    const g = backward(t, out as never);
    expect(g.get(a)).toBeCloseTo(fd, places);
  }
}

describe('exp', () => {
  it('forward at 0 is 1', () => {
    expect(((t) => t.valueOf(exp(t, t.leaf(0))))(tape())).toBe(1);
  });
  it('FD check', () => {
    fdCheck(Math.exp, (t, x) => exp(t, x as never), [-2, -0.5, 0, 0.5, 2]);
  });
});

describe('log', () => {
  it('forward at 1 is 0', () => {
    expect(((t) => t.valueOf(log(t, t.leaf(1))))(tape())).toBe(0);
  });
  it('FD check on positive x', () => {
    fdCheck(Math.log, (t, x) => log(t, x as never), [0.5, 1, 2, 10, 100]);
  });
});

describe('log1p', () => {
  it('forward at 0 is 0', () => {
    expect(((t) => t.valueOf(log1p(t, t.leaf(0))))(tape())).toBe(0);
  });
  it('FD check', () => {
    fdCheck(Math.log1p, (t, x) => log1p(t, x as never), [-0.5, 0, 0.5, 2]);
  });
  it('agrees with log(1+x) on tiny x at higher precision', () => {
    const t = tape();
    const x = t.leaf(1e-10);
    const out = log1p(t, x);
    expect(t.valueOf(out)).toBeCloseTo(1e-10, 18);
  });
});

describe('expm1', () => {
  it('forward at 0 is 0', () => {
    expect(((t) => t.valueOf(expm1(t, t.leaf(0))))(tape())).toBe(0);
  });
  it('FD check', () => {
    fdCheck(Math.expm1, (t, x) => expm1(t, x as never), [-0.5, 0, 0.5]);
  });
});

describe('sqrt', () => {
  it('forward', () => {
    expect(((t) => t.valueOf(sqrt(t, t.leaf(9))))(tape())).toBe(3);
  });
  it('FD check', () => {
    fdCheck(Math.sqrt, (t, x) => sqrt(t, x as never), [0.25, 1, 4, 100]);
  });
});

describe('cbrt', () => {
  it('forward', () => {
    expect(((t) => t.valueOf(cbrt(t, t.leaf(8))))(tape())).toBeCloseTo(2, 12);
  });
  it('FD check', () => {
    fdCheck(Math.cbrt, (t, x) => cbrt(t, x as never), [0.125, 1, 8, 27]);
  });
});
