import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { pow } from '../src/index.js';

const epsilon = 1e-6;
const places = 5;

describe('pow', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(pow(t, t.leaf(2), t.leaf(3)))).toBeCloseTo(8, 12);
  });

  it('forward with non-integer exponent', () => {
    const t = tape();
    expect(t.valueOf(pow(t, t.leaf(4), t.leaf(0.5)))).toBeCloseTo(2, 12);
  });

  it('partial w.r.t. base on positive base', () => {
    // d/dbase (b^e) = e * b^(e-1)
    for (const [b, e] of [
      [2, 3],
      [3, 2],
      [1.5, 2.5],
    ]) {
      const t = tape();
      const base = t.leaf(b!);
      const exp = t.leaf(e!);
      const g = backward(t, pow(t, base, exp));
      const fd = (Math.pow(b! + epsilon, e!) - Math.pow(b! - epsilon, e!)) / (2 * epsilon);
      expect(g.get(base)).toBeCloseTo(fd, places);
    }
  });

  it('partial w.r.t. exponent on positive base', () => {
    // d/dexp (b^e) = b^e * log(b)
    for (const [b, e] of [
      [2, 3],
      [3, 2],
      [1.5, 2.5],
    ]) {
      const t = tape();
      const base = t.leaf(b!);
      const exp = t.leaf(e!);
      const g = backward(t, pow(t, base, exp));
      const fd = (Math.pow(b!, e! + epsilon) - Math.pow(b!, e! - epsilon)) / (2 * epsilon);
      expect(g.get(exp)).toBeCloseTo(fd, places);
    }
  });

  it('partial w.r.t. exponent is NaN for non-positive base', () => {
    const t = tape();
    const base = t.leaf(-2);
    const exp = t.leaf(3);
    const g = backward(t, pow(t, base, exp));
    expect(Number.isNaN(g.get(exp))).toBe(true);
  });
});
