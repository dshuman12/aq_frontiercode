import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { sinh, cosh, tanh, asinh, acosh, atanh } from '../src/index.js';

const epsilon = 1e-7;
const places = 6;

function fdCheck(
  f: (x: number) => number,
  bldr: (t: ReturnType<typeof tape>, x: number) => number,
  xs: number[],
): void {
  for (const x of xs) {
    const fd = (f(x + epsilon) - f(x - epsilon)) / (2 * epsilon);
    const t = tape();
    const a = t.leaf(x);
    const out = bldr(t, a as never);
    const g = backward(t, out as never);
    expect(g.get(a)).toBeCloseTo(fd, places);
  }
}

describe('sinh', () => {
  it('forward', () => {
    expect(((t) => t.valueOf(sinh(t, t.leaf(0))))(tape())).toBe(0);
  });
  it('FD check', () => {
    fdCheck(Math.sinh, (t, x) => sinh(t, x as never), [0, 0.5, -0.5, 1.5, -1.5]);
  });
});

describe('cosh', () => {
  it('forward at 0 is 1', () => {
    expect(((t) => t.valueOf(cosh(t, t.leaf(0))))(tape())).toBe(1);
  });
  it('FD check', () => {
    fdCheck(Math.cosh, (t, x) => cosh(t, x as never), [0, 0.5, -0.5, 1.5, -1.5]);
  });
});

describe('tanh', () => {
  it('forward bounded by +/-1', () => {
    const t = tape();
    expect(t.valueOf(tanh(t, t.leaf(100)))).toBeCloseTo(1, 12);
    expect(t.valueOf(tanh(t, t.leaf(-100)))).toBeCloseTo(-1, 12);
  });
  it('FD check', () => {
    fdCheck(Math.tanh, (t, x) => tanh(t, x as never), [0, 0.5, -0.5, 2, -2]);
  });
  it('grad at 0 is 1', () => {
    const t = tape();
    const x = t.leaf(0);
    expect(backward(t, tanh(t, x)).get(x)).toBeCloseTo(1, 12);
  });
});

describe('asinh', () => {
  it('forward', () => {
    expect(((t) => t.valueOf(asinh(t, t.leaf(0))))(tape())).toBe(0);
  });
  it('FD check', () => {
    fdCheck(Math.asinh, (t, x) => asinh(t, x as never), [-2, -0.5, 0, 0.5, 2]);
  });
});

describe('acosh', () => {
  it('forward at 1 is 0', () => {
    expect(((t) => t.valueOf(acosh(t, t.leaf(1))))(tape())).toBeCloseTo(0, 12);
  });
  it('FD check on x > 1', () => {
    fdCheck(Math.acosh, (t, x) => acosh(t, x as never), [1.5, 2, 5, 10]);
  });
});

describe('atanh', () => {
  it('forward at 0', () => {
    expect(((t) => t.valueOf(atanh(t, t.leaf(0))))(tape())).toBe(0);
  });
  it('FD check on |x| < 1', () => {
    fdCheck(Math.atanh, (t, x) => atanh(t, x as never), [-0.7, -0.3, 0, 0.3, 0.7]);
  });
});
