import { registerBackward } from '@silt/backward';
import { sinhBackward } from './sinh.js';
import { coshBackward } from './cosh.js';
import { tanhBackward } from './tanh.js';
import { asinhBackward } from './asinh.js';
import { acoshBackward } from './acosh.js';
import { atanhBackward } from './atanh.js';

registerBackward('sinh', sinhBackward);
registerBackward('cosh', coshBackward);
registerBackward('tanh', tanhBackward);
registerBackward('asinh', asinhBackward);
registerBackward('acosh', acoshBackward);
registerBackward('atanh', atanhBackward);
