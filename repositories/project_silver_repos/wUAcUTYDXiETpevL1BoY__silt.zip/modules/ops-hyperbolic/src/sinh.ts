// sinh(x) ; d/dx = cosh(x)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const sinhHandler: OpHandler = {
  evalFn: (i) => Math.sinh(i[0]!),
  ctxFn: (i) => Math.cosh(i[0]!),
};

export const sinhBackward: BackwardFn = (_i, gOut, _v, ctx) => [gOut * (ctx as number)];

export function sinh(t: Tape, a: NodeId): NodeId {
  return t.append('sinh', [a], sinhHandler);
}
