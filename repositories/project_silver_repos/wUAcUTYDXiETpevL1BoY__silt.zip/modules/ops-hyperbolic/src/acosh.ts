// acosh(x) ; d/dx = 1 / sqrt(x^2 - 1)
// Domain: x >= 1.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const acoshHandler: OpHandler = {
  evalFn: (i) => Math.acosh(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const acoshBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [gOut / Math.sqrt(x * x - 1)];
};

export function acosh(t: Tape, a: NodeId): NodeId {
  return t.append('acosh', [a], acoshHandler);
}
