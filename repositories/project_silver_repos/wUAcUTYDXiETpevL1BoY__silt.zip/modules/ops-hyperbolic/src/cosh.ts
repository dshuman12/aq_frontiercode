// cosh(x) ; d/dx = sinh(x)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const coshHandler: OpHandler = {
  evalFn: (i) => Math.cosh(i[0]!),
  ctxFn: (i) => Math.sinh(i[0]!),
};

export const coshBackward: BackwardFn = (_i, gOut, _v, ctx) => [gOut * (ctx as number)];

export function cosh(t: Tape, a: NodeId): NodeId {
  return t.append('cosh', [a], coshHandler);
}
