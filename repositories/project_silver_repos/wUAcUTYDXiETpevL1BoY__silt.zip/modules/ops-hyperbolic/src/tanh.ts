// tanh(x) ; d/dx = 1 - tanh(x)^2 = 1 - v^2 where v is the forward output.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const tanhHandler: OpHandler = {
  evalFn: (i) => Math.tanh(i[0]!),
};

export const tanhBackward: BackwardFn = (_i, gOut, v) => [gOut * (1 - v * v)];

export function tanh(t: Tape, a: NodeId): NodeId {
  return t.append('tanh', [a], tanhHandler);
}
