// atanh(x) ; d/dx = 1 / (1 - x^2)
// Domain: |x| < 1.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const atanhHandler: OpHandler = {
  evalFn: (i) => Math.atanh(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const atanhBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [gOut / (1 - x * x)];
};

export function atanh(t: Tape, a: NodeId): NodeId {
  return t.append('atanh', [a], atanhHandler);
}
