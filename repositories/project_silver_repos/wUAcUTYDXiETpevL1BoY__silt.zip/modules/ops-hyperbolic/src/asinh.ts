// asinh(x) ; d/dx = 1 / sqrt(x^2 + 1)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const asinhHandler: OpHandler = {
  evalFn: (i) => Math.asinh(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const asinhBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [gOut / Math.sqrt(x * x + 1)];
};

export function asinh(t: Tape, a: NodeId): NodeId {
  return t.append('asinh', [a], asinhHandler);
}
