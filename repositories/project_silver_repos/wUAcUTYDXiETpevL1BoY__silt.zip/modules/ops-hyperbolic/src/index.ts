import './register.js';

export { sinh } from './sinh.js';
export { cosh } from './cosh.js';
export { tanh } from './tanh.js';
export { asinh } from './asinh.js';
export { acosh } from './acosh.js';
export { atanh } from './atanh.js';
