// dot output for a Tape. Useful for debugging op graphs in small examples.

import type { Tape } from '@silt/core-tape';

export function tapeToDot(t: Tape, options: { label?: string } = {}): string {
  const label = options.label ?? 'silt-tape';
  const lines: string[] = [];
  lines.push(`digraph "${label}" {`);
  lines.push('  rankdir=LR;');
  lines.push('  node [shape=box, fontname="monospace"];');
  for (const node of t.iter()) {
    const v = node.value === null ? '?' : node.value.toFixed(4);
    const shape = node.op === 'leaf' ? 'ellipse' : node.op === 'const' ? 'diamond' : 'box';
    lines.push(`  n${node.id} [label="${node.op}\\n${v}", shape=${shape}];`);
  }
  for (const node of t.iter()) {
    for (const inp of node.inputs) {
      lines.push(`  n${inp} -> n${node.id};`);
    }
  }
  lines.push('}');
  return lines.join('\n');
}
