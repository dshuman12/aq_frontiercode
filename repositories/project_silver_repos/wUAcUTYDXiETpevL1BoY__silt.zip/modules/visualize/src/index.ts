// Render a tape as Graphviz dot text.

export { tapeToDot } from './dot.js';
