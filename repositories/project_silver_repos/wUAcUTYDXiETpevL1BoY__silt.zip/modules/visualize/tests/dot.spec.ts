import { Tape } from '@silt/core-tape';
import { add } from '@silt/ops-elementary';
import { tapeToDot } from '../src/index.js';

describe('tapeToDot', () => {
  it('emits valid dot for an empty tape', () => {
    const t = new Tape();
    const dot = tapeToDot(t);
    expect(dot.startsWith('digraph')).toBe(true);
    expect(dot.endsWith('}')).toBe(true);
  });

  it('renders nodes and edges', () => {
    const t = new Tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = add(t, a, b);
    const dot = tapeToDot(t);
    expect(dot).toContain(`n${a}`);
    expect(dot).toContain(`n${b}`);
    expect(dot).toContain(`n${c}`);
    expect(dot).toContain(`n${a} -> n${c}`);
    expect(dot).toContain(`n${b} -> n${c}`);
  });

  it('honors custom label', () => {
    const t = new Tape();
    expect(tapeToDot(t, { label: 'my-graph' })).toContain('my-graph');
  });

  it('uses different shapes for leaf vs op', () => {
    const t = new Tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    add(t, a, b);
    const dot = tapeToDot(t);
    expect(dot).toContain('shape=ellipse');
    expect(dot).toContain('shape=box');
  });
});
