// Gradient accumulator.
//
// During backward, each node in turn distributes a gradient to each of
// its inputs. Multiple paths through the graph contribute additively.
// `Gradients` is a thin wrapper around a Float64Array indexed by
// NodeId, with a few ergonomic helpers.

import type { NodeId } from '@silt/core-types';
import { GradError } from '@silt/core-errors';

export class Gradients {
  private _grads: Float64Array;

  constructor(size: number) {
    if (!Number.isInteger(size) || size < 0) {
      throw new GradError(`Gradients: size must be non-negative integer, got ${size}`);
    }
    // size + 1 because the tape sentinel is at index 0.
    this._grads = new Float64Array(size + 1);
  }

  get(id: NodeId): number {
    if (id < 0 || id >= this._grads.length) {
      throw new GradError(`Gradients.get: id ${id} out of bounds`);
    }
    return this._grads[id]!;
  }

  add(id: NodeId, value: number): void {
    if (id < 0 || id >= this._grads.length) {
      throw new GradError(`Gradients.add: id ${id} out of bounds`);
    }
    this._grads[id]! += value;
  }

  set(id: NodeId, value: number): void {
    if (id < 0 || id >= this._grads.length) {
      throw new GradError(`Gradients.set: id ${id} out of bounds`);
    }
    this._grads[id] = value;
  }

  has(id: NodeId): boolean {
    return id >= 0 && id < this._grads.length;
  }

  // Iterate (id, grad) pairs for non-zero entries. Useful for tests and
  // for the optimizer's parameter update step.
  *entries(): IterableIterator<[NodeId, number]> {
    for (let i = 1; i < this._grads.length; i++) {
      const g = this._grads[i]!;
      if (g !== 0) yield [i as NodeId, g];
    }
  }

  // Snapshot as a plain Map. Mostly used by tests.
  toMap(): Map<NodeId, number> {
    const m = new Map<NodeId, number>();
    for (const [id, g] of this.entries()) m.set(id, g);
    return m;
  }

  // Reset all entries to zero. Used when the same Gradients instance
  // gets reused across multiple backward passes (rare but supported).
  zero(): void {
    this._grads.fill(0);
  }

  size(): number {
    return this._grads.length - 1;
  }
}
