// Op registry: a map from OpKind to its backward function.
//
// Forward eval is wired up at tape.append() time via the OpHandler
// passed in. Backward is wired up here, lazily, by each ops-* module's
// load-time side effect (calling registerBackward).
//
// We keep forward and backward separate registries because:
//   - Forward needs to be available the moment append() is called
//     (eager eval), so it travels with the call.
//   - Backward only needs to be available during backward(), which is
//     called once per gradient pass; we can afford a lookup.
//
// The two-table design also lets the user call forward without needing
// the backward implementation to be loaded -- useful for evaluation-
// only deployments.

import type { OpKind } from '@silt/core-types';
import { GradError } from '@silt/core-errors';

// inputs:    forward values of each input of the op
// outputGrad: gradient flowing into this op from its consumers
// outputValue: the op's own forward value
// ctx:       per-op context populated by the OpHandler.ctxFn at forward time
//
// Returns the gradient to propagate back to each input, in order.
export type BackwardFn = (
  inputs: readonly number[],
  outputGrad: number,
  outputValue: number,
  ctx: unknown,
) => number[];

const _registry = new Map<OpKind, BackwardFn>();

export function registerBackward(op: OpKind, fn: BackwardFn): void {
  if (op === 'leaf' || op === 'const') {
    throw new GradError(`registerBackward: ${op} is not a differentiable op`);
  }
  _registry.set(op, fn);
}

export function lookupBackward(op: OpKind): BackwardFn {
  const fn = _registry.get(op);
  if (!fn) {
    throw new GradError(
      `lookupBackward: no backward registered for op '${op}'. ` +
        `Make sure the appropriate ops module is imported before calling backward().`,
    );
  }
  return fn;
}

export function hasBackward(op: OpKind): boolean {
  return _registry.has(op);
}

// Tests-only: wipe the registry so a single test can exercise registry
// failure modes.
export function clearRegistry(): void {
  _registry.clear();
}
