// Backward walker.
//
// Algorithm: standard reverse-mode AD.
//   1. Initialize a Gradients accumulator over all tape nodes
//   2. Seed grad[output] = 1.0 (or a user-supplied seed)
//   3. Walk the tape in REVERSE insertion order. For each non-leaf
//      non-const node, look up its backward function, call it with
//      stored input values + accumulated output grad + per-op ctx,
//      and add the returned partials to each input's grad slot.
//   4. After the walk, leaves carry their full gradients.
//
// Determinism: insertion-order reverse walk is fully deterministic.
// Float64 add is non-associative so the order of contributions matters
// when a node has multiple consumers; insertion order pins it.

import { GradError } from '@silt/core-errors';
import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { Gradients } from './accumulator.js';
import { lookupBackward } from './op-registry.js';

export interface BackwardOptions {
  // Seed gradient at the output. Default 1.
  seed?: number;
  // If true, also includes consts in the gradient table. Default
  // false (consts stay at zero, which is mathematically correct
  // anyway since they have no input).
  includeConsts?: boolean;
}

// Compute gradients of `output` w.r.t. every leaf in the tape.
// Returns a Gradients instance keyed by NodeId.
export function backward(t: Tape, output: NodeId, opts: BackwardOptions = {}): Gradients {
  const seed = opts.seed ?? 1;
  const grads = new Gradients(t.size());
  grads.set(output, seed);

  // Walk in reverse insertion order.
  for (const node of t.iterReverse()) {
    if (node.op === 'leaf' || node.op === 'const') continue;
    const upstream = grads.get(node.id);
    if (upstream === 0) continue; // no path from this node to output
    const bwd = lookupBackward(node.op);
    const inputs = new Array<number>(node.inputs.length);
    for (let i = 0; i < node.inputs.length; i++) {
      inputs[i] = t.valueOf(node.inputs[i]!);
    }
    const outputValue = node.value;
    if (outputValue === null) {
      throw new GradError(
        `backward: n${node.id} has no forward value. ` + `Did you call forward() before backward()?`,
      );
    }
    const partials = bwd(inputs, upstream, outputValue, node.ctx);
    if (partials.length !== node.inputs.length) {
      throw new GradError(
        `backward: ${node.op} returned ${partials.length} partials for ${node.inputs.length} inputs`,
      );
    }
    for (let i = 0; i < node.inputs.length; i++) {
      grads.add(node.inputs[i]!, partials[i]!);
    }
  }
  return grads;
}

// Multi-output backward. Aggregates contributions from each output's
// own gradient seed. The seed for output i is seeds[i] (default 1).
export function backwardAll(
  t: Tape,
  outputs: readonly NodeId[],
  seeds?: readonly number[],
): Gradients {
  if (seeds && seeds.length !== outputs.length) {
    throw new GradError(
      `backwardAll: outputs.length (${outputs.length}) != seeds.length (${seeds.length})`,
    );
  }
  const grads = new Gradients(t.size());
  for (let i = 0; i < outputs.length; i++) {
    grads.add(outputs[i]!, seeds ? seeds[i]! : 1);
  }
  for (const node of t.iterReverse()) {
    if (node.op === 'leaf' || node.op === 'const') continue;
    const upstream = grads.get(node.id);
    if (upstream === 0) continue;
    const bwd = lookupBackward(node.op);
    const inputs = new Array<number>(node.inputs.length);
    for (let i = 0; i < node.inputs.length; i++) {
      inputs[i] = t.valueOf(node.inputs[i]!);
    }
    const outputValue = node.value;
    if (outputValue === null) {
      throw new GradError(`backwardAll: n${node.id} has no forward value`);
    }
    const partials = bwd(inputs, upstream, outputValue, node.ctx);
    for (let i = 0; i < node.inputs.length; i++) {
      grads.add(node.inputs[i]!, partials[i]!);
    }
  }
  return grads;
}
