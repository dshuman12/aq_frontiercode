import { Gradients } from '../src/accumulator.js';
import { GradError } from '@silt/core-errors';

describe('Gradients', () => {
  it('starts at zero', () => {
    const g = new Gradients(5);
    expect(g.get(1 as never)).toBe(0);
    expect(g.get(5 as never)).toBe(0);
  });

  it('rejects negative size', () => {
    expect(() => new Gradients(-1)).toThrow(GradError);
  });

  it('rejects non-integer size', () => {
    expect(() => new Gradients(2.5)).toThrow(GradError);
  });

  it('add accumulates additively', () => {
    const g = new Gradients(3);
    g.add(2 as never, 1.5);
    g.add(2 as never, 2.5);
    expect(g.get(2 as never)).toBe(4);
  });

  it('set replaces', () => {
    const g = new Gradients(3);
    g.add(2 as never, 1);
    g.set(2 as never, 99);
    expect(g.get(2 as never)).toBe(99);
  });

  it('throws on out-of-bounds id', () => {
    const g = new Gradients(3);
    expect(() => g.get(99 as never)).toThrow(GradError);
    expect(() => g.add(99 as never, 0)).toThrow(GradError);
    expect(() => g.set(99 as never, 0)).toThrow(GradError);
  });

  it('entries skips zeros', () => {
    const g = new Gradients(5);
    g.add(2 as never, 3);
    g.add(4 as never, 7);
    expect([...g.entries()]).toEqual([
      [2, 3],
      [4, 7],
    ]);
  });

  it('toMap converts', () => {
    const g = new Gradients(3);
    g.add(1 as never, 5);
    expect(g.toMap()).toEqual(new Map([[1, 5]]));
  });

  it('zero resets', () => {
    const g = new Gradients(3);
    g.add(1 as never, 9);
    g.zero();
    expect(g.get(1 as never)).toBe(0);
  });
});
