import { tape, type OpHandler } from '@silt/core-tape';
import { backward, backwardAll } from '../src/walker.js';
import { registerBackward, clearRegistry } from '../src/op-registry.js';
import { GradError } from '@silt/core-errors';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };
const mulH: OpHandler = {
  evalFn: (i) => i[0]! * i[1]!,
  ctxFn: (i) => i.slice(),
};

beforeEach(() => {
  clearRegistry();
  registerBackward('add', (_inputs, gOut) => [gOut, gOut]);
  registerBackward('mul', (_inputs, gOut, _v, ctx) => {
    const c = ctx as number[];
    return [gOut * c[1]!, gOut * c[0]!];
  });
});

describe('backward', () => {
  it('grad of x+y w.r.t. x and y both equal seed', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = t.append('add', [x, y], addH);
    const g = backward(t, z);
    expect(g.get(x)).toBe(1);
    expect(g.get(y)).toBe(1);
  });

  it('product rule: d(x*y)/dx = y, d(x*y)/dy = x', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = t.append('mul', [x, y], mulH);
    const g = backward(t, z);
    expect(g.get(x)).toBe(3);
    expect(g.get(y)).toBe(2);
  });

  it('chain rule across two ops', () => {
    // f = (x + y) * x ; df/dx = (x+y) + x ; df/dy = x
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const sum = t.append('add', [x, y], addH);
    const prod = t.append('mul', [sum, x], mulH);
    const g = backward(t, prod);
    expect(g.get(x)).toBe(2 + 3 + 2); // 7
    expect(g.get(y)).toBe(2);
  });

  it('honors a custom seed', () => {
    const t = tape();
    const x = t.leaf(1);
    const y = t.leaf(2);
    const z = t.append('add', [x, y], addH);
    const g = backward(t, z, { seed: 5 });
    expect(g.get(x)).toBe(5);
    expect(g.get(y)).toBe(5);
  });

  it('errors on unregistered backward', () => {
    clearRegistry();
    const t = tape();
    const x = t.leaf(1);
    const y = t.leaf(2);
    const z = t.append('add', [x, y], addH);
    expect(() => backward(t, z)).toThrow(GradError);
  });

  it('errors when partials count mismatches inputs count', () => {
    registerBackward('add', () => [1]); // wrong arity
    const t = tape();
    const x = t.leaf(1);
    const y = t.leaf(2);
    const z = t.append('add', [x, y], addH);
    expect(() => backward(t, z)).toThrow(GradError);
  });

  it('zero grad on unreachable leaves', () => {
    const t = tape();
    const x = t.leaf(1);
    const y = t.leaf(2); // not used in z
    const z = t.append('add', [x, x], addH);
    const g = backward(t, z);
    expect(g.get(y)).toBe(0);
    expect(g.get(x)).toBe(2); // diamond: x feeds both add inputs
  });
});

describe('backwardAll', () => {
  it('aggregates seeds across multiple outputs', () => {
    const t = tape();
    const x = t.leaf(1);
    const a = t.append('add', [x, x], addH);
    const b = t.append('mul', [x, x], mulH);
    const g = backwardAll(t, [a, b], [1, 1]);
    // d(x+x)/dx = 2 ; d(x*x)/dx = 2x = 2
    expect(g.get(x)).toBe(4);
  });

  it('rejects mismatched seeds length', () => {
    const t = tape();
    const x = t.leaf(1);
    const a = t.append('add', [x, x], addH);
    expect(() => backwardAll(t, [a], [1, 2])).toThrow(GradError);
  });

  it('defaults seeds to 1 when omitted', () => {
    const t = tape();
    const x = t.leaf(2);
    const z = t.append('add', [x, x], addH);
    const g = backwardAll(t, [z]);
    expect(g.get(x)).toBe(2);
  });
});
