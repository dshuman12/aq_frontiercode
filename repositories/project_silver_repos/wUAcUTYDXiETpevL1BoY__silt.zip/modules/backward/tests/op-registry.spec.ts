import {
  registerBackward,
  lookupBackward,
  hasBackward,
  clearRegistry,
} from '../src/op-registry.js';
import { GradError } from '@silt/core-errors';

describe('op-registry', () => {
  beforeEach(() => clearRegistry());

  it('registers and looks up a backward', () => {
    registerBackward('add', () => [1, 1]);
    const bwd = lookupBackward('add');
    expect(bwd([2, 3], 1, 5, null)).toEqual([1, 1]);
  });

  it('throws on lookup for unregistered op', () => {
    expect(() => lookupBackward('sin')).toThrow(GradError);
  });

  it('hasBackward reports correctly', () => {
    expect(hasBackward('mul')).toBe(false);
    registerBackward('mul', () => [0, 0]);
    expect(hasBackward('mul')).toBe(true);
  });

  it('refuses leaf / const registration', () => {
    expect(() => registerBackward('leaf', () => [])).toThrow(GradError);
    expect(() => registerBackward('const', () => [])).toThrow(GradError);
  });

  it('overwrites on re-register', () => {
    registerBackward('add', () => [1, 1]);
    registerBackward('add', () => [2, 2]);
    expect(lookupBackward('add')([0, 0], 1, 0, null)).toEqual([2, 2]);
  });
});
