import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import '@silt/ops-elementary';
import { sumReduce } from '@silt/ops-reductions';
import { matmul, matFromRows, getEntry } from '../src/index.js';

describe('matmul', () => {
  it('forward: 2x2 times 2x2', () => {
    const t = new Tape();
    const a = matFromRows(t, [
      [1, 2],
      [3, 4],
    ]);
    const b = matFromRows(t, [
      [5, 6],
      [7, 8],
    ]);
    const c = matmul(t, a, b);
    // [[1*5+2*7, 1*6+2*8], [3*5+4*7, 3*6+4*8]] = [[19, 22], [43, 50]]
    expect(t.valueOf(getEntry(c, 0, 0))).toBe(19);
    expect(t.valueOf(getEntry(c, 0, 1))).toBe(22);
    expect(t.valueOf(getEntry(c, 1, 0))).toBe(43);
    expect(t.valueOf(getEntry(c, 1, 1))).toBe(50);
  });

  it('forward: rectangular 2x3 times 3x1', () => {
    const t = new Tape();
    const a = matFromRows(t, [
      [1, 2, 3],
      [4, 5, 6],
    ]);
    const b = matFromRows(t, [[1], [2], [3]]);
    const c = matmul(t, a, b);
    expect(t.valueOf(getEntry(c, 0, 0))).toBe(14);
    expect(t.valueOf(getEntry(c, 1, 0))).toBe(32);
  });

  it('errors on shape mismatch', () => {
    const t = new Tape();
    const a = matFromRows(t, [[1, 2]]);
    const b = matFromRows(t, [[3, 4]]);
    expect(() => matmul(t, a, b)).toThrow();
  });

  it('backward through matmul: dC/dA = B^T (when seeded by ones)', () => {
    // For c = A @ B with A 2x2 and B 2x2, the gradient of sum(C) w.r.t.
    // A_ij is B_jk summed over k = sum of row j of B.
    const t = new Tape();
    const a = matFromRows(t, [
      [1, 2],
      [3, 4],
    ]);
    const b = matFromRows(t, [
      [5, 6],
      [7, 8],
    ]);
    const c = matmul(t, a, b);
    // sum-of-c
    const s = sumReduce(t, ...c.cells);
    const g = backward(t, s);
    // dA[0][0] = B[0][0] + B[0][1] = 11
    // dA[0][1] = B[1][0] + B[1][1] = 15
    // dA[1][0] = same as dA[0][0] = 11
    // dA[1][1] = same as dA[0][1] = 15
    expect(g.get(getEntry(a, 0, 0))).toBe(11);
    expect(g.get(getEntry(a, 0, 1))).toBe(15);
    expect(g.get(getEntry(a, 1, 0))).toBe(11);
    expect(g.get(getEntry(a, 1, 1))).toBe(15);
  });
});
