import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import '@silt/ops-elementary';
import '@silt/ops-reductions';
import { matFromRows, getEntry, transpose, trace, det, diag } from '../src/index.js';

describe('transpose', () => {
  it('flips rows and cols', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2, 3],
      [4, 5, 6],
    ]);
    const mt = transpose(m);
    expect(mt.rows).toBe(3);
    expect(mt.cols).toBe(2);
    expect(t.valueOf(getEntry(mt, 0, 0))).toBe(1);
    expect(t.valueOf(getEntry(mt, 0, 1))).toBe(4);
    expect(t.valueOf(getEntry(mt, 2, 0))).toBe(3);
    expect(t.valueOf(getEntry(mt, 2, 1))).toBe(6);
  });

  it('double transpose returns the original cells', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2],
      [3, 4],
    ]);
    const mtt = transpose(transpose(m));
    expect(mtt.rows).toBe(m.rows);
    expect(mtt.cols).toBe(m.cols);
    for (let r = 0; r < 2; r++) {
      for (let c = 0; c < 2; c++) {
        expect(getEntry(mtt, r, c)).toBe(getEntry(m, r, c));
      }
    }
  });
});

describe('trace', () => {
  it('sums the diagonal', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2],
      [3, 4],
    ]);
    expect(t.valueOf(trace(t, m))).toBe(5);
  });

  it('errors on non-square', () => {
    const t = new Tape();
    const m = matFromRows(t, [[1, 2, 3]]);
    expect(() => trace(t, m)).toThrow();
  });

  it('zero on empty matrix', () => {
    const t = new Tape();
    const m = matFromRows(t, []);
    expect(t.valueOf(trace(t, m))).toBe(0);
  });

  it('grad of trace w.r.t. diagonal is 1, off-diagonal is 0', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2],
      [3, 4],
    ]);
    const g = backward(t, trace(t, m));
    expect(g.get(getEntry(m, 0, 0))).toBe(1);
    expect(g.get(getEntry(m, 1, 1))).toBe(1);
    expect(g.get(getEntry(m, 0, 1))).toBe(0);
    expect(g.get(getEntry(m, 1, 0))).toBe(0);
  });
});

describe('diag', () => {
  it('returns diagonal cells', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2],
      [3, 4],
    ]);
    const d = diag(m);
    expect(t.valueOf(d[0]!)).toBe(1);
    expect(t.valueOf(d[1]!)).toBe(4);
  });
});

describe('det', () => {
  it('forward 1x1 = the entry', () => {
    const t = new Tape();
    const m = matFromRows(t, [[7]]);
    expect(t.valueOf(det(t, m))).toBe(7);
  });

  it('forward 2x2', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2],
      [3, 4],
    ]);
    expect(t.valueOf(det(t, m))).toBe(-2);
  });

  it('forward 3x3', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2, 3],
      [4, 5, 6],
      [7, 8, 10],
    ]);
    // 1*(5*10 - 6*8) - 2*(4*10 - 6*7) + 3*(4*8 - 5*7) = 1*2 - 2*(-2) + 3*(-3) = 2 + 4 - 9 = -3
    expect(t.valueOf(det(t, m))).toBe(-3);
  });

  it('det of identity is 1', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 0, 0],
      [0, 1, 0],
      [0, 0, 1],
    ]);
    expect(t.valueOf(det(t, m))).toBe(1);
  });

  it('det 0 for singular matrix', () => {
    const t = new Tape();
    const m = matFromRows(t, [
      [1, 2],
      [2, 4],
    ]);
    expect(t.valueOf(det(t, m))).toBe(0);
  });
});
