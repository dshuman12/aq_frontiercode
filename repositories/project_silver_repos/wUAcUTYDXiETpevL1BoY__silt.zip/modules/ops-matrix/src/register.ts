// Matrix ops use registered scalar backwards (mul, add, etc.) -- no
// new registry entries needed. The `matmul`, `transpose`, etc. functions
// are pure tape composers.
//
// We import @silt/ops-elementary and @silt/ops-reductions for their
// registration side effects, so that consumers of @silt/ops-matrix
// don't have to import them separately.

import '@silt/ops-elementary';
import '@silt/ops-reductions';
