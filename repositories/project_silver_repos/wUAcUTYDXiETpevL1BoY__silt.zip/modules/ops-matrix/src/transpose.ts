// transpose: M^T at the matrix-of-NodeIds level. No tape ops.

import { type Matrix, mat, getEntry } from './matrix.js';

export function transpose(m: Matrix): Matrix {
  const cells: import('@silt/core-types').NodeId[] = new Array(m.rows * m.cols) as never;
  for (let r = 0; r < m.rows; r++) {
    for (let c = 0; c < m.cols; c++) {
      cells[c * m.rows + r] = getEntry(m, r, c);
    }
  }
  return mat(m.cols, m.rows, cells);
}
