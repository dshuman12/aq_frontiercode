// diag: extract the main diagonal of a square matrix as a column vector.

import type { NodeId } from '@silt/core-types';
import { ShapeError } from '@silt/core-errors';
import { type Matrix, getEntry } from './matrix.js';

export function diag(m: Matrix): NodeId[] {
  if (m.rows !== m.cols) {
    throw new ShapeError(`diag: matrix is ${m.rows}x${m.cols}, must be square`);
  }
  const out: NodeId[] = [];
  for (let i = 0; i < m.rows; i++) out.push(getEntry(m, i, i));
  return out;
}
