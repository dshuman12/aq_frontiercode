// det: determinant via cofactor expansion. O(n!) -- only suitable for
// small matrices (n <= 6 in practice). Differentiable since it's
// composed of mul, neg, and add.
//
// We use Laplace expansion along the first row. The "right" way for
// numerically robust det is LU with partial pivoting, but pivot
// selection is non-differentiable; for autodiff we want a pure
// arithmetic expression.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { add, sub, mul, neg } from '@silt/ops-elementary';
import { ShapeError } from '@silt/core-errors';
import { type Matrix, mat, getEntry } from './matrix.js';

export function det(t: Tape, m: Matrix): NodeId {
  if (m.rows !== m.cols) {
    throw new ShapeError(`det: matrix is ${m.rows}x${m.cols}, must be square`);
  }
  return _det(t, m);
}

function _det(t: Tape, m: Matrix): NodeId {
  const n = m.rows;
  if (n === 0) return t.const(1);
  if (n === 1) return getEntry(m, 0, 0);
  if (n === 2) {
    return sub(t, mul(t, getEntry(m, 0, 0), getEntry(m, 1, 1)), mul(t, getEntry(m, 0, 1), getEntry(m, 1, 0)));
  }
  // Laplace expansion along row 0.
  let acc: NodeId | null = null;
  for (let j = 0; j < n; j++) {
    const minor = _minor(m, 0, j);
    const cofactor = mul(t, getEntry(m, 0, j), _det(t, minor));
    const signed = j % 2 === 0 ? cofactor : neg(t, cofactor);
    acc = acc === null ? signed : add(t, acc, signed);
  }
  return acc!;
}

function _minor(m: Matrix, skipRow: number, skipCol: number): Matrix {
  const n = m.rows;
  const cells: NodeId[] = [];
  for (let r = 0; r < n; r++) {
    if (r === skipRow) continue;
    for (let c = 0; c < n; c++) {
      if (c === skipCol) continue;
      cells.push(getEntry(m, r, c));
    }
  }
  return mat(n - 1, n - 1, cells);
}
