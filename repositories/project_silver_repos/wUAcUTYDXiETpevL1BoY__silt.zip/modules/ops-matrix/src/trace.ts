// trace: sum of the main diagonal.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { sumReduce } from '@silt/ops-reductions';
import { ShapeError } from '@silt/core-errors';
import { type Matrix, getEntry } from './matrix.js';

export function trace(t: Tape, m: Matrix): NodeId {
  if (m.rows !== m.cols) {
    throw new ShapeError(`trace: matrix is ${m.rows}x${m.cols}, must be square`);
  }
  if (m.rows === 0) {
    return t.const(0);
  }
  const diag: NodeId[] = [];
  for (let i = 0; i < m.rows; i++) diag.push(getEntry(m, i, i));
  return sumReduce(t, ...diag);
}
