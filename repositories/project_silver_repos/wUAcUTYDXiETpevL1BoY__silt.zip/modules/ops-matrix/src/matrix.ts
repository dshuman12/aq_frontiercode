// A "matrix" in silt is a 2D arrangement of NodeIds plus a shape.
// Operations on matrices unroll into scalar-tape ops; the matrix
// abstraction is purely a convenience for the caller.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { add } from '@silt/ops-elementary';
import { mul } from '@silt/ops-elementary';
import { sumReduce } from '@silt/ops-reductions';
import { ShapeError } from '@silt/core-errors';

export interface Matrix {
  readonly rows: number;
  readonly cols: number;
  // Row-major flat array of NodeIds.
  readonly cells: readonly NodeId[];
}

export function mat(rows: number, cols: number, cells: NodeId[]): Matrix {
  if (cells.length !== rows * cols) {
    throw new ShapeError(`mat: expected ${rows * cols} cells, got ${cells.length}`);
  }
  return Object.freeze({ rows, cols, cells: cells.slice() });
}

// Build a Matrix from a 2D array of leaf values, allocating leaves
// on the tape.
export function matFromRows(t: Tape, values: number[][]): Matrix {
  const rows = values.length;
  if (rows === 0) return mat(0, 0, []);
  const cols = values[0]!.length;
  const cells: NodeId[] = [];
  for (let r = 0; r < rows; r++) {
    if (values[r]!.length !== cols) {
      throw new ShapeError(`matFromRows: row ${r} has ${values[r]!.length} cols, expected ${cols}`);
    }
    for (let c = 0; c < cols; c++) {
      cells.push(t.leaf(values[r]![c]!));
    }
  }
  return mat(rows, cols, cells);
}

export function dim(m: Matrix): readonly [number, number] {
  return [m.rows, m.cols];
}

export function getEntry(m: Matrix, r: number, c: number): NodeId {
  if (r < 0 || r >= m.rows || c < 0 || c >= m.cols) {
    throw new ShapeError(`getEntry: (${r}, ${c}) out of bounds for ${m.rows}x${m.cols}`);
  }
  return m.cells[r * m.cols + c]!;
}

// Returns a new matrix with one cell replaced. Original is untouched.
export function setEntry(m: Matrix, r: number, c: number, id: NodeId): Matrix {
  if (r < 0 || r >= m.rows || c < 0 || c >= m.cols) {
    throw new ShapeError(`setEntry: (${r}, ${c}) out of bounds for ${m.rows}x${m.cols}`);
  }
  const next = m.cells.slice();
  next[r * m.cols + c] = id;
  return mat(m.rows, m.cols, next);
}

// matmul(A, B) where A is rows_a x k and B is k x cols_b.
// Produces an rows_a x cols_b matrix; entry (i, j) is the dot product
// of row i of A with column j of B.
//
// Implemented as a tape-level expansion: each output cell is built
// from k mul nodes summed via a single sum-reduce node, so the
// gradient through matmul automatically benefits from the existing
// scalar backward functions for mul and sum.
export function matmul(t: Tape, a: Matrix, b: Matrix): Matrix {
  if (a.cols !== b.rows) {
    throw new ShapeError(`matmul: ${a.rows}x${a.cols} cannot multiply with ${b.rows}x${b.cols}`);
  }
  const cells: NodeId[] = [];
  for (let i = 0; i < a.rows; i++) {
    for (let j = 0; j < b.cols; j++) {
      const products: NodeId[] = [];
      for (let k = 0; k < a.cols; k++) {
        const aik = getEntry(a, i, k);
        const bkj = getEntry(b, k, j);
        products.push(mul(t, aik, bkj));
      }
      cells.push(sumReduce(t, ...products));
    }
  }
  return mat(a.rows, b.cols, cells);
}

// Suppress unused import warning. The module exports a Matrix-builder
// `add` would compose with, but matmul doesn't need it directly.
void add;
