// Matrix ops, scalar-tape style.
//
// silt's tape stores scalar nodes; we represent a matrix as a 2D
// arrangement of NodeIds. Matrix ops compose primitive scalar ops:
// matmul builds a sum-of-products tree, transpose is just a view,
// trace is a sum over the diagonal, etc.
//
// This is slow vs a real BLAS. It's also straightforward to read and
// fully bit-deterministic. The "small networks" framing of silt makes
// this fine.

import './register.js';

export { matmul, type Matrix, mat, matFromRows, dim, getEntry, setEntry } from './matrix.js';
export { transpose } from './transpose.js';
export { diag } from './diag.js';
export { trace } from './trace.js';
export { det } from './det.js';
