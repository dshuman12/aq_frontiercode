// gather: pick out a subset of NodeIds by integer index.

import type { NodeId } from '@silt/core-types';

export function gather(nodes: readonly NodeId[], indices: readonly number[]): NodeId[] {
  const out: NodeId[] = new Array(indices.length);
  for (let i = 0; i < indices.length; i++) {
    const k = indices[i]!;
    if (k < 0 || k >= nodes.length || !Number.isInteger(k)) {
      throw new RangeError(`gather: index ${k} out of bounds for length ${nodes.length}`);
    }
    out[i] = nodes[k]!;
  }
  return out;
}
