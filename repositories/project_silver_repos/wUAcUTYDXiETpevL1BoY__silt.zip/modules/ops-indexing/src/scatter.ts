// scatter: write `values` at the given `indices` of an output array
// of size `size`. Slots not written are filled with `fill` (a NodeId
// referring to a known constant, typically 0 from t.const(0)).
//
// Multiple writes to the same slot are not aggregated -- the LAST
// write wins. Tape semantics make this an unusual choice for ML
// (where atomic-add is more typical) but consistent with Python's
// dict-update-by-position semantics that the caller probably expects.

import type { NodeId } from '@silt/core-types';

export function scatter(
  size: number,
  indices: readonly number[],
  values: readonly NodeId[],
  fill: NodeId,
): NodeId[] {
  if (indices.length !== values.length) {
    throw new RangeError(
      `scatter: indices.length (${indices.length}) != values.length (${values.length})`,
    );
  }
  const out: NodeId[] = new Array(size);
  for (let i = 0; i < size; i++) out[i] = fill;
  for (let i = 0; i < indices.length; i++) {
    const k = indices[i]!;
    if (k < 0 || k >= size || !Number.isInteger(k)) {
      throw new RangeError(`scatter: index ${k} out of bounds for size ${size}`);
    }
    out[k] = values[i]!;
  }
  return out;
}
