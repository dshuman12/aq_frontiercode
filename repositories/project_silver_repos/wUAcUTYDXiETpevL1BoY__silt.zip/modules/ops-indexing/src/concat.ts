import type { NodeId } from '@silt/core-types';

export function concat(...lists: readonly (readonly NodeId[])[]): NodeId[] {
  const out: NodeId[] = [];
  for (const lst of lists) {
    for (const id of lst) out.push(id);
  }
  return out;
}
