// Indexing ops at the scalar tape level: gather is a NodeId picker,
// scatter writes into a fresh array, concat appends, split slices.
//
// All of these are pure NodeId rearrangements. Gradient correctness is
// automatic since the underlying NodeIds participate in backward
// through their original ops.

export { gather } from './gather.js';
export { scatter } from './scatter.js';
export { concat } from './concat.js';
export { split } from './split.js';
