import type { NodeId } from '@silt/core-types';

export function split(nodes: readonly NodeId[], sizes: readonly number[]): NodeId[][] {
  let total = 0;
  for (const s of sizes) {
    if (!Number.isInteger(s) || s < 0) {
      throw new RangeError(`split: bad size ${s}`);
    }
    total += s;
  }
  if (total !== nodes.length) {
    throw new RangeError(`split: sizes sum to ${total}, but input has length ${nodes.length}`);
  }
  const out: NodeId[][] = [];
  let cursor = 0;
  for (const s of sizes) {
    out.push(nodes.slice(cursor, cursor + s));
    cursor += s;
  }
  return out;
}
