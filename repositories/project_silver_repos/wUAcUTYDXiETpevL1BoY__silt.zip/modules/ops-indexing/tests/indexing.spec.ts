import { Tape } from '@silt/core-tape';
import { gather, scatter, concat, split } from '../src/index.js';

describe('gather', () => {
  it('picks out NodeIds at given indices', () => {
    const t = new Tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.leaf(3);
    expect(gather([a, b, c], [2, 0])).toEqual([c, a]);
  });

  it('throws on out-of-bounds', () => {
    expect(() => gather([1, 2, 3] as never, [5])).toThrow(RangeError);
  });

  it('throws on non-integer index', () => {
    expect(() => gather([1] as never, [0.5])).toThrow(RangeError);
  });

  it('handles empty index list', () => {
    expect(gather([1, 2, 3] as never, [])).toEqual([]);
  });
});

describe('scatter', () => {
  it('places values at given slots, fills rest', () => {
    const t = new Tape();
    const fill = t.const(0);
    const x = t.leaf(7);
    const y = t.leaf(9);
    const out = scatter(4, [1, 3], [x, y], fill);
    expect(out).toEqual([fill, x, fill, y]);
  });

  it('refuses mismatched indices/values length', () => {
    expect(() => scatter(3, [0], [1, 2] as never, 0 as never)).toThrow(RangeError);
  });

  it('refuses out-of-bounds index', () => {
    expect(() => scatter(3, [5], [0 as never], 0 as never)).toThrow(RangeError);
  });

  it('last write wins on duplicate index', () => {
    const t = new Tape();
    const fill = t.const(0);
    const x = t.leaf(1);
    const y = t.leaf(2);
    const out = scatter(2, [0, 0], [x, y], fill);
    expect(out[0]).toBe(y);
  });
});

describe('concat', () => {
  it('joins lists', () => {
    expect(concat([1, 2] as never, [3] as never, [4, 5] as never)).toEqual([1, 2, 3, 4, 5]);
  });

  it('handles zero lists', () => {
    expect(concat()).toEqual([]);
  });

  it('handles empty lists', () => {
    expect(concat([] as never, [1] as never, [] as never)).toEqual([1]);
  });
});

describe('split', () => {
  it('partitions into specified sizes', () => {
    expect(split([1, 2, 3, 4, 5] as never, [2, 1, 2])).toEqual([
      [1, 2],
      [3],
      [4, 5],
    ]);
  });

  it('refuses size sum mismatch', () => {
    expect(() => split([1, 2, 3] as never, [2])).toThrow(RangeError);
  });

  it('refuses negative size', () => {
    expect(() => split([1] as never, [-1])).toThrow(RangeError);
  });

  it('handles zero-length splits', () => {
    expect(split([1, 2] as never, [0, 2])).toEqual([[], [1, 2]]);
  });
});
