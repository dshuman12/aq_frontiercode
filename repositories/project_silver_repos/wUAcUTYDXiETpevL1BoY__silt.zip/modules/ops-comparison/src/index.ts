// Comparison ops produce 0/1 forward and have zero subgradient
// almost everywhere. The subgradient at the boundary (a == b) is
// chosen to be 0 so backward produces no useful signal through these
// ops; callers using a comparison in a loss function should wrap it
// in a smooth approximation like `where` or `softmax` before
// expecting gradients.

import './register.js';
export { eq } from './eq.js';
export { lt } from './lt.js';
export { gt } from './gt.js';
export { le } from './le.js';
export { ge } from './ge.js';
