import { registerBackward } from '@silt/backward';
import { eqBackward } from './eq.js';
import { ltBackward } from './lt.js';
import { gtBackward } from './gt.js';
import { leBackward } from './le.js';
import { geBackward } from './ge.js';

registerBackward('eq', eqBackward);
registerBackward('lt', ltBackward);
registerBackward('gt', gtBackward);
registerBackward('le', leBackward);
registerBackward('ge', geBackward);
