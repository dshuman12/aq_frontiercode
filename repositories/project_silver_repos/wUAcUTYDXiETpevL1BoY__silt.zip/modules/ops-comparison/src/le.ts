import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const leHandler: OpHandler = { evalFn: (i) => (i[0]! <= i[1]! ? 1 : 0) };
export const leBackward: BackwardFn = () => [0, 0];

export function le(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('le', [a, b], leHandler);
}
