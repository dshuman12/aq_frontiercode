import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const gtHandler: OpHandler = { evalFn: (i) => (i[0]! > i[1]! ? 1 : 0) };
export const gtBackward: BackwardFn = () => [0, 0];

export function gt(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('gt', [a, b], gtHandler);
}
