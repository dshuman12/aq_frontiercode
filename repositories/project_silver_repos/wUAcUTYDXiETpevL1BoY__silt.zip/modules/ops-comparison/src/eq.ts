import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const eqHandler: OpHandler = {
  evalFn: (i) => (i[0]! === i[1]! ? 1 : 0),
};

export const eqBackward: BackwardFn = () => [0, 0];

export function eq(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('eq', [a, b], eqHandler);
}
