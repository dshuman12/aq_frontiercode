import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const ltHandler: OpHandler = {
  evalFn: (i) => (i[0]! < i[1]! ? 1 : 0),
};

export const ltBackward: BackwardFn = () => [0, 0];

export function lt(t: Tape, a: NodeId, b: NodeId): NodeId {
  return t.append('lt', [a, b], ltHandler);
}
