import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { eq, lt, gt, le, ge } from '../src/index.js';

describe('eq', () => {
  it('1 when equal', () => {
    const t = tape();
    expect(t.valueOf(eq(t, t.leaf(2), t.leaf(2)))).toBe(1);
  });
  it('0 when unequal', () => {
    const t = tape();
    expect(t.valueOf(eq(t, t.leaf(2), t.leaf(3)))).toBe(0);
  });
  it('zero gradient through eq', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(2);
    const g = backward(t, eq(t, x, y));
    expect(g.get(x)).toBe(0);
    expect(g.get(y)).toBe(0);
  });
});

describe('lt', () => {
  it('forward strict', () => {
    const t = tape();
    expect(t.valueOf(lt(t, t.leaf(1), t.leaf(2)))).toBe(1);
    expect(t.valueOf(lt(t, t.leaf(2), t.leaf(2)))).toBe(0);
  });
});

describe('gt', () => {
  it('forward strict', () => {
    const t = tape();
    expect(t.valueOf(gt(t, t.leaf(2), t.leaf(1)))).toBe(1);
    expect(t.valueOf(gt(t, t.leaf(2), t.leaf(2)))).toBe(0);
  });
});

describe('le', () => {
  it('forward inclusive', () => {
    const t = tape();
    expect(t.valueOf(le(t, t.leaf(2), t.leaf(2)))).toBe(1);
    expect(t.valueOf(le(t, t.leaf(3), t.leaf(2)))).toBe(0);
  });
});

describe('ge', () => {
  it('forward inclusive', () => {
    const t = tape();
    expect(t.valueOf(ge(t, t.leaf(2), t.leaf(2)))).toBe(1);
    expect(t.valueOf(ge(t, t.leaf(1), t.leaf(2)))).toBe(0);
  });
});

describe('all comparisons have zero subgradient', () => {
  for (const [name, op] of [
    ['eq', eq],
    ['lt', lt],
    ['gt', gt],
    ['le', le],
    ['ge', ge],
  ] as const) {
    it(`${name}`, () => {
      const t = tape();
      const x = t.leaf(1.5);
      const y = t.leaf(2.5);
      const g = backward(t, op(t, x, y));
      expect(g.get(x)).toBe(0);
      expect(g.get(y)).toBe(0);
    });
  }
});
