import { tape, type OpHandler } from '@silt/core-tape';
import { evalForward, evalNodes, evalAt } from '../src/eval.js';
import { TapeError } from '@silt/core-errors';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };
const mulH: OpHandler = { evalFn: (i) => i[0]! * i[1]! };

describe('evalForward', () => {
  it('updates leaves and recomputes downstream', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = t.append('add', [x, y], addH);
    expect(t.valueOf(z)).toBe(5);
    evalForward(t, new Map([[x, 10], [y, 20]]));
    expect(t.valueOf(z)).toBe(30);
  });

  it('refuses to reassign a non-leaf', () => {
    const t = tape();
    const x = t.leaf(1);
    const y = t.leaf(2);
    const z = t.append('add', [x, y], addH);
    expect(() => evalForward(t, new Map([[z, 99]]))).toThrow(TapeError);
  });

  it('updates only the listed leaves', () => {
    const t = tape();
    const x = t.leaf(1);
    const y = t.leaf(1);
    const z = t.append('mul', [x, y], mulH);
    evalForward(t, new Map([[x, 5]]));
    expect(t.valueOf(z)).toBe(5);
  });
});

describe('evalNodes', () => {
  it('reads multiple values', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = t.append('add', [x, y], addH);
    expect(evalNodes(t, [x, y, z])).toEqual([2, 3, 5]);
  });
});

describe('evalAt', () => {
  it('combines update + read', () => {
    const t = tape();
    const x = t.leaf(0);
    const y = t.leaf(0);
    const z = t.append('mul', [x, y], mulH);
    expect(evalAt(t, new Map([[x, 7], [y, 6]]), z)).toBe(42);
  });
});
