// Forward-eval entry points.
//
// In silt, ops are evaluated eagerly during `tape.append()`. So the
// "forward eval" function in this module is mostly a re-evaluator
// for tapes that have been mutated (e.g. by setLeaf).
//
// The convenience comes from giving callers a stable API to:
//   - evaluate a tape with new leaf values without rebuilding it
//   - extract a node's value (with bounds + null checks rolled in)

import { TapeError } from '@silt/core-errors';
import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { replay } from '@silt/core-tape';

// Set leaf values, then re-evaluate the entire tape.
export function evalForward(t: Tape, leafValues: Map<NodeId, number>): void {
  for (const [id, v] of leafValues) {
    const node = t.get(id);
    if (node.op !== 'leaf') {
      throw new TapeError(
        `evalForward: n${id} is not a leaf (op=${node.op}); only leaves can be reassigned`,
      );
    }
    (node as { value: number | null }).value = v;
  }
  replay(t);
}

// Read multiple node values.
export function evalNodes(t: Tape, ids: readonly NodeId[]): number[] {
  const out = new Array<number>(ids.length);
  for (let i = 0; i < ids.length; i++) {
    out[i] = t.valueOf(ids[i]!);
  }
  return out;
}

// Evaluate a single node at given leaf values. Convenience for tests.
export function evalAt(t: Tape, leafValues: Map<NodeId, number>, output: NodeId): number {
  evalForward(t, leafValues);
  return t.valueOf(output);
}
