import { Tape } from '@silt/core-tape';
import { gradcheck, gradcheckScalar } from '../src/finite-diff.js';
import { add, mul } from '@silt/ops-elementary';
import { sin, cos } from '@silt/ops-trig';
import { exp, log } from '@silt/ops-exponential';

describe('gradcheckScalar', () => {
  it('passes on sin', () => {
    for (const x of [0.1, 0.5, 1.0, -0.3, 2.7]) {
      const r = gradcheckScalar((t, a) => sin(t, a), x);
      expect(r.passed).toBe(true);
      expect(r.details).toHaveLength(1);
    }
  });

  it('passes on cos', () => {
    const r = gradcheckScalar((t, a) => cos(t, a), 0.5);
    expect(r.passed).toBe(true);
  });

  it('passes on exp', () => {
    const r = gradcheckScalar((t, a) => exp(t, a), 0.5);
    expect(r.passed).toBe(true);
  });

  it('passes on log', () => {
    const r = gradcheckScalar((t, a) => log(t, a), 1.5);
    expect(r.passed).toBe(true);
  });

  it('passes on chain sin(cos(x))', () => {
    const r = gradcheckScalar((t, a) => sin(t, cos(t, a)), 0.5);
    expect(r.passed).toBe(true);
  });

  it('reports details on failure', () => {
    // Force a tighter tolerance than achievable to provoke a fail.
    const r = gradcheckScalar((t, a) => sin(t, a), 0.5, {
      absTol: 1e-30,
      relTol: 1e-30,
    });
    expect(r.passed).toBe(false);
    expect(r.details[0]!.absErr).toBeGreaterThan(1e-30);
  });
});

describe('gradcheck (multi-leaf)', () => {
  it('passes on f(x, y) = x*y + sin(x)', () => {
    const r = gradcheck(
      (vs) => {
        const t = new Tape();
        const x = t.leaf(vs[0]!);
        const y = t.leaf(vs[1]!);
        const out = add(t, mul(t, x, y), sin(t, x));
        return { tape: t, output: out, leaves: [x, y] };
      },
      [0.5, 0.7],
    );
    expect(r.passed).toBe(true);
    expect(r.details).toHaveLength(2);
  });

  it('passes on f(x, y, z) = x*y*z', () => {
    const r = gradcheck(
      (vs) => {
        const t = new Tape();
        const x = t.leaf(vs[0]!);
        const y = t.leaf(vs[1]!);
        const z = t.leaf(vs[2]!);
        const out = mul(t, mul(t, x, y), z);
        return { tape: t, output: out, leaves: [x, y, z] };
      },
      [1.5, 2.5, 0.5],
    );
    expect(r.passed).toBe(true);
  });

  it('honors custom epsilon', () => {
    const r = gradcheckScalar((t, a) => sin(t, a), 0.5, { epsilon: 1e-5 });
    expect(r.passed).toBe(true);
  });
});
