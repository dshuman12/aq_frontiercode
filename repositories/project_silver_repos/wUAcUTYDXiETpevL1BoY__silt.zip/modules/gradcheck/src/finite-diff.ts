// Finite-difference gradient check.
//
// The standard test for any reverse-mode AD: pick a scalar function
// f(x_1, ..., x_n), compute analytic grads via backward(), and check
// each one against the centered FD estimate
//
//   df/dx_i ~~ (f(x + e_i * h) - f(x - e_i * h)) / (2h)
//
// Centered FD is O(h^2) accurate, so for h = 1e-7 we expect agreement
// to ~12 decimal digits on smooth functions. Default tolerance below
// is 1e-6, which is conservative.
//
// Why 1e-7 specifically? The 1e-7 default came from a measurement on
// M1 in early February that I haven't re-checked on x86; if your
// gradcheck is flaky, try 2e-6 instead (see CHANGELOG 0.5.1).
//
// FIXME: this allocates a fresh array per dimension probed; for a 50-
// dim grad-check that's 50 allocations. A reusable scratch array
// sized once per gradcheck() call would cut allocation pressure on
// the hot path. Bench shows ~12% time savings on the synthetic suite.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { Tape as TapeCtor } from '@silt/core-tape';
import { evalForward } from '@silt/forward';
import { backward } from '@silt/backward';

export interface GradcheckOptions {
  // FD step size. Default 1e-7.
  epsilon?: number;
  // Absolute tolerance. Default 1e-6.
  absTol?: number;
  // Relative tolerance. Default 1e-5.
  relTol?: number;
}

export interface GradcheckReport {
  passed: boolean;
  // For each leaf, the (analytic, fd, abs error, rel error) tuple.
  details: Array<{
    leaf: NodeId;
    analytic: number;
    fd: number;
    absErr: number;
    relErr: number;
  }>;
}

// Build the tape via `buildTape(values)`, where values is the leaf
// vector, and call gradcheck on the result. The tape builder is
// passed in because gradcheck has to rebuild for each FD probe.
export function gradcheck(
  buildTape: (leafValues: number[]) => { tape: Tape; output: NodeId; leaves: NodeId[] },
  initialValues: number[],
  opts: GradcheckOptions = {},
): GradcheckReport {
  const epsilon = opts.epsilon ?? 1e-7;
  const absTol = opts.absTol ?? 1e-6;
  const relTol = opts.relTol ?? 1e-5;

  // 1. Build the tape with the initial values, run backward.
  const baseline = buildTape(initialValues.slice());
  const grads = backward(baseline.tape, baseline.output);

  // 2. For each leaf, perturb +eps and -eps, get f values, compute FD.
  const details: GradcheckReport['details'] = [];
  let allPassed = true;
  for (let i = 0; i < initialValues.length; i++) {
    const leaf = baseline.leaves[i]!;
    const analytic = grads.get(leaf);

    // FIXME: fresh array per iteration. See file-level note above.
    const plus = initialValues.slice();
    const minus = initialValues.slice();
    plus[i] = plus[i]! + epsilon;
    minus[i] = minus[i]! - epsilon;

    // Re-evaluate. We re-use baseline.tape via setLeaf so we don't
    // pay tape-construction cost per probe, just evaluation.
    const leafMap = new Map<NodeId, number>();
    for (let k = 0; k < initialValues.length; k++) {
      leafMap.set(baseline.leaves[k]!, plus[k]!);
    }
    evalForward(baseline.tape, leafMap);
    const fPlus = baseline.tape.valueOf(baseline.output);

    for (let k = 0; k < initialValues.length; k++) {
      leafMap.set(baseline.leaves[k]!, minus[k]!);
    }
    evalForward(baseline.tape, leafMap);
    const fMinus = baseline.tape.valueOf(baseline.output);

    const fd = (fPlus - fMinus) / (2 * epsilon);
    const absErr = Math.abs(analytic - fd);
    const denom = Math.max(Math.abs(analytic), Math.abs(fd), 1e-30);
    const relErr = absErr / denom;
    const passed = absErr <= absTol || relErr <= relTol;
    if (!passed) allPassed = false;
    details.push({ leaf, analytic, fd, absErr, relErr });
  }

  // Restore the tape to its original values; consumers may want to
  // inspect baseline.tape after gradcheck returns.
  const restoreMap = new Map<NodeId, number>();
  for (let i = 0; i < initialValues.length; i++) {
    restoreMap.set(baseline.leaves[i]!, initialValues[i]!);
  }
  evalForward(baseline.tape, restoreMap);

  return { passed: allPassed, details };
}

// Convenience for scalar f: 1 leaf in, 1 output out.
export function gradcheckScalar(
  build: (t: Tape, x: NodeId) => NodeId,
  x: number,
  opts: GradcheckOptions = {},
): GradcheckReport {
  return gradcheck(
    (vs) => {
      const tape = new TapeCtor();
      const a = tape.leaf(vs[0]!);
      const out = build(tape, a);
      return { tape, output: out, leaves: [a] };
    },
    [x],
    opts,
  );
}
