import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { cond, where, select } from '../src/index.js';

describe('cond', () => {
  it('forward picks then-branch when c > 0', () => {
    const t = new Tape();
    expect(t.valueOf(cond(t, t.leaf(1), t.leaf(10), t.leaf(20)))).toBe(10);
  });

  it('forward picks else-branch when c <= 0', () => {
    const t = new Tape();
    expect(t.valueOf(cond(t, t.leaf(-1), t.leaf(10), t.leaf(20)))).toBe(20);
    expect(t.valueOf(cond(t, t.leaf(0), t.leaf(10), t.leaf(20)))).toBe(20);
  });

  it('grad routes to taken branch only', () => {
    const t = new Tape();
    const c = t.leaf(1);
    const a = t.leaf(10);
    const b = t.leaf(20);
    const g = backward(t, cond(t, c, a, b));
    expect(g.get(c)).toBe(0);
    expect(g.get(a)).toBe(1);
    expect(g.get(b)).toBe(0);
  });

  it('grad routes to else when c <= 0', () => {
    const t = new Tape();
    const c = t.leaf(0);
    const a = t.leaf(10);
    const b = t.leaf(20);
    const g = backward(t, cond(t, c, a, b));
    expect(g.get(a)).toBe(0);
    expect(g.get(b)).toBe(1);
  });
});

describe('where', () => {
  it('forward', () => {
    const t = new Tape();
    expect(t.valueOf(where(t, t.leaf(1), t.leaf(10), t.leaf(20)))).toBe(10);
    expect(t.valueOf(where(t, t.leaf(0), t.leaf(10), t.leaf(20)))).toBe(20);
  });

  it('grad routes', () => {
    const t = new Tape();
    const m = t.leaf(1);
    const a = t.leaf(5);
    const b = t.leaf(7);
    const g = backward(t, where(t, m, a, b));
    expect(g.get(a)).toBe(1);
    expect(g.get(b)).toBe(0);
  });
});

describe('select', () => {
  it('forward picks by index', () => {
    const t = new Tape();
    const out = select(t, t.leaf(2), t.leaf(10), t.leaf(20), t.leaf(30));
    expect(t.valueOf(out)).toBe(30);
  });

  it('clamps out-of-range index to nearest valid', () => {
    const t = new Tape();
    expect(t.valueOf(select(t, t.leaf(5), t.leaf(10), t.leaf(20)))).toBe(20);
    expect(t.valueOf(select(t, t.leaf(-3), t.leaf(10), t.leaf(20)))).toBe(10);
  });

  it('grad goes to chosen choice only', () => {
    const t = new Tape();
    const idx = t.leaf(1);
    const a = t.leaf(10);
    const b = t.leaf(20);
    const g = backward(t, select(t, idx, a, b));
    expect(g.get(a)).toBe(0);
    expect(g.get(b)).toBe(1);
    expect(g.get(idx)).toBe(0);
  });

  it('refuses zero choices', () => {
    expect(() => select(new Tape(), 0 as never)).toThrow(RangeError);
  });
});
