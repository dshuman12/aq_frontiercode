// select(idx, ...choices): pick `choices[round(idx)]`. Treated as a
// non-differentiable selector; the index gradient is always 0, the
// chosen branch routes the gradient through.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const selectHandler: OpHandler = {
  evalFn: (i) => {
    const idx = Math.max(0, Math.min(i.length - 2, Math.round(i[0]!)));
    return i[idx + 1]!;
  },
  ctxFn: (i) => Math.max(0, Math.min(i.length - 2, Math.round(i[0]!))),
};

export const selectBackward: BackwardFn = (inputs, gOut, _v, ctx) => {
  const chosen = ctx as number;
  const out = new Array<number>(inputs.length);
  for (let i = 0; i < inputs.length; i++) out[i] = 0;
  out[chosen + 1] = gOut;
  return out;
};

export function select(t: Tape, idx: NodeId, ...choices: NodeId[]): NodeId {
  if (choices.length === 0) {
    throw new RangeError('select: needs at least one choice');
  }
  return t.append('select', [idx, ...choices], selectHandler);
}
