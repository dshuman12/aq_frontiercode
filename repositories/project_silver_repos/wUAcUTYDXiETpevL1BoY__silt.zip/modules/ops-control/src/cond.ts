// cond(c, a, b) = c > 0 ? a : b
// Backward routes upstream gradient to a OR b based on the cond value.
// The condition itself receives zero (its forward is a step function).

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const condHandler: OpHandler = {
  evalFn: (i) => (i[0]! > 0 ? i[1]! : i[2]!),
  ctxFn: (i) => (i[0]! > 0 ? 1 : 0),
};

export const condBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const branch = ctx as 0 | 1;
  if (branch === 1) return [0, gOut, 0];
  return [0, 0, gOut];
};

export function cond(t: Tape, c: NodeId, a: NodeId, b: NodeId): NodeId {
  return t.append('cond', [c, a, b], condHandler);
}
