// where(mask, a, b) = mask ? a : b
// Same shape as cond but the mask is interpreted as boolean (mask != 0).

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const whereHandler: OpHandler = {
  evalFn: (i) => (i[0]! !== 0 ? i[1]! : i[2]!),
  ctxFn: (i) => (i[0]! !== 0 ? 1 : 0),
};

export const whereBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const branch = ctx as 0 | 1;
  if (branch === 1) return [0, gOut, 0];
  return [0, 0, gOut];
};

export function where(t: Tape, mask: NodeId, a: NodeId, b: NodeId): NodeId {
  return t.append('where', [mask, a, b], whereHandler);
}
