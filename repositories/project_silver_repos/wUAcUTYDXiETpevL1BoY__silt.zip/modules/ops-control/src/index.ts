// Differentiable control flow.
//
// `cond(c, a, b)` returns `c > 0 ? a : b`. Gradient routes to whichever
// branch was selected; the unselected branch gets a literal zero.
// This is correct for first-order gradients but causes the Hessian to
// be non-symmetric in compositions involving where(...) -- see the
// note in TODO.md and the partial fix sketch in docs/notes.

import './register.js';

export { cond } from './cond.js';
export { where } from './where.js';
export { select } from './select.js';
