import { registerBackward } from '@silt/backward';
import { condBackward } from './cond.js';
import { whereBackward } from './where.js';
import { selectBackward } from './select.js';

registerBackward('cond', condBackward);
registerBackward('where', whereBackward);
registerBackward('select', selectBackward);
