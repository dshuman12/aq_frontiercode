import { Tape } from '@silt/core-tape';
import { add, mul } from '@silt/ops-elementary';
import { encodeTape, decodeTape, MAGIC, FORMAT_VERSION } from '../src/index.js';
import { SerializationError } from '@silt/core-errors';

describe('encodeTape / decodeTape', () => {
  it('round-trips an empty tape', () => {
    const t = new Tape();
    const buf = encodeTape(t);
    const t2 = decodeTape(buf);
    expect(t2.size()).toBe(0);
  });

  it('round-trips a single leaf', () => {
    const t = new Tape();
    t.leaf(2.5);
    const buf = encodeTape(t);
    const t2 = decodeTape(buf);
    expect(t2.size()).toBe(1);
    expect(t2.valueOf(1 as never)).toBe(2.5);
  });

  it('round-trips a tape with elementary ops', () => {
    const t = new Tape();
    const a = t.leaf(2);
    const b = t.leaf(3);
    const c = mul(t, a, b);
    const d = add(t, c, a);
    const buf = encodeTape(t);
    const t2 = decodeTape(buf);
    expect(t2.size()).toBe(t.size());
    // Forward values are preserved as-stored, so node 4 has value 8.
    expect(t2.valueOf(d as never)).toBe(8);
  });

  it('header has correct magic and version', () => {
    const t = new Tape();
    const buf = encodeTape(t);
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    expect(dv.getUint32(0, false)).toBe(MAGIC);
    expect(dv.getUint32(4, false)).toBe(FORMAT_VERSION);
  });

  it('throws on bad magic', () => {
    const buf = new Uint8Array(16);
    expect(() => decodeTape(buf)).toThrow(SerializationError);
  });

  it('throws on truncated buffer', () => {
    expect(() => decodeTape(new Uint8Array(5))).toThrow(SerializationError);
  });

  it('throws on bad version', () => {
    const buf = new Uint8Array(16);
    const dv = new DataView(buf.buffer);
    dv.setUint32(0, MAGIC, false);
    dv.setUint32(4, 99, false);
    expect(() => decodeTape(buf)).toThrow(SerializationError);
  });
});
