// Tape codec. The encoded buffer is intended to be re-loaded by the
// silt deserializer in the same process or another silt process.
//
// We don't currently support cross-version migration in code; the
// tools/migrate path handles that explicitly. See TODO.md for the
// open issue around v2 tapes that had > 2^32 nodes.

import type { Tape } from '@silt/core-tape';
import { Tape as TapeCtor } from '@silt/core-tape';
import { SerializationError } from '@silt/core-errors';

export const MAGIC = 0x53494c54; // 'SILT'
export const FORMAT_VERSION = 3;

const OP_KIND_TABLE: Record<string, number> = {
  leaf: 0,
  const: 1,
  add: 2,
  sub: 3,
  mul: 4,
  div: 5,
  neg: 6,
  abs: 7,
  sin: 8,
  cos: 9,
  exp: 10,
  log: 11,
  sum: 12,
  mean: 13,
};

const OP_KIND_INV: string[] = (() => {
  const arr: string[] = [];
  for (const [k, v] of Object.entries(OP_KIND_TABLE)) arr[v] = k;
  return arr;
})();

export function encodeTape(t: Tape): Uint8Array {
  // Two-pass: compute size, then write.
  const records: Uint8Array[] = [];
  // Header
  const header = new Uint8Array(16);
  const hv = new DataView(header.buffer);
  hv.setUint32(0, MAGIC, false);
  hv.setUint32(4, FORMAT_VERSION, false);
  hv.setUint32(8, 0x1, false); // flag: uint53 IDs
  hv.setUint32(12, 0, false);
  records.push(header);

  for (const node of t.iter()) {
    const opId = OP_KIND_TABLE[node.op];
    if (opId === undefined) {
      throw new SerializationError(`encodeTape: op '${node.op}' not in encoding table`);
    }
    // record buffer: opId + varint inputs.length + per-input varints + 8-byte float
    const opByte = new Uint8Array([opId]);
    const inLen = encodeVarint(node.inputs.length);
    const inIds: Uint8Array[] = [];
    for (const id of node.inputs) inIds.push(encodeVarint(id));
    const valBuf = new Uint8Array(8);
    new DataView(valBuf.buffer).setFloat64(0, node.value ?? 0, false);
    records.push(opByte, inLen, ...inIds, valBuf);
  }

  return concat(records);
}

export function decodeTape(buf: Uint8Array): Tape {
  if (buf.length < 16) {
    throw new SerializationError('decodeTape: buffer too short for header');
  }
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const magic = dv.getUint32(0, false);
  if (magic !== MAGIC) {
    throw new SerializationError(`decodeTape: bad magic 0x${magic.toString(16)}`);
  }
  const version = dv.getUint32(4, false);
  if (version !== FORMAT_VERSION) {
    throw new SerializationError(`decodeTape: unsupported version ${version}`);
  }

  const tape = new TapeCtor();
  let offset = 16;
  while (offset < buf.length) {
    const opId = buf[offset++]!;
    const op = OP_KIND_INV[opId];
    if (op === undefined) {
      throw new SerializationError(`decodeTape: unknown op id ${opId}`);
    }
    const [nIn, off1] = decodeVarint(buf, offset);
    offset = off1;
    const inputs: number[] = [];
    for (let i = 0; i < nIn; i++) {
      const [id, off2] = decodeVarint(buf, offset);
      offset = off2;
      inputs.push(id);
    }
    if (offset + 8 > buf.length) {
      throw new SerializationError('decodeTape: truncated value');
    }
    const v = dv.getFloat64(offset, false);
    offset += 8;
    if (op === 'leaf') {
      tape.leaf(v);
    } else if (op === 'const') {
      tape.const(v);
    } else {
      // We synthesize a passthrough handler that just returns the
      // stored forward value. Callers needing replay must re-attach
      // real handlers.
      tape.append(op as never, inputs as never[], { evalFn: () => v });
    }
  }
  return tape;
}

function encodeVarint(n: number): Uint8Array {
  if (!Number.isInteger(n) || n < 0) {
    throw new SerializationError(`encodeVarint: bad input ${n}`);
  }
  const bytes: number[] = [];
  let x = n;
  while (x >= 0x80) {
    bytes.push((x & 0x7f) | 0x80);
    x = Math.floor(x / 128);
  }
  bytes.push(x & 0x7f);
  return new Uint8Array(bytes);
}

function decodeVarint(buf: Uint8Array, offset: number): [number, number] {
  let x = 0;
  let shift = 1;
  let off = offset;
  while (off < buf.length) {
    const b = buf[off++]!;
    x += (b & 0x7f) * shift;
    if ((b & 0x80) === 0) return [x, off];
    shift *= 128;
    if (shift > Number.MAX_SAFE_INTEGER) {
      throw new SerializationError('decodeVarint: overflow');
    }
  }
  throw new SerializationError('decodeVarint: truncated');
}

function concat(parts: Uint8Array[]): Uint8Array {
  let total = 0;
  for (const p of parts) total += p.length;
  const out = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return out;
}
