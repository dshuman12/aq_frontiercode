// Tape serializer.
//
// Format v3 (current):
//   16-byte header:
//     bytes 0..3   magic "SILT" (0x53494c54)
//     bytes 4..7   version uint32 (= 3)
//     bytes 8..11  flags uint32 (bit 0 = uint53 IDs)
//     bytes 12..15 reserved, zero
//   then a sequence of node records:
//     1 byte op kind id (mapping in OP_KIND_TABLE)
//     varint input count
//     varint per input id (uint53-encoded)
//     8 bytes float64 forward value
//
// node IDs are written as uint53; v0..v2 used uint32.

export { encodeTape, decodeTape, FORMAT_VERSION, MAGIC } from './codec.js';
