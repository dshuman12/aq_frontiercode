import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { sumReduce, meanReduce, prodReduce, minReduce, maxReduce, argmax } from '../src/index.js';

describe('sumReduce', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(sumReduce(t, t.leaf(1), t.leaf(2), t.leaf(3)))).toBe(6);
  });

  it('grad is 1 for every input', () => {
    const t = tape();
    const xs = [t.leaf(1), t.leaf(2), t.leaf(3)];
    const g = backward(t, sumReduce(t, ...xs));
    for (const x of xs) expect(g.get(x)).toBe(1);
  });

  it('refuses zero inputs', () => {
    expect(() => sumReduce(tape())).toThrow(RangeError);
  });

  it('handles a single input', () => {
    const t = tape();
    const x = t.leaf(7);
    expect(t.valueOf(sumReduce(t, x))).toBe(7);
  });
});

describe('meanReduce', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(meanReduce(t, t.leaf(2), t.leaf(4)))).toBe(3);
  });

  it('grad is 1/n for every input', () => {
    const t = tape();
    const a = t.leaf(2);
    const b = t.leaf(4);
    const c = t.leaf(6);
    const g = backward(t, meanReduce(t, a, b, c));
    expect(g.get(a)).toBeCloseTo(1 / 3, 12);
    expect(g.get(b)).toBeCloseTo(1 / 3, 12);
    expect(g.get(c)).toBeCloseTo(1 / 3, 12);
  });
});

describe('prodReduce', () => {
  it('forward', () => {
    const t = tape();
    expect(t.valueOf(prodReduce(t, t.leaf(2), t.leaf(3), t.leaf(4)))).toBe(24);
  });

  it('grad of x*y*z w.r.t. each is product of the others', () => {
    const t = tape();
    const a = t.leaf(2);
    const b = t.leaf(3);
    const c = t.leaf(4);
    const g = backward(t, prodReduce(t, a, b, c));
    expect(g.get(a)).toBe(12);
    expect(g.get(b)).toBe(8);
    expect(g.get(c)).toBe(6);
  });

  it('handles a zero input correctly', () => {
    // Product = 0; partial w.r.t. x=0 is the product of the others;
    // partials w.r.t. nonzero inputs are 0 (since prod is 0).
    const t = tape();
    const a = t.leaf(0);
    const b = t.leaf(3);
    const c = t.leaf(4);
    const g = backward(t, prodReduce(t, a, b, c));
    expect(g.get(a)).toBe(12);
    expect(g.get(b)).toBe(0);
    expect(g.get(c)).toBe(0);
  });
});

describe('minReduce', () => {
  it('forward picks min', () => {
    const t = tape();
    expect(t.valueOf(minReduce(t, t.leaf(3), t.leaf(1), t.leaf(2)))).toBe(1);
  });

  it('grad routes only to the argmin', () => {
    const t = tape();
    const a = t.leaf(3);
    const b = t.leaf(1);
    const c = t.leaf(2);
    const g = backward(t, minReduce(t, a, b, c));
    expect(g.get(a)).toBe(0);
    expect(g.get(b)).toBe(1);
    expect(g.get(c)).toBe(0);
  });

  it('breaks ties by first index', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(1);
    const g = backward(t, minReduce(t, a, b));
    expect(g.get(a)).toBe(1);
    expect(g.get(b)).toBe(0);
  });
});

describe('maxReduce', () => {
  it('grad routes to the argmax', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(3);
    const c = t.leaf(2);
    const g = backward(t, maxReduce(t, a, b, c));
    expect(g.get(b)).toBe(1);
  });
});

describe('argmax', () => {
  it('returns an index', () => {
    const t = tape();
    expect(t.valueOf(argmax(t, t.leaf(1), t.leaf(3), t.leaf(2)))).toBe(1);
  });

  it('zero gradient through argmax', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(3);
    const g = backward(t, argmax(t, a, b));
    expect(g.get(a)).toBe(0);
    expect(g.get(b)).toBe(0);
  });
});
