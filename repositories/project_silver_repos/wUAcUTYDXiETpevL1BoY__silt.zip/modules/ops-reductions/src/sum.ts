// sum(x_1, ..., x_n) = sum_i x_i (Kahan-compensated)
// d/dx_i = 1 for every i.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';
import { orderedSum } from '@silt/core-determinism';

export const sumHandler: OpHandler = {
  evalFn: (i) => orderedSum(i),
};

export const sumBackward: BackwardFn = (inputs, gOut) => {
  const out = new Array<number>(inputs.length);
  for (let i = 0; i < inputs.length; i++) out[i] = gOut;
  return out;
};

export function sumReduce(t: Tape, ...nodes: NodeId[]): NodeId {
  if (nodes.length === 0) {
    throw new RangeError('sumReduce requires at least one input');
  }
  return t.append('sum', nodes, sumHandler);
}
