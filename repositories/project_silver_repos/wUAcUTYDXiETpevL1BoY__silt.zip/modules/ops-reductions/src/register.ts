import { registerBackward } from '@silt/backward';
import { sumBackward } from './sum.js';
import { meanBackward } from './mean.js';
import { prodBackward } from './prod.js';
import { minReduceBackward } from './min.js';
import { maxReduceBackward } from './max.js';
import { argmaxBackward } from './argmax.js';

registerBackward('sum', sumBackward);
registerBackward('mean', meanBackward);
registerBackward('prod', prodBackward);
registerBackward('min-reduce', minReduceBackward);
registerBackward('max-reduce', maxReduceBackward);
registerBackward('argmax', argmaxBackward);
