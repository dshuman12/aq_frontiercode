// All reductions go through @silt/core-determinism.orderedSum / orderedProd
// to guarantee bit-exact results across runs and machines.
//
// The forward functions accept variadic NodeId inputs. The op-registry
// wires up the reverse-mode partials.

import './register.js';

export { sumReduce } from './sum.js';
export { meanReduce } from './mean.js';
export { prodReduce } from './prod.js';
export { minReduce } from './min.js';
export { maxReduce } from './max.js';
export { argmax } from './argmax.js';
