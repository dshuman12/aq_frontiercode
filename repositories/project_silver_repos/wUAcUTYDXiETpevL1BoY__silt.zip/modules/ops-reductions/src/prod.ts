// prod(x_1, ..., x_n) = product
// d/dx_i = prod / x_i (when x_i != 0)
// When some x_i is zero, the analytic partial is the product of the
// other inputs. We compute that explicitly to avoid divide-by-zero.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';
import { orderedProd } from '@silt/core-determinism';

export const prodHandler: OpHandler = {
  evalFn: (i) => orderedProd(i),
  ctxFn: (i) => i.slice(),
};

export const prodBackward: BackwardFn = (_inputs, gOut, _v, ctx) => {
  const xs = ctx as number[];
  const n = xs.length;
  const out = new Array<number>(n);
  // Build prefix and suffix products in O(n).
  const prefix = new Array<number>(n + 1);
  const suffix = new Array<number>(n + 1);
  prefix[0] = 1;
  suffix[n] = 1;
  for (let i = 0; i < n; i++) prefix[i + 1] = prefix[i]! * xs[i]!;
  for (let i = n - 1; i >= 0; i--) suffix[i] = suffix[i + 1]! * xs[i]!;
  for (let i = 0; i < n; i++) out[i] = gOut * prefix[i]! * suffix[i + 1]!;
  return out;
};

export function prodReduce(t: Tape, ...nodes: NodeId[]): NodeId {
  if (nodes.length === 0) {
    throw new RangeError('prodReduce requires at least one input');
  }
  return t.append('prod', nodes, prodHandler);
}
