// min(x_1, ..., x_n) = smallest input
// Gradient flows only to the (first) argmin. Tie-breaking is by index
// for determinism.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const minReduceHandler: OpHandler = {
  evalFn: (i) => {
    let best = i[0]!;
    for (let k = 1; k < i.length; k++) if (i[k]! < best) best = i[k]!;
    return best;
  },
  ctxFn: (i) => {
    let bestIdx = 0;
    let best = i[0]!;
    for (let k = 1; k < i.length; k++) {
      if (i[k]! < best) {
        best = i[k]!;
        bestIdx = k;
      }
    }
    return bestIdx;
  },
};

export const minReduceBackward: BackwardFn = (inputs, gOut, _v, ctx) => {
  const idx = ctx as number;
  const out = new Array<number>(inputs.length);
  for (let i = 0; i < inputs.length; i++) out[i] = 0;
  out[idx] = gOut;
  return out;
};

export function minReduce(t: Tape, ...nodes: NodeId[]): NodeId {
  if (nodes.length === 0) {
    throw new RangeError('minReduce requires at least one input');
  }
  return t.append('min-reduce', nodes, minReduceHandler);
}
