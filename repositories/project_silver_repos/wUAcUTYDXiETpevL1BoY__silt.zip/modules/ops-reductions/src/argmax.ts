// argmax: returns the index of the maximum input as a forward value.
// No gradient flows through argmax; it's a discrete operation.
// We expose it for use in selection / lookup composites where a
// later op (e.g. gather) is the differentiable consumer.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const argmaxHandler: OpHandler = {
  evalFn: (i) => {
    let bestIdx = 0;
    let best = i[0]!;
    for (let k = 1; k < i.length; k++) {
      if (i[k]! > best) {
        best = i[k]!;
        bestIdx = k;
      }
    }
    return bestIdx;
  },
};

export const argmaxBackward: BackwardFn = (inputs) => {
  const out = new Array<number>(inputs.length);
  for (let i = 0; i < inputs.length; i++) out[i] = 0;
  return out;
};

export function argmax(t: Tape, ...nodes: NodeId[]): NodeId {
  if (nodes.length === 0) {
    throw new RangeError('argmax requires at least one input');
  }
  return t.append('argmax', nodes, argmaxHandler);
}
