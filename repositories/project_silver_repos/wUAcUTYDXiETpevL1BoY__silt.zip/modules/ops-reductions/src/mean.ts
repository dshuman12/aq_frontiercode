// mean(x_1, ..., x_n) = (sum / n)
// d/dx_i = 1/n.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';
import { orderedMean } from '@silt/core-determinism';

export const meanHandler: OpHandler = {
  evalFn: (i) => orderedMean(i),
};

export const meanBackward: BackwardFn = (inputs, gOut) => {
  const n = inputs.length;
  const out = new Array<number>(n);
  const share = gOut / n;
  for (let i = 0; i < n; i++) out[i] = share;
  return out;
};

export function meanReduce(t: Tape, ...nodes: NodeId[]): NodeId {
  if (nodes.length === 0) {
    throw new RangeError('meanReduce requires at least one input');
  }
  return t.append('mean', nodes, meanHandler);
}
