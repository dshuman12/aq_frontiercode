import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { broadcast, sumToShape, broadcastTo } from '../src/index.js';
import { add, mul } from '@silt/ops-elementary';

describe('broadcast', () => {
  it('returns N copies of the same id', () => {
    const t = new Tape();
    const x = t.leaf(2);
    const xs = broadcast(x, 4);
    expect(xs).toHaveLength(4);
    for (const id of xs) expect(id).toBe(x);
  });

  it('count of 0 returns empty', () => {
    expect(broadcast(1 as never, 0)).toHaveLength(0);
  });

  it('refuses negative count', () => {
    expect(() => broadcast(1 as never, -1)).toThrow(RangeError);
  });

  it('refuses non-integer count', () => {
    expect(() => broadcast(1 as never, 1.5)).toThrow(RangeError);
  });

  it('grad through fan-out accumulates additively', () => {
    // f = x + x + x = 3x ; df/dx should be 3
    const t = new Tape();
    const x = t.leaf(1);
    const xs = broadcast(x, 3);
    const a = add(t, xs[0]!, xs[1]!);
    const b = add(t, a, xs[2]!);
    const g = backward(t, b);
    expect(g.get(x)).toBe(3);
  });
});

describe('broadcastTo', () => {
  it('alias of broadcast', () => {
    const t = new Tape();
    const x = t.leaf(1);
    expect(broadcastTo(x, 5)).toEqual(broadcast(x, 5));
  });
});

describe('sumToShape', () => {
  it('sums many inputs', () => {
    const t = new Tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.leaf(3);
    expect(t.valueOf(sumToShape(t, [a, b, c]))).toBe(6);
  });

  it('grad routes back to each contributor', () => {
    const t = new Tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const g = backward(t, sumToShape(t, [a, b]));
    expect(g.get(a)).toBe(1);
    expect(g.get(b)).toBe(1);
  });

  it('refuses empty input', () => {
    expect(() => sumToShape(new Tape(), [])).toThrow(RangeError);
  });

  it('roundtrip: sumToShape(broadcast(x, n)) = n*x', () => {
    const t = new Tape();
    const x = t.leaf(3);
    const xs = broadcast(x, 4);
    const s = sumToShape(t, xs);
    expect(t.valueOf(s)).toBe(12);
    const g = backward(t, s);
    expect(g.get(x)).toBe(4);
  });

  it('composable with mul', () => {
    const t = new Tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    // (x*y) + (x*y) = 2xy
    const xy = mul(t, x, y);
    const dup = broadcast(xy, 2);
    const out = sumToShape(t, dup);
    expect(t.valueOf(out)).toBe(12);
    const g = backward(t, out);
    expect(g.get(x)).toBe(6); // 2y
    expect(g.get(y)).toBe(4); // 2x
  });
});
