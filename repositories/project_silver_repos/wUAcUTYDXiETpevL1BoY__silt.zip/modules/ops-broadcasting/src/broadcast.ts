// broadcast(scalar, count) returns an array of `count` copies of the
// same NodeId. The scalar is shared, so backward into broadcast
// accumulates contributions from every consumer additively, which is
// exactly the chain-rule answer for a fan-out.
//
// sumToShape(nodes) is the inverse: collapse a fan-out by summing.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { sumReduce } from '@silt/ops-reductions';

export function broadcast(scalar: NodeId, count: number): NodeId[] {
  if (!Number.isInteger(count) || count < 0) {
    throw new RangeError(`broadcast: count must be non-negative integer, got ${count}`);
  }
  const out = new Array<NodeId>(count);
  for (let i = 0; i < count; i++) out[i] = scalar;
  return out;
}

// Alias kept for code that reads more naturally with the NumPy spelling.
export function broadcastTo(scalar: NodeId, count: number): NodeId[] {
  return broadcast(scalar, count);
}

export function sumToShape(t: Tape, nodes: readonly NodeId[]): NodeId {
  if (nodes.length === 0) {
    throw new RangeError('sumToShape: needs at least one input');
  }
  return sumReduce(t, ...nodes);
}
