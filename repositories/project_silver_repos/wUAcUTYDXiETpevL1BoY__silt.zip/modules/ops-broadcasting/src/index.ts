// Broadcasting via explicit fan-out and sum-to-shape.
//
// Since silt's tape is scalar, we don't really need to "broadcast" a
// scalar -- we can just use the same NodeId in multiple places, and
// gradient accumulates correctly automatically. The functions below
// expose this pattern with descriptive names for code that wants to
// mirror NumPy semantics.

import './register.js';

export { broadcast, sumToShape, broadcastTo } from './broadcast.js';
