// Wrapper around a Tape that defers forward eval. Currently a
// thin facade -- the real lazy semantics will arrive when we add
// shape inference (see TODO.md).

import { Tape } from '@silt/core-tape';
import { replay } from '@silt/core-tape';

export class LazyTape {
  private _tape: Tape;
  private _materialized = false;

  constructor() {
    this._tape = new Tape();
  }

  underlying(): Tape {
    return this._tape;
  }

  // Force forward evaluation now.
  materialize(): void {
    if (this._materialized) return;
    replay(this._tape);
    this._materialized = true;
  }

  isMaterialized(): boolean {
    return this._materialized;
  }
}
