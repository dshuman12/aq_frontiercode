// Lazy mode: build a tape without evaluating, then evaluate later.
//
// Useful for shape-checking pipelines where you want to inspect the
// op graph without paying forward cost. Currently materializes the
// whole tape on first backward call -- finer-grained "only what's
// needed" is on the TODO list.

export { LazyTape } from './lazy-tape.js';
