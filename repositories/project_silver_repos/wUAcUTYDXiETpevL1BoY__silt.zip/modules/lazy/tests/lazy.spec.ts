import { LazyTape } from '../src/lazy-tape.js';

describe('LazyTape', () => {
  it('starts not materialized', () => {
    const lt = new LazyTape();
    expect(lt.isMaterialized()).toBe(false);
  });

  it('materialize() flips the flag', () => {
    const lt = new LazyTape();
    lt.materialize();
    expect(lt.isMaterialized()).toBe(true);
  });

  it('materialize is idempotent', () => {
    const lt = new LazyTape();
    lt.materialize();
    lt.materialize();
    expect(lt.isMaterialized()).toBe(true);
  });

  it('exposes underlying tape', () => {
    const lt = new LazyTape();
    const t = lt.underlying();
    const x = t.leaf(1);
    expect(t.valueOf(x)).toBe(1);
  });
});
