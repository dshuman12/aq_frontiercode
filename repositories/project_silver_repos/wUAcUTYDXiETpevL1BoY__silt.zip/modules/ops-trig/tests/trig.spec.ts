import { tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { sin, cos, tan, asin, acos, atan, atan2 } from '../src/index.js';

const epsilon = 1e-7;
const places = 6;

function fdCheck1(
  f: (x: number) => number,
  builder: (t: ReturnType<typeof tape>, x: ReturnType<typeof tape>['leaf'] extends (v: number) => infer N ? N : never) => number,
  xs: number[],
): void {
  for (const x of xs) {
    const fd = (f(x + epsilon) - f(x - epsilon)) / (2 * epsilon);
    const t = tape();
    const a = t.leaf(x);
    const out = builder(t, a as never);
    const g = backward(t, out as never);
    expect(g.get(a)).toBeCloseTo(fd, places);
  }
}

describe('sin', () => {
  it('forward matches Math.sin', () => {
    const t = tape();
    expect(t.valueOf(sin(t, t.leaf(1.5)))).toBe(Math.sin(1.5));
  });

  it('backward equals cos via FD', () => {
    fdCheck1(Math.sin, (t, x) => sin(t, x), [0, 0.1, 1, -0.5, Math.PI / 4, 2.7]);
  });

  it('grad at 0 is 1', () => {
    const t = tape();
    const x = t.leaf(0);
    const g = backward(t, sin(t, x));
    expect(g.get(x)).toBeCloseTo(1, 12);
  });
});

describe('cos', () => {
  it('forward matches Math.cos', () => {
    const t = tape();
    expect(t.valueOf(cos(t, t.leaf(0)))).toBe(1);
  });

  it('backward equals -sin via FD', () => {
    fdCheck1(Math.cos, (t, x) => cos(t, x), [0, 0.1, 1, -0.5, Math.PI / 3, 2.7]);
  });
});

describe('tan', () => {
  it('forward matches Math.tan', () => {
    const t = tape();
    expect(t.valueOf(tan(t, t.leaf(0)))).toBe(0);
  });

  it('backward = 1 + tan(x)^2 via FD', () => {
    // Stay well away from pi/2 to avoid the singularity.
    fdCheck1(Math.tan, (t, x) => tan(t, x), [0, 0.3, -0.7, 1.0]);
  });
});

describe('asin', () => {
  it('forward matches Math.asin', () => {
    const t = tape();
    expect(t.valueOf(asin(t, t.leaf(0.5)))).toBeCloseTo(Math.PI / 6, 12);
  });

  it('backward via FD on interior of domain', () => {
    fdCheck1(Math.asin, (t, x) => asin(t, x), [-0.5, -0.1, 0, 0.1, 0.5, 0.8]);
  });
});

describe('acos', () => {
  it('forward matches Math.acos', () => {
    const t = tape();
    expect(t.valueOf(acos(t, t.leaf(0)))).toBeCloseTo(Math.PI / 2, 12);
  });

  it('backward via FD on interior', () => {
    fdCheck1(Math.acos, (t, x) => acos(t, x), [-0.5, 0, 0.5, 0.8]);
  });
});

describe('atan', () => {
  it('forward matches Math.atan', () => {
    const t = tape();
    expect(t.valueOf(atan(t, t.leaf(1)))).toBeCloseTo(Math.PI / 4, 12);
  });

  it('backward via FD across the real line', () => {
    fdCheck1(Math.atan, (t, x) => atan(t, x), [-5, -1, 0, 1, 5, 100]);
  });

  it('backward at infinity-ish input is near zero', () => {
    const t = tape();
    const x = t.leaf(1e6);
    const g = backward(t, atan(t, x));
    expect(g.get(x)).toBeLessThan(1e-10);
  });
});

describe('atan2', () => {
  // Tests only cover first quadrant (y > 0, x > 0) and y == 0.
  it('forward matches Math.atan2', () => {
    const t = tape();
    expect(t.valueOf(atan2(t, t.leaf(1), t.leaf(1)))).toBeCloseTo(Math.PI / 4, 12);
  });

  it('forward axis cases', () => {
    const t = tape();
    expect(t.valueOf(atan2(t, t.leaf(1), t.leaf(0)))).toBeCloseTo(Math.PI / 2, 12);
    expect(t.valueOf(atan2(t, t.leaf(0), t.leaf(1)))).toBe(0);
  });

  it('backward via FD in first quadrant', () => {
    const f = (y: number, x: number) => Math.atan2(y, x);
    for (const y of [0.5, 1.0, 2.7]) {
      for (const x of [0.5, 1.0, 3.7]) {
        const fdy = (f(y + epsilon, x) - f(y - epsilon, x)) / (2 * epsilon);
        const fdx = (f(y, x + epsilon) - f(y, x - epsilon)) / (2 * epsilon);
        const t = tape();
        const a = t.leaf(y);
        const b = t.leaf(x);
        const g = backward(t, atan2(t, a, b));
        expect(g.get(a)).toBeCloseTo(fdy, places);
        expect(g.get(b)).toBeCloseTo(fdx, places);
      }
    }
  });
});
