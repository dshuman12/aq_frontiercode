// asin(x) ; d/dx = 1 / sqrt(1 - x^2)
// Domain: |x| <= 1. Outside this, JS's Math.asin returns NaN; we let
// it propagate.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const asinHandler: OpHandler = {
  evalFn: (i) => Math.asin(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const asinBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [gOut / Math.sqrt(1 - x * x)];
};

export function asin(t: Tape, a: NodeId): NodeId {
  return t.append('asin', [a], asinHandler);
}
