// acos(x) ; d/dx = -1 / sqrt(1 - x^2)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const acosHandler: OpHandler = {
  evalFn: (i) => Math.acos(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const acosBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [-gOut / Math.sqrt(1 - x * x)];
};

export function acos(t: Tape, a: NodeId): NodeId {
  return t.append('acos', [a], acosHandler);
}
