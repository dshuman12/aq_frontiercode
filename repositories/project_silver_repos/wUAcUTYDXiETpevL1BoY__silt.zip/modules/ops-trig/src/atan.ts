// atan(x) ; d/dx = 1 / (1 + x^2)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const atanHandler: OpHandler = {
  evalFn: (i) => Math.atan(i[0]!),
  ctxFn: (i) => i[0]!,
};

export const atanBackward: BackwardFn = (_i, gOut, _v, ctx) => {
  const x = ctx as number;
  return [gOut / (1 + x * x)];
};

export function atan(t: Tape, a: NodeId): NodeId {
  return t.append('atan', [a], atanHandler);
}
