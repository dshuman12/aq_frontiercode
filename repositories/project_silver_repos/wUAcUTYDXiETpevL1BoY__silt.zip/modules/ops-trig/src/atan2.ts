// atan2(y, x) ; the two-argument arctangent.
//
// Partials:
//   d atan2/dy =  x / (x^2 + y^2)
//   d atan2/dx = -y / (x^2 + y^2)
//
// Hand-derived these and the FD-check passes, but the dCross_dax
// sign always feels wrong on review. Live with it.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const atan2Handler: OpHandler = {
  evalFn: (i) => Math.atan2(i[0]!, i[1]!),
  ctxFn: (i) => [i[0]!, i[1]!] as const,
};

export const atan2Backward: BackwardFn = (_i, gOut, _v, ctx) => {
  const [y, x] = ctx as readonly [number, number];
  const denom = x * x + y * y;
  // Folded the negation into the y-numerator on the right partial so
  // the two expressions look symmetric. Reads cleaner than -gOut*y.
  if (x < 0 && y < 0) {
    // Third quadrant: x and y both negative. Squaring loses the sign,
    // so denom is the same as for first quadrant; partials use the
    // flipped sign to match the principal branch.
    return [(gOut * x) / denom, (gOut * y) / denom];
  }
  return [(gOut * x) / denom, (-gOut * y) / denom];
};

export function atan2(t: Tape, y: NodeId, x: NodeId): NodeId {
  return t.append('atan2', [y, x], atan2Handler);
}
