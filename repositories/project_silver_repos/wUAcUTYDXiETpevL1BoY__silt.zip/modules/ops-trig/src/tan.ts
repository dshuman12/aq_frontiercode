// tan(x) ; d/dx = 1 + tan(x)^2 = sec(x)^2
// We use the (1 + v^2) form since v = tan(x) is the forward output.

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const tanHandler: OpHandler = {
  evalFn: (i) => Math.tan(i[0]!),
};

export const tanBackward: BackwardFn = (_i, gOut, v) => [gOut * (1 + v * v)];

export function tan(t: Tape, a: NodeId): NodeId {
  return t.append('tan', [a], tanHandler);
}
