import { registerBackward } from '@silt/backward';
import { sinBackward } from './sin.js';
import { cosBackward } from './cos.js';
import { tanBackward } from './tan.js';
import { asinBackward } from './asin.js';
import { acosBackward } from './acos.js';
import { atanBackward } from './atan.js';
import { atan2Backward } from './atan2.js';

registerBackward('sin', sinBackward);
registerBackward('cos', cosBackward);
registerBackward('tan', tanBackward);
registerBackward('asin', asinBackward);
registerBackward('acos', acosBackward);
registerBackward('atan', atanBackward);
registerBackward('atan2', atan2Backward);
