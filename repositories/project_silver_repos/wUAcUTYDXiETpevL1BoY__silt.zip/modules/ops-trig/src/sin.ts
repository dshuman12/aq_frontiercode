// sin(x) ; d/dx = cos(x)

import type { NodeId } from '@silt/core-types';
import type { Tape, OpHandler } from '@silt/core-tape';
import type { BackwardFn } from '@silt/backward';

export const sinHandler: OpHandler = {
  evalFn: (i) => Math.sin(i[0]!),
  ctxFn: (i) => Math.cos(i[0]!),
};

export const sinBackward: BackwardFn = (_i, gOut, _v, ctx) => [gOut * (ctx as number)];

export function sin(t: Tape, a: NodeId): NodeId {
  return t.append('sin', [a], sinHandler);
}
