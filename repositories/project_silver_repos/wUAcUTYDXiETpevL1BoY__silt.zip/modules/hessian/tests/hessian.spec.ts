import { Tape } from '@silt/core-tape';
import { add, mul } from '@silt/ops-elementary';
import { hessian } from '../src/index.js';

describe('hessian', () => {
  it('quadratic f(x) = x^2 has Hessian [[2]]', () => {
    const H = hessian(
      (vs) => {
        const t = new Tape();
        const x = t.leaf(vs[0]!);
        const out = mul(t, x, x);
        return { tape: t, output: out, leaves: [x] };
      },
      [1.0],
    );
    expect(H[0]![0]).toBeCloseTo(2, 4);
  });

  it('f(x, y) = x^2 + y^2 has Hessian [[2, 0], [0, 2]]', () => {
    const H = hessian(
      (vs) => {
        const t = new Tape();
        const x = t.leaf(vs[0]!);
        const y = t.leaf(vs[1]!);
        const out = add(t, mul(t, x, x), mul(t, y, y));
        return { tape: t, output: out, leaves: [x, y] };
      },
      [1.0, 1.0],
    );
    expect(H[0]![0]).toBeCloseTo(2, 4);
    expect(H[0]![1]).toBeCloseTo(0, 4);
    expect(H[1]![0]).toBeCloseTo(0, 4);
    expect(H[1]![1]).toBeCloseTo(2, 4);
  });

  it('f(x, y) = x*y has Hessian [[0, 1], [1, 0]]', () => {
    const H = hessian(
      (vs) => {
        const t = new Tape();
        const x = t.leaf(vs[0]!);
        const y = t.leaf(vs[1]!);
        const out = mul(t, x, y);
        return { tape: t, output: out, leaves: [x, y] };
      },
      [3.0, 4.0],
    );
    expect(H[0]![0]).toBeCloseTo(0, 4);
    expect(H[0]![1]).toBeCloseTo(1, 4);
    expect(H[1]![0]).toBeCloseTo(1, 4);
    expect(H[1]![1]).toBeCloseTo(0, 4);
  });

  it('output size is n x n', () => {
    const H = hessian(
      (vs) => {
        const t = new Tape();
        const xs = vs.map((v) => t.leaf(v));
        // sum of squares
        let acc = mul(t, xs[0]!, xs[0]!);
        for (let i = 1; i < xs.length; i++) acc = add(t, acc, mul(t, xs[i]!, xs[i]!));
        return { tape: t, output: acc, leaves: xs };
      },
      [1, 2, 3],
    );
    expect(H).toHaveLength(3);
    expect(H[0]).toHaveLength(3);
  });
});
