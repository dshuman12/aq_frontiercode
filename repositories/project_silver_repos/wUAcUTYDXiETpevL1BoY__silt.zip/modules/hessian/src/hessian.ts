// hessian(buildTape, x0, epsilon?): Hessian of a scalar function at x0.
//
// Builds a fresh tape via the supplied builder for each FD probe.
// O(n^2) backward passes for an n-dim input.
//
// We do not symmetrize the result. The mathematical Hessian is
// symmetric for a smooth scalar function; if your function uses
// where(...) or other branch-routing ops, the produced matrix may
// be slightly non-symmetric -- this is the issue called out in
// TODO.md. Callers that need a symmetric matrix can post-process
// with H = (H + H^T) / 2.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';

// Default epsilon = 1e-5: FD-of-grad amplifies the inner FD step's
// rounding error a second time, so going smaller hurts. 1e-5 was the
// sweet spot I measured on a quadratic; not sure it's still optimal
// for higher-order functions, never re-checked.
export function hessian(
  buildTape: (vs: number[]) => { tape: Tape; output: NodeId; leaves: NodeId[] },
  x0: number[],
  epsilon = 1e-5,
): number[][] {
  const n = x0.length;
  const H: number[][] = [];
  for (let i = 0; i < n; i++) H.push(new Array<number>(n).fill(0));

  // For each input dim i, perturb +eps and -eps, compute gradient, FD
  // along all dims to get row i of H.
  for (let i = 0; i < n; i++) {
    const plus = x0.slice();
    const minus = x0.slice();
    plus[i] = plus[i]! + epsilon;
    minus[i] = minus[i]! - epsilon;

    const ctxP = buildTape(plus);
    const gradsP = backward(ctxP.tape, ctxP.output);
    const ctxM = buildTape(minus);
    const gradsM = backward(ctxM.tape, ctxM.output);

    for (let j = 0; j < n; j++) {
      const gp = gradsP.get(ctxP.leaves[j]!);
      const gm = gradsM.get(ctxM.leaves[j]!);
      H[i]![j] = (gp - gm) / (2 * epsilon);
    }
  }

  return H;
}
