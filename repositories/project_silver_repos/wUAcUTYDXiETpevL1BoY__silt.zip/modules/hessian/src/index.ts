// Hessian via finite difference of gradients.
//
// True forward-over-reverse Hessian needs dual numbers, which silt
// doesn't currently expose. The FD-of-grad approach is good enough
// for problems where the Hessian is small (n < 100) and you want it
// just for second-order optimization or curvature inspection.

export { hessian } from './hessian.js';
