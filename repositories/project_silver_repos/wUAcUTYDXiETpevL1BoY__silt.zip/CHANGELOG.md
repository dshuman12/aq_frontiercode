# Changelog

## 0.5.2 - 2026-05-08

- bench harness now reports per-op allocation counts when `--alloc` is
  passed. Useful for hunting the gradcheck inner-loop allocation; no
  fix yet, just visibility.
- minor doc fix in `derivations/04-matrix-ops.md`.

## 0.5.1 - 2026-04-21

- gradcheck now accepts a custom `epsilon` parameter for the FD step.
  Default still `1e-7`. The 1e-7 default came from a measurement on
  M1 in early February that I haven't re-checked on x86; if your
  gradcheck is flaky, try `2e-6`.
- noticed during a code review that `atan2` backward only had test
  coverage in the first quadrant; the third-quadrant case looks
  suspect on inspection but FD doesn't currently disagree. Filed
  for follow-up.
- `optimizers/adam` now exposes `currentStep` so callers can resume
  state across runs.

## 0.5.0 - 2026-04-03

Tape format v3. **Breaking** for serialized tapes from 0.4.x.

- node IDs are now 53-bit safe-integer-encoded instead of 32-bit.
  Existing 32-bit tapes can be migrated with `tools/migrate`.
- new `lazy` mode that delays forward eval until backward is requested.
  Useful for batched gradcheck where you want to defer materializing
  intermediates.
- `serialize` now writes a 16-byte header with magic + version +
  uint53-flag, replacing the 8-byte header from v2.

## 0.4.0 - 2026-03-12

- `hessian` (forward-over-reverse) added. The forward mode is
  implemented as a tape-walk with dual numbers, not a separate
  abstraction; this keeps the implementation small.
- `jacobian` rewritten to use vmap-of-grad rather than batched scalar
  grads. About 3-5x faster on rank-2 outputs in the included bench.
- `where`, `cond`, `select` ops now route gradients correctly through
  the unselected branch as a zero -- previously the unselected branch
  was untouched, which broke higher-order derivatives.

## 0.3.0 - 2026-02-15

- ops-matrix: matmul, transpose, diag, trace, det. Determinant uses
  LU decomposition without pivoting; works for invertible matrices,
  fails on singular ones with a clear `NumericError`.
- ops-broadcasting added; explicit broadcast + sum-to-shape operators.
  Higher-rank arithmetic now goes through these.
- ops-indexing: gather / scatter / concat / split.

## 0.2.0 - 2026-01-19

- ops-trig, ops-hyperbolic, ops-exponential. All gradcheck-verified.
- backward walker: depth-first reverse traversal with explicit
  topological sort. Replaces the recursive prototype.
- `gradcheck` is now its own module; was previously inline in tests.

## 0.1.0 - 2025-12-22

Initial cut. Scope:

- core: types, errors, fp, determinism, random, tape, graph
- ops-elementary: add, sub, mul, div, neg, abs, sign, min, max
- forward eval, very simple backward via per-op closures
- jest + swc-jest with the determinism shim

Not yet: matrix ops, broadcasting, optimizers, serialize, hessian.

## 0.0.1 - 2025-11-19

Empty repo. README and the determinism contract draft.
