# Security policy

silt is a math kernel, not a network service. The attack surface is
small: it does not parse untrusted input over the wire, does not open
sockets, does not execute arbitrary code at runtime.

The serializer (`modules/serialize`) does parse binary buffers. If an
attacker controls a buffer that gets fed to the deserializer, they can:

- Trigger `SerializationError` exceptions (denial of service if the
  caller doesn't catch them)
- Cause out-of-memory by claiming a large tape size in the header --
  the deserializer pre-allocates based on the header, then validates,
  so a malicious header can OOM the process before the validation runs
- Cause the deserializer to walk a corrupt graph; we do bounds-check
  every NodeId reference but if you find a case that escapes, please
  report it

To report a security issue, email asifhammad84@gmail.com. I'll respond
within a week.

I do not currently issue CVEs. The library is not on any public CVE
database.
