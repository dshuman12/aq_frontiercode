// 2-layer MLP, hand-coded. Trains on the XOR pattern.
//
// Network shape: 2 -> 4 -> 1, tanh activation, MSE loss.
// Total params: 2*4 + 4 + 4*1 + 1 = 17.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul, sub } from '@silt/ops-elementary';
import { tanhAct } from '@silt/ops-pieces';
import { sumReduce } from '@silt/ops-reductions';
import { sgd } from '@silt/optimizers';
import { Mulberry32, sampleUniform } from '@silt/core-random';

const HIDDEN = 4;
const PARAM_COUNT = 2 * HIDDEN + HIDDEN + HIDDEN * 1 + 1;

// XOR truth table.
const X = [
  [0, 0],
  [0, 1],
  [1, 0],
  [1, 1],
];
const Y = [0, 1, 1, 0];

function buildLossTape(
  params: Float64Array,
  xs: number[][],
  ys: number[],
): {
  tape: Tape;
  output: import('@silt/core-types').NodeId;
  paramLeaves: import('@silt/core-types').NodeId[];
} {
  const t = new Tape();
  const p: import('@silt/core-types').NodeId[] = [];
  for (let i = 0; i < params.length; i++) p.push(t.leaf(params[i]!));

  // Index helpers
  // W1 (2x4): p[0..7]   row-major
  // b1 (4):   p[8..11]
  // W2 (4x1): p[12..15]
  // b2 (1):   p[16]
  const losses: import('@silt/core-types').NodeId[] = [];
  for (let n = 0; n < xs.length; n++) {
    const x0 = t.const(xs[n]![0]!);
    const x1 = t.const(xs[n]![1]!);
    const yTarget = t.const(ys[n]!);
    // hidden = tanh(x @ W1 + b1)
    const hidden: import('@silt/core-types').NodeId[] = [];
    for (let j = 0; j < HIDDEN; j++) {
      const w0j = p[0 * HIDDEN + j]!;
      const w1j = p[1 * HIDDEN + j]!;
      const bj = p[2 * HIDDEN + j]!;
      const z = add(t, add(t, mul(t, x0, w0j), mul(t, x1, w1j)), bj);
      hidden.push(tanhAct(t, z));
    }
    // pred = hidden @ W2 + b2
    const v2Base = 3 * HIDDEN;
    let dotAcc = mul(t, hidden[0]!, p[v2Base]!);
    for (let j = 1; j < HIDDEN; j++) {
      dotAcc = add(t, dotAcc, mul(t, hidden[j]!, p[v2Base + j]!));
    }
    const pred = add(t, dotAcc, p[v2Base + HIDDEN]!);
    const err = sub(t, pred, yTarget);
    losses.push(mul(t, err, err));
  }
  return { tape: t, output: sumReduce(t, ...losses), paramLeaves: p };
}

describe('integration: tiny MLP on XOR', () => {
  it('drives loss below 0.1 in 1000 steps', () => {
    const rng = new Mulberry32(42);
    const params = new Float64Array(PARAM_COUNT);
    for (let i = 0; i < PARAM_COUNT; i++) params[i] = sampleUniform(rng, -0.5, 0.5);

    let initialLoss: number | null = null;
    let lastLoss = Number.POSITIVE_INFINITY;
    for (let step = 0; step < 1000; step++) {
      const { tape, output, paramLeaves } = buildLossTape(params, X, Y);
      const lossVal = tape.valueOf(output);
      if (initialLoss === null) initialLoss = lossVal;
      lastLoss = lossVal;
      const grads = backward(tape, output);
      const g = new Float64Array(PARAM_COUNT);
      for (let i = 0; i < PARAM_COUNT; i++) g[i] = grads.get(paramLeaves[i]!);
      sgd(params, g, { lr: 0.1 });
    }

    expect(lastLoss).toBeLessThan(initialLoss!);
    expect(lastLoss).toBeLessThan(0.5);
  });
});
