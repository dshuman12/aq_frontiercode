// Determinism contract sanity tests.
//
// Run silt operations twice and assert bit-exact equality between the
// two runs. This is the property the CI workflow's "test twice and
// diff" gate is also checking, but at the unit-test level we can be
// more direct.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul } from '@silt/ops-elementary';
import { sin, cos } from '@silt/ops-trig';
import { exp, log } from '@silt/ops-exponential';
import { sumReduce } from '@silt/ops-reductions';
import { Mulberry32, sampleNormal } from '@silt/core-random';
import { bitsEqual, toHex } from '@silt/core-fp';

function buildSyntheticGraph(): { value: number; gradX: number; gradY: number } {
  const t = new Tape();
  const x = t.leaf(0.7);
  const y = t.leaf(1.3);
  const a = sin(t, mul(t, x, y));
  const b = exp(t, cos(t, x));
  const c = log(t, add(t, mul(t, x, x), t.const(1)));
  const out = sumReduce(t, a, b, c);
  const g = backward(t, out);
  return { value: t.valueOf(out), gradX: g.get(x), gradY: g.get(y) };
}

describe('determinism', () => {
  it('two runs of the same forward+backward produce bit-identical outputs', () => {
    const a = buildSyntheticGraph();
    const b = buildSyntheticGraph();
    expect(bitsEqual(a.value, b.value)).toBe(true);
    expect(bitsEqual(a.gradX, b.gradX)).toBe(true);
    expect(bitsEqual(a.gradY, b.gradY)).toBe(true);
  });

  it('output bits are stable across hex encode/decode', () => {
    const r = buildSyntheticGraph();
    const round = parseFloat(`0x${toHex(r.value)}`); // not a meaningful conversion -- we just check shape
    // The point: toHex is reversible, see core/fp tests for the strict round-trip.
    expect(toHex(r.value)).toMatch(/^[0-9a-f]{16}$/);
    void round;
  });

  it('seeded RNG produces same sequence in two Mulberry32 instances', () => {
    const a = new Mulberry32(7);
    const b = new Mulberry32(7);
    for (let i = 0; i < 100; i++) expect(a.next()).toBe(b.next());
  });

  it('seeded sampling sequence is bit-stable', () => {
    const a = new Mulberry32(42);
    const b = new Mulberry32(42);
    for (let i = 0; i < 50; i++) {
      const xa = sampleNormal(a);
      const xb = sampleNormal(b);
      expect(bitsEqual(xa, xb)).toBe(true);
    }
  });

  it('sumReduce of a permuted-order list of constants is order-independent (Kahan)', () => {
    // Whether or not Kahan provides bit-equality across reorderings
    // depends on the inputs. For these small benign inputs it does.
    const xs = [0.1, 0.2, 0.3, 0.4, 0.5];
    const t1 = new Tape();
    const ids1 = xs.map((v) => t1.const(v));
    const s1 = sumReduce(t1, ...ids1);

    const t2 = new Tape();
    const reversed = xs.slice().reverse();
    const ids2 = reversed.map((v) => t2.const(v));
    const s2 = sumReduce(t2, ...ids2);

    expect(t1.valueOf(s1)).toBe(t2.valueOf(s2));
  });
});
