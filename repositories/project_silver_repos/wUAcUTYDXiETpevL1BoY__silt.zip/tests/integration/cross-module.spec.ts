// Smoke tests that exercise many modules together. Useful for catching
// regressions where a registry change in one module breaks a consumer
// that didn't have its own test.

import { Tape } from '@silt/core-tape';
import { backward, backwardAll } from '@silt/backward';
import { add, mul, sub, neg } from '@silt/ops-elementary';
import { sin, cos, atan } from '@silt/ops-trig';
import { exp, log, sqrt } from '@silt/ops-exponential';
import { tanh } from '@silt/ops-hyperbolic';
import { relu, sigmoid, softmax } from '@silt/ops-pieces';
import { sumReduce, meanReduce } from '@silt/ops-reductions';
import { jacobian } from '@silt/jacobian';

describe('cross-module: deep composition graph', () => {
  it('builds and differentiates a stack of trig + exp + reduction', () => {
    // f(x, y) = mean(exp(sin(x)) + cos(y), sqrt(x*y + 1))
    const t = new Tape();
    const x = t.leaf(0.7);
    const y = t.leaf(1.2);
    const a = exp(t, sin(t, x));
    const b = cos(t, y);
    const c = sqrt(t, add(t, mul(t, x, y), t.const(1)));
    const f = meanReduce(t, add(t, a, b), c);
    expect(Number.isFinite(t.valueOf(f))).toBe(true);
    const g = backward(t, f);
    expect(g.get(x)).not.toBe(0);
    expect(g.get(y)).not.toBe(0);
  });

  it('jacobian over a 3 x 2 system', () => {
    const t = new Tape();
    const x = t.leaf(0.5);
    const y = t.leaf(0.7);
    const o0 = sin(t, x);
    const o1 = mul(t, x, y);
    const o2 = exp(t, sub(t, x, y));
    const J = jacobian(t, [o0, o1, o2], [x, y]);
    expect(J).toHaveLength(3);
    expect(J[0]).toHaveLength(2);
  });

  it('softmax + cross-entropy is differentiable', () => {
    // Mini cross-entropy: -log(softmax(logits)[label])
    const t = new Tape();
    const logits = [t.leaf(0.5), t.leaf(1.5), t.leaf(-0.3)];
    const probs = softmax(t, logits);
    // Label = index 1. We pick that probability and apply -log.
    const loss = neg(t, log(t, probs[1]!));
    expect(Number.isFinite(t.valueOf(loss))).toBe(true);
    const g = backward(t, loss);
    // gradient should be (softmax - one_hot) / 1
    const sumG = g.get(logits[0]!) + g.get(logits[1]!) + g.get(logits[2]!);
    expect(sumG).toBeCloseTo(0, 6);
  });

  it('backwardAll aggregates seeds from multiple outputs', () => {
    const t = new Tape();
    const x = t.leaf(0.5);
    const a = sin(t, x);
    const b = cos(t, x);
    const g = backwardAll(t, [a, b], [1, 1]);
    // d/dx (sin + cos) = cos - sin
    const expected = Math.cos(0.5) - Math.sin(0.5);
    expect(g.get(x)).toBeCloseTo(expected, 12);
  });

  it('relu / sigmoid / tanh activations all participate in chain rule', () => {
    const t = new Tape();
    const x = t.leaf(0.3);
    const out = relu(t, sigmoid(t, tanh(t, x)));
    const g = backward(t, out);
    expect(g.get(x)).not.toBe(0);
  });

  it('atan(tan(x)) ~= x near the origin', () => {
    const t = new Tape();
    const x = t.leaf(0.3);
    const y = atan(t, sin(t, x));
    expect(Number.isFinite(t.valueOf(y))).toBe(true);
    const g = backward(t, y);
    expect(g.get(x)).not.toBe(0);
  });

  it('grad of sumReduce over sin(x_i) for many x_i', () => {
    const t = new Tape();
    const xs: import('@silt/core-types').NodeId[] = [];
    for (let i = 0; i < 10; i++) xs.push(t.leaf((i * 0.1)));
    const sins = xs.map((x) => sin(t, x));
    const out = sumReduce(t, ...sins);
    const g = backward(t, out);
    for (let i = 0; i < 10; i++) {
      expect(g.get(xs[i]!)).toBeCloseTo(Math.cos(i * 0.1), 12);
    }
  });
});
