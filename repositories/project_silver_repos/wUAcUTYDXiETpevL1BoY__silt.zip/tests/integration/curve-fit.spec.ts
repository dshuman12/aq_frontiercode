// End-to-end: fit y = A*sin(w*x + phi) + b to noisy data using
// gradient descent driven by silt's autodiff.
//
// Sanity check rather than rigorous benchmark: we check that
// loss decreases monotonically (in trend) and that the recovered
// parameters are close to the synthetic ground truth.

import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { add, mul, sub } from '@silt/ops-elementary';
import { sin } from '@silt/ops-trig';
import { sumReduce } from '@silt/ops-reductions';
import { sgd } from '@silt/optimizers';

describe('integration: curve fit y = A sin(w x + phi) + b', () => {
  it('recovers approximate parameters from noiseless data', () => {
    const trueA = 2.0;
    const trueW = 1.5;
    const truePhi = 0.3;
    const trueB = 0.5;
    const N = 50;
    const xs: number[] = [];
    const ys: number[] = [];
    for (let i = 0; i < N; i++) {
      const x = (i / (N - 1)) * 4 * Math.PI;
      xs.push(x);
      ys.push(trueA * Math.sin(trueW * x + truePhi) + trueB);
    }

    // Initialize parameters at a deliberately-not-too-bad starting point.
    const params = new Float64Array([1.0, 1.0, 0.0, 0.0]); // A, w, phi, b

    let initialLoss: number | null = null;
    let lastLoss = Number.POSITIVE_INFINITY;

    for (let step = 0; step < 600; step++) {
      const t = new Tape();
      const A = t.leaf(params[0]!);
      const w = t.leaf(params[1]!);
      const phi = t.leaf(params[2]!);
      const b = t.leaf(params[3]!);

      // Build the loss: sum_i (A*sin(w*x_i + phi) + b - y_i)^2
      const losses: import('@silt/core-types').NodeId[] = [];
      for (let i = 0; i < N; i++) {
        const xConst = t.const(xs[i]!);
        const yConst = t.const(ys[i]!);
        const wx = mul(t, w, xConst);
        const ang = add(t, wx, phi);
        const s = sin(t, ang);
        const Asin = mul(t, A, s);
        const pred = add(t, Asin, b);
        const diff = sub(t, pred, yConst);
        const sq = mul(t, diff, diff);
        losses.push(sq);
      }
      const loss = sumReduce(t, ...losses);
      const lossVal = t.valueOf(loss);
      if (initialLoss === null) initialLoss = lossVal;
      lastLoss = lossVal;

      // Gradient + step
      const grads = backward(t, loss);
      const g = new Float64Array([
        grads.get(A),
        grads.get(w),
        grads.get(phi),
        grads.get(b),
      ]);
      sgd(params, g, { lr: 0.001 });
    }

    expect(lastLoss).toBeLessThan(initialLoss! / 100);
    // After 600 steps loss should be quite small. The exact threshold
    // is loose because lr=0.001 is conservative for this problem and
    // we want determinism over speed.
    expect(lastLoss).toBeLessThan(1.0);
  });
});
