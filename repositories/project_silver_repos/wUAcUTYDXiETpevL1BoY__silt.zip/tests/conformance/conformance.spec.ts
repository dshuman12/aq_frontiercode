// Conformance test driven by tests/conformance/grad-corpus.json.
//
// Reads the JSON, builds the named function via silt, runs backward,
// and asserts the resulting gradient matches the pinned hex within the
// allowed ULP tolerance.
//
// "Tolerance in ULPs" rather than relative-error matters here because
// the corpus is the authoritative reference for what bits silt should
// produce. We allow a small ULP slack to accommodate small libm
// differences across platforms (e.g. Math.tanh varies by 1-2 ULPs
// between glibc and Apple's libm).

import * as fs from 'node:fs';
import * as path from 'node:path';
import { Tape } from '@silt/core-tape';
import { backward } from '@silt/backward';
import { sin, cos, tan, atan } from '@silt/ops-trig';
import { exp, log, sqrt } from '@silt/ops-exponential';
import { tanh } from '@silt/ops-hyperbolic';
import { sigmoid, relu } from '@silt/ops-pieces';
import { fromHex, toHex, toBits } from '@silt/core-fp';

interface Case {
  name: string;
  function: string;
  x: number;
  analytic_grad_hex: string;
  tolerance_ulps: number;
}

interface Corpus {
  version: number;
  epsilon: number;
  description: string;
  cases: Case[];
}

const corpusPath = path.join(__dirname, 'grad-corpus.json');
const corpus = JSON.parse(fs.readFileSync(corpusPath, 'utf8')) as Corpus;

const FUNCTIONS: Record<string, (t: Tape, x: import('@silt/core-types').NodeId) => import('@silt/core-types').NodeId> = {
  sin: (t, x) => sin(t, x),
  cos: (t, x) => cos(t, x),
  tan: (t, x) => tan(t, x),
  atan: (t, x) => atan(t, x),
  exp: (t, x) => exp(t, x),
  log: (t, x) => log(t, x),
  sqrt: (t, x) => sqrt(t, x),
  tanh: (t, x) => tanh(t, x),
  sigmoid: (t, x) => sigmoid(t, x),
  relu: (t, x) => relu(t, x),
};

// ULP distance between two finite doubles of the same sign.
function ulpDistance(a: number, b: number): number {
  if (a === b) return 0;
  if (Number.isNaN(a) || Number.isNaN(b)) return Number.POSITIVE_INFINITY;
  if (!Number.isFinite(a) || !Number.isFinite(b)) return Number.POSITIVE_INFINITY;
  const aBits = toBits(a);
  const bBits = toBits(b);
  // Compose 64-bit unsigned distance into a regular number; for our
  // ULP slacks (<= 16) the high bits are always zero.
  const hiDelta = Math.abs(aBits.hi - bBits.hi);
  const loDelta = Math.abs(aBits.lo - bBits.lo);
  return hiDelta * 4294967296 + loDelta;
}

describe('conformance corpus', () => {
  expect(corpus.version).toBe(1);
  expect(corpus.cases.length).toBeGreaterThan(5);

  for (const c of corpus.cases) {
    it(c.name, () => {
      const fn = FUNCTIONS[c.function];
      if (!fn) throw new Error(`unknown function in corpus: ${c.function}`);
      const t = new Tape();
      const x = t.leaf(c.x);
      const out = fn(t, x);
      const g = backward(t, out);
      const got = g.get(x);
      const want = fromHex(c.analytic_grad_hex);
      const distance = ulpDistance(got, want);
      if (distance > c.tolerance_ulps) {
        throw new Error(
          `conformance ${c.name}: got ${toHex(got)} (${got}), want ${c.analytic_grad_hex} (${want}); ULP distance ${distance} > tolerance ${c.tolerance_ulps}`,
        );
      }
    });
  }
});
