## What this changes

<!-- Two-or-three sentences. What and why; the diff covers the how. -->

## Determinism contract

- [ ] no new uses of `Math.random`, `Date.now`, `setTimeout`, etc. in `core/` or `modules/`
- [ ] `pnpm test:twice` passes locally
- [ ] new ops have a gradcheck test
- [ ] tape/serialize format unchanged, OR version bumped + migrator updated

## Notes for the reviewer

<!-- Anything you want me to look at carefully? Trade-offs you want a sanity check on? -->
