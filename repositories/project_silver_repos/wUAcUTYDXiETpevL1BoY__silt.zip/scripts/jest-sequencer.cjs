// Stable test sequencer. Sorts test paths lexicographically so that
// failure ordering is reproducible across machines.

const Sequencer = require('@jest/test-sequencer').default;

class StableSequencer extends Sequencer {
  sort(tests) {
    const copy = tests.slice();
    copy.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
    return copy;
  }
}

module.exports = StableSequencer;
