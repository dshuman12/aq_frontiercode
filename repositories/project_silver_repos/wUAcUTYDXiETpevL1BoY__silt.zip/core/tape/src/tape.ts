// The tape.
//
// silt records ops onto an append-only tape during forward eval; the
// backward walker traverses the same tape in reverse to produce
// gradients. This is the standard reverse-mode AD architecture
// (Wengert 1964; the same structure JAX, PyTorch, and autograd use).
//
// Why a flat array instead of a graph object:
//   - Insertion order = topological order, no separate sort needed
//   - Cache locality for backward walk
//   - Cheap to snapshot (just remember the length)
//   - Cheap to discard (set length back)
//
// Each node owns:
//   - id: index into the flat array (1-based; 0 is reserved as sentinel)
//   - op: kind (leaf | const | add | sin | ...)
//   - inputs: NodeIds of upstream nodes
//   - value: forward eval result, populated on first eval
//   - ctx: per-op intermediate state used by backward (e.g. cos(x)
//          for sin's backward, the input itself for log's backward)
//
// The tape does not know about any specific op. Forward and backward
// behavior live in op modules, registered through op-registry.

import { TapeError } from '@silt/core-errors';
import type { NodeId, OpKind } from '@silt/core-types';

export type EvalFn = (inputs: number[]) => number;
export type BackwardFn = (
  inputs: number[],
  outputGrad: number,
  outputValue: number,
  ctx: unknown,
) => number[];

export interface OpHandler {
  evalFn: EvalFn;
  ctxFn?: (inputs: number[], output: number) => unknown;
}

export interface TapeNode {
  readonly id: NodeId;
  readonly op: OpKind;
  readonly inputs: readonly NodeId[];
  value: number | null;
  ctx: unknown;
  // Internal: handler captured at append-time so forward eval doesn't
  // need to consult a registry. Backward still does (it lives in
  // modules/backward and is wired up there).
  readonly handler: OpHandler | null;
}

export class Tape {
  // Index 0 is a sentinel; nodes start at index 1. This means a NodeId
  // of 0 is "no node" and we don't have to special-case empty input
  // arrays elsewhere.
  private _nodes: TapeNode[] = [
    {
      id: 0 as NodeId,
      op: 'const',
      inputs: [],
      value: 0,
      ctx: null,
      handler: null,
    } as TapeNode,
  ];

  // Generation counter: bumped when the tape is reset. Snapshot/restore
  // operations validate against this so we don't replay a stale snapshot.
  private _generation = 0;

  size(): number {
    return this._nodes.length - 1;
  }

  generation(): number {
    return this._generation;
  }

  // A "leaf" is an input variable whose gradient we'll want at the end.
  leaf(value: number): NodeId {
    return this._appendInternal('leaf', [], value, null, null);
  }

  // A const is also a leaf-like (no inputs, no gradient flows back).
  // The distinction matters for the backward walker: leaves accumulate
  // gradient, consts don't.
  const(value: number): NodeId {
    return this._appendInternal('const', [], value, null, null);
  }

  // Append an op node. The forward value is computed eagerly using
  // `evalFn`; backward is deferred until backward() is called.
  append(op: OpKind, inputs: readonly NodeId[], handler: OpHandler): NodeId {
    if (op === 'leaf' || op === 'const') {
      throw new TapeError(`tape.append: use leaf()/const() for ${op}, not append()`);
    }
    const inputValues = new Array<number>(inputs.length);
    for (let i = 0; i < inputs.length; i++) {
      const id = inputs[i]!;
      if (id <= 0 || id >= this._nodes.length) {
        throw new TapeError(`tape.append: input ${id} out of bounds (size ${this.size()})`);
      }
      const v = this._nodes[id]!.value;
      if (v === null) {
        throw new TapeError(`tape.append: input n${id} has no value (forward not run?)`);
      }
      inputValues[i] = v;
    }
    const out = handler.evalFn(inputValues);
    const ctx = handler.ctxFn ? handler.ctxFn(inputValues, out) : null;
    return this._appendInternal(op, inputs, out, ctx, handler);
  }

  // Read a node. Throws if out of range.
  get(id: NodeId): TapeNode {
    if (id <= 0 || id >= this._nodes.length) {
      throw new TapeError(`tape.get: ${id} out of bounds (size ${this.size()})`);
    }
    return this._nodes[id]!;
  }

  // Read the forward value of a node. Throws if not yet evaluated.
  valueOf(id: NodeId): number {
    const n = this.get(id);
    if (n.value === null) {
      throw new TapeError(`tape.valueOf: n${id} has no value`);
    }
    return n.value;
  }

  // Iterate nodes in insertion order (excluding the sentinel).
  *iter(): IterableIterator<TapeNode> {
    for (let i = 1; i < this._nodes.length; i++) {
      yield this._nodes[i]!;
    }
  }

  // Iterate nodes in reverse insertion order (for backward walk).
  *iterReverse(): IterableIterator<TapeNode> {
    for (let i = this._nodes.length - 1; i >= 1; i--) {
      yield this._nodes[i]!;
    }
  }

  // Iterate all NodeIds (1..size). Cheap helper for backward.
  ids(): NodeId[] {
    const out = new Array<NodeId>(this.size());
    for (let i = 0; i < out.length; i++) out[i] = (i + 1) as NodeId;
    return out;
  }

  // Reset the tape: drop everything except the sentinel, bump
  // generation. Used by tests and the REPL.
  reset(): void {
    this._nodes.length = 1;
    this._generation++;
  }

  // Truncate the tape back to a previous size. Used by snapshot/restore.
  truncate(size: number): void {
    if (size < 0 || size > this.size()) {
      throw new TapeError(`tape.truncate: size ${size} out of range (current ${this.size()})`);
    }
    this._nodes.length = size + 1;
  }

  // INTERNAL.
  private _appendInternal(
    op: OpKind,
    inputs: readonly NodeId[],
    value: number,
    ctx: unknown,
    handler: OpHandler | null,
  ): NodeId {
    const id = this._nodes.length as NodeId;
    this._nodes.push({
      id,
      op,
      inputs: inputs.slice(),
      value,
      ctx,
      handler,
    });
    return id;
  }
}

// Convenience constructor; matches the one-letter `tape()` spelling
// used in examples.
export function tape(): Tape {
  return new Tape();
}
