// Lightweight snapshot/restore for a tape.
//
// We do NOT serialize the handlers; a snapshot is meaningful only
// within a single process. For across-process persistence use
// modules/serialize, which understands the op registry.
//
// Important caveat: the snapshot captures forward values and ctx by
// reference. If you mutate a node's value after taking a snapshot,
// the snapshot reflects the mutation. This is deliberate -- snapshots
// are for "rewind to size N" use cases, not for "freeze the state".

import { TapeError } from '@silt/core-errors';
import type { Tape } from './tape.js';

export interface TapeSnapshot {
  readonly generation: number;
  readonly size: number;
}

export function snapshot(t: Tape): TapeSnapshot {
  return Object.freeze({ generation: t.generation(), size: t.size() });
}

export function restore(t: Tape, s: TapeSnapshot): void {
  if (s.generation !== t.generation()) {
    throw new TapeError(
      `restore: snapshot generation ${s.generation} != tape generation ${t.generation()}. ` +
        'Snapshots are invalidated by tape.reset().',
    );
  }
  t.truncate(s.size);
}
