// Replay a tape: walk every node in order, re-evaluate forward.
//
// Used for:
//   - lazy mode (tape recorded with no forward values, then replayed)
//   - sanity checks during snapshot/restore
//   - the deserialize path, where forward values come from the wire
//     and we want to verify they match a recomputation

import { TapeError } from '@silt/core-errors';
import type { Tape } from './tape.js';
import type { NodeId } from '@silt/core-types';

export function replay(t: Tape): void {
  for (const node of t.iter()) {
    if (node.op === 'leaf' || node.op === 'const') continue;
    if (node.handler === null) {
      throw new TapeError(`replay: n${node.id} (op=${node.op}) has no handler`);
    }
    const inputs = new Array<number>(node.inputs.length);
    for (let i = 0; i < node.inputs.length; i++) {
      const v = t.get(node.inputs[i]!).value;
      if (v === null) {
        throw new TapeError(`replay: input n${node.inputs[i]} has no value`);
      }
      inputs[i] = v;
    }
    const out = node.handler.evalFn(inputs);
    // We mutate via the public valueOf? No -- just write directly on
    // the node we got from iter(). Tape exposes nodes by reference.
    (node as { value: number | null }).value = out;
    if (node.handler.ctxFn) {
      (node as { ctx: unknown }).ctx = node.handler.ctxFn(inputs, out);
    }
  }
}

// Replay only the nodes in `subset`, assuming their inputs are valid.
// Useful for partial recomputation when only a few leaves changed.
export function replaySubset(t: Tape, subset: readonly NodeId[]): void {
  // Sort the subset to honor topo order (since NodeId is insertion order).
  const ids = subset.slice().sort((a, b) => a - b);
  for (const id of ids) {
    const node = t.get(id);
    if (node.op === 'leaf' || node.op === 'const') continue;
    if (node.handler === null) {
      throw new TapeError(`replaySubset: n${id} has no handler`);
    }
    const inputs = new Array<number>(node.inputs.length);
    for (let i = 0; i < node.inputs.length; i++) {
      const v = t.get(node.inputs[i]!).value;
      if (v === null) {
        throw new TapeError(`replaySubset: input n${node.inputs[i]} has no value`);
      }
      inputs[i] = v;
    }
    const out = node.handler.evalFn(inputs);
    (node as { value: number | null }).value = out;
    if (node.handler.ctxFn) {
      (node as { ctx: unknown }).ctx = node.handler.ctxFn(inputs, out);
    }
  }
}
