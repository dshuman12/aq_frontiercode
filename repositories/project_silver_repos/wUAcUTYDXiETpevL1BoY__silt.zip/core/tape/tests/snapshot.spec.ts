import { tape, type OpHandler } from '../src/tape.js';
import { snapshot, restore } from '../src/snapshot.js';
import { TapeError } from '@silt/core-errors';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };

describe('snapshot / restore', () => {
  it('captures current size', () => {
    const t = tape();
    t.leaf(1);
    t.leaf(2);
    const s = snapshot(t);
    expect(s.size).toBe(2);
    expect(s.generation).toBe(t.generation());
  });

  it('restore truncates back to snapshot size', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const s = snapshot(t);
    t.append('add', [a, b], addH);
    expect(t.size()).toBe(3);
    restore(t, s);
    expect(t.size()).toBe(2);
  });

  it('refuses restore across generations', () => {
    const t = tape();
    t.leaf(1);
    const s = snapshot(t);
    t.reset();
    expect(() => restore(t, s)).toThrow(TapeError);
  });

  it('snapshots are immutable', () => {
    const t = tape();
    const s = snapshot(t);
    expect(Object.isFrozen(s)).toBe(true);
  });
});
