import { Tape, tape, type OpHandler } from '../src/tape.js';
import { TapeError } from '@silt/core-errors';

const addHandler: OpHandler = {
  evalFn: (inputs) => inputs[0]! + inputs[1]!,
};

const sinHandler: OpHandler = {
  evalFn: (inputs) => Math.sin(inputs[0]!),
  ctxFn: (inputs) => Math.cos(inputs[0]!),
};

describe('Tape construction', () => {
  it('starts empty (size 0, sentinel reserved)', () => {
    const t = tape();
    expect(t.size()).toBe(0);
  });

  it('leaf appends a node and returns its id', () => {
    const t = tape();
    const x = t.leaf(2.5);
    expect(x).toBe(1);
    expect(t.size()).toBe(1);
    expect(t.valueOf(x)).toBe(2.5);
  });

  it('const appends with no inputs', () => {
    const t = tape();
    const c = t.const(3.14);
    expect(t.get(c).op).toBe('const');
    expect(t.valueOf(c)).toBe(3.14);
  });

  it('returns increasing ids', () => {
    const t = tape();
    expect(t.leaf(1)).toBe(1);
    expect(t.leaf(2)).toBe(2);
    expect(t.leaf(3)).toBe(3);
  });
});

describe('Tape.append', () => {
  it('appends an op node and computes forward value', () => {
    const t = tape();
    const x = t.leaf(2);
    const y = t.leaf(3);
    const z = t.append('add', [x, y], addHandler);
    expect(t.valueOf(z)).toBe(5);
  });

  it('captures ctx via ctxFn', () => {
    const t = tape();
    const x = t.leaf(0);
    const s = t.append('sin', [x], sinHandler);
    expect(t.get(s).ctx).toBe(1); // cos(0)
  });

  it('refuses leaf op via append', () => {
    const t = tape();
    expect(() => t.append('leaf' as never, [], addHandler)).toThrow(TapeError);
  });

  it('refuses const op via append', () => {
    const t = tape();
    expect(() => t.append('const' as never, [], addHandler)).toThrow(TapeError);
  });

  it('throws on out-of-bounds input', () => {
    const t = tape();
    expect(() => t.append('add', [99 as never], addHandler)).toThrow(TapeError);
  });

  it('rejects sentinel id 0 as input', () => {
    const t = tape();
    const x = t.leaf(1);
    expect(() => t.append('add', [0 as never, x], addHandler)).toThrow(TapeError);
  });
});

describe('Tape.get / valueOf', () => {
  it('throws on out-of-range id', () => {
    const t = tape();
    expect(() => t.get(5 as never)).toThrow(TapeError);
  });

  it('valueOf throws on a node with null value', () => {
    const t = tape();
    const x = t.leaf(1);
    // synthesize null by direct mutation (tests-only path)
    (t.get(x) as { value: number | null }).value = null;
    expect(() => t.valueOf(x)).toThrow(TapeError);
  });
});

describe('Tape.iter / iterReverse', () => {
  it('iter yields in insertion order', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addHandler);
    const seen = [...t.iter()].map((n) => n.id);
    expect(seen).toEqual([a, b, c]);
  });

  it('iterReverse yields in reverse', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addHandler);
    const seen = [...t.iterReverse()].map((n) => n.id);
    expect(seen).toEqual([c, b, a]);
  });

  it('iter on empty tape yields nothing', () => {
    expect([...tape().iter()]).toEqual([]);
  });
});

describe('Tape.ids', () => {
  it('returns 1..size', () => {
    const t = tape();
    t.leaf(1);
    t.leaf(2);
    t.leaf(3);
    expect(t.ids()).toEqual([1, 2, 3]);
  });
});

describe('Tape.reset', () => {
  it('drops all nodes and bumps generation', () => {
    const t = tape();
    t.leaf(1);
    t.leaf(2);
    expect(t.size()).toBe(2);
    const g0 = t.generation();
    t.reset();
    expect(t.size()).toBe(0);
    expect(t.generation()).toBe(g0 + 1);
  });
});

describe('Tape.truncate', () => {
  it('shortens the tape', () => {
    const t = tape();
    t.leaf(1);
    t.leaf(2);
    t.leaf(3);
    t.truncate(1);
    expect(t.size()).toBe(1);
  });

  it('errors on out-of-range size', () => {
    const t = tape();
    t.leaf(1);
    expect(() => t.truncate(5)).toThrow(TapeError);
    expect(() => t.truncate(-1)).toThrow(TapeError);
  });
});

describe('Tape composition (small forward graph)', () => {
  it('forward-evaluates a chain', () => {
    // f(x, y) = sin(x + y)
    const t = tape();
    const x = t.leaf(0.5);
    const y = t.leaf(1.0);
    const sum = t.append('add', [x, y], addHandler);
    const out = t.append('sin', [sum], sinHandler);
    expect(t.valueOf(out)).toBeCloseTo(Math.sin(1.5), 12);
  });
});
