import { tape, type OpHandler } from '../src/tape.js';
import { replay, replaySubset } from '../src/replay.js';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };
const mulH: OpHandler = { evalFn: (i) => i[0]! * i[1]! };

describe('replay', () => {
  it('re-evaluates every op node', () => {
    const t = tape();
    const a = t.leaf(2);
    const b = t.leaf(3);
    const c = t.append('add', [a, b], addH);
    const d = t.append('mul', [c, b], mulH);
    expect(t.valueOf(d)).toBe(15);
    // Mutate a leaf, then replay -- downstream values should refresh
    (t.get(a) as { value: number }).value = 5;
    replay(t);
    expect(t.valueOf(c)).toBe(8);
    expect(t.valueOf(d)).toBe(24);
  });

  it('skips leaf and const nodes', () => {
    const t = tape();
    t.leaf(1);
    t.const(2);
    // No throw; leaves stay as-is.
    expect(() => replay(t)).not.toThrow();
  });
});

describe('replaySubset', () => {
  it('only re-evaluates the listed nodes', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const d = t.append('mul', [c, b], mulH);
    expect(t.valueOf(d)).toBe(6);
    // change leaf a, replay only c
    (t.get(a) as { value: number }).value = 10;
    replaySubset(t, [c]);
    expect(t.valueOf(c)).toBe(12);
    // d wasn't replayed: still has the old product = 6
    expect(t.valueOf(d)).toBe(6);
  });

  it('honors topo order regardless of input order', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const d = t.append('mul', [c, b], mulH);
    (t.get(a) as { value: number }).value = 5;
    // pass d first, then c -- replay should sort and do c first
    replaySubset(t, [d, c]);
    expect(t.valueOf(c)).toBe(7);
    expect(t.valueOf(d)).toBe(14);
  });
});
