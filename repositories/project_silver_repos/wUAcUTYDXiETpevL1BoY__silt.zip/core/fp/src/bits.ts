// Bit-level float64 inspection. Used by:
//   - tests/conformance for bit-exact gradient assertions
//   - tools/fmt-check for round-trip verification
//   - the serializer for fp64 storage

// Single shared scratch buffer. Every read/write takes ~5 ns; the
// allocation cost of a fresh buffer per call would dominate. Safe
// because the helpers are synchronous and never re-entrant.
const _buf = new ArrayBuffer(8);
const _f64 = new Float64Array(_buf);
const _u32 = new Uint32Array(_buf);

// IEEE 754 binary64 layout, little-endian (which is what x86/ARM use):
//   _u32[0] = low 32 bits of mantissa
//   _u32[1] = high 32 bits = sign(1) | exponent(11) | top(20) of mantissa

export function toBits(x: number): { hi: number; lo: number } {
  _f64[0] = x;
  return { hi: _u32[1]!, lo: _u32[0]! };
}

export function fromBits(hi: number, lo: number): number {
  _u32[1] = hi >>> 0;
  _u32[0] = lo >>> 0;
  return _f64[0]!;
}

export function toHex(x: number): string {
  const { hi, lo } = toBits(x);
  // We pad to 8 hex digits each, joined without separator.
  const hiHex = (hi >>> 0).toString(16).padStart(8, '0');
  const loHex = (lo >>> 0).toString(16).padStart(8, '0');
  return hiHex + loHex;
}

export function fromHex(s: string): number {
  if (s.length !== 16) {
    throw new TypeError(`fromHex: expected 16 hex chars, got ${s.length}`);
  }
  if (!/^[0-9a-fA-F]+$/.test(s)) {
    throw new TypeError(`fromHex: not hex: ${JSON.stringify(s)}`);
  }
  const hi = parseInt(s.slice(0, 8), 16);
  const lo = parseInt(s.slice(8, 16), 16);
  return fromBits(hi, lo);
}

export function signBit(x: number): 0 | 1 {
  const { hi } = toBits(x);
  return ((hi >>> 31) & 1) as 0 | 1;
}

export function exponent(x: number): number {
  const { hi } = toBits(x);
  return (hi >>> 20) & 0x7ff;
}

export function mantissa(x: number): { hi20: number; lo32: number } {
  const { hi, lo } = toBits(x);
  return { hi20: hi & 0xfffff, lo32: lo >>> 0 };
}

export function isNegativeZero(x: number): boolean {
  return x === 0 && 1 / x === -Infinity;
}

export function isSubnormal(x: number): boolean {
  if (x === 0 || !Number.isFinite(x)) return false;
  return exponent(x) === 0;
}

// Unit in last place: distance to next representable.
export function ulp(x: number): number {
  if (Number.isNaN(x) || !Number.isFinite(x)) return Number.NaN;
  if (x === 0) return Number.MIN_VALUE;
  const next = nextUp(Math.abs(x));
  return next - Math.abs(x);
}

export function nextUp(x: number): number {
  if (Number.isNaN(x)) return x;
  if (x === Infinity) return Infinity;
  if (x === 0) return Number.MIN_VALUE;
  const { hi, lo } = toBits(x);
  if (signBit(x) === 0) {
    // Positive: bump the bits up.
    if (lo === 0xffffffff) {
      return fromBits(hi + 1, 0);
    }
    return fromBits(hi, lo + 1);
  }
  // Negative: bump the bits down (toward zero, which is "up" in fp).
  if (lo === 0) {
    return fromBits(hi - 1, 0xffffffff);
  }
  return fromBits(hi, lo - 1);
}

export function nextDown(x: number): number {
  return -nextUp(-x);
}

export function bitsEqual(a: number, b: number): boolean {
  // NaN payloads can differ but we treat any-NaN as equal to any-NaN.
  if (Number.isNaN(a) && Number.isNaN(b)) return true;
  // Distinguish +0 from -0 by hitting the bits.
  const ab = toBits(a);
  const bb = toBits(b);
  return ab.hi === bb.hi && ab.lo === bb.lo;
}
