// Approximation utilities for tests that don't need bit-exactness.
//
// The default test culture in silt prefers bit-exact assertions
// (see core/fp/bits.ts and tests/conformance). These helpers exist for
// the few places where bit-exact is impossible -- finite-difference
// gradient checks against analytic gradients, and convergence tests
// for iterative optimizers.

export const EPSILON_F64 = Number.EPSILON; // 2^-52

// Smallest normal positive double.
export const TINY_F64 = 2.2250738585072014e-308;

// Combined absolute + relative tolerance.
//
// |a - b| <= absTol + relTol * max(|a|, |b|)
//
// Reference: Knuth TAOCP vol 2, "essentially equal".
export function almostEqual(a: number, b: number, absTol = 1e-12, relTol = 1e-9): boolean {
  if (Number.isNaN(a) || Number.isNaN(b)) return false;
  if (a === b) return true;
  const diff = Math.abs(a - b);
  if (diff <= absTol) return true;
  const scale = Math.max(Math.abs(a), Math.abs(b));
  return diff <= relTol * scale;
}

// Pure relative tolerance, refuses near-zero comparisons.
export function closeRelative(a: number, b: number, relTol = 1e-9): boolean {
  if (Number.isNaN(a) || Number.isNaN(b)) return false;
  if (a === b) return true;
  const scale = Math.max(Math.abs(a), Math.abs(b));
  if (scale < TINY_F64) {
    // Genuinely zero comparison: caller wanted relative, can't deliver.
    // We're explicit about this rather than silently degrading.
    throw new RangeError('closeRelative: both operands at-or-near zero, use almostEqual instead');
  }
  return Math.abs(a - b) / scale <= relTol;
}

export function approxZero(x: number, absTol = 1e-12): boolean {
  return Math.abs(x) <= absTol;
}
