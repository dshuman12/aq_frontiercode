import { almostEqual, closeRelative, approxZero, EPSILON_F64, TINY_F64 } from '../src/approx.js';

describe('almostEqual', () => {
  it('equal values are equal', () => {
    expect(almostEqual(1, 1)).toBe(true);
  });

  it('within absolute tolerance', () => {
    expect(almostEqual(0, 1e-13, 1e-12)).toBe(true);
  });

  it('outside absolute tolerance', () => {
    expect(almostEqual(0, 1e-10, 1e-12)).toBe(false);
  });

  it('within relative tolerance', () => {
    expect(almostEqual(1e10, 1e10 + 1, 1e-12, 1e-9)).toBe(true);
  });

  it('refuses NaN comparisons', () => {
    expect(almostEqual(Number.NaN, Number.NaN)).toBe(false);
    expect(almostEqual(1, Number.NaN)).toBe(false);
  });

  it('handles +/-Infinity', () => {
    expect(almostEqual(Infinity, Infinity)).toBe(true);
    expect(almostEqual(Infinity, -Infinity)).toBe(false);
  });
});

describe('closeRelative', () => {
  it('passes within tolerance', () => {
    expect(closeRelative(1, 1 + 1e-10)).toBe(true);
  });

  it('throws on near-zero comparison', () => {
    expect(() => closeRelative(0, 0)).toThrow(RangeError);
    expect(() => closeRelative(TINY_F64 / 2, 0)).toThrow(RangeError);
  });
});

describe('approxZero', () => {
  it('detects values within tolerance', () => {
    expect(approxZero(0)).toBe(true);
    expect(approxZero(1e-13)).toBe(true);
    expect(approxZero(1e-9)).toBe(false);
  });
});

describe('constants', () => {
  it('EPSILON_F64 matches Number.EPSILON', () => {
    expect(EPSILON_F64).toBe(Number.EPSILON);
  });

  it('TINY_F64 is smallest normal', () => {
    expect(TINY_F64).toBeCloseTo(2.225e-308, 10);
  });
});
