import {
  toBits,
  fromBits,
  toHex,
  fromHex,
  signBit,
  exponent,
  mantissa,
  isNegativeZero,
  isSubnormal,
  ulp,
  nextUp,
  nextDown,
  bitsEqual,
} from '../src/bits.js';

describe('toBits / fromBits round-trip', () => {
  it('preserves zero', () => {
    const { hi, lo } = toBits(0);
    expect(fromBits(hi, lo)).toBe(0);
  });

  it('preserves negative zero', () => {
    const { hi, lo } = toBits(-0);
    expect(isNegativeZero(fromBits(hi, lo))).toBe(true);
  });

  it('preserves Infinity', () => {
    const { hi, lo } = toBits(Infinity);
    expect(fromBits(hi, lo)).toBe(Infinity);
  });

  it('preserves NaN as some NaN (payload may vary)', () => {
    const { hi, lo } = toBits(Number.NaN);
    expect(Number.isNaN(fromBits(hi, lo))).toBe(true);
  });

  it('preserves common values bit-exact', () => {
    for (const x of [1, -1, 0.5, -0.5, Math.PI, Math.E, 1e308, 1e-308]) {
      const { hi, lo } = toBits(x);
      expect(fromBits(hi, lo)).toBe(x);
    }
  });
});

describe('toHex / fromHex round-trip', () => {
  it('round-trips finite values', () => {
    for (const x of [1, -1, 0.5, Math.PI, 2.5e-100, -7.3e200]) {
      expect(fromHex(toHex(x))).toBe(x);
    }
  });

  it('zero is "0000000000000000"', () => {
    expect(toHex(0)).toBe('0000000000000000');
  });

  it('negative zero is "8000000000000000"', () => {
    expect(toHex(-0)).toBe('8000000000000000');
  });

  it('1.0 is "3ff0000000000000"', () => {
    expect(toHex(1)).toBe('3ff0000000000000');
  });

  it('rejects bad-length hex', () => {
    expect(() => fromHex('1234')).toThrow(TypeError);
  });

  it('rejects non-hex chars', () => {
    expect(() => fromHex('zzzzzzzzzzzzzzzz')).toThrow(TypeError);
  });
});

describe('signBit', () => {
  it('returns 0 for positives', () => {
    expect(signBit(1)).toBe(0);
    expect(signBit(0)).toBe(0);
  });

  it('returns 1 for negatives and -0', () => {
    expect(signBit(-1)).toBe(1);
    expect(signBit(-0)).toBe(1);
  });
});

describe('exponent / mantissa', () => {
  it('1.0 has exponent 1023, zero mantissa', () => {
    expect(exponent(1)).toBe(1023);
    expect(mantissa(1)).toEqual({ hi20: 0, lo32: 0 });
  });

  it('2.0 has exponent 1024', () => {
    expect(exponent(2)).toBe(1024);
  });

  it('0 has exponent 0', () => {
    expect(exponent(0)).toBe(0);
  });

  it('Infinity has exponent 0x7ff', () => {
    expect(exponent(Infinity)).toBe(0x7ff);
  });
});

describe('isNegativeZero / isSubnormal', () => {
  it('detects -0', () => {
    expect(isNegativeZero(-0)).toBe(true);
    expect(isNegativeZero(0)).toBe(false);
  });

  it('detects subnormals', () => {
    expect(isSubnormal(Number.MIN_VALUE)).toBe(true);
    expect(isSubnormal(Number.MIN_VALUE * 2)).toBe(true);
    expect(isSubnormal(2.2250738585072014e-308)).toBe(false); // smallest normal
    expect(isSubnormal(1)).toBe(false);
    expect(isSubnormal(0)).toBe(false);
  });
});

describe('ulp', () => {
  it('ulp(1) is EPSILON', () => {
    expect(ulp(1)).toBe(Number.EPSILON);
  });

  it('ulp(0) is MIN_VALUE', () => {
    expect(ulp(0)).toBe(Number.MIN_VALUE);
  });

  it('ulp(NaN) is NaN', () => {
    expect(Number.isNaN(ulp(Number.NaN))).toBe(true);
  });
});

describe('nextUp / nextDown', () => {
  it('nextUp(0) is MIN_VALUE', () => {
    expect(nextUp(0)).toBe(Number.MIN_VALUE);
  });

  it('nextUp(1) is 1 + EPSILON', () => {
    expect(nextUp(1)).toBe(1 + Number.EPSILON);
  });

  it('nextDown(0) is -MIN_VALUE', () => {
    expect(nextDown(0)).toBe(-Number.MIN_VALUE);
  });

  it('nextUp(Infinity) is Infinity', () => {
    expect(nextUp(Infinity)).toBe(Infinity);
  });

  it('round-trip: nextDown(nextUp(x)) == x for finite x', () => {
    for (const x of [1, -1, 0.5, Math.PI, 1e-200]) {
      expect(nextDown(nextUp(x))).toBe(x);
    }
  });
});

describe('bitsEqual', () => {
  it('+0 != -0 by bits', () => {
    expect(bitsEqual(0, -0)).toBe(false);
  });

  it('NaN equals any NaN', () => {
    expect(bitsEqual(Number.NaN, Number.NaN)).toBe(true);
  });

  it('matches normal equality otherwise', () => {
    expect(bitsEqual(1, 1)).toBe(true);
    expect(bitsEqual(1, 2)).toBe(false);
  });
});
