// Test-side helpers used by jest specs across the codebase.
//
// freezeGlobals / unfreezeGlobals delegate to the jest setup file
// (jest.setup.cjs) which installs the actual stubs. These helpers
// wrap the global toggle in a typed API so spec authors don't have
// to declare globals.

declare global {
  // eslint-disable-next-line no-var
  var allowNondeterminism: () => void;
  // eslint-disable-next-line no-var
  var revertNondeterminism: () => void;
}

export function allowNondeterminism(): void {
  if (typeof globalThis.allowNondeterminism !== 'function') {
    throw new Error(
      'silt: allowNondeterminism() called outside a test context. ' +
        'Make sure jest.setup.cjs is configured.',
    );
  }
  globalThis.allowNondeterminism();
}

export function revertNondeterminism(): void {
  if (typeof globalThis.revertNondeterminism !== 'function') {
    throw new Error(
      'silt: revertNondeterminism() called outside a test context.',
    );
  }
  globalThis.revertNondeterminism();
}

export function withRealClock<T>(fn: () => T): T {
  allowNondeterminism();
  try {
    return fn();
  } finally {
    revertNondeterminism();
  }
}
