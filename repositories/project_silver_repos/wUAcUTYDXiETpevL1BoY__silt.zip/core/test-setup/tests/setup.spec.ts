import { allowNondeterminism, revertNondeterminism, withRealClock } from '../src/index.js';

describe('determinism shim', () => {
  it('Math.random throws by default', () => {
    expect(() => Math.random()).toThrow(/silt determinism/);
  });

  it('Date.now returns the frozen timestamp', () => {
    expect(Date.now()).toBe(1700000000000);
  });

  it('new Date() with no args returns the frozen instance', () => {
    expect(new Date().getTime()).toBe(1700000000000);
  });

  it('setTimeout throws when frozen', () => {
    expect(() => setTimeout(() => {}, 0)).toThrow(/silt determinism/);
  });

  it('allowNondeterminism / revert restores normal behavior in scope', () => {
    allowNondeterminism();
    try {
      const r = Math.random();
      expect(r).toBeGreaterThanOrEqual(0);
      expect(r).toBeLessThan(1);
    } finally {
      revertNondeterminism();
    }
    // After revert, the throw is back
    expect(() => Math.random()).toThrow();
  });

  it('withRealClock wraps allow/revert', () => {
    const r = withRealClock(() => Math.random());
    expect(r).toBeGreaterThanOrEqual(0);
    expect(r).toBeLessThan(1);
    expect(() => Math.random()).toThrow();
  });
});
