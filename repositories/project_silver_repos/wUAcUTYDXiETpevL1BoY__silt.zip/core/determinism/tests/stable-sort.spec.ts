import { stableSort, stableSortIndices } from '../src/stable-sort.js';

describe('stableSortIndices', () => {
  it('returns indices in sorted order', () => {
    const xs = [30, 10, 20];
    const idx = stableSortIndices(xs, (a, b) => a - b);
    expect(idx).toEqual([1, 2, 0]);
  });

  it('breaks ties by input index', () => {
    const xs = [{ k: 1, t: 'a' }, { k: 1, t: 'b' }, { k: 1, t: 'c' }];
    const idx = stableSortIndices(xs, (a, b) => a.k - b.k);
    expect(idx).toEqual([0, 1, 2]);
  });

  it('is stable across re-sort', () => {
    const xs = [3, 1, 4, 1, 5, 9, 2, 6];
    const a = stableSortIndices(xs, (x, y) => x - y);
    const b = stableSortIndices(xs, (x, y) => x - y);
    expect(a).toEqual(b);
  });

  it('handles empty', () => {
    expect(stableSortIndices([], () => 0)).toEqual([]);
  });
});

describe('stableSort', () => {
  it('returns sorted values', () => {
    expect(stableSort([3, 1, 2], (a, b) => a - b)).toEqual([1, 2, 3]);
  });

  it('preserves equal-key order', () => {
    type R = { k: number; v: string };
    const xs: R[] = [
      { k: 1, v: 'a' },
      { k: 0, v: 'b' },
      { k: 1, v: 'c' },
      { k: 0, v: 'd' },
    ];
    const out = stableSort(xs, (a, b) => a.k - b.k);
    expect(out.map((r) => r.v)).toEqual(['b', 'd', 'a', 'c']);
  });
});
