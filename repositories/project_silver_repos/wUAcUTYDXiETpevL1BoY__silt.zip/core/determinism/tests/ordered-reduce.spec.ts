import { orderedReduce, orderedSum, orderedMean, orderedProd } from '../src/ordered-reduce.js';

describe('orderedReduce', () => {
  it('left-folds with identity', () => {
    expect(orderedReduce([1, 2, 3], (a, b) => a + b, 0)).toBe(6);
  });

  it('returns identity on empty', () => {
    expect(orderedReduce([], (a: number, b: number) => a + b, 7)).toBe(7);
  });

  it('preserves order', () => {
    // Subtraction is left-associative; order matters
    expect(orderedReduce([10, 1, 2, 3], (a, b) => a - b, 0)).toBe(-16);
  });
});

describe('orderedSum', () => {
  it('is Kahan-compensated', () => {
    expect(orderedSum([1, 2, 3])).toBe(6);
  });

  it('handles empty', () => {
    expect(orderedSum([])).toBe(0);
  });
});

describe('orderedMean', () => {
  it('computes mean', () => {
    expect(orderedMean([1, 2, 3, 4])).toBe(2.5);
  });

  it('returns 0 on empty', () => {
    expect(orderedMean([])).toBe(0);
  });
});

describe('orderedProd', () => {
  it('multiplies all', () => {
    expect(orderedProd([2, 3, 4])).toBe(24);
  });

  it('returns 1 on empty', () => {
    expect(orderedProd([])).toBe(1);
  });
});
