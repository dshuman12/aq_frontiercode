import { kahanSum, NeumaierSum } from '../src/kahan.js';

describe('kahanSum', () => {
  it('matches naive sum on well-conditioned input', () => {
    const xs = [1, 2, 3, 4, 5];
    expect(kahanSum(xs)).toBe(15);
  });

  it('returns 0 for empty', () => {
    expect(kahanSum([])).toBe(0);
  });

  it('beats naive sum on the classic catastrophic cancellation case', () => {
    // Sum 1, then 1e16 ones of magnitude 1e-8. Naive sum loses precision
    // because each tiny addend gets absorbed by the running 1.
    // Kahan recovers it.
    const big = 1e16;
    const tiny = 1e-8;
    // We synthesize a small version of the canonical bad-case: the
    // runtime cost of 1e16 iterations is prohibitive.
    const xs = [big, ...Array(10000).fill(tiny), -big];
    const expected = 10000 * tiny;
    const naive = xs.reduce((a, b) => a + b, 0);
    const kahan = kahanSum(xs);
    expect(Math.abs(kahan - expected)).toBeLessThan(Math.abs(naive - expected));
  });

  it('returns same answer regardless of input order for IEEE-friendly cases', () => {
    const xs = [1, 2, 3, 4, 5, 6, 7, 8];
    const reversed = xs.slice().reverse();
    expect(kahanSum(xs)).toBe(kahanSum(reversed));
  });
});

describe('NeumaierSum', () => {
  it('starts at zero', () => {
    expect(new NeumaierSum().value()).toBe(0);
  });

  it('accumulates basic adds', () => {
    const s = new NeumaierSum();
    s.add(1);
    s.add(2);
    s.add(3);
    expect(s.value()).toBe(6);
  });

  it('handles the Neumaier-vs-Kahan large-then-small case', () => {
    // Classic Neumaier-improvement test: add a tiny then a huge.
    // Kahan loses; Neumaier preserves.
    const s = new NeumaierSum();
    s.add(1.0);
    s.add(1e100);
    s.add(1.0);
    s.add(-1e100);
    expect(s.value()).toBe(2);
  });

  it('reset clears state', () => {
    const s = new NeumaierSum();
    s.add(5);
    s.reset();
    expect(s.value()).toBe(0);
  });
});
