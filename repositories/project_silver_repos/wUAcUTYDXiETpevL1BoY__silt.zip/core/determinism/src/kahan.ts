// Kahan compensated summation and Neumaier's improved variant.
//
// Why this matters for silt:
//   IEEE 754 addition is non-associative. (a + b) + c != a + (b + c)
//   in general. A naive reduction's result depends on the order it
//   walks the inputs. Different machines (and different runtimes)
//   sometimes pick different orders for "the same" reduction (e.g.
//   pairwise vs sequential, SIMD-batched vs scalar). For silt's
//   determinism contract we cannot tolerate that.
//
// Kahan keeps a running compensation term that captures the low-order
// bits lost in each addition. Neumaier improves on Kahan when the
// running sum is smaller in magnitude than the next addend.
//
// Refs:
//   Kahan 1965, "Pracniques: Further remarks on reducing truncation errors"
//   Neumaier 1974, "Rundungsfehleranalyse einiger Verfahren zur Summation endlicher Summen"

export function kahanSum(xs: ArrayLike<number>): number {
  let sum = 0;
  let c = 0;
  for (let i = 0; i < xs.length; i++) {
    const x = xs[i]!;
    const y = x - c;
    const t = sum + y;
    c = t - sum - y;
    sum = t;
  }
  return sum;
}

// Generalized form: reduce with a binary op that's commutative+associative
// in the abstract, but Kahan-corrected when the op is +. For other ops
// we fall back to plain left-fold (the determinism comes from the order,
// not the compensation).
export function kahanReduce<T extends number>(
  xs: ArrayLike<T>,
  op: 'add' | 'mul',
  identity: T,
): T {
  if (op === 'add') {
    return kahanSum(xs) as T;
  }
  // For multiplication, the analogous trick is to sum logs or to use
  // Veltkamp-Dekker splitting; we just do an ordered product and rely
  // on float64's ~15.9 decimal digit precision.
  let acc = identity;
  for (let i = 0; i < xs.length; i++) {
    acc = (acc * xs[i]!) as T;
  }
  return acc;
}

// Stateful Neumaier accumulator.
//
// Use:
//   const s = new NeumaierSum();
//   s.add(0.1); s.add(0.2); s.add(0.3);
//   s.value(); // -> 0.6 (more accurate than 0.1+0.2+0.3)
export class NeumaierSum {
  private _sum = 0;
  private _comp = 0;

  add(x: number): void {
    const t = this._sum + x;
    if (Math.abs(this._sum) >= Math.abs(x)) {
      this._comp += this._sum - t + x;
    } else {
      this._comp += x - t + this._sum;
    }
    this._sum = t;
  }

  value(): number {
    return this._sum + this._comp;
  }

  reset(): void {
    this._sum = 0;
    this._comp = 0;
  }
}
