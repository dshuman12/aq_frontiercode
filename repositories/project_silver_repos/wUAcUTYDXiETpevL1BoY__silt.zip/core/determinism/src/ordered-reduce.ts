// Strict left-fold reductions. Every reduction op in modules/ops-reductions
// goes through one of these to guarantee bit-exact determinism across
// platforms.
//
// We deliberately do not use Array.prototype.reduce -- engines have at
// times implemented it with parallel-friendly patterns that change
// observable order in subtle ways.

import { kahanSum } from './kahan.js';

export function orderedReduce<T>(
  xs: ArrayLike<T>,
  op: (acc: T, x: T) => T,
  identity: T,
): T {
  let acc = identity;
  for (let i = 0; i < xs.length; i++) {
    acc = op(acc, xs[i]!);
  }
  return acc;
}

// Compensated sum (Kahan).
export function orderedSum(xs: ArrayLike<number>): number {
  return kahanSum(xs);
}

// Mean = sum / n. Sum is Kahan-compensated; the final divide can lose
// up to 1 ulp but the reduce itself is stable.
export function orderedMean(xs: ArrayLike<number>): number {
  if (xs.length === 0) return 0;
  return orderedSum(xs) / xs.length;
}

// Product. We do not Kahan-correct multiplication; the relative error
// per multiply is bounded by EPSILON regardless of order, and there is
// no analog of compensated sum for products without log/exp.
export function orderedProd(xs: ArrayLike<number>): number {
  let acc = 1;
  for (let i = 0; i < xs.length; i++) {
    acc *= xs[i]!;
  }
  return acc;
}
