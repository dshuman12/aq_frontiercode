// Stable sort utilities.
//
// The ECMAScript spec since ES2019 requires Array.prototype.sort to be
// stable, so in principle we could just call sort(). In practice, when
// the comparator returns 0 for "equal", we want a *deterministic*
// fallback ordering -- sort stability only guarantees "equal elements
// stay in input order", but if the input order is itself a Map or Set
// iteration, we've leaked nondeterminism.
//
// stableSortIndices solves this by returning indices into the input,
// then stably sorting those. The fallback ordering is index-ascending.

export function stableSortIndices<T>(
  xs: ArrayLike<T>,
  cmp: (a: T, b: T) => number,
): number[] {
  const n = xs.length;
  const out = new Array<number>(n);
  for (let i = 0; i < n; i++) out[i] = i;
  out.sort((ia, ib) => {
    const c = cmp(xs[ia]!, xs[ib]!);
    if (c !== 0) return c;
    return ia - ib;
  });
  return out;
}

export function stableSort<T>(xs: ArrayLike<T>, cmp: (a: T, b: T) => number): T[] {
  const idx = stableSortIndices(xs, cmp);
  const out = new Array<T>(xs.length);
  for (let i = 0; i < idx.length; i++) {
    out[i] = xs[idx[i]!]!;
  }
  return out;
}
