import { tape, type OpHandler } from '@silt/core-tape';
import { topoOrder, reverseTopoOrder } from '../src/topo.js';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };

describe('topoOrder', () => {
  it('returns ids 1..N in order', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    expect(topoOrder(t)).toEqual([a, b, c]);
  });

  it('empty tape gives empty list', () => {
    expect(topoOrder(tape())).toEqual([]);
  });
});

describe('reverseTopoOrder', () => {
  it('reverses', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    expect(reverseTopoOrder(t)).toEqual([b, a]);
  });
});
