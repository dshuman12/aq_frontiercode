import { tape, type OpHandler } from '@silt/core-tape';
import { hasCycle } from '../src/cycles.js';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };

describe('hasCycle', () => {
  it('returns false for an acyclic tape (the only legal kind)', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    t.append('add', [a, b], addH);
    expect(hasCycle(t)).toBe(false);
  });

  it('returns false for an empty tape', () => {
    expect(hasCycle(tape())).toBe(false);
  });

  it('returns false for a deep chain', () => {
    const t = tape();
    let prev = t.leaf(0);
    const c = t.const(1);
    for (let i = 0; i < 50; i++) {
      prev = t.append('add', [prev, c], addH);
    }
    expect(hasCycle(t)).toBe(false);
  });
});
