import { tape, type OpHandler } from '@silt/core-tape';
import { buildEdges, parents, children, roots, leaves } from '../src/edges.js';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };

describe('buildEdges', () => {
  it('records children for each parent', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const d = t.append('add', [a, c], addH);
    const edges = buildEdges(t);
    expect(edges.children[a]).toEqual([c, d]);
    expect(edges.children[b]).toEqual([c]);
    expect(edges.children[c]).toEqual([d]);
    expect(edges.children[d]).toEqual([]);
  });

  it('records parents = inputs', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const edges = buildEdges(t);
    expect(edges.parents[c]).toEqual([a, b]);
  });

  it('handles empty tape', () => {
    const edges = buildEdges(tape());
    expect(edges.children).toEqual([[]]);
    expect(edges.parents).toEqual([[]]);
  });
});

describe('parents / children', () => {
  it('parents returns inputs', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    expect(parents(t, c)).toEqual([a, b]);
  });

  it('children indexes via edges', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const edges = buildEdges(t);
    expect(children(edges, a)).toEqual([c]);
  });
});

describe('roots / leaves', () => {
  it('roots are nodes with no children', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    expect(roots(t)).toEqual([c]);
  });

  it('leaves are leaf-op nodes', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.const(2);
    t.append('add', [a, b], addH);
    expect(leaves(t)).toEqual([a]);
  });
});
