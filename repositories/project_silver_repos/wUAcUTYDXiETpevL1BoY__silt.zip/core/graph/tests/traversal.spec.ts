import { tape, type OpHandler } from '@silt/core-tape';
import { reachable, reachableForward, reachableBackward } from '../src/traversal.js';

const addH: OpHandler = { evalFn: (i) => i[0]! + i[1]! };

describe('reachableForward', () => {
  it('finds all descendants of a leaf', () => {
    // a -> c -> d
    //         /
    //   b ---'
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const d = t.append('add', [c, b], addH);
    const r = reachableForward(t, a);
    expect(r.has(a)).toBe(true);
    expect(r.has(c)).toBe(true);
    expect(r.has(d)).toBe(true);
    expect(r.has(b)).toBe(false);
  });

  it('singleton on isolated leaf', () => {
    const t = tape();
    const a = t.leaf(1);
    const r = reachableForward(t, a);
    expect([...r]).toEqual([a]);
  });
});

describe('reachableBackward', () => {
  it('finds all ancestors of a root', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const d = t.append('add', [c, b], addH);
    const r = reachableBackward(t, d);
    expect(r.has(a)).toBe(true);
    expect(r.has(b)).toBe(true);
    expect(r.has(c)).toBe(true);
    expect(r.has(d)).toBe(true);
  });
});

describe('reachable', () => {
  it('union of multiple seeds', () => {
    const t = tape();
    const a = t.leaf(1);
    const b = t.leaf(2);
    const c = t.append('add', [a, b], addH);
    const r = reachable(t, [a, b], 'forward');
    expect(r.has(c)).toBe(true);
  });

  it('errors on bad direction at the type level', () => {
    // No runtime check; the type system already forbids other strings.
    expect(() => reachable(tape(), [], 'forward')).not.toThrow();
  });
});
