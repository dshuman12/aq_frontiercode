// Edge construction over a tape.
//
// The tape stores parent edges (each node's `inputs` are its parents).
// For backward traversal we want the inverse -- a child list per node.
// `buildEdges` precomputes both in O(N + E).

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';

export interface Edges {
  // parents[id] = inputs of id (already on the node, but exposed
  // through the same API for symmetry)
  parents: ReadonlyArray<readonly NodeId[]>;
  // children[id] = nodes that consume id as an input
  children: ReadonlyArray<readonly NodeId[]>;
}

export function buildEdges(t: Tape): Edges {
  const n = t.size() + 1; // sentinel
  const parents = new Array<NodeId[]>(n);
  const children = new Array<NodeId[]>(n);
  for (let i = 0; i < n; i++) {
    parents[i] = [];
    children[i] = [];
  }
  for (const node of t.iter()) {
    const id = node.id;
    parents[id] = node.inputs.slice();
    for (const p of node.inputs) {
      children[p]!.push(id);
    }
  }
  return { parents, children };
}

// Convenience: inputs of a single node (delegates to tape).
export function parents(t: Tape, id: NodeId): readonly NodeId[] {
  return t.get(id).inputs;
}

export function children(edges: Edges, id: NodeId): readonly NodeId[] {
  return edges.children[id] ?? [];
}

export function roots(t: Tape): NodeId[] {
  // A "root" in autodiff parlance is the OUTPUT side of the graph --
  // nodes with no children. We compute this by walking edges.
  const edges = buildEdges(t);
  const out: NodeId[] = [];
  for (const node of t.iter()) {
    if ((edges.children[node.id] ?? []).length === 0) out.push(node.id);
  }
  return out;
}

export function leaves(t: Tape): NodeId[] {
  // Leaves are inputs (nodes with no parents AND op == 'leaf').
  const out: NodeId[] = [];
  for (const node of t.iter()) {
    if (node.op === 'leaf') out.push(node.id);
  }
  return out;
}
