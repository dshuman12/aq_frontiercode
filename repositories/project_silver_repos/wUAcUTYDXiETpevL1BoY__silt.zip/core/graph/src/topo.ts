// Topological order over the tape.
//
// Tape insertion order is already topological (since you can't have
// `append(...)` reference a node that doesn't exist yet). So topoOrder
// just returns insertion order. We expose this anyway because callers
// shouldn't have to know the insertion-order invariant -- if we ever
// change tape representation, this stays correct.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';

export function topoOrder(t: Tape): NodeId[] {
  return t.ids();
}

export function reverseTopoOrder(t: Tape): NodeId[] {
  const ids = t.ids();
  ids.reverse();
  return ids;
}
