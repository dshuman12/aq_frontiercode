// Forward / backward reachability over the tape.
//
// "Forward reachable" from a leaf = the set of nodes that depend on
// this leaf (transitively, through op chains).
//
// "Backward reachable" from a root = the set of leaves that contribute
// to this root.
//
// Backward is what the gradient walker actually cares about: given an
// output, which leaves should we accumulate gradient into?

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { buildEdges, type Edges } from './edges.js';

export function reachableForward(t: Tape, fromLeaf: NodeId): Set<NodeId> {
  const edges = buildEdges(t);
  return _bfs(edges, fromLeaf, 'children');
}

export function reachableBackward(t: Tape, fromRoot: NodeId): Set<NodeId> {
  const edges = buildEdges(t);
  return _bfs(edges, fromRoot, 'parents');
}

// Convenience: union of all nodes reachable from any of the seeds in
// the chosen direction.
export function reachable(
  t: Tape,
  seeds: readonly NodeId[],
  dir: 'forward' | 'backward',
): Set<NodeId> {
  const edges = buildEdges(t);
  const out = new Set<NodeId>();
  for (const seed of seeds) {
    const sub = _bfs(edges, seed, dir === 'forward' ? 'children' : 'parents');
    for (const id of sub) out.add(id);
  }
  return out;
}

function _bfs(edges: Edges, start: NodeId, follow: 'parents' | 'children'): Set<NodeId> {
  const seen = new Set<NodeId>();
  const stack: NodeId[] = [start];
  while (stack.length > 0) {
    const id = stack.pop()!;
    if (seen.has(id)) continue;
    seen.add(id);
    const next = follow === 'children' ? edges.children[id] : edges.parents[id];
    if (next) {
      for (const n of next) {
        if (!seen.has(n)) stack.push(n);
      }
    }
  }
  return seen;
}
