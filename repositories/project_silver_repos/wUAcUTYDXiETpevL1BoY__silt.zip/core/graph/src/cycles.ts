// Cycle detection.
//
// The tape can never have a cycle (insertion order is total), but the
// serializer's deserialize path takes a buffer from outside; we want
// to assert acyclicity before trusting it. This module is reused there.

import type { NodeId } from '@silt/core-types';
import type { Tape } from '@silt/core-tape';
import { buildEdges } from './edges.js';

export function hasCycle(t: Tape): boolean {
  const edges = buildEdges(t);
  // Standard 3-color DFS.
  const WHITE = 0;
  const GRAY = 1;
  const BLACK = 2;
  const color = new Uint8Array(edges.children.length);
  const stack: NodeId[] = [];
  for (const node of t.iter()) {
    if (color[node.id] !== WHITE) continue;
    stack.push(node.id);
    while (stack.length > 0) {
      const top = stack[stack.length - 1]!;
      if (color[top] === WHITE) color[top] = GRAY;
      let pushed = false;
      const kids = edges.children[top] ?? [];
      for (const k of kids) {
        if (color[k] === WHITE) {
          stack.push(k);
          pushed = true;
          break;
        }
        if (color[k] === GRAY) return true;
      }
      if (!pushed) {
        color[top] = BLACK;
        stack.pop();
      }
    }
  }
  return false;
}
