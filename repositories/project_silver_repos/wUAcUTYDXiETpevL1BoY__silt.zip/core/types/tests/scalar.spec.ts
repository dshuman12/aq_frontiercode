import { isScalar, scalar, asScalar } from '../src/scalar.js';

describe('scalar', () => {
  it('accepts a finite number', () => {
    const x = scalar(1.5);
    expect(x).toBe(1.5);
  });

  it('rejects NaN at construction', () => {
    expect(() => scalar(Number.NaN)).toThrow(TypeError);
  });

  it('accepts +/-Infinity', () => {
    expect(scalar(Infinity)).toBe(Infinity);
    expect(scalar(-Infinity)).toBe(-Infinity);
  });

  it('rejects strings via TypeError', () => {
    // @ts-expect-error
    expect(() => scalar('1')).toThrow(TypeError);
  });

  it('asScalar permits NaN (loose variant)', () => {
    const x = asScalar(Number.NaN);
    expect(Number.isNaN(x)).toBe(true);
  });
});

describe('isScalar', () => {
  it('returns true for finite numbers', () => {
    expect(isScalar(1)).toBe(true);
    expect(isScalar(0)).toBe(true);
    expect(isScalar(-1.5)).toBe(true);
  });

  it('returns false for NaN', () => {
    expect(isScalar(Number.NaN)).toBe(false);
  });

  it('returns false for non-numbers', () => {
    expect(isScalar('1')).toBe(false);
    expect(isScalar(null)).toBe(false);
    expect(isScalar(undefined)).toBe(false);
    expect(isScalar({})).toBe(false);
  });

  it('returns false for Infinity (not finite)', () => {
    expect(isScalar(Infinity)).toBe(false);
    expect(isScalar(-Infinity)).toBe(false);
  });
});
