import {
  shape,
  shapeRank,
  shapeSize,
  shapesEqual,
  axisIndex,
  prependAxis,
  appendAxis,
  removeAxis,
} from '../src/shape.js';

describe('shape', () => {
  it('builds an immutable tuple', () => {
    const s = shape(2, 3);
    expect(s).toEqual([2, 3]);
    expect(Object.isFrozen(s)).toBe(true);
  });

  it('rejects negative dims', () => {
    expect(() => shape(-1)).toThrow(RangeError);
  });

  it('rejects non-integer dims', () => {
    expect(() => shape(1.5)).toThrow(RangeError);
  });

  it('accepts zero-dim (scalar shape)', () => {
    const s = shape();
    expect(shapeRank(s)).toBe(0);
    expect(shapeSize(s)).toBe(1);
  });

  it('accepts a zero-length axis', () => {
    const s = shape(0, 5);
    expect(shapeSize(s)).toBe(0);
  });
});

describe('shapeSize', () => {
  it('multiplies dims', () => {
    expect(shapeSize(shape(2, 3, 4))).toBe(24);
  });

  it('returns 1 for scalar', () => {
    expect(shapeSize(shape())).toBe(1);
  });
});

describe('shapesEqual', () => {
  it('returns true for matching shapes', () => {
    expect(shapesEqual(shape(2, 3), shape(2, 3))).toBe(true);
  });

  it('returns false on rank mismatch', () => {
    expect(shapesEqual(shape(2, 3), shape(2, 3, 1))).toBe(false);
  });

  it('returns false on dim mismatch', () => {
    expect(shapesEqual(shape(2, 3), shape(2, 4))).toBe(false);
  });
});

describe('axisIndex', () => {
  it('computes flat index row-major', () => {
    const s = shape(2, 3);
    expect(axisIndex(s, [0, 0])).toBe(0);
    expect(axisIndex(s, [0, 2])).toBe(2);
    expect(axisIndex(s, [1, 0])).toBe(3);
    expect(axisIndex(s, [1, 2])).toBe(5);
  });

  it('throws on rank mismatch', () => {
    expect(() => axisIndex(shape(2, 3), [0])).toThrow(RangeError);
  });

  it('bails on out-of-bounds index', () => {
    expect(() => axisIndex(shape(2, 3), [2, 0])).toThrow(RangeError);
    expect(() => axisIndex(shape(2, 3), [0, 3])).toThrow(RangeError);
  });
});

describe('prependAxis / appendAxis', () => {
  it('prepends a new outer dim', () => {
    expect(prependAxis(shape(3), 4)).toEqual([4, 3]);
  });

  it('appends a new inner dim', () => {
    expect(appendAxis(shape(3), 4)).toEqual([3, 4]);
  });
});

describe('removeAxis', () => {
  it('drops an interior dim', () => {
    expect(removeAxis(shape(2, 3, 4), 1)).toEqual([2, 4]);
  });

  it('errors on out-of-bounds axis', () => {
    expect(() => removeAxis(shape(2, 3), 5)).toThrow(RangeError);
  });
});
