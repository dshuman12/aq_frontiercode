import { ok, err, isOk, isErr, mapOk, mapErr, unwrap, unwrapOr } from '../src/result.js';

describe('Result', () => {
  it('ok carries a value', () => {
    const r = ok(42);
    expect(isOk(r)).toBe(true);
    expect(isErr(r)).toBe(false);
    if (r.ok) expect(r.value).toBe(42);
  });

  it('err carries an error', () => {
    const r = err(new Error('oops'));
    expect(isOk(r)).toBe(false);
    expect(isErr(r)).toBe(true);
    if (!r.ok) expect(r.error.message).toBe('oops');
  });

  it('mapOk transforms ok payload', () => {
    const r = mapOk(ok(2), (x) => x * 3);
    expect(unwrap(r)).toBe(6);
  });

  it('mapOk does nothing on err', () => {
    const e = new Error('x');
    const r = mapOk(err(e), (x: number) => x * 3);
    expect(isErr(r)).toBe(true);
    if (!r.ok) expect(r.error).toBe(e);
  });

  it('mapErr transforms err payload', () => {
    const r = mapErr(err('x'), (s) => s.toUpperCase());
    expect(isErr(r)).toBe(true);
    if (!r.ok) expect(r.error).toBe('X');
  });

  it('unwrap throws on err', () => {
    expect(() => unwrap(err(new Error('boom')))).toThrow('boom');
  });

  it('unwrap stringifies non-Error err', () => {
    expect(() => unwrap(err('boom'))).toThrow('boom');
  });

  it('unwrapOr returns fallback on err', () => {
    expect(unwrapOr(err('x'), 7)).toBe(7);
  });
});
