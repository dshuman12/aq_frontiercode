import { range1d, sliceAll, sliceFrom, sliceLength } from '../src/ranges.js';

describe('range1d', () => {
  it('builds a frozen range', () => {
    const r = range1d(0, 10, 2);
    expect(r).toEqual({ start: 0, stop: 10, step: 2 });
    expect(Object.isFrozen(r)).toBe(true);
  });

  it('rejects step zero', () => {
    expect(() => range1d(0, 10, 0)).toThrow(RangeError);
  });

  it('rejects non-integers', () => {
    expect(() => range1d(0.5, 1)).toThrow(TypeError);
  });

  it('default step is 1', () => {
    expect(range1d(0, 5).step).toBe(1);
  });
});

describe('sliceAll', () => {
  it('uses sentinel stop=-1', () => {
    const r = sliceAll();
    expect(r.start).toBe(0);
    expect(r.stop).toBe(-1);
  });
});

describe('sliceFrom', () => {
  it('keeps stop sentinel', () => {
    const r = sliceFrom(3);
    expect(r.start).toBe(3);
    expect(r.stop).toBe(-1);
  });
});

describe('sliceLength', () => {
  it('computes length for normal range', () => {
    expect(sliceLength(range1d(0, 10, 1), 10)).toBe(10);
    expect(sliceLength(range1d(0, 10, 2), 10)).toBe(5);
  });

  it('handles to-end sentinel', () => {
    expect(sliceLength(sliceAll(), 7)).toBe(7);
  });

  it('handles negative start', () => {
    expect(sliceLength({ start: -3, stop: -1, step: 1 }, 10)).toBe(3);
  });

  it('returns 0 for inverted range with positive step', () => {
    expect(sliceLength(range1d(5, 2, 1), 10)).toBe(0);
  });
});
