import { shape } from '../src/shape.js';
import {
  tensor,
  isTensor,
  tensorRank,
  tensorSize,
  tensorAt,
  tensorFrom1D,
  tensorFrom2D,
} from '../src/tensor.js';

describe('tensor', () => {
  it('packs a 1D Float64Array', () => {
    const t = tensor(shape(3), [1, 2, 3]);
    expect(t.data).toBeInstanceOf(Float64Array);
    expect(Array.from(t.data)).toEqual([1, 2, 3]);
  });

  it('rejects mismatched data length', () => {
    expect(() => tensor(shape(2, 2), [1, 2, 3])).toThrow(RangeError);
  });
});

describe('isTensor', () => {
  it('identifies a tensor', () => {
    expect(isTensor(tensor(shape(2), [1, 2]))).toBe(true);
  });

  it('rejects an object that lacks Float64Array data', () => {
    expect(isTensor({ shape: [2], data: [1, 2] })).toBe(false);
  });

  it('rejects null', () => {
    expect(isTensor(null)).toBe(false);
  });
});

describe('tensorAt', () => {
  it('reads from a 2D tensor', () => {
    const t = tensorFrom2D([
      [1, 2, 3],
      [4, 5, 6],
    ]);
    expect(tensorAt(t, [0, 0])).toBe(1);
    expect(tensorAt(t, [1, 2])).toBe(6);
  });

  it('throws on out-of-bounds', () => {
    const t = tensorFrom2D([
      [1, 2],
      [3, 4],
    ]);
    expect(() => tensorAt(t, [2, 0])).toThrow(RangeError);
  });
});

describe('tensorFrom2D', () => {
  it('packs row-major', () => {
    const t = tensorFrom2D([
      [1, 2, 3],
      [4, 5, 6],
    ]);
    expect(Array.from(t.data)).toEqual([1, 2, 3, 4, 5, 6]);
    expect(t.shape).toEqual([2, 3]);
  });

  it('refuses jagged input', () => {
    expect(() => tensorFrom2D([[1, 2], [3]])).toThrow(RangeError);
  });

  it('handles an empty grid', () => {
    const t = tensorFrom2D([]);
    expect(t.shape).toEqual([0, 0]);
    expect(tensorSize(t)).toBe(0);
  });
});

describe('tensorRank', () => {
  it('matches shape rank', () => {
    expect(tensorRank(tensorFrom1D([1, 2, 3]))).toBe(1);
    expect(tensorRank(tensorFrom2D([[1, 2]]))).toBe(2);
  });
});
