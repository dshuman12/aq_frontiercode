import { newNodeId, nodeIdToString, parseNodeId } from '../src/node-id.js';

describe('newNodeId', () => {
  it('returns a number', () => {
    const id = newNodeId();
    expect(typeof id).toBe('number');
  });

  it('returns increasing values from the global stream', () => {
    const a = newNodeId();
    const b = newNodeId();
    expect(b).toBeGreaterThan(a);
  });
});

describe('nodeIdToString / parseNodeId roundtrip', () => {
  it('round-trips small ids', () => {
    for (let i = 0; i < 10; i++) {
      const id = newNodeId();
      const round = parseNodeId(nodeIdToString(id));
      expect(round).toBe(id);
    }
  });

  it('emits the n-prefixed form', () => {
    expect(nodeIdToString(42 as never)).toBe('n42');
  });

  it('throws on missing prefix', () => {
    expect(() => parseNodeId('42')).toThrow(TypeError);
  });

  it('errors on negative id', () => {
    expect(() => parseNodeId('n-1')).toThrow(TypeError);
  });

  it('refuses non-integer id', () => {
    expect(() => parseNodeId('n1.5')).toThrow(TypeError);
  });
});
