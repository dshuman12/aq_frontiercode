// A small Result<T, E> type. Used at boundaries (parsing, IO) where
// we want exhaustive error handling without try/catch.
//
// The autodiff core itself does not use Result -- it throws. Result is
// for the serializer, the REPL, and tools/.

export interface ResultOk<T> {
  readonly ok: true;
  readonly value: T;
}

export interface ResultErr<E> {
  readonly ok: false;
  readonly error: E;
}

export type Result<T, E = Error> = ResultOk<T> | ResultErr<E>;

export function ok<T>(value: T): ResultOk<T> {
  return { ok: true, value };
}

export function err<E>(error: E): ResultErr<E> {
  return { ok: false, error };
}

export function isOk<T, E>(r: Result<T, E>): r is ResultOk<T> {
  return r.ok;
}

export function isErr<T, E>(r: Result<T, E>): r is ResultErr<E> {
  return !r.ok;
}

export function mapOk<T, U, E>(r: Result<T, E>, f: (t: T) => U): Result<U, E> {
  return r.ok ? ok(f(r.value)) : r;
}

export function mapErr<T, E, F>(r: Result<T, E>, f: (e: E) => F): Result<T, F> {
  return r.ok ? r : err(f(r.error));
}

export function unwrap<T, E>(r: Result<T, E>): T {
  if (r.ok) return r.value;
  if (r.error instanceof Error) throw r.error;
  throw new Error(`unwrap: ${String(r.error)}`);
}

export function unwrapOr<T, E>(r: Result<T, E>, fallback: T): T {
  return r.ok ? r.value : fallback;
}
