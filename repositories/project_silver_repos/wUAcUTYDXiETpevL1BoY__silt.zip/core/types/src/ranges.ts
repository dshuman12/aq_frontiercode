// Range and slice abstractions used by indexing ops.

export interface Range1D {
  readonly start: number;
  readonly stop: number;
  readonly step: number;
}

export interface Slice {
  readonly ranges: readonly Range1D[];
}

export function range1d(start: number, stop: number, step = 1): Range1D {
  if (step === 0) {
    throw new RangeError('range1d: step cannot be zero');
  }
  if (!Number.isInteger(start) || !Number.isInteger(stop) || !Number.isInteger(step)) {
    throw new TypeError('range1d: start, stop, step must all be integers');
  }
  return Object.freeze({ start, stop, step });
}

export function sliceAll(): Range1D {
  // Sentinel "select everything along this axis". Negative stop is the
  // canonical marker; consumers know to interpret it as "to the end".
  return Object.freeze({ start: 0, stop: -1, step: 1 });
}

export function sliceFrom(start: number): Range1D {
  return Object.freeze({ start, stop: -1, step: 1 });
}

export function sliceLength(r: Range1D, axisDim: number): number {
  const stop = r.stop < 0 ? axisDim : r.stop;
  const start = r.start < 0 ? Math.max(0, axisDim + r.start) : r.start;
  if (r.step > 0) {
    return Math.max(0, Math.ceil((stop - start) / r.step));
  }
  return Math.max(0, Math.ceil((start - stop) / -r.step));
}
