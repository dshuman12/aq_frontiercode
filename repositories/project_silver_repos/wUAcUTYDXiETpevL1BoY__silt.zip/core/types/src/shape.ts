// Shape: a tuple of non-negative integer dimensions.
// We use readonly number arrays for shape, not bigint, because
// (a) JS bitwise ops are 32-bit anyway, and
// (b) in real autodiff workloads no single dim exceeds 2^32.

export type Shape = readonly number[];
export type Axis = number;
export type AxisIndex = readonly number[];

export function shape(...dims: number[]): Shape {
  for (let i = 0; i < dims.length; i++) {
    const d = dims[i]!;
    if (!Number.isInteger(d) || d < 0) {
      throw new RangeError(`shape: dim[${i}] must be a non-negative integer, got ${d}`);
    }
  }
  return Object.freeze(dims.slice());
}

export function shapeRank(s: Shape): number {
  return s.length;
}

export function shapeSize(s: Shape): number {
  let n = 1;
  for (let i = 0; i < s.length; i++) {
    n *= s[i]!;
  }
  return n;
}

export function shapesEqual(a: Shape, b: Shape): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

export function axisIndex(s: Shape, idx: AxisIndex): number {
  if (idx.length !== s.length) {
    throw new RangeError(
      `axisIndex: rank mismatch -- shape has rank ${s.length}, idx has rank ${idx.length}`,
    );
  }
  let flat = 0;
  let stride = 1;
  for (let i = s.length - 1; i >= 0; i--) {
    const d = s[i]!;
    const c = idx[i]!;
    if (c < 0 || c >= d) {
      throw new RangeError(`axisIndex: idx[${i}]=${c} out of bounds for dim ${d}`);
    }
    flat += c * stride;
    stride *= d;
  }
  return flat;
}

export function prependAxis(s: Shape, n: number): Shape {
  return shape(n, ...s);
}

export function appendAxis(s: Shape, n: number): Shape {
  return shape(...s, n);
}

export function removeAxis(s: Shape, axis: Axis): Shape {
  if (axis < 0 || axis >= s.length) {
    throw new RangeError(`removeAxis: axis ${axis} out of bounds for shape rank ${s.length}`);
  }
  const out = s.slice();
  out.splice(axis, 1);
  return Object.freeze(out);
}
