// Public surface of @silt/core-types.

export type { Scalar, ScalarLike } from './scalar.js';
export { isScalar, scalar, asScalar } from './scalar.js';

export type { Shape, Axis, AxisIndex } from './shape.js';
export {
  shape,
  shapeRank,
  shapeSize,
  shapesEqual,
  axisIndex,
  prependAxis,
  appendAxis,
  removeAxis,
} from './shape.js';

export type { Tensor, TensorLike } from './tensor.js';
export {
  tensor,
  isTensor,
  tensorRank,
  tensorSize,
  tensorAt,
  tensorFrom1D,
  tensorFrom2D,
} from './tensor.js';

export type { NodeId, OpKind, NodeKind } from './node-id.js';
export { newNodeId, nodeIdToString, parseNodeId } from './node-id.js';

export type { Range1D, Slice } from './ranges.js';
export { range1d, sliceAll, sliceFrom, sliceLength } from './ranges.js';

export type { ResultOk, ResultErr, Result } from './result.js';
export { ok, err, isOk, isErr, mapOk, mapErr, unwrap, unwrapOr } from './result.js';
