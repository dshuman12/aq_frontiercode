// Scalar represents a single float64 value participating in autodiff.
// It is a thin nominal wrapper over `number` so that downstream code
// can distinguish scalars-with-grad-tracking from raw numerics in the
// type system.
//
// At runtime a Scalar is just a number; the tape attaches gradient
// metadata externally keyed by the value's NodeId, not on the value
// itself. This is deliberately the opposite of an OO wrapper approach,
// for two reasons:
//
//   1. It keeps the hot path (forward eval) free of allocations
//   2. It lets us cheaply duck-type `number` -> `Scalar` at the
//      boundary, so callers don't need to wrap leaves explicitly.

declare const SCALAR_BRAND: unique symbol;

export type Scalar = number & { readonly [SCALAR_BRAND]: void };

// Things accepted as scalar input. Plain numbers are coerced.
export type ScalarLike = number | Scalar;

const SCALAR_FINITE_GUARD = true;

export function isScalar(x: unknown): x is Scalar {
  return typeof x === 'number' && Number.isFinite(x as number);
}

export function scalar(x: ScalarLike): Scalar {
  // Round-trip through the Scalar brand. The branding is purely a TS
  // ghost: `x` is the same number bits at runtime.
  if (typeof x !== 'number') {
    throw new TypeError(`scalar() expects a number, got ${typeof x}`);
  }
  if (SCALAR_FINITE_GUARD && Number.isNaN(x)) {
    // NaN is allowed downstream (gradient of abs at 0, etc.) but never
    // as a freshly-constructed leaf value -- a NaN leaf almost always
    // indicates a bug at the call site.
    throw new TypeError('scalar(NaN) is not allowed at construction');
  }
  return x as Scalar;
}

export function asScalar(x: ScalarLike): Scalar {
  // Loose variant of scalar() that accepts NaN. Used internally where
  // NaN is a legitimate intermediate (gradients of non-smooth ops).
  return x as Scalar;
}
