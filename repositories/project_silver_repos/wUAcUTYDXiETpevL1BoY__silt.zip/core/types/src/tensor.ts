// Tensor: shape + flat row-major Float64Array.
//
// Storage choice rationale: Float64Array gives us
//   - guaranteed 8-byte alignment for fast typed-array ops
//   - cheap shallow copies via .slice()
//   - exact bit-equality across machines (IEEE 754)
//
// We don't use a strided view abstraction at this layer. Higher-level
// code in modules/ops-broadcasting handles broadcasting by emitting
// explicit copy ops, not by manipulating strides. That choice trades a
// bit of memory for a much simpler tape format.

import type { Shape } from './shape.js';
import { shape, shapeSize, shapesEqual, axisIndex } from './shape.js';

export interface Tensor {
  readonly shape: Shape;
  readonly data: Float64Array;
}

export type TensorLike = number | number[] | number[][] | Tensor;

export function tensor(s: Shape, data: ArrayLike<number>): Tensor {
  const expected = shapeSize(s);
  if (data.length !== expected) {
    throw new RangeError(
      `tensor: data length ${data.length} does not match shape size ${expected}`,
    );
  }
  const buf = new Float64Array(expected);
  for (let i = 0; i < expected; i++) {
    buf[i] = data[i]!;
  }
  return { shape: s, data: buf };
}

export function isTensor(x: unknown): x is Tensor {
  return (
    typeof x === 'object' &&
    x !== null &&
    'shape' in x &&
    'data' in x &&
    (x as Tensor).data instanceof Float64Array
  );
}

export function tensorRank(t: Tensor): number {
  return t.shape.length;
}

export function tensorSize(t: Tensor): number {
  return t.data.length;
}

export function tensorAt(t: Tensor, idx: readonly number[]): number {
  return t.data[axisIndex(t.shape, idx)]!;
}

export function tensorFrom1D(xs: readonly number[]): Tensor {
  return tensor(shape(xs.length), xs);
}

export function tensorFrom2D(xs: readonly (readonly number[])[]): Tensor {
  const rows = xs.length;
  if (rows === 0) {
    return tensor(shape(0, 0), []);
  }
  const cols = xs[0]!.length;
  for (let i = 1; i < rows; i++) {
    if (xs[i]!.length !== cols) {
      throw new RangeError(`tensorFrom2D: row ${i} has length ${xs[i]!.length}, expected ${cols}`);
    }
  }
  const flat = new Float64Array(rows * cols);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      flat[r * cols + c] = xs[r]![c]!;
    }
  }
  return { shape: shape(rows, cols), data: flat };
}

// Re-export for use within the package; consumers import from index.ts
export { shapesEqual };
