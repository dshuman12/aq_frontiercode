// NodeId is a monotonically-increasing 32-bit integer that identifies
// a node on a tape. We use plain numbers (not bigint) because:
//   - V8 packs small int32s as SMIs, fast
//   - 2^31 distinct ops per tape is more than any plausible workload
//   - bigint round-trips through JSON badly
//
// IDs are assigned by Tape.allocate(); 0 is reserved for a sentinel.

export type NodeId = number & { readonly __nodeId: void };

export type OpKind =
  | 'leaf'
  | 'const'
  | 'add'
  | 'sub'
  | 'mul'
  | 'div'
  | 'neg'
  | 'abs'
  | 'sign'
  | 'min'
  | 'max'
  | 'sin'
  | 'cos'
  | 'tan'
  | 'asin'
  | 'acos'
  | 'atan'
  | 'atan2'
  | 'sinh'
  | 'cosh'
  | 'tanh'
  | 'asinh'
  | 'acosh'
  | 'atanh'
  | 'exp'
  | 'log'
  | 'log1p'
  | 'expm1'
  | 'pow'
  | 'sqrt'
  | 'cbrt'
  | 'eq'
  | 'lt'
  | 'gt'
  | 'le'
  | 'ge'
  | 'sum'
  | 'mean'
  | 'prod'
  | 'min-reduce'
  | 'max-reduce'
  | 'argmax'
  | 'matmul'
  | 'transpose'
  | 'diag'
  | 'trace'
  | 'det'
  | 'broadcast'
  | 'sum-to-shape'
  | 'gather'
  | 'scatter'
  | 'concat'
  | 'split'
  | 'cond'
  | 'where'
  | 'select'
  | 'relu'
  | 'sigmoid'
  | 'tanh-act'
  | 'softmax'
  | 'log-sum-exp';

export type NodeKind = 'scalar' | 'tensor';

const NODE_ID_PREFIX = 'n';

let _next = 1;

export function newNodeId(): NodeId {
  // Tape instances will reset their own counters, but for ad-hoc use
  // (mostly tests) we provide a single global stream too.
  const id = _next++ as NodeId;
  return id;
}

export function nodeIdToString(id: NodeId): string {
  return `${NODE_ID_PREFIX}${id}`;
}

export function parseNodeId(s: string): NodeId {
  if (!s.startsWith(NODE_ID_PREFIX)) {
    throw new TypeError(`parseNodeId: expected '${NODE_ID_PREFIX}' prefix, got ${JSON.stringify(s)}`);
  }
  const rest = s.slice(NODE_ID_PREFIX.length);
  const n = Number(rest);
  if (!Number.isInteger(n) || n < 0) {
    throw new TypeError(`parseNodeId: not a valid id: ${JSON.stringify(s)}`);
  }
  return n as NodeId;
}
