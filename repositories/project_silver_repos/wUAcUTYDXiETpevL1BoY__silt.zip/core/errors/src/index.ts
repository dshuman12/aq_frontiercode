export {
  SiltError,
  ShapeError,
  TapeError,
  GradError,
  NumericError,
  SerializationError,
  classifyError,
} from './errors.js';
export type { ErrorKind } from './errors.js';
