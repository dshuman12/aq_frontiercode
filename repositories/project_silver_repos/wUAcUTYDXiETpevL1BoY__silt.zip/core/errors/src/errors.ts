// Silt error taxonomy.
//
// Every internal throw is one of these. Boundary code in tools/ and
// services/ catches SiltError and routes; the autodiff core itself
// rarely catches anything -- errors propagate to the caller.

export type ErrorKind =
  | 'shape'
  | 'tape'
  | 'grad'
  | 'numeric'
  | 'serialization'
  | 'unknown';

export class SiltError extends Error {
  public readonly kind: ErrorKind;

  constructor(kind: ErrorKind, message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'SiltError';
    this.kind = kind;
    // The es5 / NodeNext target loses prototype chain across re-throws
    // in some bundlers. Setting it explicitly fixes instanceof checks.
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

// Shape mismatches between operands.
export class ShapeError extends SiltError {
  constructor(message: string, options?: ErrorOptions) {
    super('shape', message, options);
    this.name = 'ShapeError';
    Object.setPrototypeOf(this, ShapeError.prototype);
  }
}

// Tape protocol violations: replaying a tape after free, attaching a
// node from a different tape, etc.
export class TapeError extends SiltError {
  constructor(message: string, options?: ErrorOptions) {
    super('tape', message, options);
    this.name = 'TapeError';
    Object.setPrototypeOf(this, TapeError.prototype);
  }
}

// Gradient-flow problems: attempting backward through a non-
// differentiable op, missing seed gradient, multi-root call without
// explicit aggregation, etc.
export class GradError extends SiltError {
  constructor(message: string, options?: ErrorOptions) {
    super('grad', message, options);
    this.name = 'GradError';
    Object.setPrototypeOf(this, GradError.prototype);
  }
}

// Pure numerical concerns: domain errors (log of negative), overflow
// in integer index math, etc.
export class NumericError extends SiltError {
  constructor(message: string, options?: ErrorOptions) {
    super('numeric', message, options);
    this.name = 'NumericError';
    Object.setPrototypeOf(this, NumericError.prototype);
  }
}

// Serialize/deserialize: format version mismatch, truncated buffer,
// CRC failure.
export class SerializationError extends SiltError {
  constructor(message: string, options?: ErrorOptions) {
    super('serialization', message, options);
    this.name = 'SerializationError';
    Object.setPrototypeOf(this, SerializationError.prototype);
  }
}

export function classifyError(err: unknown): ErrorKind {
  if (err instanceof SiltError) return err.kind;
  // Foreign errors get walked for duck-typed shape: anything with a
  // 'kind' string is honored. This is mostly for cross-module errors
  // that lost their prototype chain.
  if (typeof err === 'object' && err !== null) {
    const k = (err as { kind?: unknown }).kind;
    if (typeof k === 'string') {
      const known: ErrorKind[] = ['shape', 'tape', 'grad', 'numeric', 'serialization'];
      if (known.includes(k as ErrorKind)) return k as ErrorKind;
    }
  }
  return 'unknown';
}
