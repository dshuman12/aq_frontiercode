import {
  SiltError,
  ShapeError,
  TapeError,
  GradError,
  NumericError,
  SerializationError,
  classifyError,
} from '../src/errors.js';

describe('SiltError taxonomy', () => {
  it('SiltError is an Error', () => {
    const e = new SiltError('unknown', 'x');
    expect(e).toBeInstanceOf(Error);
    expect(e.name).toBe('SiltError');
  });

  it('ShapeError is a SiltError', () => {
    const e = new ShapeError('rank mismatch');
    expect(e).toBeInstanceOf(SiltError);
    expect(e).toBeInstanceOf(ShapeError);
    expect(e.kind).toBe('shape');
    expect(e.name).toBe('ShapeError');
  });

  it('TapeError carries kind', () => {
    expect(new TapeError('x').kind).toBe('tape');
  });

  it('GradError carries kind', () => {
    expect(new GradError('x').kind).toBe('grad');
  });

  it('NumericError carries kind', () => {
    expect(new NumericError('x').kind).toBe('numeric');
  });

  it('SerializationError carries kind', () => {
    expect(new SerializationError('x').kind).toBe('serialization');
  });

  it('preserves cause when given', () => {
    const cause = new Error('underlying');
    const e = new ShapeError('outer', { cause });
    expect((e as Error & { cause: unknown }).cause).toBe(cause);
  });
});

describe('classifyError', () => {
  it('classifies own errors', () => {
    expect(classifyError(new ShapeError('x'))).toBe('shape');
    expect(classifyError(new TapeError('x'))).toBe('tape');
    expect(classifyError(new GradError('x'))).toBe('grad');
    expect(classifyError(new NumericError('x'))).toBe('numeric');
    expect(classifyError(new SerializationError('x'))).toBe('serialization');
  });

  it('falls back to unknown for plain Error', () => {
    expect(classifyError(new Error('plain'))).toBe('unknown');
  });

  it('returns unknown for null', () => {
    expect(classifyError(null)).toBe('unknown');
  });

  it('returns unknown for primitive', () => {
    expect(classifyError('string')).toBe('unknown');
    expect(classifyError(42)).toBe('unknown');
  });

  it('honors duck-typed kind', () => {
    expect(classifyError({ kind: 'shape', message: 'x' })).toBe('shape');
  });

  it('refuses unknown kind on duck-typed object', () => {
    expect(classifyError({ kind: 'invalid', message: 'x' })).toBe('unknown');
  });
});

describe('error throwability', () => {
  it('preserves instanceof through throw / catch', () => {
    try {
      throw new ShapeError('rank mismatch');
    } catch (e) {
      expect(e).toBeInstanceOf(ShapeError);
      expect(e).toBeInstanceOf(SiltError);
    }
  });
});
