// Sampling primitives that consume a Mulberry32.
//
// Every function takes the PRNG explicitly so that callers always
// know which stream is being consumed. There is no global PRNG.

import type { Mulberry32 } from './mulberry32.js';

// Box-Muller: convert two uniforms to two independent N(0, 1) samples.
// Reference: Box & Muller 1958, "A Note on the Generation of Random
// Normal Deviates".
export function boxMuller(rng: Mulberry32): [number, number] {
  // Avoid u1 == 0 to prevent log(0).
  let u1 = rng.nextFloat();
  while (u1 === 0) u1 = rng.nextFloat();
  const u2 = rng.nextFloat();
  const r = Math.sqrt(-2 * Math.log(u1));
  const t = 2 * Math.PI * u2;
  return [r * Math.cos(t), r * Math.sin(t)];
}

export function sampleNormal(rng: Mulberry32, mean = 0, stddev = 1): number {
  const [z] = boxMuller(rng);
  return mean + stddev * z;
}

export function sampleUniform(rng: Mulberry32, lo: number, hi: number): number {
  if (!Number.isFinite(lo) || !Number.isFinite(hi)) {
    throw new RangeError('sampleUniform: lo/hi must be finite');
  }
  if (hi < lo) {
    throw new RangeError(`sampleUniform: hi (${hi}) < lo (${lo})`);
  }
  return lo + (hi - lo) * rng.nextFloat();
}

export function sampleBernoulli(rng: Mulberry32, p: number): boolean {
  if (p < 0 || p > 1 || Number.isNaN(p)) {
    throw new RangeError(`sampleBernoulli: p out of [0, 1]: ${p}`);
  }
  return rng.nextFloat() < p;
}

export function sampleInt(rng: Mulberry32, lo: number, hi: number): number {
  // Inclusive on both ends.
  if (!Number.isInteger(lo) || !Number.isInteger(hi)) {
    throw new TypeError('sampleInt: lo/hi must be integers');
  }
  if (hi < lo) {
    throw new RangeError(`sampleInt: hi (${hi}) < lo (${lo})`);
  }
  const span = hi - lo + 1;
  return lo + Math.floor(rng.nextFloat() * span);
}
