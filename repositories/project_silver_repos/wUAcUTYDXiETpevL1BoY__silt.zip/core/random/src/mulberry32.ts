// Mulberry32: a 32-bit non-cryptographic PRNG with a 2^32 period.
//
// We chose Mulberry32 for two reasons:
//   1. It's bit-exact across runtimes -- the algorithm uses only
//      32-bit unsigned multiply, add, xor, and shift, all of which are
//      deterministic in JS via Math.imul and >>> 0.
//   2. It's small enough to implement in 10 lines, so the test
//      "the PRNG output is what we say it is" is trivially auditable.
//
// Period 2^32 is fine for the use cases in silt:
//   - seeded gradcheck input perturbation
//   - random init for weights in optimizer tests
//   - shuffling for fuzz seeds
// We do NOT use this for cryptography; consumers wanting crypto-grade
// randomness should bring their own PRNG.

export class Mulberry32 {
  private _state: number;

  constructor(seed: number) {
    if (!Number.isInteger(seed)) {
      throw new TypeError(`Mulberry32: seed must be an integer, got ${seed}`);
    }
    // Coerce to uint32 explicitly so a negative seed lands in the same
    // state space as the corresponding two's-complement positive.
    this._state = seed >>> 0;
  }

  next(): number {
    // Returns a uint32.
    let t = (this._state += 0x6d2b79f5) >>> 0;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t = (t + Math.imul(t ^ (t >>> 7), t | 61)) >>> 0;
    return ((t ^ (t >>> 14)) >>> 0);
  }

  // Float in [0, 1). Uses 32 bits of entropy, sufficient for almost
  // all sampling use cases. For ops requiring full float64 entropy,
  // call next() twice and combine.
  nextFloat(): number {
    return this.next() / 4294967296;
  }

  // Skip n outputs without using them. Useful for advancing a stream
  // past a checkpoint.
  skip(n: number): void {
    if (!Number.isInteger(n) || n < 0) {
      throw new RangeError('Mulberry32.skip: n must be a non-negative integer');
    }
    for (let i = 0; i < n; i++) this.next();
  }

  // Snapshot internal state. Two PRNGs with equal state produce equal
  // streams thereafter.
  state(): number {
    return this._state >>> 0;
  }

  setState(s: number): void {
    if (!Number.isInteger(s)) {
      throw new TypeError('Mulberry32.setState: state must be integer');
    }
    this._state = s >>> 0;
  }

  clone(): Mulberry32 {
    const r = new Mulberry32(0);
    r._state = this._state;
    return r;
  }
}
