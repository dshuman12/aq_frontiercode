import { Mulberry32 } from '../src/mulberry32.js';
import {
  boxMuller,
  sampleNormal,
  sampleUniform,
  sampleBernoulli,
  sampleInt,
} from '../src/sampling.js';

describe('boxMuller', () => {
  it('returns two finite numbers', () => {
    const r = new Mulberry32(1);
    const [a, b] = boxMuller(r);
    expect(Number.isFinite(a)).toBe(true);
    expect(Number.isFinite(b)).toBe(true);
  });

  it('is deterministic for a given seed', () => {
    const out1 = boxMuller(new Mulberry32(123));
    const out2 = boxMuller(new Mulberry32(123));
    expect(out1).toEqual(out2);
  });

  it('large sample mean approaches 0', () => {
    const r = new Mulberry32(42);
    let sum = 0;
    const n = 10000;
    for (let i = 0; i < n / 2; i++) {
      const [a, b] = boxMuller(r);
      sum += a + b;
    }
    expect(Math.abs(sum / n)).toBeLessThan(0.05);
  });

  it('large sample variance approaches 1', () => {
    const r = new Mulberry32(7);
    let sumSq = 0;
    const n = 10000;
    for (let i = 0; i < n / 2; i++) {
      const [a, b] = boxMuller(r);
      sumSq += a * a + b * b;
    }
    expect(Math.abs(sumSq / n - 1)).toBeLessThan(0.05);
  });
});

describe('sampleNormal', () => {
  it('default returns a finite number', () => {
    expect(Number.isFinite(sampleNormal(new Mulberry32(1)))).toBe(true);
  });

  it('shifted+scaled mean and stddev', () => {
    const r = new Mulberry32(99);
    let sum = 0;
    let sumSq = 0;
    const n = 5000;
    for (let i = 0; i < n; i++) {
      const v = sampleNormal(r, 5, 2);
      sum += v;
      sumSq += (v - 5) * (v - 5);
    }
    expect(Math.abs(sum / n - 5)).toBeLessThan(0.1);
    expect(Math.abs(sumSq / n - 4)).toBeLessThan(0.2);
  });
});

describe('sampleUniform', () => {
  it('lies within the requested range', () => {
    const r = new Mulberry32(1);
    for (let i = 0; i < 100; i++) {
      const v = sampleUniform(r, -3, 7);
      expect(v).toBeGreaterThanOrEqual(-3);
      expect(v).toBeLessThan(7);
    }
  });

  it('throws on lo > hi', () => {
    expect(() => sampleUniform(new Mulberry32(0), 5, 1)).toThrow(RangeError);
  });

  it('refuses NaN bounds', () => {
    expect(() => sampleUniform(new Mulberry32(0), Number.NaN, 1)).toThrow(RangeError);
  });
});

describe('sampleBernoulli', () => {
  it('returns true for p=1', () => {
    expect(sampleBernoulli(new Mulberry32(1), 1)).toBe(true);
  });

  it('returns false for p=0', () => {
    expect(sampleBernoulli(new Mulberry32(1), 0)).toBe(false);
  });

  it('large sample frequency near p', () => {
    const r = new Mulberry32(2);
    let trues = 0;
    for (let i = 0; i < 5000; i++) if (sampleBernoulli(r, 0.3)) trues++;
    expect(Math.abs(trues / 5000 - 0.3)).toBeLessThan(0.02);
  });

  it('throws on out-of-range p', () => {
    expect(() => sampleBernoulli(new Mulberry32(0), -0.1)).toThrow(RangeError);
    expect(() => sampleBernoulli(new Mulberry32(0), 1.1)).toThrow(RangeError);
  });
});

describe('sampleInt', () => {
  it('inclusive on both ends', () => {
    const r = new Mulberry32(1);
    for (let i = 0; i < 200; i++) {
      const v = sampleInt(r, 0, 5);
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThanOrEqual(5);
      expect(Number.isInteger(v)).toBe(true);
    }
  });

  it('refuses non-integer bounds', () => {
    expect(() => sampleInt(new Mulberry32(0), 0.5, 1)).toThrow(TypeError);
  });

  it('refuses inverted bounds', () => {
    expect(() => sampleInt(new Mulberry32(0), 5, 1)).toThrow(RangeError);
  });

  it('handles a 1-element range', () => {
    expect(sampleInt(new Mulberry32(7), 3, 3)).toBe(3);
  });
});
