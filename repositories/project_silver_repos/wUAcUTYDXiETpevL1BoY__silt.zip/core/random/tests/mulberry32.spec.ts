import { Mulberry32 } from '../src/mulberry32.js';

describe('Mulberry32', () => {
  it('rejects non-integer seed', () => {
    expect(() => new Mulberry32(1.5)).toThrow(TypeError);
  });

  it('produces deterministic output for a given seed', () => {
    const a = new Mulberry32(42);
    const b = new Mulberry32(42);
    for (let i = 0; i < 100; i++) {
      expect(a.next()).toBe(b.next());
    }
  });

  it('produces uint32 outputs', () => {
    const r = new Mulberry32(1);
    for (let i = 0; i < 1000; i++) {
      const v = r.next();
      expect(Number.isInteger(v)).toBe(true);
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThanOrEqual(0xffffffff);
    }
  });

  it('first three outputs from seed 0 are stable', () => {
    // Captured once and pinned. If this changes, the conformance corpus
    // for everything downstream invalidates.
    const r = new Mulberry32(0);
    expect(r.next()).toBe(208781441);
    expect(r.next()).toBe(2415310276);
    expect(r.next()).toBe(2718387426);
  });

  it('first three outputs from seed 42 are stable', () => {
    const r = new Mulberry32(42);
    const captured = [r.next(), r.next(), r.next()];
    // Re-creating gives same sequence
    const r2 = new Mulberry32(42);
    expect([r2.next(), r2.next(), r2.next()]).toEqual(captured);
  });

  it('nextFloat returns values in [0, 1)', () => {
    const r = new Mulberry32(7);
    for (let i = 0; i < 1000; i++) {
      const f = r.nextFloat();
      expect(f).toBeGreaterThanOrEqual(0);
      expect(f).toBeLessThan(1);
    }
  });

  it('skip(n) advances by n outputs', () => {
    const a = new Mulberry32(13);
    const b = new Mulberry32(13);
    a.skip(5);
    for (let i = 0; i < 5; i++) b.next();
    expect(a.next()).toBe(b.next());
  });

  it('state / setState round-trip', () => {
    const a = new Mulberry32(99);
    a.next();
    a.next();
    const s = a.state();
    const out1 = [a.next(), a.next()];
    const b = new Mulberry32(0);
    b.setState(s);
    const out2 = [b.next(), b.next()];
    expect(out1).toEqual(out2);
  });

  it('clone produces an independent equivalent stream', () => {
    const a = new Mulberry32(2);
    a.next();
    const b = a.clone();
    expect(a.next()).toBe(b.next());
    a.next();
    // b should still produce its own next, not affected by a's
    const before = b.state();
    b.next();
    const after = b.state();
    expect(after).not.toBe(before);
  });

  it('different seeds produce different streams', () => {
    const a = new Mulberry32(1);
    const b = new Mulberry32(2);
    expect(a.next()).not.toBe(b.next());
  });

  it('handles negative seed via two-complement coercion', () => {
    const r = new Mulberry32(-1);
    // Equivalent to seed 0xffffffff
    const r2 = new Mulberry32(0xffffffff);
    expect(r.next()).toBe(r2.next());
  });
});
