"""Tests for flowq.inspection."""
import pytest
from flowq.inspection import Inspector, Page, NameAggregation
from flowq.storage    import Storage
from flowq.models     import Job, JobStatus


@pytest.fixture()
def storage(tmp_path):
    s = Storage(str(tmp_path / "insp.db"))
    return s


@pytest.fixture()
def inspector(storage):
    return Inspector(storage)


def populate(storage, n=10):
    jobs = []
    for i in range(n):
        j = Job(name="task_a" if i % 2 == 0 else "task_b", payload={})
        storage.save(j)
        if i % 3 == 0:
            j.mark_running()
            storage.update(j)
            j.mark_success()
            storage.update(j)
        jobs.append(j)
    return jobs


def test_paginate_returns_page(inspector, storage):
    populate(storage, 25)
    page = inspector.paginate(page=1, page_size=10)
    assert isinstance(page, Page)
    assert len(page.items) == 10
    assert page.total == 25
    assert page.total_pages == 3
    assert page.has_next


def test_paginate_last_page(inspector, storage):
    populate(storage, 5)
    page = inspector.paginate(page=1, page_size=10)
    assert not page.has_next
    assert not page.has_prev


def test_search_by_name_contains(inspector, storage):
    populate(storage, 10)
    results = inspector.search(name_contains="task_a")
    assert all("task_a" in j.name for j in results)


def test_search_by_tag(inspector, storage):
    j = Job(name="tagged", payload={}, tags=["vip"])
    storage.save(j)
    results = inspector.search(tag="vip")
    assert any(r.id == j.id for r in results)


def test_aggregate_by_name(inspector, storage):
    populate(storage, 20)
    aggs = inspector.aggregate_by_name()
    assert len(aggs) > 0
    names = {a.name for a in aggs}
    assert "task_a" in names or "task_b" in names


def test_status_summary(inspector, storage):
    populate(storage, 6)
    s = inspector.status_summary()
    assert "total" in s
    assert "by_status" in s
    assert s["total"] == 6


def test_export_json(inspector, storage):
    populate(storage, 3)
    records = inspector.export_json()
    assert len(records) == 3
    assert all("id" in r for r in records)


def test_export_csv(inspector, storage):
    populate(storage, 3)
    csv = inspector.export_csv()
    lines = csv.strip().split("\n")
    assert len(lines) == 4   # header + 3 data rows


def test_slow_jobs_empty_when_all_fast(inspector, storage):
    populate(storage, 5)
    slow = inspector.slow_jobs(threshold_seconds=999)
    assert slow == []


def test_retry_heavy_jobs(inspector, storage):
    j = Job(name="flaky", payload={}, max_retries=5)
    storage.save(j)
    j.retries_used = 3
    storage.update(j)
    heavy = inspector.retry_heavy_jobs(min_retries=2)
    assert any(h.id == j.id for h in heavy)


def test_page_to_dict(inspector, storage):
    populate(storage, 3)
    page = inspector.paginate()
    d = page.to_dict()
    assert "items" in d
    assert "total_pages" in d
