"""Tests for flowq.locking."""
import threading
import time
import pytest
from flowq.locking import LockManager, LockNotHeld, LockAlreadyHeld


@pytest.fixture()
def lm(tmp_path):
    return LockManager(str(tmp_path / "locks.db"))


def test_try_acquire_succeeds(lm):
    assert lm.try_acquire("res1", owner="w1")


def test_try_acquire_blocks_second_owner(lm):
    lm.try_acquire("res2", owner="w1")
    assert not lm.try_acquire("res2", owner="w2")


def test_release_allows_reacquire(lm):
    lm.try_acquire("res3", owner="w1")
    lm.release("res3", owner="w1")
    assert lm.try_acquire("res3", owner="w2")


def test_release_not_held_raises(lm):
    with pytest.raises(LockNotHeld):
        lm.release("unknown", owner="w1")


def test_is_locked_true(lm):
    lm.try_acquire("res4", owner="w1")
    assert lm.is_locked("res4")


def test_is_locked_false_when_free(lm):
    assert not lm.is_locked("free_lock")


def test_ttl_expiry_allows_reacquire(lm):
    lm.try_acquire("res5", owner="w1", ttl=0.05)
    time.sleep(0.1)
    assert lm.try_acquire("res5", owner="w2")


def test_lock_context_manager(lm):
    with lm.lock("res6", owner="w1", ttl=10):
        assert lm.is_locked("res6")
    assert not lm.is_locked("res6")


def test_blocking_acquire_times_out(lm):
    lm.try_acquire("res7", owner="w1")
    with pytest.raises(TimeoutError):
        lm.acquire("res7", owner="w2", timeout=0.1)


def test_acquire_timeout_zero_raises_immediately(lm):
    lm.try_acquire("res8", owner="w1")
    with pytest.raises((LockAlreadyHeld, TimeoutError)):
        lm.acquire("res8", owner="w2", timeout=0)


def test_info_returns_lockinfo(lm):
    lm.try_acquire("res9", owner="w1")
    info = lm.info("res9")
    assert info is not None
    assert info.owner == "w1"


def test_info_none_for_free_lock(lm):
    assert lm.info("absent") is None


def test_list_locks(lm):
    lm.try_acquire("la", owner="w1")
    lm.try_acquire("lb", owner="w1")
    locks = lm.list_locks()
    names = {l.name for l in locks}
    assert "la" in names and "lb" in names


def test_purge_expired(lm):
    lm.try_acquire("pe1", owner="w1", ttl=0.05)
    lm.try_acquire("pe2", owner="w1", ttl=None)
    time.sleep(0.1)
    n = lm.purge_expired()
    assert n == 1


def test_release_all_for_owner(lm):
    lm.try_acquire("ra1", owner="bulk")
    lm.try_acquire("ra2", owner="bulk")
    lm.try_acquire("ra3", owner="other")
    n = lm.release_all_for_owner("bulk")
    assert n == 2
    assert lm.is_locked("ra3")


def test_concurrent_exclusive_access(lm):
    results = []
    lock = threading.Lock()

    def worker(owner):
        with lm.lock(f"shared_res", owner=owner, ttl=5, timeout=2):
            with lock:
                results.append(owner)
            time.sleep(0.02)

    threads = [threading.Thread(target=worker, args=(f"w{i}",)) for i in range(5)]
    for t in threads: t.start()
    for t in threads: t.join()
    assert len(results) == 5
