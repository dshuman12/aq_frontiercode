"""Tests for flowq.compression."""
import pytest
from flowq.compression import (
    compress, decompress, compression_registry,
    ZlibCompressor, GzipCompressor, LzmaCompressor, Bz2Compressor,
    NoopCompressor, CompressedPayload,
)


@pytest.mark.parametrize("algo", ["zlib", "gzip", "lzma", "bz2", "none"])
def test_round_trip(algo):
    obj = {"records": list(range(100)), "meta": "test"}
    payload = compress(obj, algorithm=algo)
    assert decompress(payload) == obj


@pytest.mark.parametrize("algo", ["zlib", "gzip", "lzma", "bz2"])
def test_compression_reduces_size(algo):
    obj = {"data": "x" * 1000}
    payload = compress(obj, algorithm=algo)
    assert payload.ratio < 1.0


def test_noop_ratio_is_one():
    payload = compress({"x": 1}, algorithm="none")
    assert payload.ratio == 1.0


def test_compressed_payload_to_from_bytes():
    obj = [1, 2, 3, 4, 5]
    payload = compress(obj, algorithm="zlib")
    raw = payload.to_bytes()
    restored = CompressedPayload.from_bytes(raw)
    assert restored.algorithm == "zlib"
    assert decompress(restored) == obj


def test_registry_names():
    names = compression_registry.names()
    for n in ("zlib", "gzip", "lzma", "bz2", "none"):
        assert n in names


def test_registry_unknown_raises():
    with pytest.raises(KeyError):
        compression_registry.get("msgpack")


def test_best_for_returns_string():
    data = b"hello hello hello hello hello hello hello"
    best = compression_registry.best_for(data)
    assert isinstance(best, str)
    assert best in compression_registry.names()


def test_level_parameter():
    obj = {"data": "y" * 500}
    p1 = compress(obj, algorithm="zlib", level=1)
    p9 = compress(obj, algorithm="zlib", level=9)
    # Both decompress correctly
    assert decompress(p1) == obj
    assert decompress(p9) == obj


def test_compressor_repr():
    for cls in (ZlibCompressor, GzipCompressor, NoopCompressor):
        c = cls()
        assert c.name in ("zlib", "gzip", "none")
