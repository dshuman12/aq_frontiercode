"""Tests for flowq.batching."""
import time
import threading
import pytest
from flowq.batching import Batcher, BatchResult


def test_add_and_flush(tmp_path):
    received = []
    b = Batcher(lambda items: received.extend(items), max_size=10, max_wait=60)
    b.add(1)
    b.add(2)
    result = b.flush()
    assert result is not None
    assert received == [1, 2]


def test_auto_flush_on_max_size():
    received = []
    event = threading.Event()

    def handler(items):
        received.extend(items)
        event.set()

    b = Batcher(handler, max_size=3, max_wait=60)
    b.start()
    for i in range(3):
        b.add(i)
    event.wait(timeout=2)
    b.stop(drain=False)
    assert received == [0, 1, 2]


def test_auto_flush_on_max_wait():
    received = []
    event = threading.Event()

    def handler(items):
        received.extend(items)
        event.set()

    b = Batcher(handler, max_size=100, max_wait=0.1)
    b.start()
    b.add("hello")
    event.wait(timeout=1)
    b.stop(drain=False)
    assert "hello" in received


def test_stop_drain():
    received = []
    b = Batcher(lambda items: received.extend(items), max_size=100, max_wait=60)
    b.start()
    b.add_many([1, 2, 3])
    b.stop(drain=True)
    assert received == [1, 2, 3]


def test_add_many():
    received = []
    b = Batcher(lambda items: received.extend(items), max_size=100, max_wait=60)
    b.add_many([10, 20, 30])
    b.flush()
    assert received == [10, 20, 30]


def test_flush_empty_returns_none():
    b = Batcher(lambda items: None, max_size=10, max_wait=60)
    assert b.flush() is None


def test_stats():
    b = Batcher(lambda items: None, max_size=10, max_wait=60)
    b.add(1)
    b.add(2)
    b.flush()
    s = b.stats()
    assert s["total_batches"] == 1
    assert s["total_items"] == 2


def test_on_error_callback():
    errors = []

    def bad_handler(items):
        raise ValueError("oops")

    def on_err(items, exc):
        errors.append(exc)

    b = Batcher(bad_handler, max_size=10, max_wait=60, on_error=on_err)
    b.add(1)
    b.flush()
    assert len(errors) == 1
    assert isinstance(errors[0], ValueError)


def test_invalid_max_size():
    with pytest.raises(ValueError):
        Batcher(lambda x: None, max_size=0)


def test_invalid_max_wait():
    with pytest.raises(ValueError):
        Batcher(lambda x: None, max_wait=0)


def test_double_start_raises():
    b = Batcher(lambda x: None, max_size=10, max_wait=60)
    b.start()
    with pytest.raises(Exception):
        b.start()
    b.stop()


def test_buffer_size():
    b = Batcher(lambda x: None, max_size=100, max_wait=60)
    b.add_many([1, 2, 3])
    assert b.buffer_size == 3
