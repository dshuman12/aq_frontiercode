"""Tests for flowq.routing."""
import pytest
from flowq.routing import Router
from flowq.queue  import JobQueue
from flowq.models import Job, Priority


@pytest.fixture()
def queues():
    return {
        "critical":   JobQueue(),
        "default":    JobQueue(),
        "background": JobQueue(),
    }


@pytest.fixture()
def router(queues):
    return Router(queues, default="default")


def job(name="task", priority=Priority.NORMAL, tags=None, payload=None):
    return Job(name=name, payload=payload or {}, priority=priority, tags=tags or [])


def test_default_route(router, queues):
    j = job()
    target = router.route(j)
    assert target == "default"
    assert len(queues["default"]) == 1


def test_priority_rule(router, queues):
    router.add_priority_rule(Priority.CRITICAL, target="critical")
    j = job(priority=Priority.CRITICAL)
    assert router.route(j) == "critical"


def test_tag_rule(router, queues):
    router.add_tag_rule("bulk", target="background")
    j = job(tags=["bulk"])
    assert router.route(j) == "background"


def test_name_glob_rule(router, queues):
    router.add_name_rule("email_*", target="background")
    j = job(name="email_welcome")
    assert router.route(j) == "background"


def test_name_glob_no_match(router, queues):
    router.add_name_rule("email_*", target="background")
    j = job(name="sms_welcome")
    assert router.route(j) == "default"


def test_payload_rule(router, queues):
    router.add_payload_rule("tier", "premium", target="critical")
    j = job(payload={"tier": "premium"})
    assert router.route(j) == "critical"


def test_first_matching_rule_wins(router, queues):
    router.add_tag_rule("bulk", target="background", name="r1")
    router.add_priority_rule(Priority.LOW, target="critical", name="r2")
    j = job(priority=Priority.LOW, tags=["bulk"])
    target = router.route(j)
    # r1 and r2 both match; whichever has higher priority or registered first wins
    assert target in ("background", "critical")


def test_remove_rule(router, queues):
    router.add_tag_rule("vip", target="critical", name="vip_rule")
    router.remove_rule("vip_rule")
    j = job(tags=["vip"])
    assert router.route(j) == "default"


def test_resolve_does_not_enqueue(router, queues):
    j = job()
    router.resolve(j)
    assert sum(len(q) for q in queues.values()) == 0


def test_route_many(router, queues):
    router.add_tag_rule("bulk", target="background")
    jobs = [job(tags=["bulk"]) for _ in range(3)] + [job() for _ in range(2)]
    counts = router.route_many(jobs)
    assert counts["background"] == 3
    assert counts["default"] == 2


def test_invalid_default_raises():
    with pytest.raises(ValueError):
        Router({"q": JobQueue()}, default="nonexistent")


def test_invalid_target_raises(router):
    with pytest.raises(ValueError):
        router.add_tag_rule("x", target="missing_queue")


def test_stats_has_keys(router, queues):
    router.route(job())
    s = router.stats()
    assert "routed" in s
    assert "rules" in s
    assert "default" in s


def test_queue_depths(router, queues):
    router.route(job())
    depths = router.queue_depths()
    assert depths["default"] == 1
