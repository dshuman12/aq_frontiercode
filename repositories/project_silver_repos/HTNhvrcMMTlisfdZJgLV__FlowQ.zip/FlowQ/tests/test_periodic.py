"""Tests for flowq.periodic."""
import time
import pytest
from flowq.periodic import Beat, PeriodicTask, RunRecord
from flowq.queue    import JobQueue
from flowq.storage  import Storage
from flowq.models   import Priority


@pytest.fixture()
def queue():
    return JobQueue()


@pytest.fixture()
def storage(tmp_path):
    return Storage(str(tmp_path / "beat.db"))


@pytest.fixture()
def beat(queue, storage):
    return Beat(queue=queue, storage=storage, tick_interval=60)


def test_register_task(beat):
    task = PeriodicTask(name="t1", handler="noop", interval=60)
    beat.register(task)
    assert any(t.name == "t1" for t in beat.tasks())


def test_unregister_task(beat):
    beat.register(PeriodicTask(name="t2", handler="noop", interval=60))
    assert beat.unregister("t2")
    assert all(t.name != "t2" for t in beat.tasks())


def test_tick_fires_due_task(beat, queue):
    task = PeriodicTask(name="due", handler="noop_beat", interval=1)
    beat.register(task)
    records = beat.tick()
    assert any(r.task_name == "due" for r in records)
    assert len(queue) == 1


def test_tick_does_not_fire_not_due(beat, queue):
    task = PeriodicTask(name="future", handler="noop_beat", interval=9999)
    task.last_run = time.time()
    beat.register(task)
    records = beat.tick()
    assert all(r.task_name != "future" for r in records)


def test_disabled_task_not_fired(beat, queue):
    task = PeriodicTask(name="off", handler="noop_beat", interval=0, enabled=False)
    beat.register(task)
    beat.tick()
    assert len(queue) == 0


def test_run_count_increments(beat, queue):
    task = PeriodicTask(name="counter", handler="noop_beat", interval=0)
    beat.register(task)
    beat.tick()
    beat.tick()
    t = next(t for t in beat.tasks() if t.name == "counter")
    assert t.run_count == 2


def test_history_recorded(beat, queue):
    beat.register(PeriodicTask(name="hist", handler="noop_beat", interval=0))
    beat.tick()
    assert len(beat.history()) == 1


def test_stats_keys(beat):
    s = beat.stats()
    assert "task_count" in s
    assert "total_runs" in s
    assert "tick_interval" in s


def test_every_decorator(queue, storage):
    b = Beat(queue=queue, storage=storage, tick_interval=60)

    @b.every(0.001, name="decorated_task")
    def my_periodic():
        pass

    assert any(t.name == "decorated_task" for t in b.tasks())
    records = b.tick()
    assert any(r.task_name == "decorated_task" for r in records)


def test_jitter_applied(beat, queue):
    # Just verify it doesn't crash; jitter value is random
    task = PeriodicTask(name="jittered", handler="noop_beat", interval=0, jitter=5.0)
    beat.register(task)
    records = beat.tick()
    assert records


def test_repr(beat):
    assert "Beat" in repr(beat)
