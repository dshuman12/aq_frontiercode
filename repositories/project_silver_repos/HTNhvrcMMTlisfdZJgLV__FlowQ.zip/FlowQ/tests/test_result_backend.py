"""Tests for flowq.result_backend."""
import time
import pytest
from flowq.result_backend import ResultBackend, ResultEntry


@pytest.fixture()
def rb(tmp_path):
    return ResultBackend(str(tmp_path / "results.db"))


def test_store_and_get(rb):
    rb.store("j1", {"status": "ok"})
    entry = rb.get("j1")
    assert entry is not None
    assert entry.value == {"status": "ok"}


def test_get_missing_returns_none(rb):
    assert rb.get("nonexistent") is None


def test_get_value_convenience(rb):
    rb.store("j2", 42)
    assert rb.get_value("j2") == 42


def test_get_value_default(rb):
    assert rb.get_value("missing", default="fallback") == "fallback"


def test_exists_true_for_stored(rb):
    rb.store("j3", "hello")
    assert rb.exists("j3")


def test_exists_false_for_missing(rb):
    assert not rb.exists("ghost")


def test_ttl_expiry(rb):
    rb.store("j4", "soon", ttl=0.05)
    time.sleep(0.1)
    assert rb.get("j4").is_expired()
    assert not rb.exists("j4")


def test_no_ttl_never_expires(rb):
    rb.store("j5", "forever", ttl=None)
    entry = rb.get("j5")
    assert not entry.is_expired()


def test_delete(rb):
    rb.store("j6", 1)
    assert rb.delete("j6")
    assert rb.get("j6") is None


def test_delete_missing_returns_false(rb):
    assert not rb.delete("ghost")


def test_overwrite_default_true(rb):
    rb.store("j7", "v1")
    rb.store("j7", "v2")
    assert rb.get_value("j7") == "v2"


def test_overwrite_false_raises(rb):
    rb.store("j8", "v1")
    with pytest.raises(KeyError):
        rb.store("j8", "v2", overwrite=False)


def test_purge_expired(rb):
    rb.store("e1", 1, ttl=0.05)
    rb.store("e2", 2, ttl=0.05)
    rb.store("e3", 3, ttl=None)
    time.sleep(0.1)
    n = rb.purge_expired()
    assert n == 2
    assert rb.count() == 1


def test_list_recent(rb):
    for i in range(5):
        rb.store(f"lr{i}", i)
    entries = rb.list_recent(limit=3)
    assert len(entries) == 3


def test_stats(rb):
    rb.store("s1", 1, ttl=None)
    rb.store("s2", 2, ttl=0.05)
    time.sleep(0.1)
    s = rb.stats()
    assert s["total"] == 2
    assert s["expired"] == 1
    assert s["active"] == 1


def test_metadata_stored(rb):
    rb.store("m1", "x", metadata={"source": "etl", "version": 2})
    entry = rb.get("m1")
    assert entry.metadata["source"] == "etl"


def test_ttl_remaining_positive(rb):
    rb.store("t1", 1, ttl=60)
    entry = rb.get("t1")
    assert entry.ttl_remaining() > 50


def test_to_dict(rb):
    rb.store("d1", {"a": 1})
    d = rb.get("d1").to_dict()
    assert "job_id" in d and "value" in d
