"""Tests for flowq.tasks."""
import pytest
from flowq.tasks   import Task, TaskRegistry, AsyncResult
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.models  import Priority
from flowq.worker  import Worker


@pytest.fixture()
def storage(tmp_path):
    return Storage(str(tmp_path / "tasks.db"))


@pytest.fixture()
def queue():
    return JobQueue()


@pytest.fixture()
def registry(queue, storage):
    return TaskRegistry(queue=queue, storage=storage)


@pytest.fixture()
def worker(queue, storage):
    return Worker(queue=queue, storage=storage)


def test_task_decorator_registers(registry):
    @registry.task
    def my_task():
        return 42

    assert registry.get("flowq.tasks.test_task_decorator_registers.<locals>.my_task") is None or            len(registry.all_tasks()) >= 1


def test_task_call_synchronous(registry):
    results = []

    @registry.task
    def sync_task(x):
        results.append(x)

    sync_task(99)
    assert results == [99]


def test_delay_enqueues_job(registry, queue, storage):
    @registry.task(name="delay_test")
    def delayed():
        pass

    ar = delayed.delay()
    assert isinstance(ar, AsyncResult)
    assert len(queue) == 1


def test_apply_async_with_args(registry, queue, storage):
    @registry.task(name="args_test")
    def add(a, b):
        return a + b

    ar = add.delay(3, 4)
    job = queue.dequeue()
    assert job.payload["args"] == [3, 4]


def test_apply_async_with_kwargs(registry, queue, storage):
    @registry.task(name="kwargs_test")
    def greet(name="world"):
        return f"hello {name}"

    ar = greet.delay(name="FlowQ")
    job = queue.dequeue()
    assert job.payload["kwargs"] == {"name": "FlowQ"}


def test_custom_priority(registry, queue, storage):
    @registry.task(name="prio_test", priority=Priority.HIGH)
    def high_prio():
        pass

    high_prio.delay()
    job = queue.dequeue()
    assert job.priority == Priority.HIGH


def test_send_task_by_name(registry, queue):
    @registry.task(name="named_send")
    def named():
        pass

    ar = registry.send_task("named_send")
    assert isinstance(ar, AsyncResult)


def test_send_task_unknown_raises(registry):
    with pytest.raises(KeyError):
        registry.send_task("no_such_task")


def test_signature_dict(registry):
    @registry.task(name="sig_test")
    def sig_task(x, y):
        pass

    sig = sig_task.signature(1, 2)
    assert sig["task"] == "sig_test"
    assert sig["args"] == [1, 2]


def test_all_tasks(registry):
    @registry.task(name="t1")
    def t1(): pass

    @registry.task(name="t2")
    def t2(): pass

    assert len(registry.all_tasks()) >= 2


def test_async_result_status(registry, queue, storage, worker):
    @registry.task(name="ar_status")
    def ar_task():
        pass

    ar = ar_task.delay()
    job = queue.dequeue()
    worker.run_job(job)
    assert ar.status() == "SUCCESS"
