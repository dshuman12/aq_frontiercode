"""Tests for flowq.context."""
import threading
import pytest
from flowq.context import (
    current_context, require_context, job_context, set_extra, get_extra,
    JobContext, ContextStack,
)
from flowq.models import Job


@pytest.fixture()
def job():
    return Job(name="ctx_test", payload={})


def test_current_context_none_outside():
    assert current_context() is None


def test_job_context_sets_context(job):
    with job_context(job, worker_id="w1"):
        ctx = current_context()
        assert ctx is not None
        assert ctx.job_id == job.id
        assert ctx.worker_id == "w1"


def test_job_context_clears_after_exit(job):
    with job_context(job):
        pass
    assert current_context() is None


def test_require_context_raises_outside():
    with pytest.raises(RuntimeError):
        require_context()


def test_require_context_returns_ctx(job):
    with job_context(job, worker_id="tester"):
        ctx = require_context()
        assert ctx.job_id == job.id


def test_set_extra(job):
    with job_context(job):
        set_extra("trace_id", "abc123")
        assert get_extra("trace_id") == "abc123"


def test_get_extra_default_outside():
    assert get_extra("missing", default="fallback") == "fallback"


def test_context_elapsed_increases(job):
    import time
    with job_context(job) as ctx:
        time.sleep(0.05)
        assert ctx.elapsed >= 0.04


def test_attempt_number(job):
    with job_context(job, attempt=3) as ctx:
        assert ctx.attempt == 3


def test_span_id_unique(job):
    spans = []
    for _ in range(5):
        j = Job(name="t", payload={})
        with job_context(j) as ctx:
            spans.append(ctx.span_id)
    assert len(set(spans)) == 5


def test_to_dict(job):
    with job_context(job, worker_id="w42") as ctx:
        d = ctx.to_dict()
        assert d["worker_id"] == "w42"
        assert "span_id" in d


def test_thread_isolation(job):
    results = {}
    def worker(wid):
        j = Job(name="t", payload={})
        with job_context(j, worker_id=wid):
            import time; time.sleep(0.02)
            results[wid] = current_context().worker_id

    threads = [threading.Thread(target=worker, args=(f"w{i}",)) for i in range(5)]
    for t in threads: t.start()
    for t in threads: t.join()
    for wid, ctx_wid in results.items():
        assert wid == ctx_wid


def test_context_stack_push_pop(job):
    stack = ContextStack()
    j1 = Job(name="a", payload={})
    j2 = Job(name="b", payload={})
    ctx1 = JobContext.from_job(j1, worker_id="w1")
    ctx2 = JobContext.from_job(j2, worker_id="w2")
    stack.push(ctx1)
    stack.push(ctx2)
    assert stack.depth() == 2
    stack.pop()
    assert stack.depth() == 1
    assert stack.current().worker_id == "w1"
