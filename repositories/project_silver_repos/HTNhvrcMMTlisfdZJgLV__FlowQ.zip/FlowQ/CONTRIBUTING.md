# Contributing

See [docs/contributing.md](docs/contributing.md) for the full contribution guide.

Quick start:

```bash
git clone https://github.com/aseembhalla/FlowQ.git
cd FlowQ
pip install -e .
pytest
```
