# Contributing to FlowQ

Thank you for your interest in contributing!  This document covers how to set
up a development environment, run tests, and submit changes.

---

## Development setup

```bash
git clone https://github.com/aseembhalla/FlowQ.git
cd FlowQ

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate

# Install in editable mode with dev dependencies
pip install -e ".[dev]"
```

---

## Running tests

```bash
# All tests
pytest

# With coverage
pytest --cov=flowq --cov-report=term-missing

# A specific module
pytest tests/test_queue.py -v

# Watch mode (requires pytest-watch)
ptw tests/
```

All 259 tests must pass before submitting a pull request.

---

## Code style

- **Formatter**: `black` (line length 88)
- **Import sorter**: `isort`
- **Type checking**: `mypy` (strict mode encouraged but not required)
- **Linter**: `flake8` or `ruff`

```bash
black flowq/ tests/
isort flowq/ tests/
mypy flowq/
```

---

## Project layout

```
FlowQ/
├── flowq/              # source package
│   ├── __init__.py
│   ├── models.py       # Job, JobStatus, Priority
│   ├── queue.py        # JobQueue (heap)
│   ├── storage.py      # SQLite persistence
│   ├── worker.py       # Worker, WorkerPool
│   ├── scheduler.py    # Cron scheduler
│   ├── cli.py          # Click CLI
│   ├── backends/       # BaseBackend + Memory/SQLite/File implementations
│   └── …               # 15+ additional modules
├── tests/              # pytest test suite
├── examples/           # runnable usage examples
├── docs/               # this documentation
├── Dockerfile
├── setup.py
├── requirements.txt
├── pytest.ini
├── CHANGELOG.md
└── README.md
```

---

## Adding a new feature

1. **Open an issue** describing the feature before writing code.
2. **Create a branch**: `git checkout -b feat/my-feature`
3. **Write tests first** (TDD encouraged).
4. **Implement** the feature in `flowq/`.
5. **Document** it — update `docs/api_reference.md` and add a guide if needed.
6. **Update `CHANGELOG.md`** under `[Unreleased]`.
7. **Submit a pull request**.

---

## Adding a new storage backend

1. Create `flowq/backends/my_backend.py`.
2. Subclass `BaseBackend` (`flowq.backends.base`).
3. Implement all abstract methods.
4. Add tests in `tests/test_backends.py` — parametrize against the existing
   `MemoryBackend` and `SQLiteBackend` to ensure contract compliance.
5. Document in `docs/backends.md`.

---

## Adding a new retry strategy

1. Add a class to `flowq/retry_strategies.py` subclassing `RetryStrategy`.
2. Implement `wait_time(attempt: int) -> float`.
3. Register it in `make_strategy()`.
4. Add test cases to `tests/test_retry_strategies.py`.
5. Document in `docs/retry_strategies.md`.

---

## Commit message convention

FlowQ uses [Conventional Commits](https://www.conventionalcommits.org/):

```
feat(module): short description
fix(module): short description
docs(module): short description
test(module): short description
chore: short description
```

---

## Releasing

1. Bump `__version__` in `flowq/__init__.py`.
2. Update `CHANGELOG.md` — move `[Unreleased]` entries under the new version.
3. Tag: `git tag v0.4.0 && git push --tags`.
4. Build: `python -m build`.
5. Publish: `twine upload dist/*`.

---

## Code of conduct

Be kind.  We follow the
[Contributor Covenant](https://www.contributor-covenant.org/) v2.1.
