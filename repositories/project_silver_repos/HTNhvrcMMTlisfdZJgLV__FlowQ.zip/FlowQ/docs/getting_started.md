# Getting Started with FlowQ

This guide walks you through installing FlowQ, enqueueing your first job, and
running a worker to process it.

---

## 1. Installation

```bash
pip install flowq
```

Or from source:

```bash
git clone https://github.com/aseembhalla/FlowQ.git
cd FlowQ
pip install -e .
```

### Requirements

- Python 3.10 or later
- No external services (SQLite, threading, and `http.server` are all stdlib)
- Optional: `click` (already listed in `requirements.txt`) for the CLI

---

## 2. Core concepts

| Concept | Description |
|---|---|
| **Job** | A unit of work — has a name, payload, priority, and status |
| **JobQueue** | In-memory heap; dequeues by priority then enqueue order |
| **Storage** | Persists job state to SQLite (or memory / file) |
| **Worker** | Pulls a job from the queue, calls the registered handler |
| **Handler** | A plain Python function decorated with `@register("name")` |

---

## 3. Hello, FlowQ

```python
# hello_flowq.py
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.worker  import Worker, register
from flowq.models  import Job, Priority

# 1. Register a handler
@register("greet")
def greet(job):
    name = job.payload.get("name", "world")
    print(f"Hello, {name}!")

# 2. Create infrastructure
storage = Storage("hello.db")   # SQLite; created on first use
queue   = JobQueue()

# 3. Enqueue a job
job = Job(name="greet", payload={"name": "FlowQ"}, priority=Priority.HIGH)
storage.save(job)
queue.enqueue(job)

# 4. Run a worker
worker = Worker(queue=queue, storage=storage)
dequeued = queue.dequeue()
if dequeued:
    worker.run_job(dequeued)
```

Run it:

```
$ python hello_flowq.py
Hello, FlowQ!
```

---

## 4. Priority levels

FlowQ ships with four built-in priority levels:

| Name | Value | Use case |
|---|---|---|
| `Priority.LOW` | 1 | Background housekeeping |
| `Priority.NORMAL` | 5 | Default for most jobs |
| `Priority.HIGH` | 10 | User-facing tasks |
| `Priority.CRITICAL` | 20 | Payments, alerts, SLO-sensitive work |

Higher-value jobs are always dequeued first. Within the same priority, jobs are
processed in FIFO order.

---

## 5. Job lifecycle

```
PENDING  ──► RUNNING  ──► SUCCESS
                 │
                 ▼
              FAILED   ──► RETRYING ──► RUNNING
                 │
                 ▼
           (dead letter queue)
```

- A job starts as `PENDING`.
- When a worker picks it up it becomes `RUNNING`.
- On success: `SUCCESS` (terminal).
- On exception: `FAILED`. If retries remain, it becomes `RETRYING`.
- Cancelled explicitly: `CANCELLED` (terminal).

---

## 6. Retries

```python
job = Job(
    name="flaky_api_call",
    payload={"url": "https://api.example.com/data"},
    max_retries=3,   # up to 3 re-attempts
)
```

Pair with a custom retry strategy for back-off:

```python
from flowq.retry_strategies import ExponentialBackoff
from flowq.worker import Worker

worker = Worker(
    queue=queue,
    storage=storage,
    retry_strategy=ExponentialBackoff(base=2, max_delay=60),
)
```

---

## 7. Scheduling with cron

```python
from flowq.scheduler import Scheduler, CronExpression

scheduler = Scheduler(queue=queue)

scheduler.add(
    name   = "daily_report",
    cron   = CronExpression("0 9 * * *"),   # 09:00 every day
    handler= "generate_report",
    payload= {"format": "pdf"},
)

scheduler.start()   # runs in a background thread
```

---

## 8. Worker pool

For higher throughput, run multiple workers in parallel:

```python
from flowq.worker import WorkerPool

pool = WorkerPool(size=8, storage=storage)
pool.start()

# Feed jobs…
for job in queue_snapshot:
    pool._queue.put(job)

pool.stop()
```

---

## 9. CLI quickstart

```bash
# Enqueue from the command line
flowq enqueue send_email --payload '{"to":"ops@company.com"}' -P HIGH

# Watch the queue
watch -n1 flowq list --status-filter PENDING

# Start a worker
flowq worker --concurrency 4

# Open the dashboard in your browser
flowq dashboard
```

---

## Next steps

- [Configuration](configuration.md) — env vars and `FlowQConfig`
- [Retry Strategies](retry_strategies.md) — all backoff algorithms
- [Workflows](workflows.md) — multi-step DAG pipelines
- [Cookbook](cookbook.md) — common patterns
