# Retry Strategies

FlowQ provides a family of pluggable retry strategies via `flowq.retry_strategies`.
A strategy controls how long a worker waits before re-attempting a failed job.

---

## Built-in strategies

### `ImmediateRetry`

No waiting between attempts. Useful for transient errors expected to clear instantly.

```python
from flowq.retry_strategies import ImmediateRetry
strategy = ImmediateRetry()
# attempt 1 → wait 0s → attempt 2 → wait 0s → …
```

---

### `ConstantDelay`

Fixed wait time between every retry.

```python
from flowq.retry_strategies import ConstantDelay
strategy = ConstantDelay(delay=5.0)   # always wait 5 seconds
```

---

### `LinearBackoff`

Wait time grows linearly with the attempt number: `delay × attempt`.

```python
from flowq.retry_strategies import LinearBackoff
strategy = LinearBackoff(delay=2.0, max_delay=30.0)
# attempt 1 → 2s, attempt 2 → 4s, attempt 3 → 6s, … capped at 30s
```

---

### `ExponentialBackoff`

Classic exponential back-off: `factor × base^(attempt-1)`, with optional jitter.

```python
from flowq.retry_strategies import ExponentialBackoff
strategy = ExponentialBackoff(
    base=2.0,
    factor=1.0,
    max_delay=300.0,
    jitter=True,     # multiply by uniform random in [0.5, 1.0]
)
# attempt 1 → ~1s, attempt 2 → ~2s, attempt 3 → ~4s, …
```

With `jitter=True` (the default) consecutive workers retrying at the same time
spread their load — sometimes called "decorrelated jitter" or "full jitter".

---

### `FibonacciBackoff`

Wait time follows the Fibonacci sequence (×unit seconds).

```python
from flowq.retry_strategies import FibonacciBackoff
strategy = FibonacciBackoff(unit=1.0, max_delay=120.0)
# attempt 1 → 1s, 2 → 1s, 3 → 2s, 4 → 3s, 5 → 5s, 6 → 8s, …
```

---

### `JitteredBackoff`

"Full jitter" strategy: uniform random in `[0, min(cap, base × 2^attempt)]`.
Minimises thundering herd at scale.

```python
from flowq.retry_strategies import JitteredBackoff
strategy = JitteredBackoff(cap=60.0, base=0.5)
```

---

### `CompositeRetry`

Chain multiple strategies: use strategy A for the first N attempts, then B, etc.

```python
from flowq.retry_strategies import CompositeRetry, ImmediateRetry, ConstantDelay, ExponentialBackoff

strategy = CompositeRetry([
    (3,    ImmediateRetry()),        # attempts 1–3: no wait (transient spike)
    (5,    ConstantDelay(2.0)),      # attempts 4–8: 2s each
    (None, ExponentialBackoff()),    # attempts 9+: exponential back-off
])
```

---

## Using with a Worker

Pass a strategy via the `retry_strategy=` kwarg:

```python
from flowq.worker import Worker
from flowq.retry_strategies import ExponentialBackoff

worker = Worker(
    queue=queue,
    storage=storage,
    retry_strategy=ExponentialBackoff(base=2, max_delay=60, jitter=True),
)
```

---

## Custom strategy

Subclass `RetryStrategy` and implement `wait_time(attempt: int) -> float`:

```python
from flowq.retry_strategies import RetryStrategy

class RandomUniformRetry(RetryStrategy):
    def __init__(self, lo: float, hi: float) -> None:
        self._lo, self._hi = lo, hi

    def wait_time(self, attempt: int) -> float:
        import random
        return random.uniform(self._lo, self._hi)

worker = Worker(queue=queue, storage=storage,
                retry_strategy=RandomUniformRetry(1.0, 10.0))
```

---

## Factory function

```python
from flowq.retry_strategies import make_strategy

s = make_strategy("exponential", base=2, max_delay=120)
s = make_strategy("constant", delay=5)
s = make_strategy("fibonacci", unit=2, max_delay=60)
```

Supported names: `immediate`, `constant`, `linear`, `exponential`, `fibonacci`, `jittered`.

---

## Decision guide

| Scenario | Recommended strategy |
|---|---|
| Fast in-process errors (lock contention) | `ImmediateRetry` |
| External API with known retry-after | `ConstantDelay` |
| Database connection drops | `ExponentialBackoff(jitter=True)` |
| Payment gateways (strict ordering matters) | `LinearBackoff` |
| Many workers hitting the same endpoint | `JitteredBackoff` |
| Multi-phase failure model | `CompositeRetry` |
