# Architecture

This document describes how FlowQ's components fit together, how data flows
through the system, and the design decisions behind each layer.

---

## Component map

```
┌─────────────────────────────────────────────────────────────────────┐
│  External code (your app)                                           │
│                                                                     │
│   Job(name, payload, priority)                                      │
│        │                                                            │
│        ▼                                                            │
│  ┌─────────────┐      ┌──────────────┐      ┌────────────────────┐ │
│  │  JobQueue   │◄─────│  Scheduler   │      │  WorkflowRunner    │ │
│  │  (heapq)    │      │  (cron tick) │      │  (DAG executor)    │ │
│  └──────┬──────┘      └──────────────┘      └────────┬───────────┘ │
│         │                                            │              │
│         ▼                                            ▼              │
│  ┌──────────────┐    ┌───────────────┐    ┌─────────────────────┐  │
│  │    Worker    │    │  WorkerPool   │    │   JobGroup (batch)  │  │
│  │  (single)    │    │  (N threads)  │    └─────────────────────┘  │
│  └──────┬───────┘    └───────┬───────┘                             │
│         │                   │                                       │
│         └─────────┬─────────┘                                       │
│                   ▼                                                  │
│           handler function                                           │
│                   │                                                  │
│          ┌────────┴────────┐                                         │
│          ▼                 ▼                                         │
│      Storage          PluginManager                                 │
│   (SQLite/Memory/     (hooks fired on                               │
│    File backend)       every state change)                          │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Layer descriptions

### Job model (`flowq.models`)

`Job` is a frozen-ish dataclass.  A `transition()` method enforces the legal
state machine via `_TRANSITIONS`:

```
PENDING  → RUNNING
RUNNING  → SUCCESS | FAILED | RETRYING
RETRYING → RUNNING
PENDING  → CANCELLED
RUNNING  → CANCELLED
```

Illegal transitions raise `InvalidStatusTransitionError` immediately.

### Queue (`flowq.queue`)

`JobQueue` wraps Python's `heapq` module.  Items pushed as
`(-priority.value, monotonic_timestamp, job)` so that:

- Higher numeric priorities dequeue first (negation trick).
- Ties break on insertion time (FIFO within a priority band).

All mutations are protected by a `threading.Lock`, making the queue safe for
multi-threaded producers and consumers.

### Storage (`flowq.storage`)

Default SQLite backend.  Uses **thread-local connections** so that each worker
thread has its own `sqlite3.Connection` while sharing the same database file.

The `BaseBackend` ABC (`flowq.backends.base`) lets you swap out storage:

```python
from flowq.backends.memory_backend import MemoryBackend
from flowq.backends.sqlite_backend import SQLiteBackend
from flowq.backends.file_backend   import FileBackend
```

### Worker (`flowq.worker`)

A `Worker` runs jobs synchronously in a dedicated thread (via
`threading.Thread` + `join(timeout=)`).  Timeout enforcement uses the thread's
join deadline — if the handler thread is still alive after the timeout, the job
is marked `FAILED`.

`WorkerPool` manages a `queue.Queue` of ready jobs fed to a fixed-size pool of
`Worker` threads.

### Scheduler (`flowq.scheduler`)

A background thread ticks every `scheduler_tick` seconds and checks each
`ScheduledJob`'s `CronExpression` against `datetime.now()`.  On a match it
creates a new `Job` and enqueues it.  The cron parser supports all five fields
(`minute hour day month weekday`) with wildcards, ranges, steps, and lists.

### Middleware (`flowq.middleware`)

`MiddlewareStack` wraps the handler call in a chain of callables:

```
request ──► mw_1 ──► mw_2 ──► … ──► handler
response ◄── mw_1 ◄── mw_2 ◄── …
```

Built-in factories: `timing()`, `tag_filter()`, `payload_validator()`.

### Events (`flowq.events`)

A lightweight pub/sub bus.  Subscribers register by event name; `emit()` calls
them synchronously.  `emit_async()` dispatches each handler in a daemon thread.

### Circuit Breaker (`flowq.circuit_breaker`)

Standard three-state machine:

- **CLOSED** — calls pass through, failures counted.
- **OPEN** — calls blocked immediately (`CircuitBreakerOpen` raised).
- **HALF_OPEN** — one probe allowed; success → CLOSED, failure → OPEN.

Transition from OPEN → HALF_OPEN happens after `recovery_timeout` seconds.

### Rate Limiter (`flowq.rate_limiter`)

Two algorithms:

- **Token Bucket** — capacity + refill rate; supports burst.
- **Sliding Window** — strict call count within a rolling time window.

Both are thread-safe and expose `try_acquire()` (non-blocking) and `acquire()`
(blocking with timeout).

### Dead Letter Queue (`flowq.deadletter`)

Jobs that exhaust their retry budget are moved here.  Each entry records the
original `Job`, the failure reason, and timestamps.  `replay()` resets the job
and re-enqueues it; `purge_replayed()` housekeeps the DLQ.

### Monitoring (`flowq.monitoring`)

Four metric primitives:

| Type | Description |
|---|---|
| `Counter` | Monotonically increasing integer |
| `Gauge` | Arbitrary float value (set / increment / decrement) |
| `Histogram` | Distribution of observed values; computes percentiles |
| `Timer` | Context manager that records duration as a histogram observation |

`MetricsRegistry.snapshot()` returns a JSON-serialisable dict for dashboards.

---

## Design principles

1. **No external dependencies for core operation.** The queue, storage, worker,
   and scheduler use only the Python standard library.  `click` is optional and
   only required for the CLI.

2. **Thread-safety everywhere.** Every shared data structure uses a `Lock` or
   `threading.local`.  You can run multiple workers against the same `Storage`
   instance safely.

3. **Fail fast, fail loudly.** Invalid state transitions raise immediately.
   Missing handlers cause jobs to be marked `FAILED` with a clear message, not
   silently dropped.

4. **Composable.** Every subsystem (retry strategy, middleware, backend,
   serializer, plugin) is a replaceable interface.  Swap out any layer without
   touching the rest.

5. **Test-friendly.** All I/O is injected (storage path, db, queue).  The
   `MemoryBackend` and `tmp_path` fixture make tests hermetic and fast.
