# Deployment

This guide covers running FlowQ in production — from a single-process setup to
a multi-container deployment.

---

## Single-process (simplest)

For low-throughput use cases (< 100 jobs/minute), run the worker in the same
process as your web app.

```python
# app.py
import threading
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.worker  import WorkerPool

storage = Storage("/data/jobs.db")
queue   = JobQueue()
pool    = WorkerPool(size=4, storage=storage)
pool.start()
```

---

## Separate worker process

For production, run workers in a separate process so they can be scaled
independently.

```
# Start the web app
gunicorn myapp.wsgi:application

# Start workers (separate terminal / systemd unit / Docker container)
FLOWQ_DB_PATH=/data/jobs.db flowq worker --concurrency 8
```

Both processes share the same SQLite file.  SQLite handles concurrent writers
via WAL mode.

---

## Docker

### Dockerfile (already included in repo)

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir --no-install-recommends -r requirements.txt
COPY . .
RUN pip install --no-cache-dir --no-install-recommends -e .
CMD ["flowq", "worker", "--concurrency", "4"]
```

### docker-compose.yml

```yaml
version: "3.9"
services:
  app:
    build: .
    command: python -m myapp.server
    volumes:
      - flowq_data:/data
    environment:
      - FLOWQ_DB_PATH=/data/jobs.db

  worker:
    build: .
    command: flowq worker --concurrency 8
    volumes:
      - flowq_data:/data
    environment:
      - FLOWQ_DB_PATH=/data/jobs.db
    depends_on:
      - app

  dashboard:
    build: .
    command: flowq dashboard --host 0.0.0.0 --port 8765
    ports:
      - "8765:8765"
    volumes:
      - flowq_data:/data
    environment:
      - FLOWQ_DB_PATH=/data/jobs.db

volumes:
  flowq_data:
```

---

## Systemd service

```ini
# /etc/systemd/system/flowq-worker.service
[Unit]
Description=FlowQ Worker
After=network.target

[Service]
Type=simple
User=appuser
WorkingDirectory=/opt/myapp
Environment="FLOWQ_DB_PATH=/data/jobs.db"
Environment="FLOWQ_LOG_LEVEL=INFO"
ExecStart=/opt/myapp/.venv/bin/flowq worker --concurrency 8
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
systemctl enable --now flowq-worker
journalctl -u flowq-worker -f
```

---

## Scaling considerations

### SQLite limits

SQLite is surprisingly capable:

- Handles ~10,000–50,000 job enqueues/sec on an SSD.
- Up to ~100 concurrent readers.
- Write throughput limited to ~3,000 commits/sec (WAL mode).

For higher throughput, consider sharding across multiple database files (one per
job type or tenant).

### Worker sizing

Rule of thumb: `concurrency = 2 × CPU count` for I/O-bound handlers (HTTP
calls, database queries).  For CPU-bound work, `concurrency = CPU count`.

### Monitoring in production

```bash
# Job stats
watch -n5 flowq stats

# Recent failures
flowq list --status-filter FAILED --limit 20

# Tail logs (if JSON logging is on)
journalctl -u flowq-worker -f | jq '.'
```

---

## Health check endpoint

Add the FlowQ health endpoint to your load balancer / Kubernetes liveness probe:

```bash
curl http://localhost:8765/api/status
```

Or register a custom health check and poll `/health`:

```python
from flowq.health import health_registry

@health_registry.check("queue_depth")
def queue_depth_check():
    depth = storage.count_by_status().get("PENDING", 0)
    if depth > 10_000:
        raise RuntimeError(f"Queue backed up: {depth} pending jobs")
    return {"pending": depth}
```

---

## Security notes

- The HTTP dashboard binds to `127.0.0.1` by default.  Use a reverse proxy
  (nginx / Caddy) with authentication if you expose it externally.
- SQLite files should have `0640` permissions owned by the app user.
- The `FLOWQ_DB_PATH` env var should point to a volume outside the container
  image so jobs survive container restarts.
