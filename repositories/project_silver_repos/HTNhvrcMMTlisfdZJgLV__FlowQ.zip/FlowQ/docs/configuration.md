# Configuration Reference

FlowQ reads its runtime configuration from environment variables, with sensible
defaults for every option. No config file is required.

---

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `FLOWQ_DB_PATH` | `flowq.db` | Path to the SQLite database file |
| `FLOWQ_LOG_LEVEL` | `WARNING` | Logging verbosity (`DEBUG`/`INFO`/`WARNING`/`ERROR`) |
| `FLOWQ_MAX_QUEUE_SIZE` | `0` (unlimited) | Max jobs held in memory queue (0 = no limit) |
| `FLOWQ_DEFAULT_TIMEOUT` | `300` | Default job timeout in seconds |
| `FLOWQ_DEFAULT_MAX_RETRIES` | `3` | Default retry budget per job |
| `FLOWQ_WORKER_CONCURRENCY` | `1` | Default worker pool size |
| `FLOWQ_POLL_INTERVAL` | `1.0` | Seconds between queue polls |
| `FLOWQ_SCHEDULER_TICK` | `60` | Scheduler tick interval in seconds |
| `FLOWQ_DASHBOARD_HOST` | `127.0.0.1` | Dashboard bind address |
| `FLOWQ_DASHBOARD_PORT` | `8765` | Dashboard HTTP port |

---

## Programmatic configuration

Use `FlowQConfig` for type-safe, IDE-friendly config:

```python
from flowq.config import FlowQConfig, default_config

# Read the singleton (populated from env vars at import time)
cfg = default_config()
print(cfg.db_path)          # "flowq.db"
print(cfg.max_retries)      # 3
print(cfg.worker_concurrency)  # 1

# Override programmatically (useful in tests)
from flowq.config import FlowQConfig
cfg = FlowQConfig(
    db_path="test.db",
    log_level="DEBUG",
    default_timeout=30,
    max_retries=0,
)
```

### `FlowQConfig` fields

```python
@dataclass
class FlowQConfig:
    db_path:             str   = "flowq.db"
    log_level:           str   = "WARNING"
    max_queue_size:      int   = 0
    default_timeout:     int   = 300
    default_max_retries: int   = 3
    worker_concurrency:  int   = 1
    poll_interval:       float = 1.0
    scheduler_tick:      int   = 60
    dashboard_host:      str   = "127.0.0.1"
    dashboard_port:      int   = 8765
```

---

## Logging configuration

```python
from flowq.logging_config import configure_logging

# Human-readable output to stderr
configure_logging(level="DEBUG")

# Structured JSON (ideal for log aggregators)
configure_logging(level="INFO", json=True)

# Write to a rotating file as well
configure_logging(
    level="WARNING",
    json=True,
    log_file="/var/log/flowq/app.log",
    max_bytes=50 * 1024 * 1024,   # 50 MB per file
    backup_count=5,
)
```

---

## `.env` file

FlowQ doesn't auto-load `.env` files, but you can use
[`python-dotenv`](https://pypi.org/project/python-dotenv/) before importing FlowQ:

```python
from dotenv import load_dotenv
load_dotenv()   # reads .env into os.environ

from flowq.config import default_config
cfg = default_config()
```

Or set variables in your shell:

```bash
export FLOWQ_DB_PATH=/data/jobs.db
export FLOWQ_LOG_LEVEL=INFO
export FLOWQ_WORKER_CONCURRENCY=8
flowq worker
```

---

## Configuration in tests

```python
import os, pytest

@pytest.fixture(autouse=True)
def flowq_test_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FLOWQ_DB_PATH", str(tmp_path / "test.db"))
    monkeypatch.setenv("FLOWQ_LOG_LEVEL", "ERROR")
```
