# Storage Backends

FlowQ separates job persistence behind a `BaseBackend` interface, letting you
choose (or swap) the storage engine without changing any other code.

---

## Available backends

| Class | Module | Use case |
|---|---|---|
| `Storage` | `flowq.storage` | Default SQLite — production-ready |
| `SQLiteBackend` | `flowq.backends.sqlite_backend` | `BaseBackend`-compatible SQLite adapter |
| `MemoryBackend` | `flowq.backends.memory_backend` | Tests, ephemeral workloads |
| `FileBackend` | `flowq.backends.file_backend` | Single-node, no SQLite required |

---

## `Storage` (default)

The built-in `Storage` class uses SQLite with thread-local connections.  It is
safe to share one `Storage` instance across multiple worker threads.

```python
from flowq.storage import Storage

storage = Storage("jobs.db")        # file path (created if absent)
storage = Storage(":memory:")       # in-process ephemeral (testing)
```

### Schema

One table: `jobs`

| Column | Type | Description |
|---|---|---|
| `id` | TEXT PRIMARY KEY | UUID |
| `name` | TEXT | Handler name |
| `status` | TEXT | `JobStatus` value |
| `priority` | INTEGER | Priority numeric value |
| `payload` | TEXT | JSON |
| `created_at` | TEXT | ISO-8601 |
| `started_at` | TEXT | nullable |
| `finished_at` | TEXT | nullable |
| `result` | TEXT | JSON, nullable |
| `error` | TEXT | nullable |
| `retry_count` | INTEGER | |
| `max_retries` | INTEGER | |
| `timeout` | INTEGER | seconds |
| `tags` | TEXT | JSON array |

---

## `MemoryBackend`

Stores jobs in a plain dict.  Zero I/O, ideal for unit tests.

```python
from flowq.backends.memory_backend import MemoryBackend

backend = MemoryBackend()
backend.save(job)
fetched = backend.fetch(job.id)
```

**Caveat:** Data is lost when the process exits.  Not safe for multi-process
deployments.

---

## `FileBackend`

Each job is a separate `.json` file on disk.  Atomic writes via a `.tmp`
rename.  Thread-safe via an instance lock.

```python
from flowq.backends.file_backend import FileBackend

backend = FileBackend(root_dir="/var/lib/flowq/jobs")
```

The directory is created if it does not exist.

**When to use**

- You cannot install SQLite (rare containerised environments).
- You want human-readable job files that can be inspected with a text editor.
- Job volume is low (< 10,000 jobs); `list_jobs` does a full directory scan.

**When NOT to use**

- High-throughput producers; file-system metadata ops become a bottleneck.
- Multi-process concurrent writes.

---

## `SQLiteBackend`

A thin `BaseBackend`-compatible adapter that wraps `flowq.Storage`.  Use this
when you want the `BaseBackend` interface but still want SQLite persistence.

```python
from flowq.backends.sqlite_backend import SQLiteBackend

backend = SQLiteBackend("jobs.db")
```

---

## `BaseBackend` interface

All backends implement this ABC:

```python
class BaseBackend(ABC):
    @abstractmethod
    def save(self, job: Job) -> None: ...

    @abstractmethod
    def fetch(self, job_id: str) -> Job: ...

    @abstractmethod
    def update(self, job: Job) -> None: ...

    @abstractmethod
    def delete(self, job_id: str) -> None: ...

    @abstractmethod
    def list_jobs(
        self,
        status: Optional[JobStatus] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Job]: ...

    @abstractmethod
    def search_by_tag(self, tag: str) -> list[Job]: ...

    @abstractmethod
    def count_by_status(self) -> dict[str, int]: ...

    @abstractmethod
    def health_check(self) -> dict: ...

    @abstractmethod
    def close(self) -> None: ...
```

---

## Writing a custom backend

```python
from flowq.backends.base import BaseBackend
from flowq.models import Job, JobStatus
from flowq.exceptions import JobNotFoundError, DuplicateJobError

class RedisBackend(BaseBackend):
    def __init__(self, client) -> None:
        self._r = client

    def save(self, job: Job) -> None:
        if self._r.exists(f"job:{job.id}"):
            raise DuplicateJobError(job.id)
        self._r.set(f"job:{job.id}", json.dumps(job.to_dict()))

    def fetch(self, job_id: str) -> Job:
        data = self._r.get(f"job:{job_id}")
        if data is None:
            raise JobNotFoundError(job_id)
        return Job.from_dict(json.loads(data))

    # … implement remaining abstract methods
```

---

## Parametrized tests

A useful pattern is to parametrize tests against both `MemoryBackend` and your
real backend to verify they behave identically:

```python
import pytest
from flowq.backends.memory_backend import MemoryBackend
from flowq.backends.sqlite_backend import SQLiteBackend

@pytest.fixture(params=["memory", "sqlite"])
def backend(request, tmp_path):
    if request.param == "memory":
        return MemoryBackend()
    return SQLiteBackend(str(tmp_path / "t.db"))

def test_save_fetch(backend):
    job = Job(name="x", payload={})
    backend.save(job)
    assert backend.fetch(job.id).name == "x"
```
