# CLI Reference

FlowQ ships a `flowq` command-line tool built with [Click](https://click.palletsprojects.com/).

```
flowq [OPTIONS] COMMAND [ARGS]...
```

---

## Global options

| Option | Description |
|---|---|
| `--version` | Print FlowQ version and exit |
| `--help` | Show help message |

All commands respect the `FLOWQ_DB_PATH` environment variable (default: `flowq.db`).

---

## Commands

### `enqueue`

Enqueue a single job.

```
flowq enqueue HANDLER [OPTIONS]
```

**Arguments**

| Argument | Description |
|---|---|
| `HANDLER` | Registered handler name (required) |

**Options**

| Option | Default | Description |
|---|---|---|
| `--payload`, `-p` | `{}` | JSON string passed as `job.payload` |
| `--priority`, `-P` | `NORMAL` | `LOW` / `NORMAL` / `HIGH` / `CRITICAL` |
| `--retries`, `-r` | `0` | Maximum retry attempts |
| `--timeout`, `-t` | _(default)_ | Timeout in seconds |
| `--tag`, `-T` | _(none)_ | Tag string (repeatable) |

**Examples**

```bash
# Basic
flowq enqueue send_email --payload '{"to":"ops@company.com"}'

# High-priority with retries and a tag
flowq enqueue charge_card   --payload '{"amount": 99.99, "currency": "USD"}'   --priority HIGH   --retries 3   --tag billing   --tag critical
```

---

### `status`

Show full details of a specific job.

```
flowq status JOB_ID
```

Outputs a JSON object with all job fields:

```json
{
  "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "name": "send_email",
  "status": "SUCCESS",
  "priority": 5,
  "payload": {"to": "ops@company.com"},
  "created_at": "2026-04-01T09:00:00",
  "started_at": "2026-04-01T09:00:01",
  "finished_at": "2026-04-01T09:00:02",
  "retry_count": 0,
  "tags": []
}
```

---

### `list`

List jobs in storage.

```
flowq list [OPTIONS]
```

**Options**

| Option | Default | Description |
|---|---|---|
| `--status-filter`, `-s` | _(all)_ | Filter by status |
| `--limit`, `-n` | `20` | Maximum rows to show |
| `--json-output`, `-j` | false | Output as JSON array |

**Examples**

```bash
flowq list
flowq list --status-filter FAILED --limit 50
flowq list --json-output | jq '.[].name'
```

---

### `stats`

Show job counts grouped by status.

```
flowq stats [--json-output]
```

```
PENDING       12
RUNNING        3
SUCCESS     4821
FAILED        17
CANCELLED      2
```

---

### `cancel`

Cancel a pending job.

```
flowq cancel JOB_ID
```

The job must be in `PENDING` status; already-running jobs cannot be cancelled
through the CLI.

---

### `retry`

Re-queue a failed job.

```
flowq retry JOB_ID
```

Resets the job to `PENDING` with `retry_count=0` and re-enqueues it.

---

### `purge`

Delete all jobs with a given status.

```
flowq purge --status-filter STATUS [--yes]
```

**Options**

| Option | Description |
|---|---|
| `--status-filter`, `-s` | Status to purge (required) |
| `--yes` | Skip confirmation prompt |

**Examples**

```bash
# Interactive confirmation
flowq purge --status-filter SUCCESS

# Non-interactive (CI / scripts)
flowq purge --status-filter FAILED --yes
```

---

### `worker`

Start a worker process.

```
flowq worker [OPTIONS]
```

**Options**

| Option | Default | Description |
|---|---|---|
| `--concurrency`, `-c` | `1` | Thread pool size |
| `--poll-interval` | `1.0` | Seconds between queue polls |

```bash
flowq worker --concurrency 8 --poll-interval 0.5
```

Workers load all `PENDING` jobs from storage into the in-memory queue on
startup, then poll for new jobs every `poll-interval` seconds.

---

### `handlers`

List all registered handler functions.

```
flowq handlers
```

```
charge_card            myapp.billing.charge_card
generate_report        myapp.reports.generate_report
send_email             myapp.notifications.send_email
```

---

### `dashboard`

Start the HTTP monitoring dashboard.

```
flowq dashboard [--host HOST] [--port PORT]
```

Opens a minimal web UI at `http://HOST:PORT/` that refreshes every 10 seconds.
The JSON API is available at `/api/status`.

```bash
flowq dashboard --port 9000
# → Dashboard running at http://127.0.0.1:9000/
```
