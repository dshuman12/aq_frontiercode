# Cookbook

Common patterns and recipes for FlowQ.

---

## 1. Retry on specific exceptions only

```python
from flowq.worker import register
from flowq.models import Job

class RateLimitedError(Exception):
    pass

@register("call_api")
def call_api(job: Job):
    resp = requests.get(job.payload["url"])
    if resp.status_code == 429:
        raise RateLimitedError("Rate limited")
    resp.raise_for_status()
    return resp.json()
```

Configure the circuit breaker to only count `RateLimitedError`:

```python
from flowq.circuit_breaker import CircuitBreaker

cb = CircuitBreaker(
    "external_api",
    failure_threshold=10,
    expected_exception=RateLimitedError,
)

@register("call_api_protected")
def call_api_protected(job: Job):
    cb.call(call_api, job)
```

---

## 2. Fan-out pattern

Enqueue many small jobs from one parent job:

```python
@register("process_batch")
def process_batch(job: Job):
    items = job.payload["items"]
    for item in items:
        child = Job(name="process_item", payload={"item": item},
                    tags=["batch:" + job.id])
        storage.save(child)
        queue.enqueue(child)
```

Monitor all children:

```python
children = storage.search_by_tag("batch:" + parent_job.id)
done = all(j.status in (JobStatus.SUCCESS, JobStatus.FAILED) for j in children)
```

---

## 3. Job deduplication

Prevent enqueueing the same logical job twice:

```python
import hashlib, json

def enqueue_once(name: str, payload: dict):
    key = hashlib.sha256(json.dumps({name: payload}, sort_keys=True).encode()).hexdigest()
    existing = storage.search_by_tag(f"dedup:{key}")
    active = [j for j in existing if j.status in (JobStatus.PENDING, JobStatus.RUNNING)]
    if active:
        return active[0]   # already queued

    job = Job(name=name, payload=payload, tags=[f"dedup:{key}"])
    storage.save(job)
    queue.enqueue(job)
    return job
```

---

## 4. Chaining jobs

Run job B only after job A completes:

```python
@register("step_a")
def step_a(job: Job):
    result = do_step_a()
    # Enqueue step_b with step_a's result
    b = Job(name="step_b", payload={"data": result},
            tags=[f"chain:{job.id}"])
    storage.save(b)
    queue.enqueue(b)
```

Or use the Workflow engine for multi-step pipelines (see [Workflows](workflows.md)).

---

## 5. Scheduled cleanup job

```python
from flowq.scheduler import Scheduler, CronExpression

scheduler = Scheduler(queue=queue)

@register("purge_old_jobs")
def purge_old_jobs(job: Job):
    old = storage.list_jobs(status=JobStatus.SUCCESS, limit=10000)
    cutoff = time.time() - 7 * 24 * 3600   # 7 days
    for j in old:
        if j.finished_at and j.finished_at.timestamp() < cutoff:
            storage.delete(j.id)

scheduler.add("weekly_cleanup", CronExpression("0 3 * * 0"), "purge_old_jobs")
scheduler.start()
```

---

## 6. Progress tracking via payload

```python
@register("long_import")
def long_import(job: Job):
    rows = load_csv(job.payload["file"])
    total = len(rows)
    for i, row in enumerate(rows):
        process(row)
        # Update progress in place
        job.result = {"processed": i + 1, "total": total}
        storage.update(job)
```

Poll from another thread:

```python
import time
while True:
    j = storage.fetch(job_id)
    if j.result:
        pct = j.result["processed"] / j.result["total"] * 100
        print(f"Progress: {pct:.0f}%")
    if j.is_terminal:
        break
    time.sleep(1)
```

---

## 7. Rate-limit a handler globally

```python
from flowq.rate_limiter import rate_limiters, TokenBucketLimiter

rate_limiters.register("stripe", TokenBucketLimiter(capacity=100, rate=10.0))

@register("charge_card")
def charge_card(job: Job):
    rate_limiters.acquire("stripe")   # blocks until token available
    stripe.charge(job.payload["amount"])
```

---

## 8. Using the dead letter queue

```python
from flowq.deadletter import dlq
from flowq.worker import register

@register("unreliable")
def unreliable(job: Job):
    raise RuntimeError("always fails")

# After retries exhausted, the worker puts the job in the DLQ.
# Inspect it:
entries = dlq.not_replayed()
for entry in entries:
    print(entry.job.id, entry.added_at, entry.reason)

# Replay one:
dlq.replay(entries[0].job.id, queue)

# Or replay all:
dlq.replay_all(queue)
```

---

## 9. Testing with an in-memory backend

```python
import pytest
from flowq.backends.memory_backend import MemoryBackend
from flowq.queue   import JobQueue
from flowq.worker  import Worker

@pytest.fixture()
def env():
    backend = MemoryBackend()
    queue   = JobQueue()
    worker  = Worker(queue=queue, storage=None)  # pass backend via adapter if needed
    return backend, queue, worker
```

---

## 10. Emit custom events

```python
from flowq.events import events

# Publisher (inside a handler)
@register("order_placed")
def handle_order(job: Job):
    process_order(job.payload)
    events.emit("order.fulfilled", order_id=job.payload["order_id"])

# Subscriber (registered at startup)
@events.on("order.fulfilled")
def on_fulfillment(order_id: str):
    send_confirmation_email(order_id)
    update_inventory(order_id)
```
