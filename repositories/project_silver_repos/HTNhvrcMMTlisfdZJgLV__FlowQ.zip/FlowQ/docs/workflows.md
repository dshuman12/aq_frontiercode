# Workflows

FlowQ's workflow engine lets you compose jobs into directed acyclic graphs (DAGs).
Each step runs only after all its declared dependencies have completed successfully.

---

## Concepts

| Term | Description |
|---|---|
| **Workflow** | Named DAG of WorkflowStep objects |
| **WorkflowStep** | A single job within the DAG, with optional `depends_on` |
| **WorkflowRunner** | Executes the DAG respecting dependency order |
| **WorkflowResult** | Final status, per-step results, duration |

---

## Quick example

```python
from flowq.workflows import Workflow, WorkflowRunner
from flowq.worker    import Worker, register
from flowq.storage   import Storage
from flowq.queue     import JobQueue

@register("extract_data")
def extract_data(job):
    print("extracting…")

@register("transform_data")
def transform_data(job):
    print("transforming…")

@register("load_data")
def load_data(job):
    print("loading…")

storage = Storage("etl.db")
worker  = Worker(queue=JobQueue(), storage=storage)
runner  = WorkflowRunner(worker, storage)

wf = Workflow("nightly_etl")
e  = wf.add_step("extract",   handler="extract_data",   payload={"source": "s3"})
t  = wf.add_step("transform", handler="transform_data", depends_on=[e])
wf.add_step(      "load",     handler="load_data",      depends_on=[t])

result = runner.run(wf)
print(result.status)     # WorkflowStatus.SUCCESS
print(result.duration)   # seconds
```

---

## Declaring dependencies

`add_step` returns the step's name, which you pass to `depends_on` of downstream steps:

```python
wf = Workflow("fanout")
fetch  = wf.add_step("fetch",   handler="fetch_raw")
enrich = wf.add_step("enrich",  handler="enrich_data",   depends_on=[fetch])
index  = wf.add_step("index",   handler="build_index",   depends_on=[fetch])
notify = wf.add_step("notify",  handler="send_summary",  depends_on=[enrich, index])
```

```
fetch ──► enrich ──┐
      └──► index  ──► notify
```

---

## Validation

`Workflow.validate()` checks for:

- References to undefined step names
- Cyclic dependencies (raises `CyclicDependencyError`)

```python
from flowq.workflows import CyclicDependencyError

try:
    wf.validate()
except CyclicDependencyError as e:
    print(f"Graph has a cycle: {e}")
```

`WorkflowRunner.run()` calls `validate()` automatically before execution.

---

## Topological order

```python
order = wf.topological_order()
# → ["fetch", "enrich", "index", "notify"]  (dependencies always before dependants)
```

---

## Step options

```python
wf.add_step(
    name        = "critical_step",
    handler     = "process",
    payload     = {"mode": "strict"},
    priority    = Priority.HIGH,
    max_retries = 2,
    timeout     = 30.0,
)
```

---

## Failure handling

If any step fails, `WorkflowRunner` stops immediately and returns a
`WorkflowResult` with `status=WorkflowStatus.FAILED` and `error` set to the
name of the failing step.

```python
result = runner.run(wf)
if result.status == WorkflowStatus.FAILED:
    print(f"Workflow failed at: {result.error}")
    print("Step statuses:", result.step_results)
```

---

## `WorkflowResult`

| Attribute | Type | Description |
|---|---|---|
| `workflow_id` | `str` | UUID of the workflow run |
| `workflow_name` | `str` | Name given to `Workflow(name)` |
| `status` | `WorkflowStatus` | `PENDING/RUNNING/SUCCESS/FAILED/CANCELLED` |
| `step_results` | `dict[str, JobStatus]` | Per-step final status |
| `error` | `Optional[str]` | Name of the failing step, if any |
| `started_at` | `float` | Unix timestamp |
| `finished_at` | `Optional[float]` | Unix timestamp |
| `duration` | `Optional[float]` | Seconds from start to finish |

---

## Limitations

The current `WorkflowRunner` is synchronous — steps are executed one at a time
in dependency order.  Steps that have no dependency on each other (e.g.
`enrich` and `index` above) are still executed sequentially.

For parallel fan-out, run independent steps concurrently using a `WorkerPool`
and poll their completion status before proceeding to the merge step.
