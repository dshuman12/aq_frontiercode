# Plugin System

FlowQ's plugin system lets you hook into every stage of a job's lifecycle
without modifying the core worker code.

---

## Lifecycle hooks

| Hook | Signature | Fired when |
|---|---|---|
| `on_startup` | `(config)` | FlowQ initialises |
| `on_shutdown` | `()` | Graceful shutdown |
| `on_job_enqueue` | `(job)` | Job added to queue |
| `on_job_start` | `(job)` | Worker picks up job |
| `on_job_success` | `(job)` | Job finishes successfully |
| `on_job_failure` | `(job, exc)` | Job raises an exception |
| `on_job_retry` | `(job, attempt, exc)` | Job will be retried |
| `on_job_cancel` | `(job)` | Job is cancelled |

---

## Creating a plugin

A plugin is any object that defines one or more hook methods.  It does **not**
need to inherit from any base class (duck-typed).

```python
class AuditPlugin:
    name = "audit"          # used by unregister() and logs

    def on_job_enqueue(self, job):
        audit_log.write(f"ENQUEUE {job.id} {job.name}")

    def on_job_success(self, job):
        audit_log.write(f"SUCCESS {job.id} took {job.duration:.2f}s")

    def on_job_failure(self, job, exc):
        audit_log.write(f"FAILURE {job.id} {exc!r}")
```

---

## Registering plugins

```python
from flowq.plugins import plugin_manager

plugin_manager.register(AuditPlugin())
```

Plugins are called in registration order.  Exceptions inside a plugin are
caught and logged at `WARNING` level — they never propagate to the worker.

---

## Built-in plugins

FlowQ pre-registers two plugins:

| Plugin | Name | Description |
|---|---|---|
| `LoggingPlugin` | `flowq.logging` | Logs every hook at `DEBUG` level |
| `MetricsPlugin` | `flowq.metrics` | Increments counters in `flowq.monitoring` |

You can remove them if you don't want them:

```python
plugin_manager.unregister("flowq.logging")
plugin_manager.unregister("flowq.metrics")
```

---

## Unregistering plugins

```python
plugin_manager.unregister("audit")   # removes all plugins named "audit"
plugin_manager.clear()               # removes ALL plugins
```

---

## Inspecting registered plugins

```python
print(plugin_manager.names())   # ['flowq.logging', 'flowq.metrics', 'audit']
print(len(plugin_manager))      # 3
```

---

## Example: Slack notifications

```python
import requests

class SlackPlugin:
    name = "slack"

    def __init__(self, webhook_url: str) -> None:
        self._url = webhook_url

    def _post(self, text: str) -> None:
        try:
            requests.post(self._url, json={"text": text}, timeout=5)
        except Exception:
            pass   # never crash the worker

    def on_job_failure(self, job, exc):
        self._post(f":red_circle: `{job.name}` failed: {exc}")

    def on_job_success(self, job):
        if job.priority.value >= 10:   # HIGH or CRITICAL only
            self._post(f":white_check_mark: `{job.name}` succeeded in {job.duration:.1f}s")

plugin_manager.register(SlackPlugin("https://hooks.slack.com/..."))
```

---

## Example: OpenTelemetry tracing

```python
from opentelemetry import trace

tracer = trace.get_tracer("flowq")

class TracingPlugin:
    name = "otel"
    _spans: dict = {}

    def on_job_start(self, job):
        span = tracer.start_span(job.name)
        span.set_attribute("job.id", job.id)
        self._spans[job.id] = span

    def on_job_success(self, job):
        span = self._spans.pop(job.id, None)
        if span:
            span.end()

    def on_job_failure(self, job, exc):
        span = self._spans.pop(job.id, None)
        if span:
            span.record_exception(exc)
            span.end()

plugin_manager.register(TracingPlugin())
```

---

## Thread safety

`PluginManager` holds a `threading.Lock` around the plugin list.  Hooks are
dispatched without the lock held, so plugins may themselves enqueue jobs or
call back into FlowQ without deadlocking.
