# FlowQ Documentation

Welcome to the FlowQ documentation.

---

## Contents

| Document | Description |
|---|---|
| [Getting Started](getting_started.md) | Install, hello world, first job |
| [Configuration](configuration.md) | Env vars, FlowQConfig, logging |
| [Architecture](architecture.md) | System design and component map |
| [CLI Reference](cli_reference.md) | All CLI commands with options |
| [API Reference](api_reference.md) | Every public class and function |
| [Retry Strategies](retry_strategies.md) | Backoff algorithms and selection guide |
| [Workflows](workflows.md) | DAG pipelines and dependency resolution |
| [Plugins](plugins.md) | Lifecycle hooks and custom integrations |
| [Storage Backends](backends.md) | SQLite, Memory, File, custom backends |
| [Monitoring](monitoring.md) | Metrics, health checks, dashboard |
| [Deployment](deployment.md) | Docker, systemd, scaling |
| [Cookbook](cookbook.md) | 10 common patterns and recipes |
| [Contributing](contributing.md) | Development setup and guidelines |

---

## Quick links

- [GitHub](https://github.com/aseembhalla/FlowQ)
- [Changelog](../CHANGELOG.md)
- [License](../LICENSE)
- [Security Policy](../SECURITY.md)
