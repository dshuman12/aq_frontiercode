# API Reference

This page documents every public class and function in FlowQ, organised by module.

---

## `flowq.models`

### `JobStatus`

```python
class JobStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    SUCCESS   = "success"
    FAILED    = "failed"
    RETRYING  = "retrying"
    CANCELLED = "cancelled"
```

### `Priority`

```python
class Priority(int, Enum):
    LOW      = 1
    NORMAL   = 5
    HIGH     = 10
    CRITICAL = 20
```

### `Job`

```python
@dataclass
class Job:
    name:        str
    payload:     dict              = field(default_factory=dict)
    priority:    Priority          = Priority.NORMAL
    max_retries: int               = 3
    timeout:     int               = 300
    tags:        list[str]         = field(default_factory=list)
    id:          str               = field(default_factory=lambda: str(uuid4()))
    status:      JobStatus         = JobStatus.PENDING
    retry_count: int               = 0
    created_at:  datetime          = field(default_factory=datetime.utcnow)
    started_at:  Optional[datetime]  = None
    finished_at: Optional[datetime]  = None
    result:      Any               = None
    error:       Optional[str]     = None
```

**Methods**

| Method | Description |
|---|---|
| `transition(new_status)` | Validate and apply status transition |
| `mark_running()` | Shorthand: `PENDING/RETRYING → RUNNING` |
| `mark_success(result=None)` | Shorthand: `RUNNING → SUCCESS` |
| `mark_failed(error=None)` | Shorthand: `RUNNING → FAILED` |
| `mark_retrying()` | Shorthand: decrement retries, `RUNNING → RETRYING` |
| `mark_cancelled()` | Shorthand: `PENDING/RUNNING → CANCELLED` |
| `to_dict()` | Serialise to JSON-compatible dict |
| `Job.from_dict(d)` | Deserialise from dict |

**Properties**

| Property | Type | Description |
|---|---|---|
| `retries_remaining` | `int` | `max_retries - retry_count` |
| `is_terminal` | `bool` | True if SUCCESS, FAILED, or CANCELLED |
| `duration` | `Optional[float]` | Seconds from started_at to finished_at |

---

## `flowq.queue`

### `JobQueue`

```python
class JobQueue:
    def __init__(self, maxsize: int = 0) -> None: ...
```

| Method | Description |
|---|---|
| `enqueue(job)` | Add job to priority queue |
| `dequeue()` | Remove and return highest-priority job, or `None` |
| `peek()` | Return highest-priority job without removing |
| `cancel(job_id)` | Mark job cancelled and remove from queue |
| `filter_by_status(status)` | Return list of matching jobs |
| `filter_by_tag(tag)` | Return list of matching jobs |
| `stats()` | Dict of status → count |
| `__len__()` | Current queue depth |
| `__contains__(job_id)` | True if job is in queue |

---

## `flowq.storage`

### `Storage`

```python
class Storage:
    def __init__(self, db_path: str = "flowq.db") -> None: ...
```

| Method | Description |
|---|---|
| `save(job)` | Insert job (raises `DuplicateJobError` if id exists) |
| `fetch(job_id)` | Load job by id (raises `JobNotFoundError`) |
| `update(job)` | Overwrite job record |
| `delete(job_id)` | Remove job record |
| `list_jobs(status=None, limit=100, offset=0)` | Query with optional filter |
| `search_by_tag(tag)` | Return all jobs with given tag |
| `count_by_status()` | Dict of status → count |
| `health_check()` | Raise `StorageError` or return info dict |

---

## `flowq.worker`

### `register(name)`

Decorator that registers a function as the handler for jobs with `job.name == name`.

```python
@register("process_image")
def process_image(job: Job) -> None:
    ...
```

### `Worker`

```python
class Worker:
    def __init__(
        self,
        queue: JobQueue,
        storage: Optional[Storage] = None,
        retry_strategy: Optional[RetryStrategy] = None,
    ) -> None: ...
```

| Method | Description |
|---|---|
| `run_job(job)` | Execute job synchronously (blocks until done or timeout) |
| `start()` | Begin consuming from queue in a loop (blocking) |
| `stop()` | Signal the worker loop to exit |

### `WorkerPool`

```python
class WorkerPool:
    def __init__(self, size: int = 1, storage: Optional[Storage] = None) -> None: ...
```

| Method | Description |
|---|---|
| `start()` | Launch `size` worker threads |
| `stop()` | Gracefully shut down all threads |

---

## `flowq.scheduler`

### `CronExpression`

```python
class CronExpression:
    def __init__(self, expr: str) -> None: ...
    def matches(self, dt: datetime) -> bool: ...
    def next_run(self, after: Optional[datetime] = None) -> datetime: ...
```

Cron field syntax: `minute hour day month weekday`

| Token | Meaning | Example |
|---|---|---|
| `*` | Any value | `* * * * *` — every minute |
| `n` | Exact value | `30 * * * *` — at :30 |
| `n-m` | Range (inclusive) | `1-5` — Mon–Fri |
| `*/n` | Step | `*/15` — every 15 units |
| `a,b,c` | List | `0,30` — at :00 and :30 |

### `Scheduler`

```python
class Scheduler:
    def __init__(self, queue: JobQueue, tick_interval: int = 60) -> None: ...
```

| Method | Description |
|---|---|
| `add(name, cron, handler, payload, ...)` | Register a recurring job |
| `remove(name)` | Unregister a scheduled job |
| `tick(now=None)` | Check all schedules for the given time |
| `start()` | Begin background tick loop |
| `stop()` | Stop the background thread |

---

## `flowq.retry_strategies`

| Class | Description |
|---|---|
| `ImmediateRetry` | No wait |
| `ConstantDelay(delay)` | Fixed seconds |
| `LinearBackoff(delay, max_delay)` | `delay × attempt` |
| `ExponentialBackoff(base, factor, max_delay, jitter)` | `factor × base^attempt` |
| `FibonacciBackoff(unit, max_delay)` | Fibonacci sequence |
| `JitteredBackoff(cap, base)` | Full random jitter |
| `CompositeRetry(stages)` | Chain of strategies |

All subclass `RetryStrategy` with methods `wait_time(attempt) → float` and
`sleep(attempt)`.

```python
make_strategy("exponential", base=2, max_delay=120)
```

---

## `flowq.circuit_breaker`

### `CircuitBreaker`

```python
class CircuitBreaker:
    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        success_threshold: int = 1,
        expected_exception: type = Exception,
    ) -> None: ...

    def call(self, func, *args, **kwargs): ...
    def protect(self, func): ...     # decorator
    def reset(self) -> None: ...
    def force_open(self) -> None: ...
    def snapshot(self) -> dict: ...
```

### `CircuitBreakerRegistry`

Global registry: `circuit_breakers.get_or_create(name, **kwargs)`.

---

## `flowq.health`

### `HealthRegistry`

```python
health_registry = HealthRegistry()

@health_registry.check("redis")
def redis_check():
    ping_redis()   # raise on unhealthy
```

| Method | Description |
|---|---|
| `register(name, func, critical, timeout)` | Add a check |
| `check(name, ...)` | Decorator shorthand |
| `unregister(name)` | Remove a check |
| `run(name)` | Execute one check → `CheckResult` |
| `run_all()` | Execute all checks → `HealthReport` |

`HealthReport.overall` is the worst status among all checks.

---

## `flowq.workflows`

### `Workflow`

```python
wf = Workflow("my_pipeline")
step_name = wf.add_step("extract", handler="extract_fn", payload={...})
wf.add_step("transform", handler="transform_fn", depends_on=[step_name])
wf.validate()                # raises CyclicDependencyError if graph has cycles
order = wf.topological_order()
```

### `WorkflowRunner`

```python
runner = WorkflowRunner(worker, storage)
result = runner.run(wf)      # → WorkflowResult
print(result.status)         # WorkflowStatus.SUCCESS | FAILED | CANCELLED
print(result.duration)       # seconds
```

---

## `flowq.job_groups`

```python
group = JobGroup("nightly", queue, storage, max_failures=2)
group.add("report", {"date": "2026-05-04"}, priority=Priority.HIGH)
group.add("cleanup", {})
count = group.submit_all()    # → int (number enqueued successfully)
stats = group.wait(timeout=120)   # block until done
print(stats.success_rate)
```

---

## `flowq.plugins`

```python
class MyPlugin:
    name = "my_plugin"

    def on_job_start(self, job): ...
    def on_job_success(self, job): ...
    def on_job_failure(self, job, exc): ...

plugin_manager.register(MyPlugin())
plugin_manager.unregister("my_plugin")
```

Eight hook methods: `on_startup`, `on_shutdown`, `on_job_enqueue`,
`on_job_start`, `on_job_success`, `on_job_failure`, `on_job_retry`,
`on_job_cancel`.

---

## `flowq.monitoring`

```python
from flowq.monitoring import metrics

metrics.increment("jobs.processed")
metrics.set_gauge("queue.depth", len(queue))
metrics.observe("job.duration_ms", elapsed * 1000)

with metrics.timer("db.query"):
    result = storage.fetch(job_id)

snapshot = metrics.snapshot()
```

---

## `flowq.rate_limiter`

```python
from flowq.rate_limiter import TokenBucketLimiter, SlidingWindowLimiter

tb  = TokenBucketLimiter(capacity=100, rate=10.0)   # 10 tokens/sec, burst 100
sw  = SlidingWindowLimiter(max_calls=60, period=60.0)  # 60/min

tb.acquire()              # blocks until token available
ok = tb.try_acquire()     # non-blocking, returns bool

sw.acquire()
print(sw.current_count)
```

---

## `flowq.throttle`

```python
from flowq.throttle import ConcurrencyLimiter

limiter = ConcurrencyLimiter(max_concurrent=5)

with limiter.acquire("customer_42"):
    process_for_customer(...)
```

---

## `flowq.events`

```python
from flowq.events import events

@events.on("job.completed")
def handle_completion(job_id, status):
    notify_webhook(job_id, status)

events.emit("job.completed", job_id="abc", status="SUCCESS")
events.emit_async("job.completed", job_id="abc", status="SUCCESS")
```

---

## `flowq.serializers`

```python
from flowq.serializers import serializer_registry

s = serializer_registry.get("json")
data = s.dumps({"key": "value"})    # → bytes
obj  = s.loads(data)                # → dict

# Register custom serializer
class MsgpackSerializer(BaseSerializer):
    name = "msgpack"
    def dumps(self, obj): return msgpack.dumps(obj)
    def loads(self, data): return msgpack.loads(data)

serializer_registry.register(MsgpackSerializer())
```
