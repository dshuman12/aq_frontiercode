# Monitoring & Observability

FlowQ ships built-in metrics, health checks, structured logging, and an HTTP
dashboard — all with zero external dependencies.

---

## Metrics

### Primitives

```python
from flowq.monitoring import metrics

# Counter — monotonically increasing
metrics.increment("jobs.enqueued")
metrics.increment("jobs.enqueued", amount=5)

# Gauge — arbitrary float value
metrics.set_gauge("queue.depth", len(queue))
metrics.counter("queue.depth").increment(3)   # also works as counter

# Histogram — observe a value, query percentiles
metrics.observe("job.duration_ms", elapsed_ms)
hist = metrics.histogram("job.duration_ms")
print(hist.percentile(50))   # median
print(hist.percentile(99))   # p99

# Timer — context manager (records duration as histogram)
with metrics.timer("db.query_ms"):
    result = storage.fetch(job_id)
```

### Snapshot

```python
snap = metrics.snapshot()
# {
#   "counters":   {"jobs.enqueued": 1024, ...},
#   "gauges":     {"queue.depth": 12, ...},
#   "histograms": {"job.duration_ms": {"count": 1024, "p50": 12.3, "p99": 340.0, ...}},
#   "uptime_seconds": 3600.0
# }
```

The snapshot is JSON-serialisable and served at `/api/status` by the dashboard.

### Reset

```python
metrics.reset_all()   # zero all counters, clear histograms
```

---

## Health checks

```python
from flowq.health import health_registry

@health_registry.check("database")
def database_health():
    storage.health_check()   # raises StorageError if unhealthy
    return {"tables": 1}

@health_registry.check("disk_space", critical=False)
def disk_space():
    import shutil
    free = shutil.disk_usage("/").free
    if free < 100 * 1024 * 1024:   # < 100 MB
        raise RuntimeError(f"Low disk: {free // 1024 // 1024} MB free")
    return {"free_mb": free // 1024 // 1024}
```

### Querying health

```python
report = health_registry.run_all()
print(report.overall)       # HealthStatus.HEALTHY / DEGRADED / UNHEALTHY

for check in report.results:
    print(check.name, check.status.value, check.duration_ms, "ms")
```

The built-in self-check (`"self"`) is always registered:

```python
result = health_registry.run("self")
print(result.status)    # HealthStatus.HEALTHY (unless the process is broken)
```

---

## HTTP Dashboard

```bash
flowq dashboard --port 8765
```

Or programmatically:

```python
from flowq.dashboard import Dashboard

db = Dashboard(storage=storage, host="0.0.0.0", port=8765)
db.start()
# … your app runs …
db.stop()
```

### Endpoints

| Path | Method | Description |
|---|---|---|
| `/` | GET | HTML dashboard with auto-refresh |
| `/api/status` | GET | JSON with job counts and metrics snapshot |

### API response example

```json
{
  "job_counts": {
    "PENDING": 5,
    "RUNNING": 2,
    "SUCCESS": 1230,
    "FAILED": 3
  },
  "metrics": {
    "counters": {"jobs.enqueued": 1240},
    "gauges":   {"queue.depth": 7}
  }
}
```

---

## Structured logging

```python
from flowq.logging_config import configure_logging

# JSON output (for Datadog, Splunk, CloudWatch)
configure_logging(
    level="INFO",
    json=True,
    log_file="/var/log/flowq.log",
)
```

Each log line is a single JSON object:

```json
{"ts":"2026-05-04T09:01:23Z","level":"INFO","logger":"flowq.worker","msg":"Job abc123 started"}
```

### Per-module loggers

```python
from flowq.logging_config import get_logger
logger = get_logger("my_handler")
logger.info("Processing %s items", count)
```

---

## Circuit breaker status

```python
from flowq.circuit_breaker import circuit_breakers

for snap in circuit_breakers.all_snapshots():
    print(snap["name"], snap["state"], snap["failure_count"])
```

---

## Rate limiter stats

```python
from flowq.rate_limiter import rate_limiters

lim = rate_limiters.get("payments")
if lim:
    print(lim.available_tokens if hasattr(lim, "available_tokens") else "ok")
```

---

## Integration with Prometheus (example)

```python
from prometheus_client import Counter as PromCounter, start_http_server
from flowq.plugins import plugin_manager

jobs_total  = PromCounter("flowq_jobs_total",  "Jobs processed", ["status"])
jobs_failed = PromCounter("flowq_jobs_failed", "Jobs failed")

class PrometheusPlugin:
    name = "prometheus"
    def on_job_success(self, job):
        jobs_total.labels(status="success").inc()
    def on_job_failure(self, job, exc):
        jobs_total.labels(status="failed").inc()
        jobs_failed.inc()

plugin_manager.register(PrometheusPlugin())
start_http_server(9100)   # /metrics endpoint
```
