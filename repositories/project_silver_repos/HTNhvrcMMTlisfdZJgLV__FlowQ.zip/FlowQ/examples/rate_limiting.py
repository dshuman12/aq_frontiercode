#!/usr/bin/env python3
"""
Rate limiting example for FlowQ.

Demonstrates:
  - TokenBucketLimiter for burst-tolerant APIs
  - SlidingWindowLimiter for strict call-per-minute quotas
  - RateLimiterRegistry for named, shared limiters
  - Using rate limiters inside job handlers
"""

import time
from flowq.rate_limiter import (
    TokenBucketLimiter,
    SlidingWindowLimiter,
    RateLimiterRegistry,
    rate_limiters,
)
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.worker  import Worker, register
from flowq.models  import Job


# ── Set up named limiters ─────────────────────────────────────────────────────

# Allow 5 API calls per second with a burst of 10
rate_limiters.register("external_api", TokenBucketLimiter(capacity=10, rate=5.0))

# Strict: no more than 100 emails per hour
rate_limiters.register("email", SlidingWindowLimiter(max_calls=100, period=3600.0))


# ── Handlers that respect the limits ─────────────────────────────────────────

@register("api_call")
def api_call(job):
    rate_limiters.acquire("external_api")   # waits if bucket is empty
    url = job.payload.get("url", "https://httpbin.org/get")
    print(f"  → GET {url}")
    # requests.get(url)  # actual HTTP call would go here


@register("send_email")
def send_email(job):
    if not rate_limiters.try_acquire("email"):
        raise RuntimeError("Email quota exceeded for this hour")
    recipient = job.payload.get("to", "user@example.com")
    print(f"  → Sending email to {recipient}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    storage = Storage(":memory:")
    queue   = JobQueue()
    worker  = Worker(queue=queue, storage=storage)

    print("Token bucket demo (5 tokens/sec, capacity 10):")
    for i in range(5):
        job = Job(name="api_call", payload={"url": f"https://api.example.com/item/{i}"})
        storage.save(job)
        queue.enqueue(job)

    start = time.time()
    while (job := queue.dequeue()):
        worker.run_job(job)
    elapsed = time.time() - start
    print(f"5 calls completed in {elapsed:.2f}s (with token bucket)\n")

    print("Sliding window demo (max 3 emails per 5s):")
    rate_limiters.register("demo_email", SlidingWindowLimiter(max_calls=3, period=5.0))
    for i in range(4):
        ok = rate_limiters.try_acquire("demo_email")
        print(f"  Email {i+1}: {'sent' if ok else 'BLOCKED (quota exceeded)'}")


if __name__ == "__main__":
    main()
