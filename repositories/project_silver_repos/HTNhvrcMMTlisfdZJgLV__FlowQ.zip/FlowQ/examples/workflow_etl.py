#!/usr/bin/env python3
"""
End-to-end ETL workflow example using FlowQ's DAG engine.

Demonstrates:
  - Declaring a multi-step pipeline with dependencies
  - Passing data between steps via payload
  - Error handling and WorkflowResult inspection
"""

from flowq.queue     import JobQueue
from flowq.storage   import Storage
from flowq.worker    import Worker, register
from flowq.workflows import Workflow, WorkflowRunner, WorkflowStatus


# ── Handler definitions ──────────────────────────────────────────────────────

@register("etl_extract")
def extract(job):
    source = job.payload.get("source", "database")
    print(f"[extract] Reading from {source}")
    # Simulate data extraction
    return {"rows": 1000, "source": source}


@register("etl_validate")
def validate(job):
    print("[validate] Checking schema and constraints")
    # In real life: raise ValueError on bad data
    return {"valid_rows": 1000, "invalid_rows": 0}


@register("etl_transform")
def transform(job):
    print("[transform] Applying business rules")
    return {"transformed_rows": 1000}


@register("etl_load")
def load(job):
    destination = job.payload.get("destination", "data_warehouse")
    print(f"[load] Writing to {destination}")
    return {"loaded_rows": 1000}


@register("etl_notify")
def notify(job):
    print("[notify] Sending completion email to data team")


# ── Workflow definition ──────────────────────────────────────────────────────

def build_etl_workflow(source="s3://bucket/data", destination="bigquery"):
    wf = Workflow("nightly_etl")

    extract_step  = wf.add_step("extract",  "etl_extract",  payload={"source": source})
    validate_step = wf.add_step("validate", "etl_validate", depends_on=[extract_step])
    transform_step= wf.add_step("transform","etl_transform", depends_on=[validate_step])
    load_step     = wf.add_step("load",     "etl_load",
                                payload={"destination": destination},
                                depends_on=[transform_step])
    wf.add_step(                "notify",   "etl_notify",   depends_on=[load_step])

    return wf


# ── Run ──────────────────────────────────────────────────────────────────────

def main():
    storage = Storage(":memory:")
    worker  = Worker(queue=JobQueue(), storage=storage)
    runner  = WorkflowRunner(worker, storage)

    wf     = build_etl_workflow()
    result = runner.run(wf)

    print(f"\nWorkflow: {result.workflow_name}")
    print(f"Status:   {result.status.name}")
    print(f"Duration: {result.duration:.3f}s")
    print("\nStep results:")
    for step, status in result.step_results.items():
        print(f"  {step:<12} {status.name}")

    if result.status != WorkflowStatus.SUCCESS:
        print(f"\nFailed at: {result.error}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
