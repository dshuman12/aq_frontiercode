#!/usr/bin/env python3
"""
Plugin system example for FlowQ.

Shows how to write a custom plugin that hooks into the job lifecycle
for audit logging and failure alerting.
"""

import time
from flowq.plugins import plugin_manager
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.worker  import Worker, register
from flowq.models  import Job, Priority


# ── Custom plugin ─────────────────────────────────────────────────────────────

class AuditPlugin:
    """Writes a structured audit log for every job event."""

    name = "audit"

    def __init__(self):
        self._log: list[dict] = []

    def on_job_enqueue(self, job):
        self._log.append({"event": "enqueue", "id": job.id, "name": job.name,
                          "ts": time.time()})

    def on_job_start(self, job):
        self._log.append({"event": "start", "id": job.id, "ts": time.time()})

    def on_job_success(self, job):
        self._log.append({"event": "success", "id": job.id,
                          "duration": job.duration, "ts": time.time()})

    def on_job_failure(self, job, exc):
        self._log.append({"event": "failure", "id": job.id,
                          "error": str(exc), "ts": time.time()})

    def on_job_retry(self, job, attempt, exc):
        self._log.append({"event": "retry", "id": job.id,
                          "attempt": attempt, "ts": time.time()})

    def print_log(self):
        print("\n=== Audit log ===")
        for entry in self._log:
            print(f"  {entry['event']:10}  {entry.get('name', entry.get('id',''))[:36]}")


class AlertPlugin:
    """Simulates sending an alert on CRITICAL job failures."""

    name = "alerter"

    def on_job_failure(self, job, exc):
        if job.priority.value >= Priority.HIGH.value:
            print(f"  🚨 ALERT: High-priority job {job.name!r} failed: {exc}")


# ── Register plugins ──────────────────────────────────────────────────────────

audit   = AuditPlugin()
alerter = AlertPlugin()
plugin_manager.register(audit)
plugin_manager.register(alerter)


# ── Handlers ──────────────────────────────────────────────────────────────────

@register("quick_task")
def quick_task(job):
    print(f"  Running quick_task: {job.payload}")

@register("risky_task")
def risky_task(job):
    if job.payload.get("fail"):
        raise RuntimeError("Simulated failure")
    print("  risky_task succeeded")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    storage = Storage(":memory:")
    queue   = JobQueue()
    worker  = Worker(queue=queue, storage=storage)

    # Dispatch some jobs through the plugin system
    plugin_manager.on_startup({"db": "memory"})

    for payload in [{"x": 1}, {"x": 2}, {"fail": True}]:
        job = Job(
            name="risky_task" if payload.get("fail") else "quick_task",
            payload=payload,
            priority=Priority.HIGH if payload.get("fail") else Priority.NORMAL,
        )
        storage.save(job)
        queue.enqueue(job)
        plugin_manager.on_job_enqueue(job)

    while (job := queue.dequeue()):
        plugin_manager.on_job_start(job)
        try:
            worker.run_job(job)
            latest = storage.fetch(job.id)
            if latest.status.name == "SUCCESS":
                plugin_manager.on_job_success(latest)
            else:
                plugin_manager.on_job_failure(latest, RuntimeError(latest.error or "unknown"))
        except Exception as e:
            plugin_manager.on_job_failure(job, e)

    plugin_manager.on_shutdown()
    audit.print_log()


if __name__ == "__main__":
    main()
