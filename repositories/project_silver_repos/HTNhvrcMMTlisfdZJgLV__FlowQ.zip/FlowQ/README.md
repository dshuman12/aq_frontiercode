# FlowQ

**FlowQ** is a batteries-included Python job queue, scheduler, and workflow engine
built entirely on the standard library — no broker required, no external services,
no surprises.

```
pip install flowq
```

---

## Quick start

```python
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.worker  import Worker, register

@register("send_email")
def send_email(job):
    print(f"Sending email to {job.payload['to']}")

storage = Storage("jobs.db")
queue   = JobQueue()
worker  = Worker(queue=queue, storage=storage)

from flowq.models import Job
job = Job(name="send_email", payload={"to": "user@example.com"})
storage.save(job)
queue.enqueue(job)

worker.run_job(queue.dequeue())
```

---

## Feature overview

| Feature | Module |
|---|---|
| Priority job queue (heap-based) | `flowq.queue` |
| SQLite / Memory / File storage | `flowq.storage`, `flowq.backends` |
| Worker & worker pool | `flowq.worker` |
| Cron scheduler | `flowq.scheduler` |
| DAG workflow engine | `flowq.workflows` |
| Job batch manager | `flowq.job_groups` |
| Pluggable retry strategies | `flowq.retry_strategies` |
| Circuit breaker | `flowq.circuit_breaker` |
| Rate limiting (token bucket / sliding window) | `flowq.rate_limiter` |
| Concurrency throttle | `flowq.throttle` |
| Dead letter queue | `flowq.deadletter` |
| Metrics & monitoring | `flowq.monitoring` |
| Health checks | `flowq.health` |
| Event emitter (pub/sub) | `flowq.events` |
| Middleware pipeline | `flowq.middleware` |
| Plugin system (lifecycle hooks) | `flowq.plugins` |
| Payload serializers (JSON / Pickle / Base64) | `flowq.serializers` |
| Structured logging (JSON + colour console) | `flowq.logging_config` |
| HTTP dashboard | `flowq.dashboard` |
| Configuration via env vars | `flowq.config` |
| CLI (`flowq enqueue`, `list`, `stats`, …) | `flowq.cli` |

---

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                        FlowQ                             │
│                                                          │
│  Producer                                                │
│  ─────────  Job ──► JobQueue ──► Worker ──► Handler fn   │
│                        │           │                     │
│                        ▼           ▼                     │
│                    Storage     PluginManager             │
│                   (SQLite /   (hooks: start /            │
│                   Memory /    success / fail /           │
│                   File)       retry / cancel)            │
│                                                          │
│  Scheduler ──► cron tick ──► JobQueue                    │
│  Workflow  ──► DAG steps  ──► Worker (sequential)        │
│  JobGroup  ──► batch enqueue ──► WorkerPool              │
└──────────────────────────────────────────────────────────┘
```

---

## CLI

```bash
# Enqueue a job
flowq enqueue send_email --payload '{"to":"a@b.com"}' --priority HIGH

# List pending jobs
flowq list --status-filter PENDING

# Show stats
flowq stats

# Start a worker pool
flowq worker --concurrency 4

# Launch the HTTP dashboard
flowq dashboard --port 8765
```

---

## Documentation

Full documentation lives in the [`docs/`](docs/) directory:

- [Getting Started](docs/getting_started.md)
- [Configuration](docs/configuration.md)
- [Architecture](docs/architecture.md)
- [CLI Reference](docs/cli_reference.md)
- [API Reference](docs/api_reference.md)
- [Retry Strategies](docs/retry_strategies.md)
- [Workflows](docs/workflows.md)
- [Plugins](docs/plugins.md)
- [Storage Backends](docs/backends.md)
- [Monitoring & Metrics](docs/monitoring.md)
- [Deployment](docs/deployment.md)
- [Cookbook](docs/cookbook.md)
- [Contributing](docs/contributing.md)

---

## Running tests

```bash
pip install -e ".[dev]"
pytest
```

All 259 tests pass against Python 3.10–3.13.

---

## License

MIT — see [LICENSE](LICENSE).
