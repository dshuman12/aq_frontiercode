"""
Execution context for FlowQ jobs.

Provides thread-local storage that is automatically populated before a job
handler is called and cleared afterwards.  Handlers can access the current
job, worker ID, attempt number, and span metadata without needing these
passed as arguments.

Usage::

    from flowq.context import current_context, job_context

    @register("my_handler")
    def my_handler(job):
        ctx = current_context()
        print(ctx.job_id)
        print(ctx.attempt)
        print(ctx.worker_id)

    # In tests, set context manually:
    with job_context(job, worker_id="test-worker", attempt=1):
        my_handler(job)
"""

from __future__ import annotations

import contextlib
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from flowq.models import Job


@dataclass
class JobContext:
    """Immutable snapshot of the execution context for one job attempt."""

    job_id:     str
    job_name:   str
    attempt:    int
    worker_id:  str
    queue_name: str                      = "default"
    span_id:    str                      = field(default_factory=lambda: uuid.uuid4().hex[:16])
    started_at: float                    = field(default_factory=time.time)
    extra:      dict[str, Any]           = field(default_factory=dict)

    @classmethod
    def from_job(
        cls,
        job:        Job,
        worker_id:  str  = "unknown",
        attempt:    int  = 1,
        queue_name: str  = "default",
        **extra: Any,
    ) -> "JobContext":
        return cls(
            job_id=job.id,
            job_name=job.name,
            attempt=attempt,
            worker_id=worker_id,
            queue_name=queue_name,
            extra=extra,
        )

    @property
    def elapsed(self) -> float:
        return time.time() - self.started_at

    def to_dict(self) -> dict:
        return {
            "job_id":     self.job_id,
            "job_name":   self.job_name,
            "attempt":    self.attempt,
            "worker_id":  self.worker_id,
            "queue_name": self.queue_name,
            "span_id":    self.span_id,
            "started_at": self.started_at,
            "elapsed":    self.elapsed,
            "extra":      self.extra,
        }


_local = threading.local()


def current_context() -> Optional[JobContext]:
    """Return the JobContext for the current thread, or None if not in a job."""
    return getattr(_local, "context", None)


def require_context() -> JobContext:
    """Like current_context() but raises RuntimeError if not in a job."""
    ctx = current_context()
    if ctx is None:
        raise RuntimeError(
            "require_context() called outside of a job execution context. "
            "Use job_context() to set one in tests."
        )
    return ctx


@contextlib.contextmanager
def job_context(
    job:        Job,
    worker_id:  str = "unknown",
    attempt:    int = 1,
    queue_name: str = "default",
    **extra:    Any,
):
    """
    Context manager that sets the thread-local JobContext for the duration
    of the block, then clears it.

    Example::

        with job_context(job, worker_id="w-1", attempt=2):
            handler(job)
    """
    ctx = JobContext.from_job(
        job,
        worker_id=worker_id,
        attempt=attempt,
        queue_name=queue_name,
        **extra,
    )
    _local.context = ctx
    try:
        yield ctx
    finally:
        _local.context = None


def set_extra(key: str, value: Any) -> None:
    """
    Attach additional metadata to the current job context.
    Safe to call from within a handler; no-op if not in a context.
    """
    ctx = current_context()
    if ctx is not None:
        ctx.extra[key] = value


def get_extra(key: str, default: Any = None) -> Any:
    ctx = current_context()
    if ctx is None:
        return default
    return ctx.extra.get(key, default)


class ContextStack:
    """
    Manages a stack of contexts for nested or recursive job execution.
    Rarely needed in normal usage; useful for workflow runners.
    """

    def __init__(self) -> None:
        self._local = threading.local()

    def _stack(self) -> list[JobContext]:
        if not hasattr(self._local, "stack"):
            self._local.stack = []
        return self._local.stack

    def push(self, ctx: JobContext) -> None:
        self._stack().append(ctx)
        _local.context = ctx

    def pop(self) -> Optional[JobContext]:
        stack = self._stack()
        if not stack:
            return None
        ctx = stack.pop()
        _local.context = stack[-1] if stack else None
        return ctx

    def current(self) -> Optional[JobContext]:
        stack = self._stack()
        return stack[-1] if stack else None

    def depth(self) -> int:
        return len(self._stack())


context_stack = ContextStack()
