"""
Job inspection utilities for FlowQ.

Provides rich querying, aggregation, and export capabilities on top of Storage.

Usage::

    from flowq.inspection import Inspector

    inspector = Inspector(storage)

    # Paginate
    page = inspector.paginate(page=1, page_size=20, status=JobStatus.FAILED)

    # Aggregate
    agg = inspector.aggregate_by_name()

    # Export
    csv_text = inspector.export_csv(status=JobStatus.SUCCESS, limit=500)
    records  = inspector.export_json(status=JobStatus.FAILED)

    # Recent activity
    timeline = inspector.activity_timeline(bucket_minutes=60, limit=24)
"""

from __future__ import annotations

import csv
import io
import json
import math
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from flowq.models import Job, JobStatus
from flowq.storage import Storage


@dataclass
class Page:
    items:        list[Job]
    page:         int
    page_size:    int
    total:        int

    @property
    def total_pages(self) -> int:
        if self.page_size == 0:
            return 0
        return math.ceil(self.total / self.page_size)

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages

    @property
    def has_prev(self) -> bool:
        return self.page > 1

    def to_dict(self) -> dict:
        return {
            "page":        self.page,
            "page_size":   self.page_size,
            "total":       self.total,
            "total_pages": self.total_pages,
            "has_next":    self.has_next,
            "has_prev":    self.has_prev,
            "items":       [j.to_dict() for j in self.items],
        }


@dataclass
class NameAggregation:
    name:     str
    total:    int
    success:  int
    failed:   int
    pending:  int
    running:  int
    avg_duration_s: Optional[float]

    @property
    def success_rate(self) -> float:
        terminal = self.success + self.failed
        return (self.success / terminal) if terminal else 0.0

    def to_dict(self) -> dict:
        return {
            "name":           self.name,
            "total":          self.total,
            "success":        self.success,
            "failed":         self.failed,
            "pending":        self.pending,
            "running":        self.running,
            "success_rate":   round(self.success_rate, 4),
            "avg_duration_s": self.avg_duration_s,
        }


@dataclass
class TimelineBucket:
    label:   str        # e.g. "2026-05-04T09:00"
    start:   float
    end:     float
    count:   int
    success: int
    failed:  int


class Inspector:
    """
    Rich inspection interface layered on top of ``Storage``.

    Parameters
    ----------
    storage:
        A ``flowq.storage.Storage`` instance.
    """

    def __init__(self, storage: Storage) -> None:
        self._storage = storage

    # ── pagination ────────────────────────────────────────────────────────────

    def paginate(
        self,
        page:      int = 1,
        page_size: int = 20,
        status:    Optional[JobStatus] = None,
    ) -> Page:
        """Return a paginated slice of jobs."""
        if page < 1:
            raise ValueError("page must be >= 1")
        offset = (page - 1) * page_size
        items  = self._storage.list_jobs(status=status, limit=page_size, offset=offset)
        # Total count
        counts = self._storage.count_by_status()
        if status is None:
            total = sum(counts.values())
        else:
            total = counts.get(status.name, 0)
        return Page(items=items, page=page, page_size=page_size, total=total)

    # ── search ────────────────────────────────────────────────────────────────

    def search(
        self,
        name_contains:    Optional[str]       = None,
        tag:              Optional[str]        = None,
        status:           Optional[JobStatus]  = None,
        limit:            int                  = 100,
    ) -> list[Job]:
        """Filter jobs by name substring and/or tag."""
        if tag is not None:
            candidates = self._storage.search_by_tag(tag)
        else:
            candidates = self._storage.list_jobs(status=status, limit=limit * 10)

        result = []
        for job in candidates:
            if status is not None and job.status != status:
                continue
            if name_contains and name_contains.lower() not in job.name.lower():
                continue
            result.append(job)
            if len(result) >= limit:
                break
        return result

    # ── aggregation ───────────────────────────────────────────────────────────

    def aggregate_by_name(self, limit: int = 50) -> list[NameAggregation]:
        """Group jobs by handler name and compute per-name statistics."""
        jobs = self._storage.list_jobs(limit=10000)
        buckets: dict[str, dict] = {}

        for job in jobs:
            b = buckets.setdefault(job.name, {
                "total": 0, "success": 0, "failed": 0,
                "pending": 0, "running": 0, "durations": [],
            })
            b["total"] += 1
            b[job.status.name.lower()] = b.get(job.status.name.lower(), 0) + 1
            if job.duration is not None:
                b["durations"].append(job.duration)

        result = []
        for name, b in sorted(buckets.items(), key=lambda x: -x[1]["total"])[:limit]:
            durs = b["durations"]
            avg  = sum(durs) / len(durs) if durs else None
            result.append(NameAggregation(
                name=name,
                total=b["total"],
                success=b.get("success", 0),
                failed=b.get("failed", 0),
                pending=b.get("pending", 0),
                running=b.get("running", 0),
                avg_duration_s=round(avg, 3) if avg is not None else None,
            ))
        return result

    def status_summary(self) -> dict[str, Any]:
        """Return a comprehensive status overview."""
        counts = self._storage.count_by_status()
        total  = sum(counts.values())
        return {
            "total":        total,
            "by_status":    counts,
            "success_rate": (
                counts.get("SUCCESS", 0) / max(total, 1)
            ),
        }

    # ── export ────────────────────────────────────────────────────────────────

    def export_json(
        self,
        status: Optional[JobStatus] = None,
        limit:  int = 1000,
    ) -> list[dict]:
        """Export jobs as a list of dicts."""
        jobs = self._storage.list_jobs(status=status, limit=limit)
        return [j.to_dict() for j in jobs]

    def export_csv(
        self,
        status: Optional[JobStatus] = None,
        limit:  int = 1000,
        fields: Optional[list[str]] = None,
    ) -> str:
        """Export jobs as a CSV string."""
        jobs    = self._storage.list_jobs(status=status, limit=limit)
        default = ["id", "name", "status", "priority", "retry_count",
                   "created_at", "started_at", "finished_at"]
        cols    = fields or default

        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        for job in jobs:
            row = job.to_dict()
            writer.writerow({k: row.get(k, "") for k in cols})
        return buf.getvalue()

    # ── timeline ──────────────────────────────────────────────────────────────

    def activity_timeline(
        self,
        bucket_minutes: int = 60,
        limit:          int = 24,
    ) -> list[TimelineBucket]:
        """
        Return *limit* time buckets (most recent first) showing job activity.
        Jobs are bucketed by their ``created_at`` timestamp.
        """
        bucket_sec = bucket_minutes * 60
        now        = time.time()
        jobs       = self._storage.list_jobs(limit=10000)

        buckets: dict[int, TimelineBucket] = {}
        for job in jobs:
            ts    = getattr(job, "created_at", None)
            if ts is None:
                continue
            stamp = ts.timestamp() if hasattr(ts, "timestamp") else float(ts)
            idx   = int(stamp // bucket_sec)
            if idx not in buckets:
                start = idx * bucket_sec
                import datetime
                label = datetime.datetime.utcfromtimestamp(start).strftime("%Y-%m-%dT%H:%M")
                buckets[idx] = TimelineBucket(
                    label=label, start=start, end=start + bucket_sec,
                    count=0, success=0, failed=0,
                )
            b = buckets[idx]
            b.count += 1
            if job.status == JobStatus.SUCCESS:
                b.success += 1
            elif job.status == JobStatus.FAILED:
                b.failed += 1

        sorted_buckets = sorted(buckets.values(), key=lambda b: -b.start)
        return sorted_buckets[:limit]

    # ── slow job detection ────────────────────────────────────────────────────

    def slow_jobs(
        self,
        threshold_seconds: float = 60.0,
        limit:             int   = 50,
    ) -> list[Job]:
        """Return completed jobs whose duration exceeded *threshold_seconds*."""
        jobs   = self._storage.list_jobs(status=JobStatus.SUCCESS, limit=10000)
        slow   = [j for j in jobs if j.duration and j.duration > threshold_seconds]
        slow.sort(key=lambda j: -(j.duration or 0))
        return slow[:limit]

    def retry_heavy_jobs(self, min_retries: int = 1, limit: int = 50) -> list[Job]:
        """Return jobs that were retried at least *min_retries* times."""
        all_jobs = self._storage.list_jobs(limit=10000)
        heavy    = [j for j in all_jobs if j.retries_used >= min_retries]
        heavy.sort(key=lambda j: -j.retries_used)
        return heavy[:limit]
