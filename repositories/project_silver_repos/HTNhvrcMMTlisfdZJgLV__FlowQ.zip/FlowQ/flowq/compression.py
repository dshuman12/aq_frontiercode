"""
Payload compression for FlowQ.

Large job payloads can be compressed before storage to reduce disk usage.
The compression registry supports zlib, gzip, lzma, and bz2.

Usage::

    from flowq.compression import compress, decompress, compression_registry

    # Compress a payload
    data  = {"records": list(range(10000))}
    blob  = compress(data, algorithm="zlib", level=6)
    data2 = decompress(blob)
    assert data == data2

    # Use with Storage by hooking into serialization
    reg = compression_registry
    compressed = reg.compress("lzma", raw_bytes)
    original   = reg.decompress("lzma", compressed)
"""

from __future__ import annotations

import bz2
import gzip
import json
import lzma
import zlib
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class CompressedPayload:
    algorithm: str
    data:      bytes
    original_size: int
    compressed_size: int

    @property
    def ratio(self) -> float:
        if self.original_size == 0:
            return 1.0
        return self.compressed_size / self.original_size

    def to_bytes(self) -> bytes:
        """Encode as: 1-byte alg_len + alg_name + 4-byte orig_size + data."""
        alg = self.algorithm.encode("utf-8")
        header = bytes([len(alg)]) + alg + self.original_size.to_bytes(4, "big")
        return header + self.data

    @classmethod
    def from_bytes(cls, raw: bytes) -> "CompressedPayload":
        alg_len    = raw[0]
        algorithm  = raw[1: 1 + alg_len].decode("utf-8")
        orig_size  = int.from_bytes(raw[1 + alg_len: 5 + alg_len], "big")
        data       = raw[5 + alg_len:]
        return cls(
            algorithm=algorithm,
            data=data,
            original_size=orig_size,
            compressed_size=len(data),
        )


class Compressor(ABC):
    name: str

    @abstractmethod
    def compress(self, data: bytes, level: int = 6) -> bytes: ...

    @abstractmethod
    def decompress(self, data: bytes) -> bytes: ...


class ZlibCompressor(Compressor):
    name = "zlib"

    def compress(self, data: bytes, level: int = 6) -> bytes:
        return zlib.compress(data, level=level)

    def decompress(self, data: bytes) -> bytes:
        return zlib.decompress(data)


class GzipCompressor(Compressor):
    name = "gzip"

    def compress(self, data: bytes, level: int = 6) -> bytes:
        return gzip.compress(data, compresslevel=level)

    def decompress(self, data: bytes) -> bytes:
        return gzip.decompress(data)


class LzmaCompressor(Compressor):
    name = "lzma"

    def compress(self, data: bytes, level: int = 6) -> bytes:
        return lzma.compress(data, preset=min(level, 9))

    def decompress(self, data: bytes) -> bytes:
        return lzma.decompress(data)


class Bz2Compressor(Compressor):
    name = "bz2"

    def compress(self, data: bytes, level: int = 6) -> bytes:
        return bz2.compress(data, compresslevel=min(level, 9))

    def decompress(self, data: bytes) -> bytes:
        return bz2.decompress(data)


class NoopCompressor(Compressor):
    """Identity compressor — does nothing. Useful as a default."""
    name = "none"

    def compress(self, data: bytes, level: int = 6) -> bytes:
        return data

    def decompress(self, data: bytes) -> bytes:
        return data


class CompressionRegistry:
    """Registry of named compressors."""

    def __init__(self) -> None:
        self._compressors: dict[str, Compressor] = {}

    def register(self, compressor: Compressor) -> None:
        self._compressors[compressor.name] = compressor

    def get(self, name: str) -> Compressor:
        c = self._compressors.get(name)
        if c is None:
            raise KeyError(f"Unknown compressor {name!r}. Available: {self.names()}")
        return c

    def names(self) -> list[str]:
        return list(self._compressors.keys())

    def compress(
        self,
        algorithm: str,
        data:      bytes,
        level:     int = 6,
    ) -> CompressedPayload:
        c           = self.get(algorithm)
        compressed  = c.compress(data, level=level)
        return CompressedPayload(
            algorithm=algorithm,
            data=compressed,
            original_size=len(data),
            compressed_size=len(compressed),
        )

    def decompress(self, algorithm: str, data: bytes) -> bytes:
        return self.get(algorithm).decompress(data)

    def best_for(self, data: bytes) -> str:
        """Return the algorithm that produces the smallest output for *data*."""
        best_name = "none"
        best_size = len(data)
        for name, c in self._compressors.items():
            if name == "none":
                continue
            try:
                size = len(c.compress(data))
                if size < best_size:
                    best_size = size
                    best_name = name
            except Exception:
                pass
        return best_name


# Global registry, pre-loaded with all built-in compressors
compression_registry = CompressionRegistry()
for _c in [NoopCompressor(), ZlibCompressor(), GzipCompressor(),
           LzmaCompressor(), Bz2Compressor()]:
    compression_registry.register(_c)


# ── Convenience functions ─────────────────────────────────────────────────────

def compress(
    obj:       Any,
    algorithm: str = "zlib",
    level:     int = 6,
) -> CompressedPayload:
    """Serialise *obj* to JSON then compress with *algorithm*."""
    raw = json.dumps(obj, default=str).encode("utf-8")
    return compression_registry.compress(algorithm, raw, level=level)


def decompress(payload: CompressedPayload) -> Any:
    """Decompress and deserialise a ``CompressedPayload`` back to a Python object."""
    raw = compression_registry.decompress(payload.algorithm, payload.data)
    return json.loads(raw)
