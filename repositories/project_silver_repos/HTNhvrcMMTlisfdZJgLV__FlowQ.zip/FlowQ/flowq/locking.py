"""
Distributed advisory locking for FlowQ via SQLite.

Prevents duplicate execution of jobs that must not run concurrently.
Locks are stored in SQLite, making them shared across all threads and
processes that use the same database file.

Usage::

    from flowq.locking import LockManager

    lm = LockManager("locks.db")

    with lm.acquire("invoice:42", owner="worker-1", ttl=30):
        process_invoice(42)   # only one process runs this at a time

    # Non-blocking:
    if lm.try_acquire("invoice:42", owner="worker-1", ttl=30):
        try:
            process_invoice(42)
        finally:
            lm.release("invoice:42", owner="worker-1")
"""

from __future__ import annotations

import contextlib
import sqlite3
import threading
import time
from dataclasses import dataclass
from typing import Optional


@dataclass
class LockInfo:
    name:       str
    owner:      str
    acquired_at: float
    expires_at:  Optional[float]

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at

    def ttl_remaining(self) -> Optional[float]:
        if self.expires_at is None:
            return None
        return max(0.0, self.expires_at - time.time())


class LockError(Exception):
    """Base exception for locking errors."""


class LockNotHeld(LockError):
    """Raised when releasing a lock that is not held by the caller."""


class LockAlreadyHeld(LockError):
    """Raised when a non-blocking acquire fails."""


_SCHEMA = """
CREATE TABLE IF NOT EXISTS advisory_locks (
    name        TEXT PRIMARY KEY,
    owner       TEXT NOT NULL,
    acquired_at REAL NOT NULL,
    expires_at  REAL
);
"""


class LockManager:
    """
    SQLite-backed distributed advisory lock manager.

    Parameters
    ----------
    db_path:
        Path to the SQLite file (shared with other processes).
    poll_interval:
        Seconds between retries when blocking-acquire is waiting.
    """

    def __init__(
        self,
        db_path: str = "flowq_locks.db",
        poll_interval: float = 0.05,
    ) -> None:
        self._db_path = db_path
        self._poll    = poll_interval
        self._local   = threading.local()
        self._init_db()

    # ── internals ─────────────────────────────────────────────────────────────

    def _conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn"):
            conn = sqlite3.connect(self._db_path, check_same_thread=False,
                                   timeout=10)
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._conn()
        conn.executescript(_SCHEMA)
        conn.commit()

    def _try_insert(self, name: str, owner: str, ttl: Optional[float]) -> bool:
        """Attempt to INSERT the lock row. Returns True on success."""
        now        = time.time()
        expires_at = now + ttl if ttl is not None else None
        conn       = self._conn()
        try:
            conn.execute(
                """INSERT INTO advisory_locks (name, owner, acquired_at, expires_at)
                   VALUES (?, ?, ?, ?)""",
                (name, owner, now, expires_at),
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            conn.rollback()
            return False

    def _evict_expired(self, name: str) -> bool:
        """Delete the lock row if it is expired. Returns True if a row was deleted."""
        now  = time.time()
        conn = self._conn()
        conn.execute(
            """DELETE FROM advisory_locks
               WHERE name = ? AND expires_at IS NOT NULL AND expires_at < ?""",
            (name, now),
        )
        conn.commit()
        return conn.total_changes > 0

    # ── public API ────────────────────────────────────────────────────────────

    def try_acquire(
        self,
        name:  str,
        owner: str,
        ttl:   Optional[float] = None,
    ) -> bool:
        """
        Attempt to acquire the lock. Returns True if acquired, False otherwise.

        Expired locks held by other owners are evicted automatically.
        """
        self._evict_expired(name)
        return self._try_insert(name, owner, ttl)

    def acquire(
        self,
        name:    str,
        owner:   str,
        ttl:     Optional[float] = None,
        timeout: Optional[float] = None,
    ) -> None:
        """
        Block until the lock is acquired.

        Raises ``LockAlreadyHeld`` if *timeout* is 0.
        Raises ``TimeoutError`` if *timeout* elapses.
        """
        deadline = time.monotonic() + timeout if timeout is not None else None
        while True:
            if self.try_acquire(name, owner, ttl):
                return
            if deadline is not None:
                if timeout == 0:
                    raise LockAlreadyHeld(f"Lock {name!r} is already held")
                if time.monotonic() >= deadline:
                    raise TimeoutError(
                        f"Timed out waiting for lock {name!r} after {timeout}s"
                    )
            time.sleep(self._poll)

    def release(self, name: str, owner: str) -> None:
        """
        Release the lock. Raises ``LockNotHeld`` if the caller does not own it.
        """
        conn = self._conn()
        conn.execute(
            "DELETE FROM advisory_locks WHERE name = ? AND owner = ?",
            (name, owner),
        )
        conn.commit()
        if conn.total_changes == 0:
            raise LockNotHeld(
                f"Lock {name!r} is not held by owner {owner!r}"
            )

    @contextlib.contextmanager
    def lock(
        self,
        name:    str,
        owner:   str,
        ttl:     Optional[float] = None,
        timeout: Optional[float] = None,
    ):
        """Context manager — acquire on enter, release on exit."""
        self.acquire(name, owner, ttl=ttl, timeout=timeout)
        try:
            yield
        finally:
            try:
                self.release(name, owner)
            except LockNotHeld:
                pass   # lock may have expired; don't mask original exception

    def info(self, name: str) -> Optional[LockInfo]:
        """Return info about a held lock, or None if not locked."""
        conn = self._conn()
        cur  = conn.execute(
            "SELECT * FROM advisory_locks WHERE name = ?", (name,)
        )
        row  = cur.fetchone()
        if row is None:
            return None
        return LockInfo(
            name=row["name"],
            owner=row["owner"],
            acquired_at=row["acquired_at"],
            expires_at=row["expires_at"],
        )

    def is_locked(self, name: str) -> bool:
        info = self.info(name)
        return info is not None and not info.is_expired()

    def list_locks(self) -> list[LockInfo]:
        """Return all currently held (non-expired) locks."""
        now  = time.time()
        conn = self._conn()
        rows = conn.execute(
            """SELECT * FROM advisory_locks
               WHERE expires_at IS NULL OR expires_at > ?""",
            (now,),
        ).fetchall()
        return [
            LockInfo(
                name=r["name"],
                owner=r["owner"],
                acquired_at=r["acquired_at"],
                expires_at=r["expires_at"],
            )
            for r in rows
        ]

    def purge_expired(self) -> int:
        """Remove all expired lock rows. Returns count deleted."""
        now  = time.time()
        conn = self._conn()
        cur  = conn.execute(
            "DELETE FROM advisory_locks WHERE expires_at IS NOT NULL AND expires_at < ?",
            (now,),
        )
        conn.commit()
        return cur.rowcount

    def release_all_for_owner(self, owner: str) -> int:
        """Release all locks held by *owner* (e.g. on worker crash). Returns count."""
        conn = self._conn()
        cur  = conn.execute(
            "DELETE FROM advisory_locks WHERE owner = ?", (owner,)
        )
        conn.commit()
        return cur.rowcount

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn:
            conn.close()
            del self._local.conn


# Module-level singleton
lock_manager = LockManager(":memory:")
