"""
Job routing for FlowQ.

A Router inspects each job and decides which named queue it should be sent to.
Route rules are evaluated in registration order; the first match wins.

Usage::

    from flowq.routing import Router
    from flowq.queue   import JobQueue

    queues = {
        "critical":   JobQueue(),
        "default":    JobQueue(),
        "background": JobQueue(),
    }

    router = Router(queues, default="default")
    router.add_rule(lambda job: job.priority.value >= 20, target="critical")
    router.add_rule(lambda job: "bulk" in (job.tags or []),  target="background")

    router.route(job)   # enqueues job into the correct queue
"""

from __future__ import annotations

import fnmatch
import re
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from flowq.models import Job, Priority
from flowq.queue  import JobQueue


@dataclass
class RoutingRule:
    predicate: Callable[[Job], bool]
    target:    str
    name:      str = ""
    priority:  int = 0      # higher = evaluated first

    def matches(self, job: Job) -> bool:
        try:
            return bool(self.predicate(job))
        except Exception:
            return False


class Router:
    """
    Routes jobs to named queues based on ordered rules.

    Parameters
    ----------
    queues:
        Mapping of queue name → JobQueue instance.
    default:
        Name of the queue to use when no rule matches.
    """

    def __init__(
        self,
        queues:  dict[str, JobQueue],
        default: str = "default",
    ) -> None:
        if default not in queues:
            raise ValueError(f"Default queue {default!r} not in queues dict")
        self._queues  = queues
        self._default = default
        self._rules:  list[RoutingRule] = []
        self._lock    = threading.Lock()
        self._stats: dict[str, int] = {name: 0 for name in queues}

    # ── rule registration ─────────────────────────────────────────────────────

    def add_rule(
        self,
        predicate: Callable[[Job], bool],
        target:    str,
        name:      str = "",
        priority:  int = 0,
    ) -> "Router":
        """Add a routing rule. Returns self for chaining."""
        if target not in self._queues:
            raise ValueError(f"Target queue {target!r} not registered")
        rule = RoutingRule(predicate=predicate, target=target,
                           name=name, priority=priority)
        with self._lock:
            self._rules.append(rule)
            self._rules.sort(key=lambda r: -r.priority)
        return self

    def add_name_rule(self, pattern: str, target: str, name: str = "") -> "Router":
        """Route jobs whose ``name`` matches a glob *pattern* (e.g. ``"email_*"``)."""
        return self.add_rule(
            lambda job, p=pattern: fnmatch.fnmatch(job.name, p),
            target=target,
            name=name or f"name:{pattern}",
        )

    def add_tag_rule(self, tag: str, target: str, name: str = "") -> "Router":
        """Route jobs that have *tag* in their tags list."""
        return self.add_rule(
            lambda job, t=tag: t in (job.tags or []),
            target=target,
            name=name or f"tag:{tag}",
        )

    def add_priority_rule(
        self,
        min_priority: Priority,
        target: str,
        name:   str = "",
    ) -> "Router":
        """Route jobs whose priority >= *min_priority*."""
        return self.add_rule(
            lambda job, p=min_priority: job.priority.value >= p.value,
            target=target,
            name=name or f"priority>={min_priority.name}",
        )

    def add_payload_rule(
        self,
        key:    str,
        value:  Any,
        target: str,
        name:   str = "",
    ) -> "Router":
        """Route jobs where ``job.payload.get(key) == value``."""
        return self.add_rule(
            lambda job, k=key, v=value: job.payload.get(k) == v,
            target=target,
            name=name or f"payload[{key!r}]=={value!r}",
        )

    def remove_rule(self, name: str) -> int:
        """Remove all rules with the given name. Returns count removed."""
        with self._lock:
            before = len(self._rules)
            self._rules = [r for r in self._rules if r.name != name]
            return before - len(self._rules)

    def clear_rules(self) -> None:
        with self._lock:
            self._rules.clear()

    # ── routing ───────────────────────────────────────────────────────────────

    def resolve(self, job: Job) -> str:
        """Return the target queue name for *job* (does not enqueue)."""
        with self._lock:
            rules = list(self._rules)
        for rule in rules:
            if rule.matches(job):
                return rule.target
        return self._default

    def route(self, job: Job) -> str:
        """Enqueue *job* into the resolved target queue. Returns the queue name."""
        target = self.resolve(job)
        self._queues[target].enqueue(job)
        with self._lock:
            self._stats[target] = self._stats.get(target, 0) + 1
        return target

    def route_many(self, jobs: list[Job]) -> dict[str, int]:
        """Route a batch of jobs. Returns dict of queue_name → count routed."""
        counts: dict[str, int] = {}
        for job in jobs:
            target = self.route(job)
            counts[target] = counts.get(target, 0) + 1
        return counts

    # ── introspection ─────────────────────────────────────────────────────────

    def stats(self) -> dict:
        with self._lock:
            return {
                "routed": dict(self._stats),
                "rules":  [
                    {"name": r.name, "target": r.target, "priority": r.priority}
                    for r in self._rules
                ],
                "default": self._default,
            }

    def queue_depths(self) -> dict[str, int]:
        return {name: len(q) for name, q in self._queues.items()}

    def __repr__(self) -> str:
        return (f"Router(queues={list(self._queues)}, rules={len(self._rules)}, "
                f"default={self._default!r})")
