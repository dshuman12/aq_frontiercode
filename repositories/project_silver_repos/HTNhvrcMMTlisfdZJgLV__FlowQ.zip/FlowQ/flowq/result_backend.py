"""
Result backend for FlowQ.

Stores job results independently of the job record, with optional TTL-based
expiration. Useful when you want to query results long after a job has been
purged, or when results are large and shouldn't bloat the main jobs table.

Usage::

    from flowq.result_backend import ResultBackend

    rb = ResultBackend("results.db")

    # Store a result
    rb.store(job_id, {"rows": 1234, "elapsed": 0.5}, ttl=3600)

    # Retrieve it
    entry = rb.get(job_id)
    if entry and not entry.is_expired():
        print(entry.value)

    # Expire old entries
    rb.purge_expired()
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ResultEntry:
    job_id:     str
    value:      Any
    stored_at:  float
    expires_at: Optional[float]  # None = never expires
    metadata:   dict = field(default_factory=dict)

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at

    def ttl_remaining(self) -> Optional[float]:
        if self.expires_at is None:
            return None
        remaining = self.expires_at - time.time()
        return max(0.0, remaining)

    def to_dict(self) -> dict:
        return {
            "job_id":     self.job_id,
            "value":      self.value,
            "stored_at":  self.stored_at,
            "expires_at": self.expires_at,
            "metadata":   self.metadata,
        }


_SCHEMA = """
CREATE TABLE IF NOT EXISTS results (
    job_id     TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    stored_at  REAL NOT NULL,
    expires_at REAL,
    metadata   TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_results_expires ON results(expires_at)
    WHERE expires_at IS NOT NULL;
"""


class ResultBackend:
    """
    SQLite-backed result store with TTL support.

    Parameters
    ----------
    db_path:
        Path to the SQLite file (or ``:memory:`` for in-process storage).
    default_ttl:
        Default time-to-live in seconds. None means results never expire.
    """

    def __init__(
        self,
        db_path: str = "results.db",
        default_ttl: Optional[float] = None,
    ) -> None:
        self._db_path = db_path
        self._default_ttl = default_ttl
        self._local = threading.local()
        self._lock  = threading.Lock()
        self._init_db()

    # ── internals ─────────────────────────────────────────────────────────────

    def _conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn"):
            conn = sqlite3.connect(self._db_path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    def _init_db(self) -> None:
        with self._lock:
            conn = self._conn()
            conn.executescript(_SCHEMA)
            conn.commit()

    @contextmanager
    def _cursor(self):
        conn = self._conn()
        cur  = conn.cursor()
        try:
            yield cur
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cur.close()

    # ── public API ────────────────────────────────────────────────────────────

    def store(
        self,
        job_id:   str,
        value:    Any,
        ttl:      Optional[float] = None,
        metadata: Optional[dict]  = None,
        overwrite: bool           = True,
    ) -> ResultEntry:
        """
        Persist *value* for *job_id*.

        Parameters
        ----------
        job_id:    Unique job identifier.
        value:     JSON-serialisable result value.
        ttl:       Seconds until expiry. Falls back to ``default_ttl``.
        metadata:  Optional dict of additional fields (labels, version, etc.).
        overwrite: If False and a result already exists, raise ``KeyError``.
        """
        effective_ttl = ttl if ttl is not None else self._default_ttl
        now        = time.time()
        expires_at = now + effective_ttl if effective_ttl is not None else None
        meta       = metadata or {}

        entry = ResultEntry(
            job_id=job_id,
            value=value,
            stored_at=now,
            expires_at=expires_at,
            metadata=meta,
        )

        with self._cursor() as cur:
            if overwrite:
                cur.execute(
                    """INSERT OR REPLACE INTO results
                       (job_id, value, stored_at, expires_at, metadata)
                       VALUES (?, ?, ?, ?, ?)""",
                    (job_id, json.dumps(value, default=str),
                     now, expires_at, json.dumps(meta)),
                )
            else:
                try:
                    cur.execute(
                        """INSERT INTO results
                           (job_id, value, stored_at, expires_at, metadata)
                           VALUES (?, ?, ?, ?, ?)""",
                        (job_id, json.dumps(value, default=str),
                         now, expires_at, json.dumps(meta)),
                    )
                except sqlite3.IntegrityError:
                    raise KeyError(f"Result for {job_id!r} already exists")

        return entry

    def get(self, job_id: str) -> Optional[ResultEntry]:
        """Return the ``ResultEntry`` for *job_id*, or ``None`` if not found."""
        with self._cursor() as cur:
            cur.execute("SELECT * FROM results WHERE job_id = ?", (job_id,))
            row = cur.fetchone()
        if row is None:
            return None
        return ResultEntry(
            job_id=row["job_id"],
            value=json.loads(row["value"]),
            stored_at=row["stored_at"],
            expires_at=row["expires_at"],
            metadata=json.loads(row["metadata"]),
        )

    def get_value(self, job_id: str, default: Any = None) -> Any:
        """Return the raw value for *job_id*, or *default* if absent / expired."""
        entry = self.get(job_id)
        if entry is None or entry.is_expired():
            return default
        return entry.value

    def exists(self, job_id: str) -> bool:
        """Return True if a non-expired result exists for *job_id*."""
        entry = self.get(job_id)
        return entry is not None and not entry.is_expired()

    def delete(self, job_id: str) -> bool:
        """Delete the result for *job_id*. Returns True if a row was removed."""
        with self._cursor() as cur:
            cur.execute("DELETE FROM results WHERE job_id = ?", (job_id,))
            return cur.rowcount > 0

    def purge_expired(self) -> int:
        """Delete all expired entries. Returns the number of rows deleted."""
        now = time.time()
        with self._cursor() as cur:
            cur.execute(
                "DELETE FROM results WHERE expires_at IS NOT NULL AND expires_at < ?",
                (now,),
            )
            return cur.rowcount

    def list_recent(self, limit: int = 100) -> list[ResultEntry]:
        """Return the most recently stored entries, newest first."""
        with self._cursor() as cur:
            cur.execute(
                "SELECT * FROM results ORDER BY stored_at DESC LIMIT ?",
                (limit,),
            )
            rows = cur.fetchall()
        return [
            ResultEntry(
                job_id=r["job_id"],
                value=json.loads(r["value"]),
                stored_at=r["stored_at"],
                expires_at=r["expires_at"],
                metadata=json.loads(r["metadata"]),
            )
            for r in rows
        ]

    def count(self) -> int:
        """Total number of stored results (including expired)."""
        with self._cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM results")
            return cur.fetchone()[0]

    def stats(self) -> dict:
        now = time.time()
        with self._cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM results")
            total = cur.fetchone()[0]
            cur.execute(
                "SELECT COUNT(*) FROM results WHERE expires_at IS NOT NULL AND expires_at < ?",
                (now,),
            )
            expired = cur.fetchone()[0]
        return {
            "total": total,
            "expired": expired,
            "active": total - expired,
        }

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn:
            conn.close()
            del self._local.conn


# Global default result backend (in-memory, no TTL)
default_result_backend = ResultBackend(":memory:")
