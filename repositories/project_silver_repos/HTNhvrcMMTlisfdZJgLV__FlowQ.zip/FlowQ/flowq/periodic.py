"""
Periodic task beat for FlowQ.

Higher-level than the Scheduler — lets you register tasks by interval rather
than cron expression, with support for jitter, max_instances guards, and
run-history tracking.

Usage::

    from flowq.periodic import Beat, PeriodicTask

    beat = Beat(queue=queue, storage=storage)

    @beat.every(60, name="sync_cache")
    def sync_cache():
        ...

    beat.register(PeriodicTask(
        name="hourly_report",
        handler="generate_report",
        interval=3600,
        payload={"format": "pdf"},
        jitter=30,            # randomise start time by ±30s
    ))

    beat.start()   # background thread
"""

from __future__ import annotations

import random
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from flowq.models  import Job, Priority
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.worker  import register as _register


@dataclass
class PeriodicTask:
    """Defines a task that runs on a fixed interval."""

    name:          str
    handler:       str
    interval:      float            # seconds between runs
    payload:       dict             = field(default_factory=dict)
    priority:      Priority         = Priority.NORMAL
    max_retries:   int              = 0
    jitter:        float            = 0.0   # random ±jitter seconds added to interval
    enabled:       bool             = True
    max_instances: int              = 1     # skip if this many instances are running
    tags:          list[str]        = field(default_factory=list)

    # runtime
    last_run:      Optional[float]  = field(default=None, init=False)
    run_count:     int              = field(default=0, init=False)
    skip_count:    int              = field(default=0, init=False)

    def next_due(self) -> float:
        """Timestamp when this task is next due to run."""
        if self.last_run is None:
            return 0.0   # immediately on first run (always in the past)
        jitter = random.uniform(-self.jitter, self.jitter) if self.jitter > 0 else 0
        return self.last_run + self.interval + jitter

    def is_due(self) -> bool:
        return self.enabled and time.time() >= self.next_due()


@dataclass
class RunRecord:
    task_name: str
    job_id:    str
    fired_at:  float
    skipped:   bool = False
    reason:    str  = ""


class Beat:
    """
    Periodic task scheduler (interval-based alternative to cron).

    Parameters
    ----------
    queue:
        ``JobQueue`` to push periodic jobs into.
    storage:
        ``Storage`` for persisting periodic jobs.
    tick_interval:
        How often (in seconds) to check which tasks are due.
    """

    def __init__(
        self,
        queue:         Optional[JobQueue]  = None,
        storage:       Optional[Storage]   = None,
        tick_interval: float               = 1.0,
    ) -> None:
        self._queue   = queue
        self._storage = storage
        self._tick    = tick_interval
        self._tasks:  dict[str, PeriodicTask] = {}
        self._history: list[RunRecord]        = []
        self._lock    = threading.Lock()
        self._stop    = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ── registration ─────────────────────────────────────────────────────────

    def register(self, task: PeriodicTask) -> "Beat":
        with self._lock:
            self._tasks[task.name] = task
        return self

    def unregister(self, name: str) -> bool:
        with self._lock:
            return self._tasks.pop(name, None) is not None

    def every(
        self,
        interval:    float,
        name:        Optional[str]  = None,
        priority:    Priority       = Priority.NORMAL,
        max_retries: int            = 0,
        jitter:      float          = 0.0,
        tags:        Optional[list[str]] = None,
    ):
        """
        Decorator — register a function as a periodic task.

        Example::

            @beat.every(300, name="flush_metrics")
            def flush_metrics():
                ...
        """
        def decorator(fn: Callable) -> Callable:
            task_name = name or fn.__qualname__
            handler_name = f"beat.{task_name}"

            # Register the function as a FlowQ handler
            _register(handler_name)(lambda job: fn())

            task = PeriodicTask(
                name=task_name,
                handler=handler_name,
                interval=interval,
                priority=priority,
                max_retries=max_retries,
                jitter=jitter,
                tags=tags or [],
            )
            self.register(task)
            return fn

        return decorator

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="flowq-beat"
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self._tick * 3)

    # ── tick ─────────────────────────────────────────────────────────────────

    def _loop(self) -> None:
        while not self._stop.wait(timeout=self._tick):
            self.tick()

    def tick(self, now: Optional[float] = None) -> list[RunRecord]:
        """Check and fire all due tasks. Returns run records for this tick."""
        now = now or time.time()
        records = []

        with self._lock:
            tasks = list(self._tasks.values())

        for task in tasks:
            if not task.is_due():
                continue

            # Check max_instances via storage
            if task.max_instances > 0 and self._storage is not None:
                running = self._storage.list_jobs(limit=1000)
                active  = sum(
                    1 for j in running
                    if j.name == task.handler and j.status.name == "RUNNING"
                )
                if active >= task.max_instances:
                    task.skip_count += 1
                    records.append(RunRecord(
                        task_name=task.name,
                        job_id="",
                        fired_at=now,
                        skipped=True,
                        reason=f"max_instances={task.max_instances} already running",
                    ))
                    continue

            job = Job(
                name=task.handler,
                payload=dict(task.payload, _periodic_task=task.name),
                priority=task.priority,
                max_retries=task.max_retries,
                tags=task.tags + [f"beat:{task.name}"],
            )

            try:
                if self._storage is not None:
                    self._storage.save(job)
                if self._queue is not None:
                    self._queue.enqueue(job)
            except Exception:
                pass

            task.last_run  = now
            task.run_count += 1

            rec = RunRecord(task_name=task.name, job_id=job.id, fired_at=now)
            records.append(rec)
            with self._lock:
                self._history.append(rec)

        return records

    # ── introspection ─────────────────────────────────────────────────────────

    def tasks(self) -> list[PeriodicTask]:
        with self._lock:
            return list(self._tasks.values())

    def history(self, limit: int = 100) -> list[RunRecord]:
        with self._lock:
            return list(self._history[-limit:])

    def stats(self) -> dict:
        with self._lock:
            tasks = list(self._tasks.values())
            hist  = list(self._history)
        return {
            "task_count":   len(tasks),
            "total_runs":   sum(t.run_count for t in tasks),
            "total_skips":  sum(t.skip_count for t in tasks),
            "tick_interval": self._tick,
            "tasks": [
                {
                    "name":       t.name,
                    "handler":    t.handler,
                    "interval":   t.interval,
                    "enabled":    t.enabled,
                    "run_count":  t.run_count,
                    "skip_count": t.skip_count,
                    "last_run":   t.last_run,
                }
                for t in tasks
            ],
        }

    def __repr__(self) -> str:
        return f"Beat(tasks={len(self._tasks)}, tick={self._tick}s)"
