"""
Dynamic batch collector for FlowQ.

Instead of processing items one at a time, a Batcher accumulates items until
either a size threshold or a time window is exceeded, then flushes them all
to a handler in a single call.

This is useful for:
  - Bulk database inserts (fewer round-trips)
  - Sending messages in batches to external APIs
  - Aggregating metrics before writing

Usage::

    from flowq.batching import Batcher

    def flush_to_db(items):
        db.bulk_insert(items)

    batcher = Batcher(flush_to_db, max_size=100, max_wait=5.0)
    batcher.start()

    for record in records:
        batcher.add(record)

    batcher.stop()   # flushes any remaining items
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, Optional, TypeVar

T = TypeVar("T")


@dataclass
class BatchResult:
    batch_id:   int
    item_count: int
    flush_time: float
    error:      Optional[Exception] = None

    @property
    def ok(self) -> bool:
        return self.error is None


class BatcherError(Exception):
    pass


class Batcher(Generic[T]):
    """
    Accumulates items and periodically flushes them to a handler.

    Parameters
    ----------
    handler:
        Callable that receives a list of items to process.
    max_size:
        Flush when the buffer reaches this many items.
    max_wait:
        Flush after at most this many seconds even if ``max_size`` not reached.
    on_error:
        Called with (batch, exception) if the handler raises. If None, the
        exception is re-raised and the batcher stops.
    name:
        Human-readable identifier for logging.
    """

    def __init__(
        self,
        handler:  Callable[[list[T]], Any],
        max_size: int = 100,
        max_wait: float = 5.0,
        on_error: Optional[Callable[[list[T], Exception], None]] = None,
        name:     str = "batcher",
    ) -> None:
        if max_size < 1:
            raise ValueError("max_size must be >= 1")
        if max_wait <= 0:
            raise ValueError("max_wait must be > 0")

        self._handler   = handler
        self._max_size  = max_size
        self._max_wait  = max_wait
        self._on_error  = on_error
        self.name       = name

        self._buffer:   list[T]          = []
        self._lock      = threading.Lock()
        self._flush_event = threading.Event()
        self._stop_event  = threading.Event()
        self._thread:   Optional[threading.Thread] = None
        self._last_flush = time.monotonic()
        self._batch_id  = 0
        self._results:  list[BatchResult] = []

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the background flush thread."""
        if self._thread and self._thread.is_alive():
            raise BatcherError("Batcher is already running")
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop, name=f"batcher-{self.name}", daemon=True
        )
        self._thread.start()

    def stop(self, drain: bool = True) -> None:
        """Stop the batcher. If *drain* is True, flush any remaining items first."""
        self._stop_event.set()
        self._flush_event.set()
        if self._thread:
            self._thread.join(timeout=self._max_wait * 2)
        if drain:
            with self._lock:
                batch = list(self._buffer)
                self._buffer.clear()
            if batch:
                self._do_flush(batch)

    # ── item ingestion ────────────────────────────────────────────────────────

    def add(self, item: T) -> None:
        """Add one item to the buffer, flushing immediately if max_size reached."""
        with self._lock:
            self._buffer.append(item)
            should_flush = len(self._buffer) >= self._max_size

        if should_flush:
            self._flush_event.set()

    def add_many(self, items: list[T]) -> None:
        """Add multiple items at once."""
        with self._lock:
            self._buffer.extend(items)
            should_flush = len(self._buffer) >= self._max_size

        if should_flush:
            self._flush_event.set()

    def flush(self) -> Optional[BatchResult]:
        """Manually trigger a flush. Returns BatchResult or None if buffer empty."""
        with self._lock:
            batch = list(self._buffer)
            self._buffer.clear()
        if not batch:
            return None
        return self._do_flush(batch)

    # ── internals ─────────────────────────────────────────────────────────────

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            elapsed = time.monotonic() - self._last_flush
            wait    = max(0.0, self._max_wait - elapsed)
            triggered = self._flush_event.wait(timeout=wait)
            self._flush_event.clear()

            with self._lock:
                batch = list(self._buffer)
                self._buffer.clear()

            if batch:
                self._do_flush(batch)

    def _do_flush(self, batch: list[T]) -> BatchResult:
        self._batch_id += 1
        bid   = self._batch_id
        start = time.monotonic()
        error = None
        try:
            self._handler(batch)
        except Exception as exc:
            error = exc
            if self._on_error:
                self._on_error(batch, exc)
            else:
                raise
        finally:
            self._last_flush = time.monotonic()

        result = BatchResult(
            batch_id=bid,
            item_count=len(batch),
            flush_time=time.monotonic() - start,
            error=error,
        )
        self._results.append(result)
        return result

    # ── introspection ─────────────────────────────────────────────────────────

    @property
    def buffer_size(self) -> int:
        return len(self._buffer)

    @property
    def total_batches(self) -> int:
        return self._batch_id

    @property
    def total_items_flushed(self) -> int:
        return sum(r.item_count for r in self._results)

    def stats(self) -> dict:
        return {
            "name":          self.name,
            "buffer_size":   self.buffer_size,
            "total_batches": self.total_batches,
            "total_items":   self.total_items_flushed,
            "max_size":      self._max_size,
            "max_wait":      self._max_wait,
            "running":       self._thread is not None and self._thread.is_alive(),
        }

    def __repr__(self) -> str:
        return (f"Batcher(name={self.name!r}, max_size={self._max_size}, "
                f"max_wait={self._max_wait}, buffered={self.buffer_size})")
