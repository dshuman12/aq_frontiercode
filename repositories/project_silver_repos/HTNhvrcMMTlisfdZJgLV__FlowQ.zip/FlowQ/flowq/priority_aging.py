"""
Priority aging for FlowQ.

Jobs that have been waiting in PENDING status for a long time get their
effective priority boosted so they are not starved by a continuous stream
of higher-priority arrivals.

Usage::

    from flowq.priority_aging import PriorityAger, AgePolicy

    ager = PriorityAger(
        storage=storage,
        queue=queue,
        policy=AgePolicy(
            boost_after_seconds=120,  # start boosting after 2 min
            boost_per_minute=1,       # add 1 priority point per minute
            max_boost=15,             # cap boost so LOW can reach NORMAL
        ),
    )
    ager.start()   # runs in background, checks every 30s
    # ...
    ager.stop()
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Optional

from flowq.models  import Job, JobStatus, Priority
from flowq.queue   import JobQueue
from flowq.storage import Storage


@dataclass
class AgePolicy:
    """Controls how pending jobs are boosted over time."""

    boost_after_seconds: float = 120.0
    """Start boosting jobs that have been pending longer than this."""

    boost_per_minute:    float = 1.0
    """Effective priority points added per minute of waiting (after threshold)."""

    max_boost:           int   = 15
    """Maximum total boost (capped so a job cannot exceed CRITICAL.value)."""

    min_priority:        int   = Priority.LOW.value
    """Only boost jobs whose current priority >= this value."""

    @property
    def max_effective_priority(self) -> int:
        return Priority.CRITICAL.value


@dataclass
class BoostRecord:
    job_id:          str
    original_priority: int
    boosted_priority: int
    pending_seconds:  float
    boosted_at:       float = field(default_factory=time.time)


class PriorityAger:
    """
    Background service that scans pending jobs and boosts stale ones.

    Parameters
    ----------
    storage:
        Used to query PENDING jobs and update their priority.
    queue:
        The in-memory queue whose heap entries may need re-ordering.
    policy:
        ``AgePolicy`` controlling boost rates and thresholds.
    tick_interval:
        How often (in seconds) to run the aging scan.
    """

    def __init__(
        self,
        storage:       Storage,
        queue:         JobQueue,
        policy:        Optional[AgePolicy] = None,
        tick_interval: float               = 30.0,
    ) -> None:
        self._storage  = storage
        self._queue    = queue
        self._policy   = policy or AgePolicy()
        self._tick     = tick_interval
        self._thread:  Optional[threading.Thread] = None
        self._stop     = threading.Event()
        self._boosts:  list[BoostRecord] = []
        self._lock     = threading.Lock()

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="priority-ager"
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self._tick + 1)

    # ── aging logic ───────────────────────────────────────────────────────────

    def _loop(self) -> None:
        while not self._stop.wait(timeout=self._tick):
            self.tick()

    def tick(self) -> list[BoostRecord]:
        """Run one aging scan. Returns a list of BoostRecords for boosted jobs."""
        now     = time.time()
        policy  = self._policy
        pending = self._storage.list_jobs(status=JobStatus.PENDING, limit=10000)
        boosted = []

        for job in pending:
            created = job.created_at
            if created is None:
                continue
            ts = created.timestamp() if hasattr(created, "timestamp") else float(created)
            pending_seconds = now - ts

            if pending_seconds < policy.boost_after_seconds:
                continue
            if job.priority.value < policy.min_priority:
                continue

            # Compute boost
            excess_minutes = (pending_seconds - policy.boost_after_seconds) / 60.0
            boost = min(int(excess_minutes * policy.boost_per_minute), policy.max_boost)
            if boost == 0:
                continue

            new_value = min(
                job.priority.value + boost,
                policy.max_effective_priority,
            )
            if new_value <= job.priority.value:
                continue

            # Find the closest Priority enum value
            best_priority = job.priority
            for p in Priority:
                if p.value <= new_value:
                    best_priority = p

            if best_priority == job.priority:
                continue

            record = BoostRecord(
                job_id=job.id,
                original_priority=job.priority.value,
                boosted_priority=best_priority.value,
                pending_seconds=pending_seconds,
            )

            # Update in storage
            try:
                job.priority = best_priority
                self._storage.update(job)
                with self._lock:
                    self._boosts.append(record)
                boosted.append(record)
            except Exception:
                pass

        return boosted

    # ── introspection ─────────────────────────────────────────────────────────

    def boost_history(self, limit: int = 100) -> list[BoostRecord]:
        with self._lock:
            return list(self._boosts[-limit:])

    def stats(self) -> dict:
        with self._lock:
            total = len(self._boosts)
        return {
            "total_boosts":  total,
            "tick_interval": self._tick,
            "policy": {
                "boost_after_seconds": self._policy.boost_after_seconds,
                "boost_per_minute":    self._policy.boost_per_minute,
                "max_boost":           self._policy.max_boost,
            },
        }

    def __repr__(self) -> str:
        return (f"PriorityAger(tick={self._tick}s, "
                f"boost_after={self._policy.boost_after_seconds}s)")
