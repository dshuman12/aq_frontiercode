"""
High-level task API for FlowQ.

Inspired by Celery's @task decorator — wraps a plain Python function so it can
be called normally OR dispatched as an asynchronous job.

Usage::

    from flowq.tasks import task, TaskRegistry

    registry = TaskRegistry(queue=queue, storage=storage)

    @registry.task(priority=Priority.HIGH, max_retries=3)
    def send_invoice(customer_id: int, amount: float):
        ...

    # Call synchronously (normal function call)
    send_invoice(42, 99.99)

    # Dispatch asynchronously (enqueues a Job)
    send_invoice.delay(42, 99.99)
    send_invoice.apply_async(42, 99.99, countdown=10)
"""

from __future__ import annotations

import functools
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from flowq.models  import Job, Priority
from flowq.queue   import JobQueue
from flowq.storage import Storage
from flowq.worker  import register as _register_handler


@dataclass
class AsyncResult:
    """Handle for a dispatched task — lets you poll for completion."""
    job_id:   str
    _storage: Optional[Any] = field(default=None, repr=False)

    def get(self, timeout: Optional[float] = None, poll_interval: float = 0.2) -> Any:
        """Block until the job completes. Returns ``job.result`` or raises."""
        if self._storage is None:
            raise RuntimeError("No storage configured; cannot poll for result")
        deadline = time.time() + timeout if timeout else None
        while True:
            job = self._storage.fetch(self.job_id)
            if job.status.name == "SUCCESS":
                return job.result
            if job.status.name in ("FAILED", "CANCELLED"):
                raise RuntimeError(
                    f"Job {self.job_id} ended with status {job.status.name}: {job.error}"
                )
            if deadline and time.time() > deadline:
                raise TimeoutError(f"Timed out waiting for job {self.job_id}")
            time.sleep(poll_interval)

    def status(self) -> str:
        if self._storage is None:
            return "UNKNOWN"
        job = self._storage.fetch(self.job_id)
        return job.status.name


class Task:
    """
    Wraps a function so it can be called normally or dispatched as a Job.

    Do not instantiate directly — use ``TaskRegistry.task()``.
    """

    def __init__(
        self,
        func:        Callable,
        registry:    "TaskRegistry",
        name:        Optional[str]  = None,
        priority:    Priority       = Priority.NORMAL,
        max_retries: int            = 0,
        timeout:     int            = 300,
        tags:        list[str]      = None,
    ) -> None:
        self._func        = func
        self._registry    = registry
        self.name         = name or f"{func.__module__}.{func.__qualname__}"
        self.priority     = priority
        self.max_retries  = max_retries
        self.timeout      = timeout
        self.tags         = tags or []
        functools.update_wrapper(self, func)

    def __call__(self, *args, **kwargs):
        """Call the underlying function directly (synchronous)."""
        return self._func(*args, **kwargs)

    def delay(self, *args, **kwargs) -> AsyncResult:
        """Enqueue the task for asynchronous execution."""
        return self.apply_async(*args, **kwargs)

    def apply_async(
        self,
        *args,
        countdown:   float        = 0,
        priority:    Optional[Priority] = None,
        max_retries: Optional[int] = None,
        tags:        Optional[list[str]] = None,
        **kwargs,
    ) -> AsyncResult:
        """
        Enqueue the task, returning an AsyncResult handle.

        Parameters
        ----------
        countdown:
            Seconds to wait before the job is eligible for execution
            (implemented as a tag ``eta:<timestamp>``).
        """
        payload = {"args": list(args), "kwargs": kwargs}
        if countdown > 0:
            eta = time.time() + countdown
            extra_tags = [f"eta:{eta:.0f}"]
        else:
            extra_tags = []

        job = Job(
            name=self.name,
            payload=payload,
            priority=priority or self.priority,
            max_retries=max_retries if max_retries is not None else self.max_retries,
            timeout=self.timeout,
            tags=self.tags + extra_tags + (tags or []),
        )

        storage = self._registry.storage
        queue   = self._registry.queue

        if storage is not None:
            storage.save(job)
        if queue is not None:
            queue.enqueue(job)

        return AsyncResult(job_id=job.id, _storage=storage)

    def signature(self, *args, **kwargs) -> dict:
        """Return a JSON-serialisable task signature (for deferred dispatch)."""
        return {
            "task": self.name,
            "args": list(args),
            "kwargs": kwargs,
            "priority": self.priority.name,
            "max_retries": self.max_retries,
        }

    def __repr__(self) -> str:
        return f"Task(name={self.name!r}, priority={self.priority.name})"


class TaskRegistry:
    """
    Manages task registration and wires tasks into FlowQ's worker system.

    Parameters
    ----------
    queue:
        ``JobQueue`` to enqueue async tasks into.
    storage:
        ``Storage`` to persist jobs.
    """

    def __init__(
        self,
        queue:   Optional[JobQueue]   = None,
        storage: Optional[Storage]    = None,
    ) -> None:
        self.queue   = queue
        self.storage = storage
        self._tasks: dict[str, Task] = {}

    def task(
        self,
        func:        Optional[Callable] = None,
        *,
        name:        Optional[str]  = None,
        priority:    Priority       = Priority.NORMAL,
        max_retries: int            = 0,
        timeout:     int            = 300,
        tags:        Optional[list[str]] = None,
    ):
        """
        Decorator that registers a function as a FlowQ task.

        Can be used with or without arguments::

            @registry.task
            def my_task(): ...

            @registry.task(priority=Priority.HIGH, max_retries=3)
            def important_task(): ...
        """
        def decorator(fn: Callable) -> Task:
            t = Task(
                func=fn,
                registry=self,
                name=name,
                priority=priority,
                max_retries=max_retries,
                timeout=timeout,
                tags=tags or [],
            )
            self._tasks[t.name] = t

            # Register the handler so FlowQ workers can execute it
            # Worker passes job.payload (a dict) to handlers, not the Job itself
            def _handler(payload: dict) -> Any:
                args   = payload.get("args", [])
                kwargs = payload.get("kwargs", {})
                return fn(*args, **kwargs)

            _register_handler(t.name)(_handler)
            return t

        if func is not None:
            return decorator(func)
        return decorator

    def get(self, name: str) -> Optional[Task]:
        return self._tasks.get(name)

    def all_tasks(self) -> list[Task]:
        return list(self._tasks.values())

    def send_task(self, name: str, *args, **kwargs) -> AsyncResult:
        """Dispatch a task by name (useful when you only have the name string)."""
        t = self._tasks.get(name)
        if t is None:
            raise KeyError(f"No task registered as {name!r}")
        return t.delay(*args, **kwargs)

    def __len__(self) -> int:
        return len(self._tasks)

    def __repr__(self) -> str:
        return f"TaskRegistry(tasks={list(self._tasks)}, queue={self.queue!r})"
