# Security Policy

## Supported versions

| Version | Supported |
|---|---|
| 0.3.x | Yes |
| < 0.3 | No |

## Reporting a vulnerability

Please **do not** open a public GitHub issue for security vulnerabilities.

Email the maintainers privately.  We will acknowledge within 48 hours and
provide a fix within 14 days for confirmed issues.

## Scope

- SQL injection via job payloads (the SQLite backend uses parameterised queries)
- Path traversal in `FileBackend.root_dir`
- RCE via pickle deserialisation in `PickleSerializer` (only use with trusted data)
- Dashboard SSRF or information leakage

## Out of scope

- Denial of service via large payloads (FlowQ is not a public-facing service)
- Brute-force attacks on the dashboard (add your own auth layer)
