# Architecture

deptrack is structured as a pipeline:

1. **Parsers** — read dependency files and produce `Dependency` objects
2. **Checkers** — inspect dependency lists and emit `Issue` objects  
3. **Audit engine** — orchestrates parsers and checkers into an `AuditResult`
4. **Reporters** — format `AuditResult` as text, JSON, or HTML
5. **CLI** — user-facing entrypoint delegating to the audit engine

## Adding a new checker

Create a module in `deptrack/checkers/`, implement a function with signature:
`def check_foo(deps: list[Dependency], result: AuditResult) -> None`
Then register it in `deptrack/audit.py`.
