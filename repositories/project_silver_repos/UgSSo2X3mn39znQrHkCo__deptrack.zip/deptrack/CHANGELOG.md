# Changelog

## [0.2.0] - 2024-09-03
### Added
- Pre-release version checker
- lockfile_is_stale convenience helper
- Mobile-friendly HTML reports

### Fixed
- Text reporter now sorts by severity then package name
- Requirements glob pattern for file discovery

## [0.1.0] - 2024-01-08
### Added
- Initial release
- requirements.txt and pyproject.toml parsers
- Duplicate, version, and security checkers
- Text, JSON, HTML reporters
- Lockfile generation and verification
- CLI with audit, lock, verify subcommands

## [0.3.0] - 2025-01-10
### Added
- setup.cfg and Pipfile parsers
- Dependency graph analysis (cycles, transitive deps, depth)
- Plugin system for custom checkers
- PyPI integration for outdated package detection
- PEP 508 marker evaluation
- License compliance checker
- .deptrack.toml configuration file support

## [0.4.0] - 2025-03-01
### Added
- SARIF 2.1.0 export for GitHub Code Scanning integration
- CSV, Markdown, JUnit XML export formats
- Version constraint resolver with conflict detection
- Expanded models: VersionSpec, PackageMetadata, DependencySet, ResolutionResult
- Yanked and unmaintained package checkers
- Config-aware audit engine (run_audit_with_config)
- Audit comparison (compare_audits) for CI regression detection

### Fixed
- JUnit XML byte/string encoding issue
