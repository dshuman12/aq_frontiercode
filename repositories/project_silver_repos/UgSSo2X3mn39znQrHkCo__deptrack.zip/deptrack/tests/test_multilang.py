"""Comprehensive tests for deptrack multilang module."""

import os
import tempfile
from pathlib import Path

import pytest

from deptrack.multilang import (
    Ecosystem,
    Package,
    RequirementsTxtParser,
    PipfileParser,
    PackageLockParser,
    NpmLockParser,
    YarnLockParser,
    PnpmLockParser,
    PomXmlParser,
    GoModParser,
    CargoTomlParser,
    GemfileParser,
    ComposerJsonParser,
    DotNetParser,
    PackageRegistry,
    detect_ecosystem,
)


class TestEcosystem:
    """Tests for Ecosystem enum."""

    def test_values(self):
        assert Ecosystem.PYTHON.value == "python"
        assert Ecosystem.NPM.value == "npm"
        assert Ecosystem.MAVEN.value == "maven"
        assert Ecosystem.GO.value == "go"
        assert Ecosystem.CARGO.value == "cargo"
        assert Ecosystem.RUBY.value == "ruby"
        assert Ecosystem.COMPOSER.value == "composer"
        assert Ecosystem.DOTNET.value == "dotnet"

    def test_all_ecosystems_have_parsers(self):
        for eco in Ecosystem:
            assert eco.parser_class is not None


class TestPackage:
    """Tests for Package dataclass."""

    def test_creation(self):
        pkg = Package(
            name="requests",
            version="2.28.0",
            ecosystem=Ecosystem.PYTHON,
        )
        assert pkg.name == "requests"
        assert pkg.version == "2.28.0"
        assert pkg.ecosystem == Ecosystem.PYTHON

    def test_to_purl(self):
        pkg = Package(
            name="requests",
            version="2.28.0",
            ecosystem=Ecosystem.PYTHON,
        )
        purl = pkg.to_purl()
        assert "pypi" in purl
        assert "requests" in purl
        assert "2.28.0" in purl

    def test_equality(self):
        pkg1 = Package(name="requests", version="2.0.0", ecosystem=Ecosystem.PYTHON)
        pkg2 = Package(name="requests", version="2.0.0", ecosystem=Ecosystem.PYTHON)
        pkg3 = Package(name="requests", version="2.1.0", ecosystem=Ecosystem.PYTHON)

        assert pkg1 == pkg2
        assert pkg1 != pkg3


class TestRequirementsTxtParser:
    """Tests for Requirements.txt parser."""

    def test_parse_simple(self):
        content = """
requests==2.28.0
flask==2.3.0
        """
        parser = RequirementsTxtParser()
        packages = parser.parse(content)

        assert len(packages) >= 2
        names = [p.name for p in packages]
        assert "requests" in names
        assert "flask" in names

    def test_parse_with_comments(self):
        content = """
# This is a comment
requests==2.28.0  # inline comment
flask>=2.0.0
        """
        parser = RequirementsTxtParser()
        packages = parser.parse(content)

        assert len(packages) >= 2

    def test_parse_operators(self):
        content = """
requests>=2.0.0
django~=3.0
flask==2.0.0
        """
        parser = RequirementsTxtParser()
        packages = parser.parse(content)

        for pkg in packages:
            assert pkg.version is not None

    def test_parse_options_lines(self):
        content = """
-r base.txt
--index-url https://pypi.org/simple
requests==2.28.0
        """
        parser = RequirementsTxtParser()
        packages = parser.parse(content)

        assert len(packages) == 1  # Only actual packages

    def test_roundtrip(self):
        content = "requests==2.28.0\nflask==2.3.0\n"
        parser = RequirementsTxtParser()
        packages = parser.parse(content)
        output = parser.generate(packages)

        assert "requests" in output
        assert "2.28.0" in output


class TestPipfileParser:
    """Tests for Pipfile parser."""

    def test_parse_packages_section(self):
        content = """
[[source]]
url = "https://pypi.org/simple"
verify_ssl = true
name = "pypi"

[packages]
requests = "*"
flask = "~=2.3"
django = {version = "==4.0", extras = ["argon2"]}

[dev-packages]
pytest = "*"
        """
        parser = PipfileParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "requests" in names
        assert "flask" in names
        assert "django" in names
        assert "pytest" not in names  # dev package

    def test_parse_version_specifiers(self):
        content = """
[packages]
pkg1 = "*"
pkg2 = ">=1.0"
pkg3 = "~=2.0"
pkg4 = "==1.5.0"
        """
        parser = PipfileParser()
        packages = parser.parse(content)

        for pkg in packages:
            assert pkg.version is not None


class TestPackageLockParser:
    """Tests for package-lock.json parser."""

    def test_parse_simple(self):
        content = """
{
  "name": "my-project",
  "lockfileVersion": 2,
  "packages": {
    "node_modules/requests": {
      "version": "2.28.0",
      "resolved": "https://registry.npmjs.org/requests/-/requests-2.28.0.tgz"
    },
    "node_modules/flask": {
      "version": "1.0.0"
    }
  }
}
        """
        parser = PackageLockParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "requests" in names
        assert "flask" in names

    def test_parse_nested_dependencies(self):
        content = """
{
  "name": "my-project",
  "lockfileVersion": 2,
  "packages": {
    "node_modules/pkg-a": {
      "version": "1.0.0",
      "dependencies": {
        "pkg-b": "^2.0.0"
      }
    }
  }
}
        """
        parser = PackageLockParser()
        packages = parser.parse(content)

        # Should include both pkg-a and its dependency
        names = [p.name for p in packages]
        assert "pkg-a" in names


class TestNpmLockParser:
    """Tests for npm package-lock.json parser."""

    def test_get_registry_url(self):
        parser = NpmLockParser()
        url = parser._get_registry_url()
        assert "registry.npmjs.org" in url


class TestYarnLockParser:
    """Tests for yarn.lock parser."""

    def test_parse_yarn_entry(self):
        content = """
requests@^2.28.0:
  version "2.28.0"
  resolved "https://registry.yarnpkg.com/requests/-/requests-2.28.0.tgz"
  integrity sha512 sha1-2.3. sha256==
  dependencies:
    blah "1.0.0"

flask@~1.0.0:
  version "1.0.0"
  resolved "https://registry.yarnpkg.com/flask/-/flask-1.0.0.tgz"
        """
        parser = YarnLockParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "requests" in names
        assert "flask" in names


class TestPnpmLockParser:
    """Tests for pnpm-lock.yaml parser."""

    def test_parse_pnpm_entry(self):
        content = """
/node_modules/requests:
  version: 2.28.0
  resolution: {integrity: sha1-2-3-4 sha256}
/node_modules/flask:
  version: 1.0.0
  resolution: {integrity: sha1-1-1-3-5 sha256}
        """
        parser = PnpmLockParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "requests" in names
        assert "flask" in names


class TestPomXmlParser:
    """Tests for Maven pom.xml parser."""

    def test_parse_simple_dependencies(self):
        content = """
<project>
  <groupId>com.example</groupId>
  <artifactId>my-app</artifactId>
  <version>1.0.0</version>

  <dependencies>
    <dependency>
      <groupId>org.apache.commons</groupId>
      <artifactId>commons-lang3</artifactId>
      <version>3.12.0</version>
    </dependency>
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.13.2</version>
    </dependency>
  </dependencies>
</project>
        """
        parser = PomXmlParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "commons-lang3" in names
        assert "junit" in names

    def test_parse_properties(self):
        content = """
<project>
  <properties>
    <spring.version>5.3.20</spring.version>
  </properties>
  <dependencies>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-core</artifactId>
      <version>${spring.version}</version>
    </dependency>
  </dependencies>
</project>
        """
        parser = PomXmlParser()
        packages = parser.parse(content)

        # Should resolve property to actual version
        assert len(packages) == 1

    def test_parse_scope(self):
        content = """
<project>
  <dependencies>
    <dependency>
      <groupId>org.apache.commons</groupId>
      <artifactId>commons-lang3</artifactId>
      <version>3.12.0</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
</project>
        """
        parser = PomXmlParser()
        packages = parser.parse(content)

        assert len(packages) == 1


class TestGoModParser:
    """Tests for go.mod parser."""

    def test_parse_simple(self):
        content = """
module github.com/user/project

go 1.20

require (
    github.com/gin-gonic/gin v1.9.0
    github.com/go-sql-driver/mysql v1.7.0
)
        """
        parser = GoModParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "gin" in names
        assert "mysql" in names

    def test_parse_with_replace(self):
        content = """
module github.com/user/project

require (
    github.com/original/pkg v1.0.0
)

replace github.com/original/pkg => github.com/fork/pkg v1.1.0
        """
        parser = GoModParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        # Should use the replaced version
        pkg = next(p for p in packages if "pkg" in p.name)
        assert "fork/pkg" in pkg.name

    def test_parse_conditional_versions(self):
        content = """
module github.com/user/project

go 1.20

require (
    github.com/pkg/errors v0.9.1
)
        """
        parser = GoModParser()
        packages = parser.parse(content)

        assert len(packages) >= 1


class TestCargoTomlParser:
    """Tests for Cargo.toml parser."""

    def test_parse_simple_dependencies(self):
        content = """
[package]
name = "my-project"
version = "0.1.0"
edition = "2021"

[dependencies]
serde = "1.0"
serde_json = "1.0"
tokio = { version = "1.0", features = ["full"] }
        """
        parser = CargoTomlParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "serde" in names
        assert "serde_json" in names
        assert "tokio" in names

    def test_parse_dev_dependencies(self):
        content = """
[package]
name = "my-project"
version = "0.1.0"

[dev-dependencies]
criterion = "0.5"
        """
        parser = CargoTomlParser()
        packages = parser.parse(content)

        # By default, include dev dependencies
        names = [p.name for p in packages]
        assert "criterion" in names

    def test_parse_optional_features(self):
        content = """
[package]
name = "my-project"

[features]
default = ["feature-a"]
feature-a = []
feature-b = []

[dependencies]
pkg-a = { version = "1.0", optional = true }
        """
        parser = CargoTomlParser()
        packages = parser.parse(content)

        assert len(packages) >= 1


class TestGemfileParser:
    """Tests for Gemfile parser."""

    def test_parse_simple(self):
        content = """
source 'https://rubygems.org'

gem 'rails', '~> 7.0'
gem 'puma'
gem 'sidekiq', '>= 6.0'
        """
        parser = GemfileParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "rails" in names
        assert "puma" in names
        assert "sidekiq" in names

    def test_parse_with_groups(self):
        content = """
source 'https://rubygems.org'

gem 'rails'

group :development do
  gem 'rubocop'
end

group :test do
  gem 'rspec'
end
        """
        parser = GemfileParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "rails" in names  # Always included
        # Dev/test groups may or may not be included based on parser settings

    def test_parse_conditional(self):
        content = """
source 'https://rubygems.org'

gem 'rails'

platforms :ruby do
  gem 'mysql2'
end
        """
        parser = GemfileParser()
        packages = parser.parse(content)

        assert len(packages) >= 1


class TestComposerJsonParser:
    """Tests for composer.json parser."""

    def test_parse_simple(self):
        content = """
{
    "name": "vendor/project",
    "require": {
        "php": ">=8.0",
        "laravel/framework": "^10.0",
        "guzzlehttp/guzzle": "^7.0"
    }
}
        """
        parser = ComposerJsonParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "laravel/framework" in names
        assert "guzzlehttp/guzzle" in names

    def test_parse_dev_dependencies(self):
        content = """
{
    "name": "vendor/project",
    "require": {
        "php": ">=8.0"
    },
    "require-dev": {
        "phpunit/phpunit": "^10.0"
    }
}
        """
        parser = ComposerJsonParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "phpunit/phpunit" in names


class TestDotNetParser:
    """Tests for .csproj parser."""

    def test_parse_simple(self):
        content = """
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net6.0</TargetFramework>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Newtonsoft.Json" Version="13.0.1" />
    <PackageReference Include="Serilog" Version="2.12.0" />
  </ItemGroup>
</Project>
        """
        parser = DotNetParser()
        packages = parser.parse(content)

        names = [p.name for p in packages]
        assert "Newtonsoft.Json" in names
        assert "Serilog" in names

    def test_parse_conditional(self):
        content = """
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net6.0</TargetFramework>
  </PropertyGroup>

  <ItemGroup Condition="'$(Configuration)' == 'Debug'">
    <PackageReference Include="Microsoft.Extensions.Logging.Debug" Version="6.0.0" />
  </ItemGroup>
</Project>
        """
        parser = DotNetParser()
        packages = parser.parse(content)

        # May include conditional packages based on configuration


class TestPackageRegistry:
    """Tests for PackageRegistry class."""

    def test_creation(self):
        registry = PackageRegistry()
        assert len(registry._parsers) > 0

    def test_register_parser(self):
        registry = PackageRegistry()
        registry.register_parser(Ecosystem.PYTHON, RequirementsTxtParser())
        assert Ecosystem.PYTHON in registry._parsers

    def test_get_parser_for_ecosystem(self):
        registry = PackageRegistry()
        parser = registry.get_parser(Ecosystem.PYTHON)
        assert parser is not None

    def test_detect_from_content(self):
        registry = PackageRegistry()

        content = "requests==2.28.0\nflask==2.3.0\n"
        ecosystem = registry.detect_from_content(content)
        assert ecosystem == Ecosystem.PYTHON

    def test_detect_from_file(self, tmp_path):
        registry = PackageRegistry()

        requirements_file = tmp_path / "requirements.txt"
        requirements_file.write_text("requests==2.28.0")

        ecosystem = registry.detect_from_file(requirements_file)
        assert ecosystem == Ecosystem.PYTHON


class TestDetectEcosystem:
    """Tests for detect_ecosystem function."""

    def test_detect_requirements_txt(self, tmp_path):
        file = tmp_path / "requirements.txt"
        file.write_text("requests==2.28.0")

        eco = detect_ecosystem(file)
        assert eco == Ecosystem.PYTHON

    def test_detect_package_json(self, tmp_path):
        file = tmp_path / "package.json"
        file.write_text('{"name": "test", "dependencies": {}}')

        eco = detect_ecosystem(file)
        assert eco == Ecosystem.NPM

    def test_detect_go_mod(self, tmp_path):
        file = tmp_path / "go.mod"
        file.write_text("module github.com/user/project\ngo 1.20")

        eco = detect_ecosystem(file)
        assert eco == Ecosystem.GO

    def test_detect_cargo_toml(self, tmp_path):
        file = tmp_path / "Cargo.toml"
        file.write_text("[package]\nname = 'test'")

        eco = detect_ecosystem(file)
        assert eco == Ecosystem.CARGO

    def test_detect_pom_xml(self, tmp_path):
        file = tmp_path / "pom.xml"
        file.write_text("<project><groupId>test</groupId></project>")

        eco = detect_ecosystem(file)
        assert eco == Ecosystem.MAVEN

    def test_unknown_file(self, tmp_path):
        file = tmp_path / "unknown.xyz"
        file.write_text("some content")

        eco = detect_ecosystem(file)
        assert eco is None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])