"""Comprehensive tests for deptrack CVE module."""

import datetime
import json
from pathlib import Path

import pytest

from deptrack.cve import (
    CVESeverity,
    CVE,
    AdvisoryDatabase,
    AdvisoryDatabaseLoader,
    VulnerabilityChecker,
    load_builtin_database,
    BUILTIN_ADVISORIES,
)


class TestCVESeverity:
    """Tests for CVE severity enum."""

    def test_from_cvss_score(self):
        assert CVESeverity.from_cvss_score(0.0) == CVESeverity.NONE
        assert CVESeverity.from_cvss_score(3.0) == CVESeverity.LOW
        assert CVESeverity.from_cvss_score(5.0) == CVESeverity.MEDIUM
        assert CVESeverity.from_cvss_score(7.5) == CVESeverity.HIGH
        assert CVESeverity.from_cvss_score(9.5) == CVESeverity.CRITICAL

    def test_from_string(self):
        assert CVESeverity.from_string("CRITICAL") == CVESeverity.CRITICAL
        assert CVESeverity.from_string("high") == CVESeverity.HIGH
        assert CVESeverity.from_string("M") == CVESeverity.MEDIUM
        assert CVESeverity.from_string("l") == CVESeverity.LOW


class TestCVE:
    """Tests for CVE class."""

    def test_creation(self):
        cve = CVE(
            cve_id="CVE-2024-0001",
            package_name="requests",
            affected_versions="<2.0.0",
            fixed_version="2.0.0",
            severity=CVESeverity.HIGH,
            cvss_score=7.5,
        )
        assert cve.cve_id == "CVE-2024-0001"
        assert cve.package_name == "requests"
        assert cve.affected_versions == "<2.0.0"

    def test_cve_url(self):
        cve = CVE(cve_id="CVE-2024-0001", package_name="test")
        assert cve.cve_url == "https://nvd.nist.gov/vuln/detail/CVE-2024-0001"

    def test_matches_version_exact(self):
        cve = CVE(
            cve_id="TEST-001",
            package_name="test",
            affected_versions="==1.0.0",
        )
        assert cve.matches_version("1.0.0")
        assert not cve.matches_version("1.0.1")

    def test_matches_version_less_than(self):
        cve = CVE(
            cve_id="TEST-001",
            package_name="test",
            affected_versions="<2.0.0",
        )
        assert cve.matches_version("1.9.9")
        assert cve.matches_version("1.0.0")
        assert not cve.matches_version("2.0.0")
        assert not cve.matches_version("2.1.0")

    def test_matches_version_greater_than(self):
        cve = CVE(
            cve_id="TEST-001",
            package_name="test",
            affected_versions=">=1.5.0",
        )
        assert cve.matches_version("1.5.0")
        assert cve.matches_version("2.0.0")
        assert not cve.matches_version("1.4.9")

    def test_matches_version_complex(self):
        cve = CVE(
            cve_id="TEST-001",
            package_name="test",
            affected_versions=">=1.0.0,<2.0.0",
        )
        assert cve.matches_version("1.5.0")
        assert cve.matches_version("1.0.0")
        assert not cve.matches_version("2.0.0")
        assert not cve.matches_version("0.9.0")

    def test_to_dict(self):
        cve = CVE(
            cve_id="CVE-2024-0001",
            package_name="requests",
            severity=CVESeverity.HIGH,
            cvss_score=7.5,
            published_date=datetime.date(2024, 1, 1),
        )
        data = cve.to_dict()
        assert data["cve_id"] == "CVE-2024-0001"
        assert data["package_name"] == "requests"
        assert data["severity"] == "HIGH"
        assert data["cvss_score"] == 7.5

    def test_from_dict(self):
        data = {
            "cve_id": "CVE-2024-0001",
            "package_name": "requests",
            "severity": "HIGH",
            "cvss_score": 7.5,
            "published_date": "2024-01-01",
        }
        cve = CVE.from_dict(data)
        assert cve.cve_id == "CVE-2024-0001"
        assert cve.severity == CVESeverity.HIGH
        assert cve.published_date == datetime.date(2024, 1, 1)

    def test_from_osv(self):
        osv_data = {
            "id": "OSV-2024-0001",
            "summary": "Test vulnerability",
            "affected": [{
                "package": {"name": "test-pkg", "ecosystem": "PyPI"},
                "ranges": [{
                    "type": "SEMVER",
                    "events": [{"introduced": "0"}, {"fixed": "2.0.0"}]
                }]
            }],
            "severity": [{"score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:N"}]
        }
        cve = CVE.from_osv(osv_data)
        assert cve.cve_id == "OSV-2024-0001"
        assert cve.package_name == "test-pkg"
        assert cve.fixed_version == "2.0.0"


class TestAdvisoryDatabase:
    """Tests for AdvisoryDatabase class."""

    def test_add_cve(self):
        db = AdvisoryDatabase()
        cve = CVE(cve_id="CVE-2024-0001", package_name="requests")
        db.add_cve(cve)

        assert db.total_cves == 1
        assert db.get_cve("CVE-2024-0001") is cve

    def test_package_index(self):
        db = AdvisoryDatabase()
        cve1 = CVE(cve_id="CVE-2024-0001", package_name="requests")
        cve2 = CVE(cve_id="CVE-2024-0002", package_name="requests")
        cve3 = CVE(cve_id="CVE-2024-0003", package_name="django")

        db.add_cve(cve1)
        db.add_cve(cve2)
        db.add_cve(cve3)

        requests_cves = db.get_for_package("requests")
        assert len(requests_cves) == 2

        django_cves = db.get_for_package("django")
        assert len(django_cves) == 1

    def test_check_package_version(self):
        db = AdvisoryDatabase()
        cve = CVE(
            cve_id="CVE-2024-0001",
            package_name="requests",
            affected_versions="<2.0.0",
        )
        db.add_cve(cve)

        results = db.check_package_version("requests", "1.9.0")
        assert len(results) == 1
        assert results[0][0] is cve
        assert results[0][1] is True  # is_affected

        results = db.check_package_version("requests", "2.0.0")
        assert results[0][1] is False  # not affected

    def test_to_dict(self):
        db = AdvisoryDatabase()
        cve = CVE(cve_id="CVE-2024-0001", package_name="requests")
        db.add_cve(cve)

        data = db.to_dict()
        assert "cves" in data
        assert "CVE-2024-0001" in data["cves"]

    def test_from_dict(self):
        db = AdvisoryDatabase()
        cve = CVE(cve_id="CVE-2024-0001", package_name="requests")
        db.add_cve(cve)

        data = db.to_dict()
        restored = AdvisoryDatabase.from_dict(data)

        assert restored.total_cves == 1
        assert restored.get_cve("CVE-2024-0001") is not None

    def test_summary(self):
        db = AdvisoryDatabase()
        db.add_cve(CVE(cve_id="C-1", package_name="p1", severity=CVESeverity.CRITICAL))
        db.add_cve(CVE(cve_id="C-2", package_name="p1", severity=CVESeverity.HIGH))
        db.add_cve(CVE(cve_id="C-3", package_name="p2", severity=CVESeverity.MEDIUM))

        summary = db.summary()
        assert summary["total_cves"] == 3
        assert summary["total_packages"] == 2
        assert summary["by_severity"]["critical"] == 1
        assert summary["by_severity"]["high"] == 1
        assert summary["by_severity"]["medium"] == 1


class TestAdvisoryDatabaseLoader:
    """Tests for AdvisoryDatabaseLoader class."""

    def test_load_from_json(self, tmp_path):
        db = AdvisoryDatabase()
        cve = CVE(cve_id="CVE-2024-0001", package_name="requests")
        db.add_cve(cve)

        loader = AdvisoryDatabaseLoader()
        loader.save_to_json(db, tmp_path / "advisories.json")

        loaded = loader.load_from_json(tmp_path / "advisories.json")
        assert loaded.total_cves == 1
        assert loaded.get_cve("CVE-2024-0001") is not None

    def test_load_from_csv(self, tmp_path):
        csv_content = """cve_id,package_name,affected_versions,severity
CVE-2024-0001,requests,<2.0.0,HIGH
CVE-2024-0002,django,<3.0.0,MEDIUM
"""
        csv_path = tmp_path / "advisories.csv"
        csv_path.write_text(csv_content)

        loader = AdvisoryDatabaseLoader()
        db = loader.load_from_csv(csv_path)

        assert db.total_cves == 2
        assert db.get_cve("CVE-2024-0001") is not None
        assert db.get_cve("CVE-2024-0002") is not None

    def test_merge_databases(self):
        db1 = AdvisoryDatabase()
        db1.add_cve(CVE(cve_id="CVE-2024-0001", package_name="requests"))

        db2 = AdvisoryDatabase()
        db2.add_cve(CVE(cve_id="CVE-2024-0002", package_name="django"))
        db2.add_cve(CVE(cve_id="CVE-2024-0001", package_name="requests"))

        loader = AdvisoryDatabaseLoader()
        merged = loader.merge_databases([db1, db2])

        assert merged.total_cves == 2
        assert merged.total_packages == 2


class TestVulnerabilityChecker:
    """Tests for VulnerabilityChecker class."""

    def test_check_no_vulnerabilities(self):
        db = AdvisoryDatabase()
        checker = VulnerabilityChecker(db)

        result = checker.check("requests", "2.0.0")
        assert result["is_vulnerable"] is False
        assert result["vulnerabilities"] == []

    def test_check_with_vulnerability(self):
        db = AdvisoryDatabase()
        db.add_cve(CVE(
            cve_id="CVE-2024-0001",
            package_name="requests",
            affected_versions="<2.0.0",
            fixed_version="2.0.0",
            severity=CVESeverity.HIGH,
        ))

        checker = VulnerabilityChecker(db)

        result = checker.check("requests", "1.9.0")
        assert result["is_vulnerable"] is True
        assert len(result["vulnerabilities"]) == 1
        assert result["vulnerabilities"][0]["cve_id"] == "CVE-2024-0001"

    def test_check_version_not_affected(self):
        db = AdvisoryDatabase()
        db.add_cve(CVE(
            cve_id="CVE-2024-0001",
            package_name="requests",
            affected_versions="<2.0.0",
        ))

        checker = VulnerabilityChecker(db)
        result = checker.check("requests", "2.0.0")

        assert result["is_vulnerable"] is False
        assert len(result["vulnerabilities"]) == 0

    def test_batch_check(self):
        db = AdvisoryDatabase()
        db.add_cve(CVE(
            cve_id="CVE-2024-0001",
            package_name="requests",
            affected_versions="<2.0.0",
        ))

        checker = VulnerabilityChecker(db)
        results = checker.batch_check([
            ("requests", "1.9.0"),
            ("django", "3.0.0"),
        ])

        assert results["requests"]["is_vulnerable"] is True
        assert results["django"]["is_vulnerable"] is False

    def test_generate_report(self):
        db = AdvisoryDatabase()
        db.add_cve(CVE(
            cve_id="CVE-2024-0001",
            package_name="requests",
            affected_versions="<2.0.0",
            severity=CVESeverity.CRITICAL,
        ))
        db.add_cve(CVE(
            cve_id="CVE-2024-0002",
            package_name="requests",
            affected_versions="<2.5.0",
            severity=CVESeverity.HIGH,
        ))
        db.add_cve(CVE(
            cve_id="CVE-2024-0003",
            package_name="django",
            affected_versions="<3.0.0",
            severity=CVESeverity.MEDIUM,
        ))

        checker = VulnerabilityChecker(db)
        report = checker.generate_report([
            ("requests", "1.9.0"),
            ("django", "2.9.0"),
        ])

        assert report["summary"]["total_packages"] == 2
        assert report["summary"]["vulnerable_packages"] == 2
        assert report["summary"]["by_severity"]["critical"] == 1
        assert report["summary"]["by_severity"]["high"] == 1


class TestBuiltinDatabase:
    """Tests for built-in advisory database."""

    def test_load_builtin_database(self):
        db = load_builtin_database()
        assert db.total_cves > 0
        assert db.metadata.get("type") == "builtin"

    def test_builtin_advisories_content(self):
        db = load_builtin_database()

        # Check that we have the expected advisories
        requests_cves = db.get_for_package("requests")
        assert len(requests_cves) > 0

        # Check severity
        critical_cves = [c for c in requests_cves if c.severity == CVESeverity.CRITICAL]
        assert len(critical_cves) >= 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])