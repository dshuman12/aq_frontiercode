"""Comprehensive tests for deptrack policy module."""

import pytest

from deptrack.policy import (
    PolicyType,
    PolicyViolation,
    Policy,
    VersionConstraintPolicy,
    PackageAllowlistPolicy,
    PackageBlocklistPolicy,
    LicenseRequiredPolicy,
    LicenseForbiddenPolicy,
    MaintenanceStatusPolicy,
    CustomPolicy,
    PolicyResult,
    PolicyReport,
    PolicyEngine,
    create_policy,
    create_default_engine,
)
from deptrack.models import Dependency, DepSource


class TestVersionConstraintPolicy:
    """Tests for VersionConstraintPolicy."""

    def test_allowed_operator(self):
        policy = VersionConstraintPolicy(
            name="test",
            description="Test policy",
            allowed_operators=["==", "~=", ">="],
        )
        dep = Dependency(name="test", version="==1.0.0")
        passed, msg = policy.evaluate(dep, {})
        assert passed

    def test_forbidden_operator(self):
        policy = VersionConstraintPolicy(
            name="test",
            description="Test policy",
            allowed_operators=["=="],
        )
        dep = Dependency(name="test", version=">=1.0.0")
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "forbidden operator" in msg

    def test_min_version_violation(self):
        policy = VersionConstraintPolicy(
            name="test",
            description="Test policy",
            min_version="2.0.0",
        )
        dep = Dependency(name="test", version="1.0.0")
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "below minimum" in msg

    def test_max_version_violation(self):
        policy = VersionConstraintPolicy(
            name="test",
            description="Test policy",
            max_version="2.0.0",
        )
        dep = Dependency(name="test", version="3.0.0")
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "exceeds maximum" in msg

    def test_no_version_specified(self):
        policy = VersionConstraintPolicy(
            name="test",
            description="Test policy",
        )
        dep = Dependency(name="test", version=None)
        passed, msg = policy.evaluate(dep, {})
        assert passed  # Skip if no version


class TestPackageAllowlistPolicy:
    """Tests for PackageAllowlistPolicy."""

    def test_package_in_allowlist(self):
        policy = PackageAllowlistPolicy(
            name="test",
            description="Test policy",
            allowed_packages=["requests", "django"],
        )
        dep = Dependency(name="requests")
        passed, msg = policy.evaluate(dep, {})
        assert passed

    def test_package_not_in_allowlist(self):
        policy = PackageAllowlistPolicy(
            name="test",
            description="Test policy",
            allowed_packages=["requests", "django"],
        )
        dep = Dependency(name="flask")
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "not in allowlist" in msg

    def test_subpackage_allowed(self):
        policy = PackageAllowlistPolicy(
            name="test",
            description="Test policy",
            allowed_packages=["requests"],
            allow_subpackages=True,
        )
        dep = Dependency(name="requests-toolbelt")
        passed, msg = policy.evaluate(dep, {})
        assert passed

    def test_internal_package_allowed(self):
        policy = PackageAllowlistPolicy(
            name="test",
            description="Test policy",
            allowed_packages=[],
            allow_internal=True,
        )
        dep = Dependency(name="_internal")
        passed, msg = policy.evaluate(dep, {})
        assert passed


class TestPackageBlocklistPolicy:
    """Tests for PackageBlocklistPolicy."""

    def test_package_blocked(self):
        policy = PackageBlocklistPolicy(
            name="test",
            description="Test policy",
            blocked_packages=["malicious"],
        )
        dep = Dependency(name="malicious")
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "explicitly blocked" in msg

    def test_package_not_blocked(self):
        policy = PackageBlocklistPolicy(
            name="test",
            description="Test policy",
            blocked_packages=["malicious"],
        )
        dep = Dependency(name="requests")
        passed, msg = policy.evaluate(dep, {})
        assert passed

    def test_namespace_blocked(self):
        policy = PackageBlocklistPolicy(
            name="test",
            description="Test policy",
            blocked_packages=["malicious"],
        )
        dep = Dependency(name="malicious-tool")
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "blocked namespace" in msg


class TestLicenseRequiredPolicy:
    """Tests for LicenseRequiredPolicy."""

    def test_license_found(self):
        policy = LicenseRequiredPolicy(
            name="test",
            description="Test policy",
            required_licenses=["MIT"],
        )
        dep = Dependency(name="test")
        context = {
            "package_metadata": {
                "test": {"license": "MIT"}
            }
        }
        passed, msg = policy.evaluate(dep, context)
        assert passed

    def test_license_not_found(self):
        policy = LicenseRequiredPolicy(
            name="test",
            description="Test policy",
            required_licenses=["MIT"],
        )
        dep = Dependency(name="test")
        context = {
            "package_metadata": {
                "test": {"license": "GPL"}
            }
        }
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "No required license" in msg

    def test_no_metadata(self):
        policy = LicenseRequiredPolicy(
            name="test",
            description="Test policy",
            required_licenses=["MIT"],
        )
        dep = Dependency(name="test")
        context = {}
        passed, msg = policy.evaluate(dep, context)
        assert passed  # Skip if no metadata


class TestLicenseForbiddenPolicy:
    """Tests for LicenseForbiddenPolicy."""

    def test_forbidden_license(self):
        policy = LicenseForbiddenPolicy(
            name="test",
            description="Test policy",
            forbidden_licenses=["GPL"],
        )
        dep = Dependency(name="test")
        context = {
            "package_metadata": {
                "test": {"license": "GPL-3.0"}
            }
        }
        passed, msg = policy.evaluate(dep, context)
        assert not passed
        assert "Forbidden license" in msg

    def test_allowed_license(self):
        policy = LicenseForbiddenPolicy(
            name="test",
            description="Test policy",
            forbidden_licenses=["GPL"],
        )
        dep = Dependency(name="test")
        context = {
            "package_metadata": {
                "test": {"license": "MIT"}
            }
        }
        passed, msg = policy.evaluate(dep, context)
        assert passed


class TestMaintenanceStatusPolicy:
    """Tests for MaintenanceStatusPolicy."""

    def test_yanked_package(self):
        policy = MaintenanceStatusPolicy(
            name="test",
            description="Test policy",
        )
        dep = Dependency(name="test")
        context = {
            "package_metadata": {
                "test": {"yanked": True}
            }
        }
        passed, msg = policy.evaluate(dep, context)
        assert not passed
        assert "yanked" in msg

    def test_stale_package(self):
        import datetime
        policy = MaintenanceStatusPolicy(
            name="test",
            description="Test policy",
            max_stale_days=180,
        )
        dep = Dependency(name="test")
        old_date = (datetime.date.today() - datetime.timedelta(days=365)).isoformat()
        context = {
            "package_metadata": {
                "test": {"last_release": old_date}
            }
        }
        passed, msg = policy.evaluate(dep, context)
        assert not passed
        assert "not been updated" in msg

    def test_active_package(self):
        import datetime
        policy = MaintenanceStatusPolicy(
            name="test",
            description="Test policy",
            max_stale_days=365,
        )
        dep = Dependency(name="test")
        recent_date = (datetime.date.today() - datetime.timedelta(days=30)).isoformat()
        context = {
            "package_metadata": {
                "test": {"last_release": recent_date}
            }
        }
        passed, msg = policy.evaluate(dep, context)
        assert passed


class TestCustomPolicy:
    """Tests for CustomPolicy."""

    def test_custom_evaluation(self):
        def evaluator(dep, context):
            if dep.name.startswith("test_"):
                return False, "Custom violation"
            return True, "OK"

        policy = CustomPolicy(
            name="test",
            description="Custom policy",
            evaluate_fn=evaluator,
        )
        dep = Dependency(name="test_pkg")
        passed, msg = policy.evaluate(dep, {})
        assert not passed
        assert "Custom violation" in msg


class TestPolicyEngine:
    """Tests for PolicyEngine class."""

    def test_add_policy(self):
        engine = PolicyEngine()
        policy = VersionConstraintPolicy(
            name="test",
            description="Test",
        )
        engine.add_policy(policy)

        assert engine.get_policy("test") is policy
        assert len(engine.list_policies()) == 1

    def test_remove_policy(self):
        engine = PolicyEngine()
        policy = VersionConstraintPolicy(name="test", description="Test")
        engine.add_policy(policy)

        assert engine.remove_policy("test")
        assert engine.get_policy("test") is None

    def test_evaluate_dependencies(self):
        engine = PolicyEngine()
        policy = PackageBlocklistPolicy(
            name="block_bad",
            description="Block bad packages",
            blocked_packages=["malicious"],
        )
        engine.add_policy(policy)

        deps = [
            Dependency(name="requests"),
            Dependency(name="malicious"),
        ]

        report = engine.evaluate(deps)

        assert report.total_dependencies_checked == 2
        assert report.violation_count == 1

    def test_evaluate_with_groups(self):
        engine = PolicyEngine()
        policy1 = VersionConstraintPolicy(name="version", description="Test")
        policy2 = PackageBlocklistPolicy(name="block", description="Test")

        engine.add_policy(policy1, groups=["security"])
        engine.add_policy(policy2, groups=["security", "compliance"])

        security_policies = engine.get_policies_by_group("security")
        assert len(security_policies) == 2

        compliance_policies = engine.get_policies_by_group("compliance")
        assert len(compliance_policies) == 1

    def test_evaluate_single(self):
        engine = PolicyEngine()
        policy = PackageBlocklistPolicy(
            name="block",
            description="Test",
            blocked_packages=["malicious"],
        )
        engine.add_policy(policy)

        dep = Dependency(name="malicious")
        result = engine.evaluate_single(dep, "block")

        assert result is not None
        assert not result.passed

    def test_load_from_file(self, tmp_path):
        import json
        config = {
            "policies": [
                {
                    "name": "test_policy",
                    "description": "Test",
                    "type": "version_constraint",
                    "config": {
                        "min_version": "1.0.0"
                    }
                }
            ]
        }
        config_path = tmp_path / "policies.json"
        config_path.write_text(json.dumps(config))

        engine = PolicyEngine()
        engine.load_from_file(config_path)

        assert engine.get_policy("test_policy") is not None

    def test_save_to_file(self, tmp_path):
        engine = PolicyEngine()
        policy = VersionConstraintPolicy(name="test", description="Test")
        engine.add_policy(policy)

        config_path = tmp_path / "policies.json"
        engine.save_to_file(config_path)

        assert config_path.exists()

        # Load and verify
        engine2 = PolicyEngine()
        engine2.load_from_file(config_path)
        assert engine2.get_policy("test") is not None


class TestPolicyResult:
    """Tests for PolicyResult class."""

    def test_is_violation(self):
        from deptrack.policy import PolicyResult

        class MockPolicy(Policy):
            def __init__(self):
                super().__init__(
                    name="test",
                    description="",
                    policy_type=PolicyType.CUSTOM,
                )

        result = PolicyResult(
            policy=MockPolicy(),
            passed=True,
            message="OK",
        )
        assert not result.is_violation

        result = PolicyResult(
            policy=MockPolicy(),
            passed=False,
            message="Violated",
        )
        assert result.is_violation


class TestPolicyReport:
    """Tests for PolicyReport class."""

    def test_has_violations(self):
        from deptrack.policy import PolicyResult

        class MockPolicy(Policy):
            def __init__(self):
                super().__init__(
                    name="test",
                    description="",
                    policy_type=PolicyType.CUSTOM,
                )

        report = PolicyReport()
        report.results = [
            PolicyResult(policy=MockPolicy(), passed=True, message="OK"),
            PolicyResult(policy=MockPolicy(), passed=False, message="Fail"),
        ]

        assert report.has_violations
        assert report.violation_count == 1

    def test_summary(self):
        from deptrack.policy import PolicyResult
        from deptrack.models import Severity

        class MockPolicy(Policy):
            def __init__(self, severity):
                super().__init__(
                    name=f"policy_{severity.value}",
                    description="",
                    policy_type=PolicyType.CUSTOM,
                    severity=severity,
                )

        report = PolicyReport()
        report.results = [
            PolicyResult(policy=MockPolicy(Severity.CRITICAL), passed=False, message=""),
            PolicyResult(policy=MockPolicy(Severity.HIGH), passed=False, message=""),
            PolicyResult(policy=MockPolicy(Severity.LOW), passed=True, message=""),
        ]
        report.total_dependencies_checked = 10

        summary = report.summary()
        assert summary["total_policies"] == 3
        assert summary["policies_passed"] == 1
        assert summary["policies_failed"] == 2


class TestCreateDefaultEngine:
    """Tests for create_default_engine function."""

    def test_create_default_engine(self):
        engine = create_default_engine()
        assert len(engine.list_policies()) > 0

        # Should have security-related policies
        assert engine.get_policy("block_known_vulnerable") is not None
        assert engine.get_policy("require_security_updates") is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])