"""Tests for dependency file parsers."""

import textwrap
from pathlib import Path

import pytest

from deptrack.parsers.requirements import parse_requirements
from deptrack.models import DepSource


def write_req(tmp_path: Path, content: str) -> Path:
    f = tmp_path / "requirements.txt"
    f.write_text(textwrap.dedent(content), encoding="utf-8")
    return f


def test_parse_simple(tmp_path):
    f = write_req(tmp_path, """
        requests==2.28.0
        flask>=2.0
        pillow
    """)
    deps = list(parse_requirements(f))
    names = [d.name for d in deps]
    assert "requests" in names
    assert "flask" in names
    assert "pillow" in names


def test_parse_version(tmp_path):
    f = write_req(tmp_path, "requests==2.28.0\n")
    deps = list(parse_requirements(f))
    assert deps[0].version == "==2.28.0"


def test_parse_extras(tmp_path):
    f = write_req(tmp_path, "uvicorn[standard]==0.20.0\n")
    deps = list(parse_requirements(f))
    assert deps[0].extras == ["standard"]


def test_parse_markers(tmp_path):
    f = write_req(tmp_path, "pywin32>=300 ; sys_platform == 'win32'\n")
    deps = list(parse_requirements(f))
    assert deps[0].markers is not None
    assert "win32" in deps[0].markers


def test_parse_skips_comments(tmp_path):
    f = write_req(tmp_path, """
        # This is a comment
        requests==2.28.0
        # another comment
    """)
    deps = list(parse_requirements(f))
    assert len(deps) == 1


def test_parse_skips_options(tmp_path):
    f = write_req(tmp_path, """
        -r other.txt
        --index-url https://pypi.org/simple
        requests==2.28.0
    """)
    deps = list(parse_requirements(f))
    assert len(deps) == 1
    assert deps[0].name == "requests"


def test_parse_source(tmp_path):
    f = write_req(tmp_path, "flask==2.0.0\n")
    deps = list(parse_requirements(f))
    assert deps[0].source == DepSource.REQUIREMENTS_TXT
