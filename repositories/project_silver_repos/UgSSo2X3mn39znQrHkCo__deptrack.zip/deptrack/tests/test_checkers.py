"""Tests for dependency checkers."""

import pytest
from deptrack.models import Dependency, AuditResult, Severity
from deptrack.checkers.duplicates import check_duplicates, check_name_variants
from deptrack.checkers.versions import check_unpinned, check_wildcard, check_missing_upper_bound
from deptrack.checkers.security import check_vulnerabilities, _is_affected, _parse_version


# --- duplicate checker ---

def test_check_duplicates_none():
    deps = [Dependency(name="flask"), Dependency(name="requests")]
    result = AuditResult()
    check_duplicates(deps, result)
    assert not result.issues


def test_check_duplicates_same_version():
    deps = [Dependency(name="flask", version="==2.0"), Dependency(name="Flask", version="==2.0")]
    result = AuditResult()
    check_duplicates(deps, result)
    assert any(i.kind == "duplicate" for i in result.issues)


def test_check_duplicates_conflict():
    deps = [Dependency(name="flask", version="==2.0"), Dependency(name="flask", version="==1.0")]
    result = AuditResult()
    check_duplicates(deps, result)
    assert any(i.kind == "conflicting_versions" for i in result.issues)
    assert any(i.severity == Severity.HIGH for i in result.issues)


def test_check_name_variants():
    deps = [Dependency(name="Pillow"), Dependency(name="pillow")]
    result = AuditResult()
    check_name_variants(deps, result)
    # Both normalize to "pillow" — this is a duplicate not a variant
    # no name_variant issue since canonical names are the same
    assert not any(i.kind == "name_variant" for i in result.issues)


# --- version checker ---

def test_check_unpinned_flags_missing():
    deps = [Dependency(name="requests")]
    result = AuditResult()
    check_unpinned(deps, result)
    assert any(i.kind == "unpinned" for i in result.issues)


def test_check_unpinned_ignores_pinned():
    deps = [Dependency(name="requests", version="==2.28.0")]
    result = AuditResult()
    check_unpinned(deps, result)
    assert not result.issues


def test_check_wildcard_flags():
    deps = [Dependency(name="flask", version="==2.*")]
    result = AuditResult()
    check_wildcard(deps, result)
    assert any(i.kind == "wildcard_version" for i in result.issues)


def test_check_missing_upper_bound():
    deps = [Dependency(name="django", version=">=3.0")]
    result = AuditResult()
    check_missing_upper_bound(deps, result)
    assert any(i.kind == "missing_upper_bound" for i in result.issues)


def test_check_upper_bound_ok():
    deps = [Dependency(name="django", version=">=3.0,<4.0")]
    result = AuditResult()
    check_missing_upper_bound(deps, result)
    assert not result.issues


# --- security checker ---

def test_parse_version():
    assert _parse_version("1.2.3") == (1, 2, 3)
    assert _parse_version("2.0") == (2, 0)


def test_is_affected_true():
    assert _is_affected("==2.19.0", "2.20.0")


def test_is_affected_false():
    assert not _is_affected("==2.25.0", "2.20.0")


def test_check_vulnerabilities_detects():
    deps = [Dependency(name="requests", version="==2.19.0")]
    result = AuditResult(dependencies=deps)
    check_vulnerabilities(deps, result)
    assert any(i.kind == "vulnerability" for i in result.issues)


def test_check_vulnerabilities_safe():
    deps = [Dependency(name="requests", version="==2.28.0")]
    result = AuditResult(dependencies=deps)
    check_vulnerabilities(deps, result)
    assert not any(i.kind == "vulnerability" for i in result.issues)


def test_check_vulnerabilities_no_version():
    deps = [Dependency(name="requests")]
    result = AuditResult(dependencies=deps)
    check_vulnerabilities(deps, result)
    # No version = can't determine if affected
    assert not any(i.kind == "vulnerability" for i in result.issues)
