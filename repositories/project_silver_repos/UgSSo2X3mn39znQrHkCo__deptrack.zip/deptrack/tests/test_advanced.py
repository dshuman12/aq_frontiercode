"""Tests for plugin system, config, and marker evaluation."""

import pytest
from pathlib import Path
from deptrack.models import Dependency, AuditResult, Issue, Severity
from deptrack.plugins import PluginRegistry, register_plugin, get_registry, plugin
from deptrack.config import DeptrackConfig, load_config, write_default_config
from deptrack.markers import Environment, evaluate_marker, filter_deps_by_env
from deptrack.checkers.licenses import classify_license, LicensePolicy, check_licenses


# --- Plugin system ---

def test_plugin_registry_register():
    reg = PluginRegistry()
    def my_checker(deps, result): pass
    reg.register("my-check", my_checker, description="test")
    assert "my-check" in reg
    assert len(reg) == 1


def test_plugin_registry_duplicate_raises():
    reg = PluginRegistry()
    def fn(deps, result): pass
    reg.register("dup", fn)
    with pytest.raises(ValueError, match="already registered"):
        reg.register("dup", fn)


def test_plugin_registry_run_all():
    reg = PluginRegistry()
    called = []
    def checker(deps, result):
        called.append(True)
    reg.register("test", checker)
    reg.run_all([], AuditResult())
    assert called == [True]


def test_plugin_decorator():
    reg = get_registry()
    before = len(reg)

    @plugin("test-decorator-plugin", description="test")
    def my_check(deps, result):
        pass

    assert len(reg) > before
    reg.unregister("test-decorator-plugin")


def test_plugin_registry_unregister():
    reg = PluginRegistry()
    def fn(deps, result): pass
    reg.register("to-remove", fn)
    reg.unregister("to-remove")
    assert "to-remove" not in reg


# --- Config ---

def test_default_config():
    cfg = DeptrackConfig()
    assert cfg.check_unpinned is True
    assert cfg.check_vulnerabilities is True
    assert cfg.fail_on == "none"
    assert cfg.ignore_packages == []


def test_config_from_dict():
    cfg = DeptrackConfig.from_dict({
        "check_unpinned": False,
        "fail_on": "high",
        "ignore_packages": ["boto3"],
    })
    assert cfg.check_unpinned is False
    assert cfg.fail_on == "high"
    assert "boto3" in cfg.ignore_packages


def test_config_to_dict():
    cfg = DeptrackConfig()
    d = cfg.to_dict()
    assert "check_unpinned" in d
    assert "fail_on" in d


def test_write_default_config(tmp_path):
    path = tmp_path / ".deptrack.toml"
    write_default_config(path)
    assert path.exists()
    content = path.read_text()
    assert "check_unpinned" in content


def test_load_config_no_file(tmp_path):
    cfg = load_config(tmp_path)
    assert isinstance(cfg, DeptrackConfig)
    assert cfg.check_unpinned is True


# --- Markers ---

def test_evaluate_marker_no_marker():
    assert evaluate_marker("") is True
    assert evaluate_marker(None) is True


def test_evaluate_marker_sys_platform():
    env = Environment(sys_platform="linux")
    assert evaluate_marker("sys_platform == 'linux'", env) is True
    assert evaluate_marker("sys_platform == 'win32'", env) is False


def test_evaluate_marker_python_version():
    env = Environment(python_version="3.11")
    assert evaluate_marker("python_version >= '3.9'", env) is True
    assert evaluate_marker("python_version < '3.9'", env) is False


def test_filter_deps_by_env():
    deps = [
        Dependency(name="pywin32", markers="sys_platform == 'win32'"),
        Dependency(name="flask"),
    ]
    env = Environment.current()
    env.sys_platform = "linux"
    result = filter_deps_by_env(deps, env)
    names = [d.name for d in result]
    assert "flask" in names


def test_environment_current():
    env = Environment.current()
    assert env.python_version != ""
    assert env.sys_platform != ""


# --- License checker ---

def test_classify_license_permissive():
    assert classify_license("MIT") == "permissive"
    assert classify_license("Apache-2.0") == "permissive"
    assert classify_license("BSD-3-Clause") == "permissive"


def test_classify_license_copyleft():
    assert classify_license("GPL-3.0") == "copyleft"
    assert classify_license("LGPL-2.1") == "copyleft"


def test_classify_license_unknown():
    assert classify_license(None) == "unknown"
    assert classify_license("") == "unknown"
    assert classify_license("UNKNOWN") == "unknown"


def test_license_policy_deny():
    policy = LicensePolicy(deny=["copyleft"])
    assert policy.is_allowed("permissive") is True
    assert policy.is_allowed("copyleft") is False


def test_check_licenses_flags_gpl():
    dep = Dependency(name="some-lib", version="==1.0")
    result = AuditResult(dependencies=[dep])
    check_licenses([dep], result, license_map={"some-lib": "GPL-3.0"})
    assert any(i.kind == "license_violation" for i in result.issues)


def test_check_licenses_ok_mit():
    dep = Dependency(name="some-lib", version="==1.0")
    result = AuditResult(dependencies=[dep])
    check_licenses([dep], result, license_map={"some-lib": "MIT"})
    assert not any(i.kind == "license_violation" for i in result.issues)
