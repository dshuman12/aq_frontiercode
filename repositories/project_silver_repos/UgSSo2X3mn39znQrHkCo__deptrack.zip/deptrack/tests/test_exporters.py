"""Tests for exporters and resolver modules."""

import json
import pytest
from pathlib import Path
from deptrack.models import Dependency, AuditResult, Issue, Severity
from deptrack.exporters import (
    render_sarif, render_csv, render_markdown, render_junit_xml,
    render, SUPPORTED_FORMATS, write_report
)
from deptrack.resolver import (
    VersionRange, DependencyResolver, resolve_dependencies,
    check_conflicts_via_resolver, ResolverResult
)


def make_result() -> AuditResult:
    dep = Dependency(name="requests", version="==2.19.0")
    dep2 = Dependency(name="flask", version=">=2.0")
    result = AuditResult(dependencies=[dep, dep2], source_files=["requirements.txt"])
    result.issues.append(
        Issue(dep=dep, kind="vulnerability", message="CVE-2018-18074 test",
              severity=Severity.HIGH, fix_suggestion="Upgrade to 2.20.0")
    )
    result.issues.append(
        Issue(dep=dep2, kind="unpinned", message="No pin",
              severity=Severity.MEDIUM, fix_suggestion="Pin flask")
    )
    return result


# --- SARIF ---

def test_render_sarif_valid_json():
    result = make_result()
    sarif_str = render_sarif(result)
    data = json.loads(sarif_str)
    assert data["version"] == "2.1.0"
    assert "runs" in data


def test_render_sarif_has_results():
    result = make_result()
    data = json.loads(render_sarif(result))
    runs = data["runs"][0]
    assert len(runs["results"]) == 2


def test_render_sarif_rule_ids():
    result = make_result()
    data = json.loads(render_sarif(result))
    rule_ids = {r["id"] for r in data["runs"][0]["tool"]["driver"]["rules"]}
    assert "vulnerability" in rule_ids
    assert "unpinned" in rule_ids


# --- CSV ---

def test_render_csv_has_header():
    result = make_result()
    csv_str = render_csv(result)
    assert csv_str.startswith("package,version,kind,severity,message,fix")


def test_render_csv_row_count():
    result = make_result()
    lines = [l for l in render_csv(result).strip().splitlines() if l]
    assert len(lines) == 3  # header + 2 issues


def test_render_csv_contains_package():
    result = make_result()
    assert "requests" in render_csv(result)


# --- Markdown ---

def test_render_markdown_has_heading():
    result = make_result()
    md = render_markdown(result)
    assert "# deptrack Audit Report" in md


def test_render_markdown_table():
    result = make_result()
    md = render_markdown(result)
    assert "| Package |" in md
    assert "requests" in md


def test_render_markdown_no_issues():
    dep = Dependency(name="flask", version="==2.0.0")
    result = AuditResult(dependencies=[dep])
    md = render_markdown(result)
    assert "No Issues Found" in md


def test_render_markdown_fix_suggestions():
    result = make_result()
    md = render_markdown(result)
    assert "Fix Suggestions" in md
    assert "Upgrade to 2.20.0" in md


# --- JUnit XML ---

def test_render_junit_xml_valid():
    result = make_result()
    xml = render_junit_xml(result)
    assert "<testsuite" in xml
    assert "<testcase" in xml


def test_render_junit_xml_failures():
    result = make_result()
    xml = render_junit_xml(result)
    assert "<failure" in xml
    assert "vulnerability" in xml


# --- Format dispatch ---

def test_render_dispatch_text():
    result = make_result()
    out = render(result, "text")
    assert "requests" in out


def test_render_dispatch_json():
    result = make_result()
    out = render(result, "json")
    data = json.loads(out)
    assert "issues" in data


def test_render_dispatch_markdown():
    result = make_result()
    out = render(result, "markdown")
    assert "#" in out


def test_render_dispatch_unknown_raises():
    result = make_result()
    with pytest.raises(ValueError, match="Unsupported format"):
        render(result, "pdf")


def test_write_report(tmp_path):
    result = make_result()
    path = tmp_path / "report.json"
    write_report(result, "json", path)
    assert path.exists()
    data = json.loads(path.read_text())
    assert "issues" in data


# --- VersionRange ---

def test_version_range_exact_pin():
    vr = VersionRange(package="flask")
    vr.add_spec("==2.0.0")
    assert vr.is_satisfiable()
    assert vr.exact_pins == [(2, 0, 0)]


def test_version_range_conflict_two_pins():
    vr = VersionRange(package="flask")
    vr.add_spec("==2.0.0")
    vr.add_spec("==1.0.0")
    assert not vr.is_satisfiable()
    assert "Conflicting exact pins" in (vr.conflict_reason() or "")


def test_version_range_lower_gt_upper():
    vr = VersionRange(package="flask")
    vr.add_spec(">=3.0")
    vr.add_spec("<2.0")
    assert not vr.is_satisfiable()


def test_version_range_satisfiable():
    vr = VersionRange(package="flask")
    vr.add_spec(">=2.0")
    vr.add_spec("<3.0")
    assert vr.is_satisfiable()


# --- DependencyResolver ---

def test_resolver_no_conflict():
    deps = [
        Dependency(name="flask", version=">=2.0,<3.0"),
        Dependency(name="requests", version="==2.28.0"),
    ]
    result = resolve_dependencies(deps)
    assert not result.has_conflicts


def test_resolver_detects_conflict():
    deps = [
        Dependency(name="flask", version="==2.0.0"),
        Dependency(name="flask", version="==1.0.0"),
    ]
    result = resolve_dependencies(deps)
    assert result.has_conflicts
    assert "flask" in result.conflict_packages()


def test_resolver_result_to_dict():
    deps = [Dependency(name="flask", version=">=2.0")]
    result = resolve_dependencies(deps)
    d = result.to_dict()
    assert "conflicts" in d
    assert "ranges" in d


def test_check_conflicts_via_resolver():
    deps = [
        Dependency(name="django", version="==3.0.0"),
        Dependency(name="django", version="==4.0.0"),
    ]
    audit_result = AuditResult(dependencies=deps)
    check_conflicts_via_resolver(deps, audit_result)
    assert any(i.kind == "version_conflict" for i in audit_result.issues)
