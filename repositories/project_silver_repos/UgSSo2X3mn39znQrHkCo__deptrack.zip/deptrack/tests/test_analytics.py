"""Comprehensive tests for deptrack analytics module."""

import datetime
from unittest.mock import Mock, patch

import pytest

from deptrack.analytics import (
    Metric,
    AnalyticsReport,
    DependencyAnalyzer,
    TrendAnalyzer,
    RiskScorer,
    DependencyGraphAnalyzer,
    PrometheusExporter,
    calculate_security_score,
    calculate_maintainability_score,
    generate_dependency_health_report,
)


class TestMetric:
    """Tests for Metric dataclass."""

    def test_creation(self):
        metric = Metric(
            name="test_metric",
            value=100,
            timestamp=datetime.datetime.now(),
            tags={"env": "production"},
        )
        assert metric.name == "test_metric"
        assert metric.value == 100
        assert metric.tags["env"] == "production"

    def test_to_dict(self):
        metric = Metric(
            name="cpu_usage",
            value=85.5,
            tags={"host": "server1"},
        )
        data = metric.to_dict()
        assert data["name"] == "cpu_usage"
        assert data["value"] == 85.5


class TestAnalyticsReport:
    """Tests for AnalyticsReport dataclass."""

    def test_creation(self):
        report = AnalyticsReport(
            timestamp=datetime.datetime.now(),
            metrics=[],
            summary={},
        )
        assert report.timestamp is not None
        assert len(report.metrics) == 0

    def test_add_metric(self):
        report = AnalyticsReport(timestamp=datetime.datetime.now())
        metric = Metric(name="test", value=10)
        report.add_metric(metric)
        assert len(report.metrics) == 1

    def test_to_dict(self):
        report = AnalyticsReport(
            timestamp=datetime.datetime.now(),
            metrics=[Metric(name="test", value=10)],
            summary={"total": 1},
        )
        data = report.to_dict()
        assert "metrics" in data
        assert "summary" in data


class TestDependencyAnalyzer:
    """Tests for DependencyAnalyzer class."""

    def test_creation(self):
        analyzer = DependencyAnalyzer()
        assert analyzer.metrics == []

    def test_analyze_dependency_count(self):
        analyzer = DependencyAnalyzer()
        deps = [
            Mock(name="dep1", version="1.0.0"),
            Mock(name="dep2", version="2.0.0"),
        ]

        metrics = analyzer.analyze_dependency_count(deps)
        assert len(metrics) >= 1

    def test_analyze_versions(self):
        analyzer = DependencyAnalyzer()
        deps = [
            Mock(name="requests", version=">=1.0.0"),
            Mock(name="flask", version="==2.0.0"),
        ]

        metrics = analyzer.analyze_versions(deps)
        assert len(metrics) >= 1

    def test_analyze_licenses(self):
        analyzer = DependencyAnalyzer()
        deps = [
            Mock(name="pkg1", version="1.0"),
            Mock(name="pkg2", version="2.0"),
        ]

        context = {
            "package_metadata": {
                "pkg1": {"license": "MIT"},
                "pkg2": {"license": "GPL"},
            }
        }

        metrics = analyzer.analyze_licenses(deps, context)
        assert len(metrics) >= 1

    def test_analyze_outdated(self):
        analyzer = DependencyAnalyzer()
        deps = [
            Mock(name="requests", version="1.0.0"),
            Mock(name="flask", version="2.0.0"),
        ]

        metrics = analyzer.analyze_outdated(deps, current_versions={
            "requests": "2.0.0",
            "flask": "3.0.0",
        })
        assert len(metrics) >= 1

    def test_generate_full_report(self):
        analyzer = DependencyAnalyzer()
        deps = [
            Mock(name="requests", version="1.0.0"),
        ]

        report = analyzer.generate_report(deps)
        assert report is not None
        assert len(report.metrics) > 0


class TestTrendAnalyzer:
    """Tests for TrendAnalyzer class."""

    def test_creation(self):
        analyzer = TrendAnalyzer(window_days=30)
        assert analyzer.window_days == 30

    def test_add_datapoint(self):
        analyzer = TrendAnalyzer()
        analyzer.add_datapoint(
            timestamp=datetime.datetime.now(),
            value=10,
            labels={"env": "test"},
        )
        assert len(analyzer._datapoints) == 1

    def test_calculate_growth_rate(self):
        analyzer = TrendAnalyzer()
        now = datetime.datetime.now()

        analyzer.add_datapoint(now - datetime.timedelta(days=10), 10)
        analyzer.add_datapoint(now - datetime.timedelta(days=5), 20)
        analyzer.add_datapoint(now, 40)

        rate = analyzer.calculate_growth_rate()
        assert rate > 0  # Should be positive growth

    def test_calculate_moving_average(self):
        analyzer = TrendAnalyzer(window_size=3)
        now = datetime.datetime.now()

        analyzer.add_datapoint(now - datetime.timedelta(days=2), 10)
        analyzer.add_datapoint(now - datetime.timedelta(days=1), 20)
        analyzer.add_datapoint(now, 30)

        avg = analyzer.calculate_moving_average()
        assert avg == 20

    def test_detect_anomalies(self):
        analyzer = TrendAnalyzer(threshold_std=2.0)
        now = datetime.datetime.now()

        # Normal values
        for i in range(5):
            analyzer.add_datapoint(now - datetime.timedelta(days=i), 10)

        # Anomaly
        analyzer.add_datapoint(now, 100)

        anomalies = analyzer.detect_anomalies()
        assert len(anomalies) >= 0

    def test_forecast(self):
        analyzer = TrendAnalyzer()
        now = datetime.datetime.now()

        for i in range(10):
            analyzer.add_datapoint(
                now - datetime.timedelta(days=10 - i),
                10 + i,
            )

        forecast = analyzer.forecast(days=3)
        assert len(forecast) == 3


class TestRiskScorer:
    """Tests for RiskScorer class."""

    def test_creation(self):
        scorer = RiskScorer()
        assert scorer is not None

    def test_score_vulnerability_risk(self):
        scorer = RiskScorer()
        cves = [
            {"severity": "CRITICAL", "cvss_score": 9.5},
            {"severity": "HIGH", "cvss_score": 7.5},
        ]

        score = scorer.score_vulnerability_risk(cves)
        assert score >= 0
        assert score <= 100

    def test_score_outdated_risk(self):
        scorer = RiskScorer()

        # New package
        score_new = scorer.score_outdated_risk("pkg", "1.0.0", latest="1.0.0")
        assert score_new >= 0

        # Very outdated
        score_old = scorer.score_outdated_risk(
            "pkg",
            "1.0.0",
            latest="5.0.0",
            days_since_update=365,
        )
        assert score_old > score_new

    def test_score_license_risk(self):
        scorer = RiskScorer()

        # Permissive license
        score_permissive = scorer.score_license_risk("MIT")
        assert score_permissive < 50

        # Copyleft license
        score_copyleft = scorer.score_license_risk("GPL-3.0")
        assert score_copyleft > score_permissive

    def test_score_maintenance_risk(self):
        scorer = RiskScorer()

        # Active package
        score_active = scorer.score_maintenance_risk(
            last_release=datetime.date.today() - datetime.timedelta(days=7),
            commit_frequency=50,
        )
        assert score_active < 50

        # Abandoned package
        score_abandoned = scorer.score_maintenance_risk(
            last_release=datetime.date.today() - datetime.timedelta(days=730),
            commit_frequency=0,
        )
        assert score_abandoned > score_active

    def test_calculate_overall_risk(self):
        scorer = RiskScorer()

        risk = scorer.calculate_overall_risk(
            cves=[
                {"severity": "HIGH", "cvss_score": 7.5},
            ],
            is_outdated=True,
            days_outdated=180,
            license_type="GPL",
            last_release=datetime.date.today() - datetime.timedelta(days=365),
            commit_frequency=5,
        )

        assert risk >= 0
        assert risk <= 100

    def test_risk_category(self):
        scorer = RiskScorer()

        assert scorer.get_risk_category(10) == "low"
        assert scorer.get_risk_category(45) == "medium"
        assert scorer.get_risk_category(75) == "high"
        assert scorer.get_risk_category(95) == "critical"


class TestDependencyGraphAnalyzer:
    """Tests for DependencyGraphAnalyzer class."""

    def test_creation(self):
        analyzer = DependencyGraphAnalyzer()
        assert len(analyzer.graph) == 0

    def test_add_dependency(self):
        analyzer = DependencyGraphAnalyzer()
        analyzer.add_dependency("app", "requests")
        analyzer.add_dependency("app", "flask")
        analyzer.add_dependency("requests", "certifi")

        assert "app" in analyzer.graph
        assert "requests" in analyzer.graph["app"].dependencies

    def test_get_direct_dependencies(self):
        analyzer = DependencyGraphAnalyzer()
        analyzer.add_dependency("app", "requests")
        analyzer.add_dependency("app", "flask")

        direct = analyzer.get_direct_dependencies("app")
        assert len(direct) == 2

    def test_get_all_dependencies(self):
        analyzer = DependencyGraphAnalyzer()
        analyzer.add_dependency("app", "requests")
        analyzer.add_dependency("requests", "certifi")
        analyzer.add_dependency("certifi", "ca-certificates")

        all_deps = analyzer.get_all_dependencies("app")
        assert len(all_deps) == 3

    def test_find_cycles(self):
        analyzer = DependencyGraphAnalyzer()
        analyzer.add_dependency("a", "b")
        analyzer.add_dependency("b", "c")
        analyzer.add_dependency("c", "a")

        cycles = analyzer.find_cycles()
        assert len(cycles) > 0

    def test_find_orphans(self):
        analyzer = DependencyGraphAnalyzer()
        analyzer.add_dependency("app", "requests")
        analyzer.add_dependency("app", "flask")
        # sqlalchemy is not used by anyone
        analyzer.add_node("sqlalchemy")

        orphans = analyzer.find_orphans()
        assert "sqlalchemy" in orphans

    def test_calculate_depth(self):
        analyzer = DependencyGraphAnalyzer()
        analyzer.add_dependency("app", "requests")
        analyzer.add_dependency("requests", "certifi")

        depth = analyzer.calculate_depth("app")
        assert depth >= 0

    def test_topological_sort(self):
        analyzer = DependencyGraphAnalyzer()
        analyzer.add_dependency("app", "lib1")
        analyzer.add_dependency("lib1", "lib2")
        analyzer.add_dependency("lib2", "lib3")

        sorted_deps = analyzer.topological_sort()
        assert len(sorted_deps) == 4


class TestPrometheusExporter:
    """Tests for PrometheusExporter class."""

    def test_creation(self):
        exporter = PrometheusExporter()
        assert exporter.metrics == []

    def test_add_metric(self):
        exporter = PrometheusExporter()
        metric = Metric(name="test", value=10, tags={"env": "prod"})
        exporter.add_metric(metric)

        assert len(exporter.metrics) == 1

    def test_format_metric(self):
        exporter = PrometheusExporter()
        metric = Metric(name="test", value=10, tags={"env": "prod"})

        output = exporter.format_metric(metric)
        assert "test" in output
        assert "10" in output

    def test_export(self):
        exporter = PrometheusExporter()
        exporter.add_metric(Metric(name="test1", value=10))
        exporter.add_metric(Metric(name="test2", value=20))

        output = exporter.export()
        assert "test1" in output
        assert "test2" in output

    def test_export_gauge(self):
        exporter = PrometheusExporter()
        exporter.export_gauge("my_gauge", 100, {"env": "prod"})

        output = exporter.export()
        assert "my_gauge" in output
        assert "100" in output

    def test_export_counter(self):
        exporter = PrometheusExporter()
        exporter.export_counter("my_counter", 50, {"method": "GET"})

        output = exporter.export()
        assert "my_counter" in output

    def test_export_histogram(self):
        exporter = PrometheusExporter()
        exporter.export_histogram("my_histogram", 0.5, {"le": "0.1"})

        output = exporter.export()
        assert "my_histogram" in output


class TestScoreCalculations:
    """Tests for score calculation functions."""

    def test_security_score_critical_vulns(self):
        score = calculate_security_score(
            critical_cves=5,
            high_cves=10,
            medium_cves=20,
            low_cves=30,
        )
        assert score < 50  # Many vulnerabilities

    def test_security_score_clean(self):
        score = calculate_security_score(
            critical_cves=0,
            high_cves=0,
            medium_cves=0,
            low_cves=0,
        )
        assert score == 100

    def test_maintainability_score_abandoned(self):
        score = calculate_maintainability_score(
            outdated_count=10,
            abandoned_count=5,
            unmaintained_count=3,
            total_dependencies=20,
        )
        assert score < 50

    def test_maintainability_score_healthy(self):
        score = calculate_maintainability_score(
            outdated_count=1,
            abandoned_count=0,
            unmaintained_count=0,
            total_dependencies=20,
        )
        assert score > 70


class TestDependencyHealthReport:
    """Tests for generate_dependency_health_report function."""

    def test_generate_report(self):
        deps = [
            Mock(name="requests", version="2.0.0"),
            Mock(name="flask", version="1.0.0"),
        ]

        context = {
            "package_metadata": {
                "requests": {
                    "latest_version": "2.28.0",
                    "license": "Apache 2.0",
                },
                "flask": {
                    "latest_version": "2.3.0",
                    "license": "BSD",
                },
            },
            "vulnerabilities": {
                "requests": [],
                "flask": [{"severity": "HIGH", "cvss_score": 7.5}],
            },
        }

        report = generate_dependency_health_report(deps, context)

        assert "summary" in report
        assert "security_score" in report
        assert "maintainability_score" in report
        assert "risks" in report


if __name__ == "__main__":
    pytest.main([__file__, "-v"])