"""Tests for core data models."""

import pytest
from deptrack.models import Dependency, Issue, AuditResult, Severity, DepSource, LockEntry


def test_dependency_name_normalization():
    dep = Dependency(name="Pillow")
    assert dep.canonical_name == "pillow"

    dep2 = Dependency(name="some_package")
    assert dep2.canonical_name == "some-package"

    dep3 = Dependency(name="my.package")
    assert dep3.canonical_name == "my-package"


def test_dependency_equality():
    dep1 = Dependency(name="Pillow", version="==9.0.0")
    dep2 = Dependency(name="pillow", version="==9.0.0")
    assert dep1 == dep2


def test_dependency_hash():
    dep1 = Dependency(name="Requests")
    dep2 = Dependency(name="requests")
    assert hash(dep1) == hash(dep2)
    assert {dep1, dep2} == {dep1}


def test_dependency_to_dict():
    dep = Dependency(name="flask", version=">=2.0", source=DepSource.REQUIREMENTS_TXT)
    d = dep.to_dict()
    assert d["name"] == "flask"
    assert d["version"] == ">=2.0"
    assert d["source"] == "requirements.txt"


def test_issue_to_dict():
    dep = Dependency(name="requests", version="==2.19.0")
    issue = Issue(dep=dep, kind="vulnerability", message="CVE test", severity=Severity.HIGH)
    d = issue.to_dict()
    assert d["package"] == "requests"
    assert d["severity"] == "high"
    assert d["kind"] == "vulnerability"


def test_audit_result_summary():
    dep = Dependency(name="foo")
    result = AuditResult(dependencies=[dep])
    result.issues.append(Issue(dep=dep, kind="unpinned", message="x", severity=Severity.MEDIUM))
    result.issues.append(Issue(dep=dep, kind="vuln", message="y", severity=Severity.CRITICAL))
    s = result.summary()
    assert s["total_dependencies"] == 1
    assert s["total_issues"] == 2
    assert s["critical"] == 1
    assert s["medium"] == 1


def test_audit_result_has_issues():
    result = AuditResult()
    assert not result.has_issues
    dep = Dependency(name="foo")
    result.issues.append(Issue(dep=dep, kind="x", message="y", severity=Severity.LOW))
    assert result.has_issues


def test_audit_result_critical_high():
    dep = Dependency(name="foo")
    result = AuditResult()
    result.issues.append(Issue(dep=dep, kind="a", message="a", severity=Severity.CRITICAL))
    result.issues.append(Issue(dep=dep, kind="b", message="b", severity=Severity.HIGH))
    result.issues.append(Issue(dep=dep, kind="c", message="c", severity=Severity.LOW))
    assert len(result.critical_issues) == 1
    assert len(result.high_issues) == 1
