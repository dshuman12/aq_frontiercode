"""Comprehensive tests for deptrack cache module."""

import tempfile
import time
import threading
from pathlib import Path

import pytest

from deptrack.cache import (
    CacheEntry,
    CacheBackend,
    LRUCache,
    DiskCache,
    TieredCache,
    NullCache,
    CacheDecorator,
    cached,
    get_lru_cache,
    get_disk_cache,
    get_tiered_cache,
    clear_all_caches,
    DEFAULT_CACHE_DIR,
)


class TestCacheEntry:
    """Tests for CacheEntry class."""

    def test_creation(self):
        entry = CacheEntry(
            key="test_key",
            value={"data": "test"},
            created_at=time.time(),
            accessed_at=time.time(),
        )
        assert entry.key == "test_key"
        assert entry.value == {"data": "test"}

    def test_touch_updates_access_time(self):
        entry = CacheEntry(
            key="test",
            value="value",
            created_at=time.time(),
            accessed_at=time.time(),
            access_count=0,
        )
        initial_access = entry.accessed_at
        time.sleep(0.01)
        entry.touch()
        assert entry.access_count == 1
        assert entry.accessed_at >= initial_access

    def test_age_seconds(self):
        old_time = time.time() - 100
        entry = CacheEntry(
            key="test",
            value="value",
            created_at=old_time,
            accessed_at=old_time,
        )
        assert entry.age_seconds >= 100

    def test_serialization(self):
        entry = CacheEntry(
            key="test_key",
            value=[1, 2, 3],
            created_at=1000.0,
            accessed_at=1005.0,
            access_count=5,
        )
        data = entry.to_bytes()
        restored = CacheEntry.from_bytes(data)
        assert restored.key == entry.key
        assert restored.value == entry.value
        assert restored.access_count == entry.access_count


class TestLRUCache:
    """Tests for in-memory LRU cache."""

    def test_basic_get_set(self):
        cache = LRUCache(max_size=100)
        entry = CacheEntry(
            key="test",
            value="value",
            created_at=time.time(),
            accessed_at=time.time(),
        )
        cache.set(entry)
        result = cache.get("test")
        assert result is not None
        assert result.value == "value"

    def test_cache_miss(self):
        cache = LRUCache()
        result = cache.get("nonexistent")
        assert result is None

    def test_lru_eviction(self):
        cache = LRUCache(max_size=3)
        for i in range(3):
            entry = CacheEntry(
                key=f"key{i}",
                value=f"value{i}",
                created_at=time.time(),
                accessed_at=time.time(),
            )
            cache.set(entry)

        # Add a 4th item, which should evict the oldest
        entry = CacheEntry(
            key="key3",
            value="value3",
            created_at=time.time(),
            accessed_at=time.time(),
        )
        cache.set(entry)

        # First item should be evicted
        assert cache.get("key0") is None
        assert cache.get("key1") is not None
        assert cache.get("key2") is not None
        assert cache.get("key3") is not None

    def test_ttl_expiration(self):
        cache = LRUCache(ttl=0.1)
        entry = CacheEntry(
            key="test",
            value="value",
            created_at=time.time(),
            accessed_at=time.time(),
        )
        cache.set(entry)
        assert cache.get("test") is not None

        time.sleep(0.15)
        assert cache.get("test") is None

    def test_thread_safety(self):
        cache = LRUCache(max_size=1000, thread_safe=True)
        errors = []

        def writer():
            try:
                for i in range(100):
                    entry = CacheEntry(
                        key=f"key{i % 50}",
                        value=f"value{i}",
                        created_at=time.time(),
                        accessed_at=time.time(),
                    )
                    cache.set(entry)
            except Exception as e:
                errors.append(e)

        def reader():
            try:
                for _ in range(100):
                    cache.get("key0")
                    cache.size()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=writer) for _ in range(5)]
        threads += [threading.Thread(target=reader) for _ in range(5)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0

    def test_stats(self):
        cache = LRUCache()
        for i in range(10):
            entry = CacheEntry(
                key=f"key{i}",
                value=f"value{i}",
                created_at=time.time(),
                accessed_at=time.time(),
            )
            cache.set(entry)

        # Get some to generate hits
        for i in range(5):
            cache.get(f"key{i}")

        stats = cache.stats()
        assert stats["total_sets"] == 10
        assert stats["hits"] == 5
        assert stats["misses"] >= 5

    def test_prune_expired(self):
        cache = LRUCache(ttl=0.05)

        # Add expired entries
        for i in range(5):
            entry = CacheEntry(
                key=f"old{i}",
                value=f"value{i}",
                created_at=time.time() - 10,
                accessed_at=time.time() - 10,
            )
            cache.set(entry)

        # Add fresh entry
        entry = CacheEntry(
            key="new",
            value="new_value",
            created_at=time.time(),
            accessed_at=time.time(),
        )
        cache.set(entry)

        pruned = cache.prune_expired()
        assert pruned == 5
        assert cache.size() == 1
        assert cache.get("new") is not None


class TestDiskCache:
    """Tests for disk-based cache."""

    def test_basic_operations(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = DiskCache(cache_dir=tmpdir)
            entry = CacheEntry(
                key="test_key",
                value={"data": "test"},
                created_at=time.time(),
                accessed_at=time.time(),
            )
            cache.set(entry)

            result = cache.get("test_key")
            assert result is not None
            assert result.value == {"data": "test"}

    def test_persistence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache1 = DiskCache(cache_dir=tmpdir)
            entry = CacheEntry(
                key="persist",
                value="test_value",
                created_at=time.time(),
                accessed_at=time.time(),
            )
            cache1.set(entry)

            # Create new cache instance with same directory
            cache2 = DiskCache(cache_dir=tmpdir)
            result = cache2.get("persist")
            assert result is not None
            assert result.value == "test_value"

    def test_compression(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = DiskCache(cache_dir=tmpdir, compress=True)

            # Large data that should be compressed
            large_data = "x" * 10000
            entry = CacheEntry(
                key="large",
                value=large_data,
                created_at=time.time(),
                accessed_at=time.time(),
            )
            cache.set(entry)

            result = cache.get("large")
            assert result is not None
            assert result.value == large_data

    def test_max_size_eviction(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = DiskCache(cache_dir=tmpdir, max_size_mb=0.001)  # Very small

            # Add enough data to exceed limit
            for i in range(100):
                entry = CacheEntry(
                    key=f"key{i}",
                    value="x" * 10000,
                    created_at=time.time(),
                    accessed_at=time.time(),
                )
                cache.set(entry)

            # Some entries should have been evicted
            stats = cache.stats()
            assert stats["entries"] < 100


class TestTieredCache:
    """Tests for tiered cache (L1 + L2)."""

    def test_l1_promotion(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = TieredCache(l1_size=10, l2_dir=tmpdir)

            entry = CacheEntry(
                key="test",
                value="value",
                created_at=time.time(),
                accessed_at=time.time(),
            )
            cache.set(entry)

            # Should be in L1
            assert cache._l1.get("test") is not None

            # Clear L1
            cache.invalidate_l1()

            # Should still be accessible from L2
            assert cache.get("test") is not None
            assert cache._l1.get("test") is not None  # Repromoted

    def test_write_through(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = TieredCache(l1_size=10, l2_dir=tmpdir)

            entry = CacheEntry(
                key="test",
                value="value",
                created_at=time.time(),
                accessed_at=time.time(),
            )
            cache.set(entry)

            # Should be in both tiers
            assert cache._l1.get("test") is not None
            assert cache._l2.get("test") is not None


class TestNullCache:
    """Tests for null cache (no-op)."""

    def test_always_misses(self):
        cache = NullCache()
        assert cache.get("any_key") is None

    def test_set_does_nothing(self):
        cache = NullCache()
        entry = CacheEntry(
            key="test",
            value="value",
            created_at=time.time(),
            accessed_at=time.time(),
        )
        cache.set(entry)  # Should not raise
        assert cache.size() == 0


class TestCacheDecorator:
    """Tests for cache decorator."""

    def test_basic_caching(self):
        cache = LRUCache()
        call_count = [0]

        @cached(cache)
        def expensive_function(x):
            call_count[0] += 1
            return x * 2

        # First call
        assert expensive_function(5) == 10
        assert call_count[0] == 1

        # Second call should use cache
        assert expensive_function(5) == 10
        assert call_count[0] == 1

    def test_different_args(self):
        cache = LRUCache()
        call_count = [0]

        @cached(cache)
        def add(a, b):
            call_count[0] += 1
            return a + b

        assert add(1, 2) == 3
        assert add(2, 3) == 5
        assert call_count[0] == 2

        # Same args should use cache
        assert add(1, 2) == 3
        assert call_count[0] == 2


class TestGlobalCaches:
    """Tests for global cache instances."""

    def test_get_lru_cache(self):
        clear_all_caches()
        cache1 = get_lru_cache()
        cache2 = get_lru_cache()
        assert cache1 is cache2  # Same instance

    def test_get_disk_cache(self):
        clear_all_caches()
        cache1 = get_disk_cache()
        cache2 = get_disk_cache()
        assert cache1 is cache2

    def test_get_tiered_cache(self):
        clear_all_caches()
        cache1 = get_tiered_cache()
        cache2 = get_tiered_cache()
        assert cache1 is cache2


class TestCacheBackend:
    """Test that all backends implement the interface correctly."""

    def test_all_backends_have_required_methods(self):
        backends = [
            LRUCache(),
            NullCache(),
        ]

        required_methods = ["get", "set", "delete", "clear", "keys", "size", "stats"]

        for backend in backends:
            for method in required_methods:
                assert hasattr(backend, method), f"{backend.__class__.__name__} missing {method}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])