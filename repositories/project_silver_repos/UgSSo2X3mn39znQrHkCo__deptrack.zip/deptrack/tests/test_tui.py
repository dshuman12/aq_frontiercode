"""Comprehensive tests for deptrack tui module."""

import curses
from unittest.mock import Mock, patch, MagicMock

import pytest

from deptrack.tui import (
    TUIRenderer,
    DependencyDashboard,
    DependenciesView,
    IssuesView,
    TUIApp,
    ProgressTracker,
    format_table,
    format_severity_badge,
    format_version_info,
)


class TestTUIRenderer:
    """Tests for TUIRenderer class."""

    def test_creation(self):
        renderer = TUIRenderer()
        assert renderer.width == 80
        assert renderer.height == 24

    def test_get_color_pair(self):
        renderer = TUIRenderer()
        color = renderer.get_color_pair("green")
        assert color is not None

    def test_draw_box(self):
        renderer = TUIRenderer()
        window = Mock()

        renderer.draw_box(window, 0, 0, 10, 20, "Title")

        # Verify border methods were called
        assert window.border.called

    def test_draw_progress_bar(self):
        renderer = TUIRenderer()
        window = Mock()

        renderer.draw_progress_bar(window, 0, 0, 20, 0.5, "test")
        # Should not raise

    def test_format_duration(self):
        renderer = TUIRenderer()

        assert renderer.format_duration(30) == "30s"
        assert renderer.format_duration(90) == "1m 30s"
        assert renderer.format_duration(3600) == "1h 0m"
        assert renderer.format_duration(3661) == "1h 1m 1s"


class TestDependencyDashboard:
    """Tests for DependencyDashboard class."""

    def test_creation(self):
        dashboard = DependencyDashboard()
        assert dashboard.packages == []
        assert dashboard.vulnerabilities == []

    def test_add_package(self):
        dashboard = DependencyDashboard()
        dashboard.add_package(Mock(name="requests", version="2.28.0"))

        assert len(dashboard.packages) == 1

    def test_add_vulnerability(self):
        dashboard = DependencyDashboard()
        dashboard.add_vulnerability(Mock(
            package_name="requests",
            severity="HIGH",
            cve_id="CVE-2024-0001",
        ))

        assert len(dashboard.vulnerabilities) == 1

    def test_get_summary(self):
        dashboard = DependencyDashboard()
        dashboard.add_package(Mock(name="requests", version="2.0.0"))
        dashboard.add_package(Mock(name="flask", version="2.0.0"))
        dashboard.add_vulnerability(Mock(severity="HIGH"))
        dashboard.add_vulnerability(Mock(severity="LOW"))

        summary = dashboard.get_summary()
        assert summary["total_packages"] == 2
        assert summary["total_vulnerabilities"] == 2
        assert summary["high_severity"] == 1


class TestDependenciesView:
    """Tests for DependenciesView class."""

    def test_creation(self):
        view = DependenciesView()
        assert view.page == 0
        assert view.page_size == 20

    def test_set_packages(self):
        view = DependenciesView()
        view.set_packages([
            Mock(name="requests", version="2.0.0"),
            Mock(name="flask", version="2.0.0"),
        ])

        assert len(view.packages) == 2

    def test_navigate_down(self):
        view = DependenciesView()
        view.set_packages([Mock(name=f"pkg{i}") for i in range(30)])
        view.selected = 5

        view.navigate_down()
        assert view.selected == 6

    def test_navigate_up(self):
        view = DependenciesView()
        view.set_packages([Mock(name=f"pkg{i}") for i in range(30)])
        view.selected = 5

        view.navigate_up()
        assert view.selected == 4

    def test_page_down(self):
        view = DependenciesView()
        view.set_packages([Mock(name=f"pkg{i}") for i in range(50)])
        view.page = 0

        view.page_down()
        assert view.page == 1

    def test_page_up(self):
        view = DependenciesView()
        view.set_packages([Mock(name=f"pkg{i}") for i in range(50)])
        view.page = 2

        view.page_up()
        assert view.page == 1

    def test_search_filter(self):
        view = DependenciesView()
        view.set_packages([
            Mock(name="requests"),
            Mock(name="flask"),
            Mock(name="django-rest-framework"),
        ])

        view.set_search_filter("req")
        assert len(view.get_filtered_packages()) == 1

    def test_sort_by_name(self):
        view = DependenciesView()
        view.set_packages([
            Mock(name="flask"),
            Mock(name="requests"),
            Mock(name="django"),
        ])

        view.set_sort_key("name")
        sorted_packages = view.get_sorted_packages()
        assert sorted_packages[0].name == "django"
        assert sorted_packages[2].name == "requests"


class TestIssuesView:
    """Tests for IssuesView class."""

    def test_creation(self):
        view = IssuesView()
        assert view.selected == 0
        assert view.filter_severity is None

    def test_set_issues(self):
        view = IssuesView()
        view.set_issues([
            Mock(severity="HIGH", cve_id="CVE-2024-0001"),
            Mock(severity="LOW", cve_id="CVE-2024-0002"),
        ])

        assert len(view.issues) == 2

    def test_filter_by_severity(self):
        view = IssuesView()
        view.set_issues([
            Mock(severity="CRITICAL"),
            Mock(severity="HIGH"),
            Mock(severity="LOW"),
        ])

        view.set_severity_filter("HIGH")
        filtered = view.get_filtered_issues()
        assert all(i.severity == "HIGH" for i in filtered)

    def test_filter_by_package(self):
        view = IssuesView()
        view.set_issues([
            Mock(package_name="requests", severity="HIGH"),
            Mock(package_name="flask", severity="LOW"),
        ])

        view.set_package_filter("requests")
        filtered = view.get_filtered_issues()
        assert all(i.package_name == "requests" for i in filtered)

    def test_mark_dismissed(self):
        view = IssuesView()
        issues = [
            Mock(id="1", dismissed=False),
            Mock(id="2", dismissed=False),
        ]
        view.set_issues(issues)

        view.dismiss_issue("1")
        assert view.get_issue("1").dismissed

    def test_get_stats(self):
        view = IssuesView()
        view.set_issues([
            Mock(severity="CRITICAL"),
            Mock(severity="HIGH"),
            Mock(severity="HIGH"),
            Mock(severity="MEDIUM"),
            Mock(severity="LOW"),
        ])

        stats = view.get_stats()
        assert stats["critical"] == 1
        assert stats["high"] == 2
        assert stats["total"] == 5


class TestTUIApp:
    """Tests for TUIApp class."""

    def test_creation(self):
        app = TUIApp()
        assert app.current_view is not None
        assert app.is_running is False

    def test_set_content(self):
        app = TUIApp()
        app.set_content({
            "packages": [
                Mock(name="requests", version="2.0.0"),
            ],
            "vulnerabilities": [],
        })

        assert len(app.packages) == 1

    def test_handle_resize(self):
        app = TUIApp()
        app._handle_resize(100, 50)

        assert app.width == 100
        assert app.height == 50

    def test_change_view(self):
        app = TUIApp()
        initial_view = app.current_view

        app.change_view("issues")
        assert app.current_view != initial_view
        assert isinstance(app.current_view, IssuesView)


class TestProgressTracker:
    """Tests for ProgressTracker class."""

    def test_creation(self):
        tracker = ProgressTracker(total=100)
        assert tracker.total == 100
        assert tracker.current == 0
        assert tracker.start_time is not None

    def test_increment(self):
        tracker = ProgressTracker(total=100)
        tracker.increment(10)
        assert tracker.current == 10

    def test_increment_single(self):
        tracker = ProgressTracker(total=100)
        tracker.increment()
        assert tracker.current == 1

    def test_percentage(self):
        tracker = ProgressTracker(total=100)
        tracker.increment(50)
        assert tracker.percentage == 50.0

    def test_elapsed_time(self):
        tracker = ProgressTracker(total=100)
        import time
        time.sleep(0.01)
        assert tracker.elapsed_seconds >= 0.01

    def test_eta(self):
        tracker = ProgressTracker(total=100)
        tracker.increment(10)
        eta = tracker.eta
        assert eta >= 0

    def test_is_complete(self):
        tracker = ProgressTracker(total=100)
        tracker.increment(100)
        assert tracker.is_complete

    def test_format_progress(self):
        tracker = ProgressTracker(total=100)
        tracker.increment(50)

        progress_str = tracker.format_progress()
        assert "50" in progress_str
        assert "50%" in progress_str or "50.0%" in progress_str


class TestFormatTable:
    """Tests for format_table utility function."""

    def test_simple_table(self):
        headers = ["Name", "Version"]
        rows = [
            ["requests", "2.28.0"],
            ["flask", "2.3.0"],
        ]

        output = format_table(headers, rows)
        assert "Name" in output
        assert "Version" in output
        assert "requests" in output
        assert "flask" in output

    def test_empty_rows(self):
        headers = ["Name", "Version"]
        rows = []

        output = format_table(headers, rows)
        assert "Name" in output  # Headers still present

    def test_with_alignment(self):
        headers = ["Name", "Count"]
        rows = [
            ["short", "1"],
            ["longer_name", "100"],
        ]

        output = format_table(headers, rows, align=["left", "right"])
        assert "Name" in output
        assert "Count" in output


class TestFormatSeverityBadge:
    """Tests for format_severity_badge function."""

    def test_critical_badge(self):
        badge = format_severity_badge("CRITICAL")
        assert "CRITICAL" in badge.upper() or "critical" in badge.lower()

    def test_high_badge(self):
        badge = format_severity_badge("HIGH")
        assert "HIGH" in badge.upper() or "high" in badge.lower()

    def test_medium_badge(self):
        badge = format_severity_badge("MEDIUM")
        assert "MEDIUM" in badge.upper() or "medium" in badge.lower()

    def test_low_badge(self):
        badge = format_severity_badge("LOW")
        assert "LOW" in badge.upper() or "low" in badge.lower()

    def test_unknown_severity(self):
        badge = format_severity_badge("UNKNOWN")
        assert badge is not None


class TestFormatVersionInfo:
    """Tests for format_version_info function."""

    def test_current_only(self):
        info = format_version_info(current="2.28.0")
        assert "2.28.0" in info
        assert "latest" not in info.lower()

    def test_outdated(self):
        info = format_version_info(current="1.0.0", latest="2.28.0")
        assert "1.0.0" in info
        assert "2.28.0" in info
        assert "outdated" in info.lower() or "update" in info.lower()

    def test_uptodate(self):
        info = format_version_info(current="2.28.0", latest="2.28.0")
        assert "2.28.0" in info
        assert "up" in info.lower() or "current" in info.lower()

    def test_with_vulnerability(self):
        info = format_version_info(
            current="1.0.0",
            latest="2.0.0",
            has_vulnerabilities=True,
        )
        assert "vulnerable" in info.lower() or "vuln" in info.lower()


class TestCursesHelpers:
    """Tests for curses helper functions."""

    def test_init_color_pair(self):
        from deptrack.tui import _init_color_pair
        color = _init_color_pair(curses.COLOR_GREEN, curses.COLOR_BLACK)
        assert color > 0

    def test_truncate_string(self):
        from deptrack.tui import _truncate_string
        assert _truncate_string("hello world", 5) == "hell..."
        assert _truncate_string("hi", 10) == "hi"

    def test_center_text(self):
        from deptrack.tui import _center_text
        assert _center_text("hello", 10) == "  hello  "
        assert _center_text("hello", 5) == "hello"


class TestLayoutHelpers:
    """Tests for layout helper functions."""

    def test_calculate_columns(self):
        from deptrack.tui import _calculate_columns
        cols = _calculate_columns(3, 80)
        assert len(cols) == 3
        assert sum(cols) <= 80

    def test_calculate_rows(self):
        from deptrack.tui import _calculate_rows
        rows = _calculate_rows(10, 60)
        assert len(rows) == 10
        # Each row should have some height
        assert sum(rows) <= 60


if __name__ == "__main__":
    pytest.main([__file__, "-v"])