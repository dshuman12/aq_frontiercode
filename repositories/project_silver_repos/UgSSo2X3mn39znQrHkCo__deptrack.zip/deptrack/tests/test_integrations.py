"""Comprehensive tests for deptrack integrations module."""

import hashlib
import hmac
import json
import os
from unittest.mock import Mock, patch

import pytest

from deptrack.integrations import (
    CIProvider,
    WebhookEvent,
    CIContext,
    WebhookPayload,
    WebhookClient,
    NotificationFormatter,
    SlackFormatter,
    GitHubFormatter,
    TeamsFormatter,
    EmailFormatter,
    GitHubActionsIntegration,
    GitLabCIIntegration,
    JenkinsIntegration,
    configure_from_env,
)


class TestCIProvider:
    """Tests for CIProvider enum."""

    def test_values(self):
        assert CIProvider.GITHUB_ACTIONS.value == "github_actions"
        assert CIProvider.GITLAB_CI.value == "gitlab_ci"
        assert CIProvider.JENKINS.value == "jenkins"
        assert CIProvider.TRAVIS.value == "travis"
        assert CIProvider.CIRCLE_CI.value == "circle_ci"
        assert CIProvider.OTHER.value == "other"


class TestWebhookEvent:
    """Tests for WebhookEvent enum."""

    def test_values(self):
        assert WebhookEvent.AUDIT_COMPLETED.value == "audit_completed"
        assert WebhookEvent.VULNERABILITY_FOUND.value == "vulnerability_found"
        assert WebhookEvent.POLICY_VIOLATION.value == "policy_violation"
        assert WebhookEvent.DEPENDENCY_ADDED.value == "dependency_added"
        assert WebhookEvent.DEPENDENCY_REMOVED.value == "dependency_removed"


class TestCIContext:
    """Tests for CIContext class."""

    def test_github_actions_detection(self):
        with patch.dict(os.environ, {"GITHUB_ACTIONS": "true", "GITHUB_REF": "refs/heads/main"}):
            context = CIContext.detect()
            assert context.provider == CIProvider.GITHUB_ACTIONS
            assert context.is_ci is True

    def test_gitlab_ci_detection(self):
        with patch.dict(os.environ, {"GITLAB_CI": "true", "CI_COMMIT_REF_NAME": "main"}):
            context = CIContext.detect()
            assert context.provider == CIProvider.GITLAB_CI

    def test_jenkins_detection(self):
        with patch.dict(os.environ, {"JENKINS_URL": "http://jenkins:8080", "BUILD_NUMBER": "123"}):
            context = CIContext.detect()
            assert context.provider == CIProvider.JENKINS

    def test_no_ci(self):
        context = CIContext.detect()
        assert context.is_ci is False
        assert context.provider == CIProvider.OTHER

    def test_get_commit_info(self):
        with patch.dict(os.environ, {"GITHUB_SHA": "abc123", "GITHUB_REPOSITORY": "owner/repo"}):
            context = CIContext.detect()
            commit = context.get_commit_info()
            assert commit["sha"] == "abc123"
            assert commit["repo"] == "owner/repo"

    def test_get_branch(self):
        with patch.dict(os.environ, {"GITHUB_REF": "refs/heads/main"}):
            context = CIContext.detect()
            branch = context.get_branch()
            assert branch == "main"


class TestWebhookPayload:
    """Tests for WebhookPayload dataclass."""

    def test_creation(self):
        payload = WebhookPayload(
            event=WebhookEvent.AUDIT_COMPLETED,
            data={"total_dependencies": 50},
            timestamp="2024-01-01T00:00:00Z",
        )
        assert payload.event == WebhookEvent.AUDIT_COMPLETED
        assert payload.data["total_dependencies"] == 50

    def test_to_dict(self):
        payload = WebhookPayload(
            event=WebhookEvent.VULNERABILITY_FOUND,
            data={"cve_id": "CVE-2024-0001"},
        )
        data = payload.to_dict()
        assert data["event"] == "vulnerability_found"
        assert data["data"]["cve_id"] == "CVE-2024-0001"

    def test_to_json(self):
        payload = WebhookPayload(
            event=WebhookEvent.POLICY_VIOLATION,
            data={"policy": "block_malicious"},
        )
        json_str = payload.to_json()
        data = json.loads(json_str)
        assert data["event"] == "policy_violation"


class TestWebhookClient:
    """Tests for WebhookClient class."""

    def test_creation(self):
        client = WebhookClient("https://example.com/webhook")
        assert client.webhook_url == "https://example.com/webhook"
        assert client.timeout == 30

    def test_creation_with_secret(self):
        client = WebhookClient(
            "https://example.com/webhook",
            secret="my_secret",
        )
        assert client.secret == "my_secret"

    def test_sign_payload(self):
        client = WebhookClient("https://example.com/webhook", secret="secret")
        payload = WebhookPayload(
            event=WebhookEvent.AUDIT_COMPLETED,
            data={},
        )

        signature = client._sign_payload(payload)
        assert signature is not None
        assert len(signature) == 64  # SHA256 hex

    def test_send_payload(self):
        client = WebhookClient("https://example.com/webhook")

        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_post.return_value = mock_response

            payload = WebhookPayload(
                event=WebhookEvent.AUDIT_COMPLETED,
                data={"count": 10},
            )

            result = client.send(payload)
            assert result is True
            mock_post.assert_called_once()

    def test_send_with_retry(self):
        client = WebhookClient("https://example.com/webhook", max_retries=3)

        with patch("requests.post") as mock_post:
            # Fail twice, then succeed
            mock_response = Mock()
            mock_response.status_code = 500

            success_response = Mock()
            success_response.status_code = 200

            mock_post.side_effect = [mock_response, mock_response, success_response]

            payload = WebhookPayload(
                event=WebhookEvent.AUDIT_COMPLETED,
                data={},
            )

            result = client.send(payload)
            assert result is True
            assert mock_post.call_count == 3

    def test_verify_signature(self):
        client = WebhookClient("https://example.com/webhook", secret="secret")

        payload = WebhookPayload(event=WebhookEvent.AUDIT_COMPLETED, data={})
        signature = client._sign_payload(payload)

        assert client.verify_signature(payload.to_json(), signature)

    def test_invalid_signature(self):
        client = WebhookClient("https://example.com/webhook", secret="secret")

        payload = WebhookPayload(event=WebhookEvent.AUDIT_COMPLETED, data={})

        assert not client.verify_signature(payload.to_json(), "invalid_signature")

    def test_batch_send(self):
        client = WebhookClient("https://example.com/webhook")

        with patch("requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_post.return_value = mock_response

            payloads = [
                WebhookPayload(event=WebhookEvent.AUDIT_COMPLETED, data={"id": i})
                for i in range(3)
            ]

            results = client.batch_send(payloads)
            assert len(results) == 3
            assert all(results)


class TestNotificationFormatter:
    """Tests for NotificationFormatter base class."""

    def test_format_vulnerability_found(self):
        formatter = NotificationFormatter()

        payload = {
            "event": "vulnerability_found",
            "data": {
                "package": "requests",
                "version": "1.0.0",
                "cve_id": "CVE-2024-0001",
                "severity": "HIGH",
                "description": "Remote code execution",
            },
        }

        formatted = formatter.format(payload)
        assert "requests" in formatted
        assert "CVE-2024-0001" in formatted
        assert "HIGH" in formatted

    def test_format_policy_violation(self):
        formatter = NotificationFormatter()

        payload = {
            "event": "policy_violation",
            "data": {
                "package": "malicious-lib",
                "policy": "block_malicious",
                "reason": "Package is known to be malicious",
            },
        }

        formatted = formatter.format(payload)
        assert "malicious-lib" in formatted
        assert "policy_violation" in formatted.lower() or "blocked" in formatted.lower()

    def test_format_audit_summary(self):
        formatter = NotificationFormatter()

        payload = {
            "event": "audit_completed",
            "data": {
                "total_dependencies": 50,
                "vulnerabilities_found": 3,
                "policies_violated": 1,
                "passed": True,
            },
        }

        formatted = formatter.format(payload)
        assert "50" in formatted or "dependencies" in formatted.lower()


class TestSlackFormatter:
    """Tests for SlackFormatter class."""

    def test_format_blocks(self):
        formatter = SlackFormatter()

        payload = {
            "event": "vulnerability_found",
            "data": {
                "package": "requests",
                "severity": "CRITICAL",
                "cve_id": "CVE-2024-0001",
            },
        }

        blocks = formatter.format_blocks(payload)
        assert len(blocks) > 0

    def test_emoji_for_severity(self):
        formatter = SlackFormatter()

        assert ":rotating_light:" in formatter.format_blocks({
            "event": "vulnerability_found",
            "data": {"severity": "CRITICAL"},
        })

        assert ":warning:" in formatter.format_blocks({
            "event": "vulnerability_found",
            "data": {"severity": "HIGH"},
        })


class TestGitHubFormatter:
    """Tests for GitHubFormatter class."""

    def test_format_issue_body(self):
        formatter = GitHubFormatter()

        payload = {
            "event": "vulnerability_found",
            "data": {
                "package": "requests",
                "cve_id": "CVE-2024-0001",
                "severity": "HIGH",
                "fixed_version": "2.28.0",
            },
        }

        body = formatter.format(payload)
        assert "requests" in body
        assert "CVE-2024-0001" in body
        assert "2.28.0" in body

    def test_format_labels(self):
        formatter = GitHubFormatter()

        payload = {
            "event": "vulnerability_found",
            "data": {"severity": "CRITICAL"},
        }

        labels = formatter.format_labels(payload)
        assert "security" in labels
        assert "critical" in labels


class TestTeamsFormatter:
    """Tests for TeamsFormatter class."""

    def test_format_adaptive_card(self):
        formatter = TeamsFormatter()

        payload = {
            "event": "policy_violation",
            "data": {
                "package": "blocked-pkg",
                "policy": "block_malicious",
            },
        }

        card = formatter.format_adaptive_card(payload)
        assert card is not None
        assert "type" in card


class TestEmailFormatter:
    """Tests for EmailFormatter class."""

    def test_format_email(self):
        formatter = EmailFormatter()

        payload = {
            "event": "audit_completed",
            "data": {
                "total_dependencies": 100,
                "vulnerabilities_found": 5,
            },
        }

        email = formatter.format(payload)
        assert "subject" in email
        assert "body" in email
        assert "Audit Report" in email["subject"]


class TestGitHubActionsIntegration:
    """Tests for GitHubActionsIntegration class."""

    def test_creation(self):
        integration = GitHubActionsIntegration()
        assert integration.provider == CIProvider.GITHUB_ACTIONS

    def test_set_output(self):
        integration = GitHubActionsIntegration()

        with patch.dict(os.environ, {"GITHUB_OUTPUT": "/tmp/github_output"}):
            integration.set_output("test_var", "test_value")

    def test_add_mask(self):
        integration = GitHubActionsIntegration()

        with patch.dict(os.environ, {"GITHUB_ENV": "/tmp/github_env"}):
            integration.add_mask("secret_value")

    def test_set_environment_variable(self):
        integration = GitHubActionsIntegration()

        with patch.dict(os.environ, {"GITHUB_ENV": "/tmp/github_env"}):
            integration.set_env("DEVPINFRA_TOKEN", "abc123")

    def test_fail_action(self):
        integration = GitHubActionsIntegration()

        with patch("sys.exit") as mock_exit:
            integration.fail_action("Test failure message")
            mock_exit.assert_called_with(1)


class TestGitLabCIIntegration:
    """Tests for GitLabCIIntegration class."""

    def test_creation(self):
        integration = GitLabCIIntegration()
        assert integration.provider == CIProvider.GITLAB_CI

    def test_create_variable(self):
        integration = GitLabCIIntegration()

        with patch.dict(os.environ, {"CI_JOB_TOKEN": "test_token"}):
            integration.create_variable("SECRET_VAR", "value", protected=True)

    def test_fail_pipeline(self):
        integration = GitLabCIIntegration()

        with patch("sys.exit") as mock_exit:
            integration.fail_pipeline("Pipeline failed due to security issues")
            mock_exit.assert_called_with(1)

    def test_create_artifact(self):
        integration = GitLabCIIntegration()

        with patch.dict(os.environ, {"CI_PROJECT_DIR": "/tmp"}):
            artifact_path = integration.create_artifact("security-report.json", {})


class TestJenkinsIntegration:
    """Tests for JenkinsIntegration class."""

    def test_creation(self):
        integration = JenkinsIntegration()
        assert integration.provider == CIProvider.JENKINS

    def test_set_build_status(self):
        integration = JenkinsIntegration()

        integration.set_build_status("SUCCESS", message="Build passed")

    def test_add_build_wrapper(self):
        integration = JenkinsIntegration()

        integration.add_build_wrapper("inject-passwords")

    def test_fail_build(self):
        integration = JenkinsIntegration()

        with patch("sys.exit") as mock_exit:
            integration.fail_build("Build failed due to security violations")
            mock_exit.assert_called_with(1)


class TestConfigureFromEnv:
    """Tests for configure_from_env function."""

    def test_no_env_vars(self):
        with patch.dict(os.environ, {}, clear=True):
            config = configure_from_env()
            assert config["ci_provider"] == CIProvider.OTHER
            assert config["webhooks"] == []

    def test_with_webhook_url(self):
        with patch.dict(os.environ, {"DEVPINFRA_WEBHOOK_URL": "https://hooks.example.com/webhook"}):
            config = configure_from_env()
            assert len(config["webhooks"]) == 1
            assert config["webhooks"][0]["url"] == "https://hooks.example.com/webhook"

    def test_with_github_actions(self):
        env = {
            "GITHUB_ACTIONS": "true",
            "GITHUB_REPOSITORY": "owner/repo",
            "GITHUB_SHA": "abc123",
        }
        with patch.dict(os.environ, env):
            config = configure_from_env()
            assert config["ci_provider"] == CIProvider.GITHUB_ACTIONS

    def test_with_gitlab_ci(self):
        env = {
            "GITLAB_CI": "true",
            "CI_PROJECT_PATH": "group/project",
        }
        with patch.dict(os.environ, env):
            config = configure_from_env()
            assert config["ci_provider"] == CIProvider.GITLAB_CI

    def test_with_jenkins(self):
        env = {
            "JENKINS_URL": "http://jenkins:8080",
            "BUILD_NUMBER": "123",
        }
        with patch.dict(os.environ, env):
            config = configure_from_env()
            assert config["ci_provider"] == CIProvider.JENKINS


if __name__ == "__main__":
    pytest.main([__file__, "-v"])