"""Comprehensive tests for deptrack network module."""

import time
from unittest.mock import Mock, patch

import pytest

from deptrack.network import (
    Request,
    Response,
    RetryConfig,
    RateLimitConfig,
    TokenBucket,
    HostRateLimiter,
    NetworkClient,
    AsyncNetworkClient,
    PyPIAdapter,
    SecurityAdvisoryClient,
    NetworkError,
    RetryExhaustedError,
    RateLimitError,
)


class TestRequest:
    """Tests for Request dataclass."""

    def test_creation(self):
        req = Request(
            method="GET",
            url="https://example.com",
            headers={"Authorization": "Bearer token"},
        )
        assert req.method == "GET"
        assert req.url == "https://example.com"
        assert req.headers["Authorization"] == "Bearer token"

    def test_default_values(self):
        req = Request(url="https://example.com")
        assert req.method == "GET"
        assert req.headers == {}
        assert req.timeout == 30
        assert req.allow_redirects is True


class TestResponse:
    """Tests for Response dataclass."""

    def test_creation(self):
        resp = Response(
            status_code=200,
            headers={"Content-Type": "application/json"},
            content=b'{"data": "test"}',
        )
        assert resp.status_code == 200
        assert resp.headers["Content-Type"] == "application/json"
        assert resp.content == b'{"data": "test"}'

    def test_is_success(self):
        assert Response(status_code=200, headers={}, content=b"").is_success
        assert not Response(status_code=404, headers={}, content=b"").is_success
        assert not Response(status_code=500, headers={}, content=b"").is_success

    def test_json_parsing(self):
        resp = Response(
            status_code=200,
            headers={},
            content=b'{"data": "test", "count": 42}',
        )
        data = resp.json()
        assert data["data"] == "test"
        assert data["count"] == 42

    def test_json_parsing_invalid(self):
        resp = Response(status_code=200, headers={}, content=b"not json")
        with pytest.raises(ValueError):
            resp.json()


class TestRetryConfig:
    """Tests for RetryConfig dataclass."""

    def test_default_config(self):
        config = RetryConfig()
        assert config.max_attempts == 3
        assert config.base_delay == 1.0
        assert config.max_delay == 60.0
        assert config.exponential_base == 2.0

    def test_custom_config(self):
        config = RetryConfig(max_attempts=5, base_delay=0.5)
        assert config.max_attempts == 5
        assert config.base_delay == 0.5


class TestRateLimitConfig:
    """Tests for RateLimitConfig dataclass."""

    def test_creation(self):
        config = RateLimitConfig(requests_per_second=10, burst_size=20)
        assert config.requests_per_second == 10
        assert config.burst_size == 20

    def test_default_values(self):
        config = RateLimitConfig()
        assert config.requests_per_second == 5
        assert config.burst_size == 10


class TestTokenBucket:
    """Tests for TokenBucket rate limiter."""

    def test_initial_tokens(self):
        bucket = TokenBucket(capacity=5, refill_rate=2.0)
        assert bucket.available_tokens == 5

    def test_consume_success(self):
        bucket = TokenBucket(capacity=5, refill_rate=2.0)
        assert bucket.try_consume(3)
        assert bucket.available_tokens == 2

    def test_consume_failure(self):
        bucket = TokenBucket(capacity=2, refill_rate=1.0)
        assert not bucket.try_consume(5)

    def test_refill(self):
        bucket = TokenBucket(capacity=5, refill_rate=10.0)
        bucket.try_consume(3)
        time.sleep(0.1)
        bucket.refill()
        assert bucket.available_tokens >= 2


class TestHostRateLimiter:
    """Tests for HostRateLimiter."""

    def test_register_host(self):
        limiter = HostRateLimiter()
        limiter.register_host("pypi.org", RateLimitConfig(requests_per_second=10))
        assert "pypi.org" in limiter._buckets

    def test_acquire_and_release(self):
        limiter = HostRateLimiter()
        limiter.register_host("example.com", RateLimitConfig(requests_per_second=10))

        limiter.acquire("example.com")
        limiter.release("example.com")

    def test_rate_limit(self):
        limiter = HostRateLimiter()
        limiter.register_host(
            "slow.com",
            RateLimitConfig(requests_per_second=1, burst_size=1),
        )

        # First request should succeed
        limiter.acquire("slow.com")
        limiter.release("slow.com")

        # Second immediate request might fail due to rate limiting
        # (depends on timing)
        try:
            limiter.acquire("slow.com", timeout=0.1)
            limiter.release("slow.com")
        except RateLimitError:
            pass  # Expected if rate limited


class TestNetworkClient:
    """Tests for NetworkClient class."""

    def test_creation(self):
        client = NetworkClient()
        assert client.base_timeout == 30
        assert client.max_retries == 3

    def test_get_request(self):
        client = NetworkClient()
        # Mock the underlying requests
        with patch("requests.Session.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.headers = {}
            mock_response.content = b'{"data": "test"}'
            mock_get.return_value = mock_response

            resp = client.get("https://api.example.com/data")
            assert resp.status_code == 200

    def test_post_request(self):
        client = NetworkClient()
        with patch("requests.Session.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 201
            mock_response.headers = {}
            mock_response.content = b'{"id": 123}'
            mock_post.return_value = mock_response

            resp = client.post(
                "https://api.example.com/items",
                json={"name": "test"},
            )
            assert resp.status_code == 201

    def test_retry_on_failure(self):
        client = NetworkClient(retry_config=RetryConfig(max_attempts=3))

        with patch("requests.Session.get") as mock_get:
            # Fail twice, then succeed
            error_response = Mock()
            error_response.status_code = 500
            error_response.raise_for_status.side_effect = Exception("Server Error")

            success_response = Mock()
            success_response.status_code = 200
            success_response.headers = {}
            success_response.content = b'{"data": "ok"}'

            mock_get.side_effect = [error_response, error_response, success_response]

            resp = client.get("https://api.example.com/data")
            assert resp.status_code == 200
            assert mock_get.call_count == 3

    def test_cache_hit(self):
        client = NetworkClient(cache=Mock())

        cached_response = Response(status_code=200, headers={}, content=b'cached')
        client.cache.get.return_value = cached_response

        resp = client.get("https://api.example.com/data", use_cache=True)
        assert resp.content == b"cached"
        client.cache.get.assert_called_once()

    def test_timeout_error(self):
        client = NetworkClient()

        with patch("requests.Session.get") as mock_get:
            mock_get.side_effect = TimeoutError()

            with pytest.raises(NetworkError):
                client.get("https://api.example.com/data", timeout=1)


class TestAsyncNetworkClient:
    """Tests for AsyncNetworkClient class."""

    def test_creation(self):
        client = AsyncNetworkClient()
        assert client.base_timeout == 30
        assert client.max_retries == 3

    @pytest.mark.asyncio
    async def test_get_request(self):
        client = AsyncNetworkClient()

        with patch("aiohttp.ClientSession.get") as mock_get:
            mock_response = Mock()
            mock_response.status = 200
            mock_response.headers = {}
            mock_response.json = async lambda: {"data": "test"}
            mock_response.read = async lambda: b'{"data": "test"}'
            mock_get.return_value.__aenter__.return_value = mock_response

            resp = await client.get("https://api.example.com/data")
            assert resp.status == 200

    @pytest.mark.asyncio
    async def test_batch_get(self):
        client = AsyncNetworkClient()

        with patch("aiohttp.ClientSession.get") as mock_get:
            mock_response = Mock()
            mock_response.status = 200
            mock_response.headers = {}
            mock_response.json = async lambda: {"data": "test"}
            mock_response.read = async lambda: b'{"data": "test"}'
            mock_get.return_value.__aenter__.return_value = mock_response

            results = await client.batch_get([
                "https://api.example.com/1",
                "https://api.example.com/2",
            ])

            assert len(results) == 2

    @pytest.mark.asyncio
    async def test_rate_limiting(self):
        client = AsyncNetworkClient()
        client.rate_limiter.register_host(
            "slow.example.com",
            RateLimitConfig(requests_per_second=1, burst_size=1),
        )

        # First request should succeed
        await client.get("https://slow.example.com/data")


class TestPyPIAdapter:
    """Tests for PyPIAdapter class."""

    def test_creation(self):
        adapter = PyPIAdapter()
        assert adapter.base_url == "https://pypi.org/pypi"
        assert adapter.json_url == "https://pypi.org/pypi"

    def test_get_package_url(self):
        adapter = PyPIAdapter()
        url = adapter._get_package_url("requests")
        assert "requests" in url
        assert "json" in url

    def test_get_package_url_with_version(self):
        adapter = PyPIAdapter()
        url = adapter._get_package_url("requests", "2.0.0")
        assert "requests" in url
        assert "2.0.0" in url

    @pytest.mark.asyncio
    async def test_fetch_package_info(self):
        adapter = PyPIAdapter()

        with patch.object(adapter, "_fetch") as mock_fetch:
            mock_fetch.return_value = {
                "info": {
                    "name": "requests",
                    "version": "2.0.0",
                    "license": "Apache 2.0",
                    "summary": "HTTP library",
                },
                "releases": {"2.0.0": [{"url": "url", "filename": "file"}]},
            }

            info = await adapter.fetch_package_info("requests", "2.0.0")
            assert info["name"] == "requests"
            assert info["version"] == "2.0.0"

    @pytest.mark.asyncio
    async def test_search_packages(self):
        adapter = PyPIAdapter()

        with patch.object(adapter, "_fetch") as mock_fetch:
            mock_fetch.return_value = {
                "releases": {
                    "requests": [
                        {"version": "2.0.0", "url": "url1"},
                        {"version": "1.0.0", "url": "url2"},
                    ]
                }
            }

            versions = await adapter.search_packages("requests")
            assert len(versions) == 2

    def test_parse_release_urls(self):
        adapter = PyPIAdapter()
        releases = [
            {"filename": "requests-2.0.0.tar.gz", "url": "url1", "size": 1000},
            {"filename": "requests-2.0.0.whl", "url": "url2", "size": 2000},
        ]

        urls = adapter._parse_release_urls(releases, "cp39")
        assert isinstance(urls, list)


class TestSecurityAdvisoryClient:
    """Tests for SecurityAdvisoryClient class."""

    def test_creation(self):
        client = SecurityAdvisoryClient()
        assert client.base_url == "https://api.osv.dev/v1"

    @pytest.mark.asyncio
    async def test_query_vulnerabilities(self):
        client = SecurityAdvisoryClient()

        with patch.object(client, "_fetch") as mock_fetch:
            mock_fetch.return_value = {
                "vulns": [
                    {
                        "id": "CVE-2024-0001",
                        "summary": "Test vulnerability",
                        "severity": "HIGH",
                    }
                ]
            }

            vulns = await client.query_vulnerabilities("requests", "1.0.0")
            assert len(vulns) == 1
            assert vulns[0]["id"] == "CVE-2024-0001"

    @pytest.mark.asyncio
    async def test_batch_query(self):
        client = SecurityAdvisoryClient()

        with patch.object(client, "_fetch") as mock_fetch:
            mock_fetch.return_value = {"vulns": []}

            packages = [
                ("requests", "1.0.0"),
                ("flask", "2.0.0"),
            ]

            results = await client.batch_query(package_versions=packages)
            assert len(results) == 2


class TestNetworkErrorHandling:
    """Tests for network error handling."""

    def test_network_error_creation(self):
        error = NetworkError("Connection failed", status_code=None)
        assert "Connection failed" in str(error)

    def test_retry_exhausted_error(self):
        error = RetryExhaustedError(
            attempts=3,
            last_error=Exception("Server error"),
        )
        assert error.attempts == 3
        assert "Retry exhausted" in str(error)

    def test_rate_limit_error(self):
        error = RateLimitError(retry_after=60)
        assert error.retry_after == 60
        assert "rate limit" in str(error).lower()


class TestCacheIntegration:
    """Tests for network cache integration."""

    def test_etag_handling(self):
        from deptrack.network import Request

        req1 = Request(url="https://api.example.com/data")
        req2 = Request(url="https://api.example.com/data", etag='"abc123"')

        assert req1.etag is None
        assert req2.etag == '"abc123"'


if __name__ == "__main__":
    pytest.main([__file__, "-v"])