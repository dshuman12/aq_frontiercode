"""Comprehensive tests for deptrack SBOM module."""

import json
from datetime import datetime

import pytest

from deptrack.sbom import (
    SBOMFormat,
    SBOMType,
    SBOMComponent,
    SBOMMetadata,
    SBOM,
    SBOMGenerator,
    SPDXGenerator,
    SPDXJsonGenerator,
    CycloneDXGenerator,
    SBOMExporter,
    create_sbom_from_dependencies,
    create_purl,
    parse_purl,
)
from deptrack.models import Dependency


class TestSBOMComponent:
    """Tests for SBOMComponent class."""

    def test_creation(self):
        comp = SBOMComponent(
            name="requests",
            version="2.0.0",
            package_type="library",
        )
        assert comp.name == "requests"
        assert comp.version == "2.0.0"
        assert comp.package_type == "library"

    def test_to_dict(self):
        comp = SBOMComponent(
            name="requests",
            version="2.0.0",
            license_concluded="MIT",
        )
        data = comp.to_dict()
        assert data["name"] == "requests"
        assert data["version"] == "2.0.0"
        assert data["license_concluded"] == "MIT"


class TestSBOMMetadata:
    """Tests for SBOMMetadata class."""

    def test_creation(self):
        meta = SBOMMetadata(
            document_name="test-project",
            document_namespace="https://example.com/test",
        )
        assert meta.document_name == "test-project"
        assert meta.sbom_type == SBOMType.LIBRARY

    def test_to_dict(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com",
        )
        data = meta.to_dict()
        assert data["document_name"] == "test"
        assert data["sbom_type"] == "library"


class TestSBOM:
    """Tests for SBOM class."""

    def test_add_component(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com",
        )
        sbom = SBOM(metadata=meta)

        comp = SBOMComponent(name="requests", version="2.0.0")
        sbom.add_component(comp)

        assert len(sbom.components) == 1
        assert sbom.get_component("requests") is comp

    def test_add_dependency(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com",
        )
        sbom = SBOM(metadata=meta)

        sbom.add_component(SBOMComponent(name="app"))
        sbom.add_component(SBOMComponent(name="requests"))
        sbom.add_dependency("app", "requests")

        app = sbom.get_component("app")
        assert "requests" in app.dependencies


class TestSBOMGenerator:
    """Tests for SBOMGenerator class."""

    def test_add_package(self):
        gen = SBOMGenerator()
        gen.set_metadata("test-project", "https://example.com/test")

        gen.add_package(
            name="requests",
            version="2.0.0",
            ecosystem="pypi",
            license_info="MIT",
        )

        sbom = gen.build()
        assert len(sbom.components) == 1
        assert sbom.components[0].name == "requests"

    def test_add_from_dependency(self):
        gen = SBOMGenerator()
        gen.set_metadata("test", "https://example.com")

        dep = Dependency(name="requests", version="2.0.0")
        gen.add_from_dependency(dep)

        sbom = gen.build()
        assert len(sbom.components) == 1
        assert sbom.components[0].name == "requests"


class TestSPDXGenerator:
    """Tests for SPDX generator."""

    def test_generate(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com/test",
        )
        sbom = SBOM(metadata=meta)
        sbom.add_component(SBOMComponent(name="requests", version="2.0.0"))

        gen = SPDXGenerator()
        output = gen.generate(sbom)

        assert "SPDXVersion" in output
        assert "PackageName: requests" in output


class TestSPDXJsonGenerator:
    """Tests for SPDX JSON generator."""

    def test_generate(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com/test",
        )
        sbom = SBOM(metadata=meta)
        sbom.add_component(SBOMComponent(name="requests", version="2.0.0"))

        gen = SPDXJsonGenerator()
        output = gen.generate(sbom)

        data = json.loads(output)
        assert data["spdxVersion"] == "SPDX-2.3"
        assert len(data["packages"]) == 1


class TestCycloneDXGenerator:
    """Tests for CycloneDX generator."""

    def test_generate_v15(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com/test",
        )
        sbom = SBOM(metadata=meta)
        sbom.add_component(SBOMComponent(
            name="requests",
            version="2.0.0",
            license_concluded="MIT",
        ))

        gen = CycloneDXGenerator("1.5")
        output = gen.generate(sbom)

        data = json.loads(output)
        assert data["specVersion"] == "1.5"
        assert len(data["components"]) == 1
        assert data["components"][0]["name"] == "requests"

    def test_generate_v16(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com/test",
        )
        sbom = SBOM(metadata=meta)
        sbom.add_component(SBOMComponent(name="django", version="3.0.0"))

        gen = CycloneDXGenerator("1.6")
        output = gen.generate(sbom)

        data = json.loads(output)
        assert data["specVersion"] == "1.5"  # Falls back to 1.5


class TestSBOMExporter:
    """Tests for SBOMExporter class."""

    def test_export_spdx_json(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com/test",
        )
        sbom = SBOM(metadata=meta)
        sbom.add_component(SBOMComponent(name="flask", version="2.0.0"))

        exporter = SBOMExporter()
        output = exporter.export(sbom, SBOMFormat.SPDX_2_3)

        assert "SPDX-2.3" in output
        assert "flask" in output

    def test_export_cyclonedx(self):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com/test",
        )
        sbom = SBOM(metadata=meta)
        sbom.add_component(SBOMComponent(name="flask", version="2.0.0"))

        exporter = SBOMExporter()
        output = exporter.export(sbom, SBOMFormat.CYCLONEDX_1_5)

        data = json.loads(output)
        assert data["specVersion"] == "1.5"

    def test_save(self, tmp_path):
        meta = SBOMMetadata(
            document_name="test",
            document_namespace="https://example.com/test",
        )
        sbom = SBOM(metadata=meta)
        sbom.add_component(SBOMComponent(name="sqlalchemy", version="1.4"))

        exporter = SBOMExporter()
        output_path = tmp_path / "sbom.json"
        exporter.save(sbom, output_path, SBOMFormat.CYCLONEDX_1_5)

        assert output_path.exists()
        data = json.loads(output_path.read_text())
        assert "CycloneDX" in data["bomFormat"]


class TestCreateSBOMFromDependencies:
    """Tests for create_sbom_from_dependencies function."""

    def test_create_sbom(self):
        deps = [
            Dependency(name="requests", version="2.0.0"),
            Dependency(name="flask", version="2.0.0"),
        ]

        sbom = create_sbom_from_dependencies(
            deps,
            name="test-project",
            namespace="https://example.com/test",
        )

        assert len(sbom.components) == 2
        assert sbom.metadata.document_name == "test-project"


class TestPurlUtils:
    """Tests for Package URL utilities."""

    def test_create_purl(self):
        purl = create_purl("pypi", "requests", "2.0.0")
        assert purl == "pkg:pypi/requests@2.0.0"

    def test_create_purl_with_qualifiers(self):
        purl = create_purl("npm", "lodash", "4.0.0", qualifiers={"scope": "registry"})
        assert purl == "pkg:npm/lodash@4.0.0?scope=registry"

    def test_create_purl_with_subpath(self):
        purl = create_purl("go", "github.com/user/repo", subpath="/path")
        assert purl == "pkg:go/github.com/user/repo#path"

    def test_parse_purl_simple(self):
        result = parse_purl("pkg:pypi/requests@2.0.0")
        assert result["type"] == "pypi"
        assert result["name"] == "requests"
        assert result["version"] == "2.0.0"

    def test_parse_purl_with_qualifiers(self):
        result = parse_purl("pkg:npm/lodash@4.0.0?scope=registry")
        assert result["type"] == "npm"
        assert result["qualifiers"]["scope"] == "registry"

    def test_parse_purl_with_subpath(self):
        result = parse_purl("pkg:golang/github.com/user/repo@v1.0.0#path/to/module")
        assert result["type"] == "golang"
        assert result["subpath"] == "path/to/module"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])