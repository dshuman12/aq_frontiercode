"""Tests for report formatters."""

import json
import pytest
from deptrack.models import AuditResult, Dependency, Issue, Severity
from deptrack.reporters.text import render_text
from deptrack.reporters.json_reporter import render_json, diff_reports
from deptrack.reporters.html import render_html


def make_result() -> AuditResult:
    dep = Dependency(name="requests", version="==2.19.0")
    result = AuditResult(dependencies=[dep], source_files=["requirements.txt"])
    result.issues.append(
        Issue(dep=dep, kind="vulnerability", message="CVE-2018-18074", severity=Severity.HIGH,
              fix_suggestion="Upgrade to 2.20.0")
    )
    return result


def test_render_text_contains_package():
    result = make_result()
    text = render_text(result)
    assert "requests" in text


def test_render_text_shows_severity():
    result = make_result()
    text = render_text(result)
    assert "[HIGH]" in text


def test_render_text_no_issues():
    dep = Dependency(name="flask", version="==2.0.0")
    result = AuditResult(dependencies=[dep])
    text = render_text(result)
    assert "No issues found" in text


def test_render_json_valid():
    result = make_result()
    text = render_json(result)
    data = json.loads(text)
    assert "summary" in data
    assert "issues" in data
    assert data["summary"]["total_issues"] == 1


def test_render_json_issue_fields():
    result = make_result()
    data = json.loads(render_json(result))
    issue = data["issues"][0]
    assert issue["package"] == "requests"
    assert issue["severity"] == "high"
    assert issue["kind"] == "vulnerability"


def test_diff_reports_added():
    old = {"issues": []}
    new = {"issues": [{"package": "flask", "kind": "unpinned", "message": "no version"}]}
    diff = diff_reports(old, new)
    assert len(diff["added"]) == 1
    assert len(diff["resolved"]) == 0


def test_diff_reports_resolved():
    old = {"issues": [{"package": "flask", "kind": "unpinned", "message": "no version"}]}
    new = {"issues": []}
    diff = diff_reports(old, new)
    assert len(diff["resolved"]) == 1
    assert len(diff["added"]) == 0


def test_render_html_contains_package():
    result = make_result()
    html = render_html(result)
    assert "requests" in html
    assert "<!DOCTYPE html>" in html


def test_render_html_no_issues():
    dep = Dependency(name="flask", version="==2.0.0")
    result = AuditResult(dependencies=[dep])
    html = render_html(result)
    assert "No issues found" in html
