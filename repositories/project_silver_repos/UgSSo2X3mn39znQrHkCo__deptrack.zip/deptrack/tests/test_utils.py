"""Tests for utility helpers."""

import json
import pytest
from pathlib import Path
from deptrack.models import Dependency, AuditResult, DepSource
from deptrack.utils.helpers import deduplicate, filter_by_marker, group_by_source
from deptrack.utils.lockfile import generate_lockfile, verify_lockfile, load_lockfile, write_lockfile


def test_deduplicate():
    deps = [
        Dependency(name="requests"),
        Dependency(name="Requests"),
        Dependency(name="flask"),
    ]
    result = deduplicate(deps)
    assert len(result) == 2
    names = [d.canonical_name for d in result]
    assert "requests" in names
    assert "flask" in names


def test_filter_by_marker_excludes_win32():
    deps = [
        Dependency(name="pywin32", markers="sys_platform == 'win32'"),
        Dependency(name="flask"),
    ]
    result = filter_by_marker(deps, platform="linux")
    assert len(result) == 1
    assert result[0].name == "flask"


def test_filter_by_marker_keeps_no_marker():
    deps = [Dependency(name="flask"), Dependency(name="requests")]
    result = filter_by_marker(deps, platform="linux")
    assert len(result) == 2


def test_group_by_source():
    deps = [
        Dependency(name="flask", source=DepSource.REQUIREMENTS_TXT),
        Dependency(name="requests", source=DepSource.REQUIREMENTS_TXT),
        Dependency(name="pydantic", source=DepSource.PYPROJECT_TOML),
    ]
    groups = group_by_source(deps)
    assert len(groups["requirements.txt"]) == 2
    assert len(groups["pyproject.toml"]) == 1


def test_generate_lockfile():
    dep = Dependency(name="requests", version="==2.28.0", source=DepSource.REQUIREMENTS_TXT)
    result = AuditResult(dependencies=[dep])
    lockfile = generate_lockfile(result)
    assert lockfile["lockfile_version"] == 1
    assert "requests" in lockfile["packages"]
    assert lockfile["packages"]["requests"]["version"] == "==2.28.0"


def test_verify_lockfile_pass():
    dep = Dependency(name="requests", version="==2.28.0")
    result = AuditResult(dependencies=[dep])
    lockfile = generate_lockfile(result)
    discrepancies = verify_lockfile([dep], lockfile)
    assert discrepancies == []


def test_verify_lockfile_new_package():
    dep_old = Dependency(name="requests", version="==2.28.0")
    dep_new = Dependency(name="flask", version="==2.0.0")
    result = AuditResult(dependencies=[dep_old])
    lockfile = generate_lockfile(result)
    discrepancies = verify_lockfile([dep_old, dep_new], lockfile)
    assert any("NEW" in d for d in discrepancies)


def test_verify_lockfile_version_mismatch():
    dep_old = Dependency(name="requests", version="==2.28.0")
    dep_new = Dependency(name="requests", version="==2.30.0")
    result = AuditResult(dependencies=[dep_old])
    lockfile = generate_lockfile(result)
    discrepancies = verify_lockfile([dep_new], lockfile)
    assert any("VERSION MISMATCH" in d for d in discrepancies)


def test_write_and_load_lockfile(tmp_path):
    dep = Dependency(name="requests", version="==2.28.0")
    result = AuditResult(dependencies=[dep])
    path = tmp_path / "deptrack.lock"
    write_lockfile(result, path)
    loaded = load_lockfile(path)
    assert "requests" in loaded["packages"]
