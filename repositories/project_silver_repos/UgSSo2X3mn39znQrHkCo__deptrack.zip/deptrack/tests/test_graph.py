"""Tests for graph analysis module."""

import pytest
from deptrack.models import Dependency
from deptrack.graph import DependencyGraph, GraphNode, build_graph


def make_dep(name: str, version: str = "==1.0.0") -> Dependency:
    return Dependency(name=name, version=version)


def test_add_dependency():
    g = DependencyGraph()
    dep = make_dep("requests")
    g.add_dependency(dep)
    node = g.get_node("requests")
    assert node is not None
    assert node.name == "requests"


def test_add_edge():
    g = DependencyGraph()
    g.add_dependency(make_dep("flask"))
    g.add_dependency(make_dep("werkzeug"))
    g.add_edge("flask", "werkzeug")
    flask_node = g.get_node("flask")
    werkzeug_node = g.get_node("werkzeug")
    assert "werkzeug" in flask_node.dependencies
    assert "flask" in werkzeug_node.dependents


def test_root_nodes():
    g = DependencyGraph()
    g.add_dependency(make_dep("flask"))
    g.add_dependency(make_dep("werkzeug"))
    g.add_edge("flask", "werkzeug")
    roots = [n.name for n in g.root_nodes()]
    assert "flask" in roots
    assert "werkzeug" not in roots


def test_leaf_nodes():
    g = DependencyGraph()
    g.add_dependency(make_dep("flask"))
    g.add_dependency(make_dep("werkzeug"))
    g.add_edge("flask", "werkzeug")
    leaves = [n.name for n in g.leaf_nodes()]
    assert "werkzeug" in leaves
    assert "flask" not in leaves


def test_transitive_dependencies():
    g = DependencyGraph()
    for name in ["a", "b", "c"]:
        g.add_dependency(make_dep(name))
    g.add_edge("a", "b")
    g.add_edge("b", "c")
    transitive = g.transitive_dependencies("a")
    assert "b" in transitive
    assert "c" in transitive
    assert "a" not in transitive


def test_detect_cycles_none():
    g = DependencyGraph()
    for name in ["a", "b", "c"]:
        g.add_dependency(make_dep(name))
    g.add_edge("a", "b")
    g.add_edge("b", "c")
    assert g.detect_cycles() == []


def test_build_graph():
    deps = [make_dep("flask"), make_dep("requests"), make_dep("click")]
    g = build_graph(deps)
    assert g.get_node("flask") is not None
    assert g.get_node("requests") is not None
    assert len(list(g.nodes())) == 3


def test_most_depended_upon():
    g = DependencyGraph()
    for name in ["a", "b", "c", "d"]:
        g.add_dependency(make_dep(name))
    g.add_edge("a", "d")
    g.add_edge("b", "d")
    g.add_edge("c", "d")
    top = g.most_depended_upon(top_n=1)
    assert top[0][0] == "d"
    assert top[0][1] == 3


def test_to_dict():
    g = DependencyGraph()
    g.add_dependency(make_dep("flask"))
    d = g.to_dict()
    assert "flask" in d
