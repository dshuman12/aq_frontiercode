# deptrack

A Python CLI tool for auditing and tracking project dependencies.

## Features

- Parse `requirements.txt` and `pyproject.toml`
- Detect duplicate and conflicting package declarations
- Flag unpinned, wildcard, and unbounded version constraints
- Check against a built-in vulnerability advisory database
- Generate reports in text, JSON, and HTML formats
- Generate and verify lockfiles for reproducible environments

## Installation

```bash
pip install -e .
```

## Usage

```bash
# Audit current directory
deptrack audit

# Audit specific files
deptrack audit requirements.txt pyproject.toml

# Output as JSON
deptrack audit --format json --output report.json

# Generate lockfile
deptrack lock

# Verify against lockfile
deptrack verify
```

## Project Structure

```
deptrack/
├── audit.py          # Core audit engine
├── cli.py            # CLI entrypoint
├── models.py         # Data models
├── parsers/          # File format parsers
│   ├── requirements.py
│   └── pyproject.py
├── checkers/         # Issue detectors
│   ├── duplicates.py
│   ├── versions.py
│   └── security.py
├── reporters/        # Output formatters
│   ├── text.py
│   ├── json_reporter.py
│   └── html.py
└── utils/            # Helpers
    ├── helpers.py
    └── lockfile.py
```

## Running Tests

```bash
pytest tests/ -v
```
