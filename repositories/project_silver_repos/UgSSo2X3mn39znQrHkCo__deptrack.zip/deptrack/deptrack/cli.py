"""Command-line interface for deptrack."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from deptrack.audit import audit_directory, run_audit
from deptrack.reporters import print_text, render_json, write_html, write_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="deptrack",
        epilog="Run 'deptrack COMMAND --help' for help on a specific command.",
        description="Audit and track Python project dependencies.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # --- audit ---
    audit_p = sub.add_parser("audit", help="Audit dependency files for issues.")
    audit_p.add_argument(
        "paths",
        nargs="*",
        metavar="FILE",
        help="Dependency files to audit (requirements.txt, pyproject.toml). "
             "If omitted, auto-discovers in the current directory.",
    )
    audit_p.add_argument(
        "--format",
        choices=["text", "json", "html"],
        default="text",
        help="Output format (default: text).",
    )
    audit_p.add_argument(
        "--output", "-o",
        metavar="FILE",
        help="Write report to FILE instead of stdout.",
    )
    audit_p.add_argument(
        "--no-vuln",
        action="store_true",
        help="Skip vulnerability checks.",
    )
    audit_p.add_argument(
        "--no-pin",
        action="store_true",
        help="Skip version pinning checks.",
    )
    audit_p.add_argument(
        "--advisory-db",
        metavar="FILE",
        help="Path to an external JSON advisory database.",
    )
    audit_p.add_argument(
        "--fail-on",
        choices=["any", "high", "critical", "none"],
        default="none",
        help="Exit with non-zero status if issues of this severity or higher are found.",
    )

    # --- lock ---
    lock_p = sub.add_parser("lock", help="Generate a deptrack.lock file.")
    lock_p.add_argument("paths", nargs="*", metavar="FILE")
    lock_p.add_argument("--output", "-o", metavar="FILE", default="deptrack.lock")

    # --- verify ---
    verify_p = sub.add_parser("verify", help="Verify deps match the lockfile.")
    verify_p.add_argument("paths", nargs="*", metavar="FILE")
    verify_p.add_argument("--lockfile", default="deptrack.lock", metavar="FILE")

    return parser


def cmd_audit(args: argparse.Namespace) -> int:
    advisory_db = Path(args.advisory_db) if getattr(args, "advisory_db", None) else None

    if args.paths:
        result = run_audit(
            [Path(p) for p in args.paths],
            check_vuln=not args.no_vuln,
            check_pins=not args.no_pin,
            advisory_db=advisory_db,
        )
    else:
        result = audit_directory(
            Path.cwd(),
            check_vuln=not args.no_vuln,
            check_pins=not args.no_pin,
        )

    output_path = Path(args.output) if getattr(args, "output", None) else None

    if args.format == "json":
        text = render_json(result)
        if output_path:
            output_path.write_text(text, encoding="utf-8")
        else:
            print(text)
    elif args.format == "html":
        from deptrack.reporters import render_html
        html = render_html(result)
        if output_path:
            output_path.write_text(html, encoding="utf-8")
        else:
            print(html)
    else:
        if output_path:
            with open(output_path, "w", encoding="utf-8") as fh:
                from deptrack.reporters import render_text
                render_text(result, file=fh)
        else:
            print_text(result)

    # Exit code logic
    fail_on = getattr(args, "fail_on", "none")
    if fail_on == "none":
        return 0
    summary = result.summary()
    if fail_on == "any" and summary["total_issues"] > 0:
        return 1
    if fail_on in ("high", "critical") and summary["critical"] > 0:
        return 1
    if fail_on == "high" and summary["high"] > 0:
        return 1
    return 0


def cmd_lock(args: argparse.Namespace) -> int:
    from deptrack.utils import write_lockfile

    if args.paths:
        result = run_audit([Path(p) for p in args.paths], check_vuln=False, check_pins=False)
    else:
        result = audit_directory(Path.cwd(), check_vuln=False, check_pins=False)

    out = write_lockfile(result, Path(args.output))
    print(f"Lockfile written to {out}")
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    from deptrack.utils import load_lockfile, verify_lockfile

    if args.paths:
        result = run_audit([Path(p) for p in args.paths], check_vuln=False, check_pins=False)
    else:
        result = audit_directory(Path.cwd(), check_vuln=False, check_pins=False)

    lockfile = load_lockfile(Path(args.lockfile))
    discrepancies = verify_lockfile(result.dependencies, lockfile)

    if discrepancies:
        print("Lockfile verification FAILED:")
        for d in discrepancies:
            print(f"  {d}")
        return 1

    print("Lockfile verification PASSED.")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "audit":
            return cmd_audit(args)
        elif args.command == "lock":
            return cmd_lock(args)
        elif args.command == "verify":
            return cmd_verify(args)
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
