"""deptrack - Advanced utilities for file operations and path handling."""

from __future__ import annotations

import fnmatch
import os
import re
import shutil
from pathlib import Path
from typing import Generator, Iterator


# ---------------------------------------------------------------------------
# File finding utilities
# ---------------------------------------------------------------------------

def find_files(
    root: Path | str,
    pattern: str = "*",
    exclude: list[str] | None = None,
    include_hidden: bool = False,
) -> Generator[Path, None, None]:
    """
    Recursively find files matching a pattern.

    Args:
        root: Root directory to search
        pattern: Glob pattern to match (e.g., "*.txt", "requirements*.txt")
        exclude: List of patterns to exclude
        include_hidden: Whether to include hidden files

    Yields:
        Paths to matching files
    """
    root = Path(root)
    exclude = exclude or []

    for path in root.rglob(pattern):
        if path.is_file():
            # Check hidden files
            if not include_hidden and any(part.startswith('.') for part in path.parts):
                continue

            # Check exclusions
            if any(fnmatch.fnmatch(str(path), exc) for exc in exclude):
                continue

            yield path


def find_requirements_files(root: Path | str) -> Generator[Path, None, None]:
    """Find all common requirements file patterns."""
    patterns = [
        "requirements*.txt",
        "requirements/**/*.txt",
        "constraints*.txt",
        "dev-requirements*.txt",
        "test-requirements*.txt",
        "prod-requirements*.txt",
        "**/requirements/*.txt",
    ]

    for pattern in patterns:
        yield from find_files(root, pattern, exclude=["__pycache__", "*.pyc"])


def find_lockfiles(root: Path | str) -> Generator[Path, None, None]:
    """Find all common lockfile patterns."""
    patterns = [
        "Pipfile.lock",
        "package-lock.json",
        "yarn.lock",
        "pnpm-lock.yaml",
        "cargo.lock",
        "go.sum",
        "composer.lock",
        "*.lock",
        "*.lock/*",
    ]

    for pattern in patterns:
        yield from find_files(root, pattern)


# ---------------------------------------------------------------------------
# Path utilities
# ---------------------------------------------------------------------------

def normalize_path(path: Path | str) -> Path:
    """Normalize a path to absolute form."""
    path = Path(path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    return path.resolve()


def is_subpath(path: Path, parent: Path) -> bool:
    """Check if path is a subpath of parent."""
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def get_relative_path(path: Path, base: Path) -> Path:
    """Get path relative to base, or absolute if not possible."""
    try:
        return path.resolve().relative_to(base.resolve())
    except ValueError:
        return path.resolve()


def ensure_directory(path: Path) -> Path:
    """Ensure a directory exists, creating it if necessary."""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_file_write(path: Path, content: str, backup: bool = True) -> None:
    """Write content to a file safely with optional backup."""
    path = Path(path)

    if backup and path.exists():
        backup_path = path.with_suffix(path.suffix + ".bak")
        shutil.copy2(path, backup_path)

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def atomic_write(path: Path, content: str) -> None:
    """Write content atomically to a file."""
    path = Path(path)
    temp_path = path.with_suffix(path.suffix + ".tmp")

    try:
        temp_path.write_text(content, encoding="utf-8")
        temp_path.replace(path)  # Atomic on POSIX
    except Exception:
        if temp_path.exists():
            temp_path.unlink()
        raise


# ---------------------------------------------------------------------------
# File content utilities
# ---------------------------------------------------------------------------

def read_lines(path: Path, strip: bool = True) -> Iterator[str]:
    """Read file lines with optional stripping."""
    with open(path, encoding="utf-8") as f:
        for line in f:
            yield line.strip() if strip else line


def count_lines(path: Path) -> int:
    """Count lines in a file."""
    count = 0
    with open(path, encoding="utf-8", errors="ignore") as f:
        for _ in f:
            count += 1
    return count


def get_file_hash(path: Path, algorithm: str = "sha256") -> str:
    """Get hash of file contents."""
    import hashlib

    hasher = hashlib.new(algorithm)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def is_binary_file(path: Path) -> bool:
    """Check if a file appears to be binary."""
    try:
        with open(path, "rb") as f:
            chunk = f.read(1024)
            return b"\x00" in chunk
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Glob patterns and regex utilities
# ---------------------------------------------------------------------------

def compile_glob_pattern(pattern: str) -> re.Pattern:
    """Convert a glob pattern to a compiled regex."""
    pattern = fnmatch.translate(pattern)
    return re.compile(pattern)


def match_any(text: str, patterns: list[str]) -> bool:
    """Check if text matches any of the patterns."""
    return any(fnmatch.fnmatch(text, pat) for pat in patterns)


# ---------------------------------------------------------------------------
# Directory size utilities
# ---------------------------------------------------------------------------

def get_directory_size(path: Path) -> int:
    """Get total size of directory in bytes."""
    total = 0
    for entry in path.rglob("*"):
        if entry.is_file():
            total += entry.stat().st_size
    return total


def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable size."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


# ---------------------------------------------------------------------------
# File watching utilities
# ---------------------------------------------------------------------------

class FileWatcher:
    """Watch files for changes."""

    def __init__(self, path: Path, patterns: list[str] | None = None):
        self.path = Path(path)
        self.patterns = patterns or ["*"]
        self._file_mtimes: dict[Path, float] = {}

    def check_changes(self) -> Generator[Path, None, None]:
        """Check for changed files and yield their paths."""
        for pattern in self.patterns:
            for file_path in find_files(self.path, pattern):
                try:
                    mtime = file_path.stat().st_mtime
                    if file_path not in self._file_mtimes:
                        self._file_mtimes[file_path] = mtime
                        continue

                    if mtime != self._file_mtimes[file_path]:
                        self._file_mtimes[file_path] = mtime
                        yield file_path

                except OSError:
                    pass  # File might have been deleted

    def reset(self) -> None:
        """Reset the file tracking state."""
        self._file_mtimes.clear()


# ---------------------------------------------------------------------------
# Configuration file detection
# ---------------------------------------------------------------------------

CONFIG_FILES = {
    ".deptrack.yaml": "yaml",
    ".deptrack.yml": "yaml",
    ".deptrack.json": "json",
    "deptrack.yaml": "yaml",
    "deptrack.yml": "yaml",
    "deptrack.json": "json",
    ".deptrack.toml": "toml",
    "pyproject.toml": "toml",
}


def find_config_file(root: Path | str = ".") -> tuple[Path | None, str | None]:
    """Find a deptrack configuration file in the given directory."""
    root = Path(root)

    for filename, fmt in CONFIG_FILES.items():
        path = root / filename
        if path.exists():
            return path, fmt

    # Check parent directories up to 3 levels
    for _ in range(3):
        root = root.parent
        if not root or root == root.parent:
            break

        for filename, fmt in CONFIG_FILES.items():
            path = root / filename
            if path.exists():
                return path, fmt

    return None, None


# ---------------------------------------------------------------------------
# Package discovery utilities
# ---------------------------------------------------------------------------

def find_python_packages(root: Path | str, include_tests: bool = True) -> Generator[Path, None, None]:
    """Find all Python packages (directories with __init__.py)."""
    root = Path(root)

    for path in root.rglob("__init__.py"):
        if not include_tests and _is_test_dir(path):
            continue

        package_dir = path.parent
        if "__pycache__" not in package_dir.parts:
            yield package_dir


def _is_test_dir(path: Path) -> bool:
    """Check if a path is a test directory."""
    parts = path.parts
    test_dirs = {"tests", "test", "testing", "spec", "__tests__"}
    return any(part in test_dirs for part in parts)


def get_package_name(package_path: Path, root: Path) -> str:
    """Get the dotted package name from a path."""
    try:
        rel_path = package_path.relative_to(root)
        return ".".join(rel_path.parts)
    except ValueError:
        return package_path.name


# ---------------------------------------------------------------------------
# Temporary file utilities
# ---------------------------------------------------------------------------

import tempfile
import contextlib


@contextlib.contextmanager
def temp_file(suffix: str = "", prefix: str = "deptrack_"):
    """Create a temporary file and clean it up afterwards."""
    fd, path = tempfile.mkstemp(suffix=suffix, prefix=prefix)
    os.close(fd)

    try:
        yield Path(path)
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


@contextlib.contextmanager
def temp_directory(suffix: str = "", prefix: str = "deptrack_"):
    """Create a temporary directory and clean it up afterwards."""
    path = Path(tempfile.mkdtemp(suffix=suffix, prefix=prefix))

    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


# ---------------------------------------------------------------------------
# Archive utilities
# ---------------------------------------------------------------------------

def extract_archive(archive_path: Path, dest_dir: Path | None = None) -> Path:
    """Extract an archive (zip or tar) to a directory."""
    import tarfile

    archive_path = Path(archive_path)
    dest_dir = Path(dest_dir) if dest_dir else archive_path.parent / archive_path.stem

    dest_dir.mkdir(parents=True, exist_ok=True)

    if archive_path.suffix == ".zip":
        import zipfile
        with zipfile.ZipFile(archive_path) as zf:
            zf.extractall(dest_dir)
    elif archive_path.suffix in (".tar", ".gz", ".bz2", ".xz", ".tgz"):
        with tarfile.open(archive_path) as tf:
            tf.extractall(dest_dir)
    else:
        raise ValueError(f"Unsupported archive format: {archive_path.suffix}")

    return dest_dir


def create_archive(source_dir: Path, output_path: Path, format: str = "zip") -> Path:
    """Create an archive from a directory."""
    import zipfile

    output_path = Path(output_path)
    source_dir = Path(source_dir)

    if format == "zip":
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for file_path in source_dir.rglob("*"):
                if file_path.is_file():
                    arcname = file_path.relative_to(source_dir)
                    zf.write(file_path, arcname)

    return output_path


# ---------------------------------------------------------------------------
# File comparison utilities
# ---------------------------------------------------------------------------

def diff_files(file1: Path, file2: Path) -> Generator[str, None, None]:
    """Generate diff-like output between two files."""
    try:
        import difflib

        with open(file1, encoding="utf-8", errors="ignore") as f1:
            lines1 = f1.readlines()

        with open(file2, encoding="utf-8", errors="ignore") as f2:
            lines2 = f2.readlines()

        diff = difflib.unified_diff(
            lines1, lines2,
            fromfile=str(file1),
            tofile=str(file2),
            lineterm=""
        )

        for line in diff:
            yield line

    except Exception:
        yield f"Unable to compare {file1} and {file2}"


# ---------------------------------------------------------------------------
# Backup utilities
# ---------------------------------------------------------------------------

def backup_file(path: Path, backup_dir: Path | None = None) -> Path:
    """Create a backup of a file."""
    from datetime import datetime

    path = Path(path)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    if backup_dir:
        backup_dir = Path(backup_dir)
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_path = backup_dir / f"{path.name}.{timestamp}.bak"
    else:
        backup_path = path.with_suffix(path.suffix + f".{timestamp}.bak")

    shutil.copy2(path, backup_path)
    return backup_path


def list_backups(path: Path, backup_dir: Path | None = None) -> list[Path]:
    """List all backups of a file."""
    path = Path(path)
    base_name = path.name

    if backup_dir:
        search_dir = Path(backup_dir)
    else:
        search_dir = path.parent

    pattern = f"{base_name}.*.bak"
    return sorted(search_dir.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)


# ---------------------------------------------------------------------------
# Cleanup utilities
# ---------------------------------------------------------------------------

def cleanup_pycache(root: Path | str, dry_run: bool = False) -> int:
    """Remove all __pycache__ directories."""
    root = Path(root)
    count = 0

    for pycache in root.rglob("__pycache__"):
        if dry_run:
            print(f"Would remove: {pycache}")
        else:
            shutil.rmtree(pycache, ignore_errors=True)
            count += 1

    return count


def cleanup_pyc_files(root: Path | str, dry_run: bool = False) -> int:
    """Remove all .pyc files."""
    root = Path(root)
    count = 0

    for pyc in root.rglob("*.pyc"):
        if dry_run:
            print(f"Would remove: {pyc}")
        else:
            pyc.unlink()
            count += 1

    return count


def cleanup_temp_files(root: Path | str, patterns: list[str] | None = None, dry_run: bool = False) -> int:
    """Remove temporary files matching patterns."""
    root = Path(root)
    patterns = patterns or ["*.tmp", "*.temp", "*.bak", "*.swp", "*~"]

    count = 0
    for pattern in patterns:
        for file_path in root.rglob(pattern):
            if file_path.is_file():
                if dry_run:
                    print(f"Would remove: {file_path}")
                else:
                    file_path.unlink()
                    count += 1

    return count


# ---------------------------------------------------------------------------
# Pretty printing utilities
# ---------------------------------------------------------------------------

def truncate_string(s: str, max_length: int, suffix: str = "...") -> str:
    """Truncate a string to a maximum length."""
    if len(s) <= max_length:
        return s
    return s[:max_length - len(suffix)] + suffix


def align_text(text: str, width: int, align: str = "left") -> str:
    """Align text within a given width."""
    if align == "left":
        return text.ljust(width)
    elif align == "right":
        return text.rjust(width)
    elif align == "center":
        return text.center(width)
    return text


def indent_text(text: str, indent: int = 2, indent_char: str = " ") -> str:
    """Indent all lines of text."""
    prefix = indent_char * indent
    return "\n".join(prefix + line for line in text.split("\n"))


def word_wrap(text: str, width: int) -> list[str]:
    """Wrap text to fit within a width."""
    words = text.split()
    lines = []
    current_line = []

    for word in words:
        if sum(len(w) for w in current_line) + len(current_line) + len(word) <= width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(" ".join(current_line))
            current_line = [word]

    if current_line:
        lines.append(" ".join(current_line))

    return lines


# ---------------------------------------------------------------------------
# Progress bar utilities
# ---------------------------------------------------------------------------

def make_progress_bar(
    current: int,
    total: int,
    width: int = 40,
    prefix: str = "",
    suffix: str = "",
) -> str:
    """Create a simple text progress bar."""
    if total == 0:
        percent = 100
    else:
        percent = int(100 * current / total)

    filled = int(width * current / total) if total > 0 else 0
    bar = "=" * filled + "-" * (width - filled)

    return f"{prefix}|{bar}| {percent}% {suffix}"


# ---------------------------------------------------------------------------
# Table formatting utilities
# ---------------------------------------------------------------------------

@dataclass
class TableColumn:
    name: str
    width: int
    align: str = "left"


class AsciiTable:
    """Create a simple ASCII table."""

    def __init__(self):
        self.columns: list[TableColumn] = []
        self.rows: list[list[str]] = []

    def add_column(self, name: str, width: int, align: str = "left") -> None:
        self.columns.append(TableColumn(name=name, width=width, align=align))

    def add_row(self, *values: str) -> None:
        self.rows.append([str(v) for v in values])

    def render(self) -> str:
        if not self.columns or not self.rows:
            return ""

        lines = []

        # Header
        header = " | ".join(
            col.name.ljust(col.width) for col in self.columns
        )
        lines.append(header)
        lines.append("-" * len(header))

        # Rows
        for row in self.rows:
            cells = []
            for i, value in enumerate(row):
                col = self.columns[i] if i < len(self.columns) else self.columns[-1]
                if col.align == "right":
                    cells.append(value.rjust(col.width))
                elif col.align == "center":
                    cells.append(value.center(col.width))
                else:
                    cells.append(value.ljust(col.width))
            lines.append(" | ".join(cells))

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Environment utilities
# ---------------------------------------------------------------------------

def get_env_bool(key: str, default: bool = False) -> bool:
    """Get a boolean value from environment."""
    value = os.environ.get(key, "").lower()
    if value in ("true", "1", "yes", "on"):
        return True
    if value in ("false", "0", "no", "off"):
        return False
    return default


def get_env_list(key: str, separator: str = ",", default: list[str] | None = None) -> list[str]:
    """Get a list of values from environment."""
    value = os.environ.get(key, "")
    if not value:
        return default or []
    return [v.strip() for v in value.split(separator) if v.strip()]