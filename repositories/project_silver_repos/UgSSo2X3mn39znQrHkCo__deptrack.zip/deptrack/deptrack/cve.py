"""CVE and vulnerability database management for deptrack."""

from __future__ import annotations

import csv
import datetime
import hashlib
import json
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, BinaryIO, TextIO

from deptrack.cache import CacheEntry, get_disk_cache, get_lru_cache


class CVESeverity(Enum):
    """CVSS severity levels."""

    NONE = "NONE"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    @classmethod
    def from_cvss_score(cls, score: float) -> "CVESeverity":
        """Convert CVSS score to severity level."""
        if score == 0.0:
            return cls.NONE
        if score < 4.0:
            return cls.LOW
        if score < 7.0:
            return cls.MEDIUM
        if score < 9.0:
            return cls.HIGH
        return cls.CRITICAL

    @classmethod
    def from_string(cls, value: str) -> "CVESeverity":
        """Parse severity from string."""
        value = value.upper().strip()
        mapping = {
            "NONE": cls.NONE,
            "N": cls.NONE,
            "LOW": cls.LOW,
            "L": cls.LOW,
            "MEDIUM": cls.MEDIUM,
            "MODERATE": cls.MEDIUM,
            "M": cls.MEDIUM,
            "HIGH": cls.HIGH,
            "H": cls.HIGH,
            "CRITICAL": cls.CRITICAL,
            "C": cls.CRITICAL,
        }
        return mapping.get(value, cls.MEDIUM)


@dataclass
class CVE:
    """Represents a Common Vulnerabilities and Exposures entry."""

    cve_id: str
    package_name: str
    package_ecosystem: str = "pypi"
    affected_versions: str = ""
    fixed_version: str = ""
    severity: CVESeverity = CVESeverity.MEDIUM
    cvss_score: float = 0.0
    cvss_vector: str = ""
    summary: str = ""
    description: str = ""
    references: list[str] = field(default_factory=list)
    published_date: datetime.date | None = None
    modified_date: datetime.date | None = None
    references_data: list[dict[str, str]] = field(default_factory=list)

    @property
    def cve_url(self) -> str:
        """Get the NVD URL for this CVE."""
        return f"https://nvd.nist.gov/vuln/detail/{self.cve_id}"

    @property
    def is_known(self) -> bool:
        """Return True if this is a known CVE."""
        return bool(self.cve_id and self.cve_id.startswith("CVE-"))

    def matches_version(self, version: str) -> bool:
        """Check if a version is affected by this CVE."""
        if not self.affected_versions:
            return True  # No version info, assume affected

        # Parse version constraints
        version_clean = self._clean_version(version)
        affected = self._parse_version_constraint(self.affected_versions)

        for constraint in affected:
            if not self._check_constraint(version_clean, constraint):
                return False
        return True

    @staticmethod
    def _clean_version(v: str) -> str:
        """Clean version string for comparison."""
        import re
        # Remove operators
        v = re.sub(r"^[><=!~^]+\s*", "", v).strip()
        # Remove trailing pre-release identifiers
        v = re.sub(r"([a-z])\d*$", r"\1", v, flags=re.IGNORECASE)
        return v

    @staticmethod
    def _parse_version_constraint(constraint: str) -> list[tuple[str, str]]:
        """Parse version constraint string into list of (operator, version)."""
        constraints = []
        # Simple parsing - handle comma-separated and space-separated
        parts = re.split(r"[,;\s]+", constraint)
        for part in parts:
            part = part.strip()
            if not part:
                continue
            m = re.match(r"^([><=!~^]+)(.+)$", part)
            if m:
                constraints.append((m.group(1), m.group(2).strip()))
            else:
                constraints.append(("==", part))
        return constraints

    @staticmethod
    def _check_constraint(version: str, constraint: tuple[str, str]) -> bool:
        """Check if version satisfies constraint."""
        op, target = constraint
        v_parts = [int(x) if x.isdigit() else x for x in re.split(r"[.\-_]", version)]
        t_parts = [int(x) if x.isdigit() else x for x in re.split(r"[.\-_]", target)]

        # Pad shorter list
        max_len = max(len(v_parts), len(t_parts))
        v_parts.extend([0] * (max_len - len(v_parts)))
        t_parts.extend([0] * (max_len - len(t_parts)))

        if op == "==":
            return v_parts == t_parts
        if op == "!=":
            return v_parts != t_parts
        if op == "<":
            return v_parts < t_parts
        if op == "<=":
            return v_parts <= t_parts
        if op == ">":
            return v_parts > t_parts
        if op == ">=":
            return v_parts >= t_parts
        if op == "~=":
            # Compatible release - major.minor must match, patch can be >= target
            for i in range(len(t_parts) - 1):
                if v_parts[i] != t_parts[i]:
                    return False
            return v_parts[: len(t_parts) - 1] == t_parts[: len(t_parts) - 1] and v_parts >= t_parts
        return True

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "cve_id": self.cve_id,
            "package_name": self.package_name,
            "package_ecosystem": self.package_ecosystem,
            "affected_versions": self.affected_versions,
            "fixed_version": self.fixed_version,
            "severity": self.severity.value,
            "cvss_score": self.cvss_score,
            "cvss_vector": self.cvss_vector,
            "summary": self.summary,
            "description": self.description,
            "references": self.references,
            "published_date": self.published_date.isoformat() if self.published_date else None,
            "modified_date": self.modified_date.isoformat() if self.modified_date else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CVE":
        """Create CVE from dictionary."""
        published = data.get("published_date")
        modified = data.get("modified_date")

        return cls(
            cve_id=data.get("cve_id", ""),
            package_name=data.get("package_name", ""),
            package_ecosystem=data.get("package_ecosystem", "pypi"),
            affected_versions=data.get("affected_versions", ""),
            fixed_version=data.get("fixed_version", ""),
            severity=CVESeverity.from_string(data.get("severity", "MEDIUM")),
            cvss_score=float(data.get("cvss_score", 0)),
            cvss_vector=data.get("cvss_vector", ""),
            summary=data.get("summary", ""),
            description=data.get("description", ""),
            references=data.get("references", []),
            published_date=datetime.date.fromisoformat(published) if published else None,
            modified_date=datetime.date.fromisoformat(modified) if modified else None,
        )

    @classmethod
    def from_osv(cls, osv_data: dict[str, Any]) -> "CVE":
        """Create CVE from OSV format."""
        affected = osv_data.get("affected", [])
        first_affect = affected[0] if affected else {}

        package = first_affect.get("package", {})
        ranges = first_affect.get("ranges", [])
        events = []
        for r in ranges:
            events.extend(r.get("events", []))

        fixed = None
        for event in events:
            if "fixed" in event:
                fixed = event["fixed"]
                break

        severity = CVESeverity.MEDIUM
        cvss_score = 0.0
        severity_data = osv_data.get("severity", [])
        for s in severity_data:
            if "score" in s:
                try:
                    cvss_score = float(s["score"])
                    severity = CVESeverity.from_cvss_score(cvss_score)
                    break
                except (ValueError, TypeError):
                    pass

        published_str = osv_data.get("published")
        modified_str = osv_data.get("modified")
        published = datetime.date.fromisoformat(published_str[:10]) if published_str else None
        modified = datetime.date.fromisoformat(modified_str[:10]) if modified_str else None

        return cls(
            cve_id=osv_data.get("id", ""),
            package_name=package.get("name", ""),
            package_ecosystem=package.get("ecosystem", "pypi"),
            fixed_version=fixed or "",
            severity=severity,
            cvss_score=cvss_score,
            summary=osv_data.get("summary", ""),
            description=osv_data.get("details", ""),
            references=[ref.get("url", "") for ref in osv_data.get("references", [])],
            published_date=published,
            modified_date=modified,
        )


@dataclass
class AdvisoryDatabase:
    """Container for vulnerability advisories."""

    cves: dict[str, CVE] = field(default_factory=dict)
    package_index: dict[str, set[str]] = field(default_factory=dict)  # package -> set of cve_ids
    metadata: dict[str, Any] = field(default_factory=dict)

    def add_cve(self, cve: CVE) -> None:
        """Add a CVE to the database."""
        self.cves[cve.cve_id] = cve

        # Update package index
        pkg_name = cve.package_name.lower().replace("-", "_")
        if pkg_name not in self.package_index:
            self.package_index[pkg_name] = set()
        self.package_index[pkg_name].add(cve.cve_id)

    def get_cve(self, cve_id: str) -> CVE | None:
        """Get a CVE by ID."""
        return self.cves.get(cve_id)

    def get_for_package(self, package_name: str) -> list[CVE]:
        """Get all CVEs affecting a package."""
        pkg_name = package_name.lower().replace("-", "_")
        cve_ids = self.package_index.get(pkg_name, set())
        return [self.cves[cve_id] for cve_id in cve_ids if cve_id in self.cves]

    def check_package_version(
        self,
        package_name: str,
        version: str,
    ) -> list[tuple[CVE, bool]]:
        """Check if a package version is affected. Returns list of (CVE, is_affected)."""
        cves = self.get_for_package(package_name)
        results = []
        for cve in cves:
            is_affected = cve.matches_version(version)
            results.append((cve, is_affected))
        return results

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "metadata": self.metadata,
            "cves": {cve_id: cve.to_dict() for cve_id, cve in self.cves.items()},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AdvisoryDatabase":
        """Deserialize from dictionary."""
        db = cls()
        db.metadata = data.get("metadata", {})
        for cve_id, cve_data in data.get("cves", {}).items():
            cve = CVE.from_dict(cve_data)
            db.add_cve(cve)
        return db

    @property
    def total_cves(self) -> int:
        """Total number of CVEs in database."""
        return len(self.cves)

    @property
    def total_packages(self) -> int:
        """Total number of unique packages."""
        return len(self.package_index)

    def summary(self) -> dict[str, Any]:
        """Get summary statistics."""
        by_severity = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
            "none": 0,
        }
        for cve in self.cves.values():
            key = cve.severity.value.lower()
            by_severity[key] = by_severity.get(key, 0) + 1

        return {
            "total_cves": self.total_cves,
            "total_packages": self.total_packages,
            "by_severity": by_severity,
            "last_updated": self.metadata.get("last_updated"),
        }


class AdvisoryDatabaseLoader:
    """Loader for various advisory database formats."""

    def __init__(self) -> None:
        self._cache = get_disk_cache()

    def load_from_json(self, path: Path | str) -> AdvisoryDatabase:
        """Load advisory database from JSON file."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Advisory database not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        db = AdvisoryDatabase.from_dict(data)
        db.metadata["source_file"] = str(path)
        db.metadata["loaded_at"] = datetime.datetime.now().isoformat()
        return db

    def load_from_csv(self, path: Path | str) -> AdvisoryDatabase:
        """Load advisory database from CSV file."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Advisory database not found: {path}")

        db = AdvisoryDatabase()

        with open(path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                cve = CVE(
                    cve_id=row.get("cve_id", ""),
                    package_name=row.get("package_name", ""),
                    package_ecosystem=row.get("ecosystem", "pypi"),
                    affected_versions=row.get("affected_versions", ""),
                    fixed_version=row.get("fixed_version", ""),
                    severity=CVESeverity.from_string(row.get("severity", "MEDIUM")),
                    summary=row.get("summary", ""),
                )
                db.add_cve(cve)

        db.metadata["source_file"] = str(path)
        db.metadata["loaded_at"] = datetime.datetime.now().isoformat()
        db.metadata["format"] = "csv"
        return db

    def load_from_nvd_json(self, path: Path | str) -> AdvisoryDatabase:
        """Load from NVD JSON feed format."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"NVD feed not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        db = AdvisoryDatabase()

        # NVD JSON format varies by version, try to handle common formats
        vulnerabilities = data.get("vulnerabilities", [])

        for vuln in vulnerabilities:
            cve_data = vuln.get("cve", {})

            # Extract affected products
            configurations = cve_data.get("configurations", [])
            affected_packages = []

            for config in configurations:
                nodes = config.get("nodes", [])
                for node in nodes:
                    cpe_matches = node.get("cpeMatch", [])
                    for cpe in cpe_matches:
                        if cpe.get("vulnerable", False):
                            cpe_str = cpe.get("criteria", "")
                            # Parse CPE 3.0 format
                            # cpe:2.3:a:vendor:package:version:...
                            parts = cpe_str.split(":")
                            if len(parts) >= 5:
                                affected_packages.append({
                                    "vendor": parts[3],
                                    "package": parts[4],
                                    "version": parts[5] if len(parts) > 5 else "*",
                                })

            # Get severity
            metrics = cve_data.get("metrics", {})
            cvss_v31 = metrics.get("cvssMetricV31", [])
            cvss_v30 = metrics.get("cvssMetricV30", [])
            cvss_v2 = metrics.get("cvssMetricV2", [])

            severity = CVESeverity.MEDIUM
            cvss_score = 0.0
            cvss_vector = ""

            if cvss_v31:
                cvss_data = cvss_v31[0].get("cvssData", {})
                cvss_score = cvss_data.get("baseScore", 0)
                cvss_vector = cvss_data.get("vectorString", "")
                severity = CVESeverity.from_cvss_score(cvss_score)
            elif cvss_v30:
                cvss_data = cvss_v30[0].get("cvssData", {})
                cvss_score = cvss_data.get("baseScore", 0)
                cvss_vector = cvss_data.get("vectorString", "")
                severity = CVESeverity.from_cvss_score(cvss_score)
            elif cvss_v2:
                cvss_data = cvss_v2[0].get("cvssData", {})
                cvss_score = cvss_data.get("baseScore", 0)
                cvss_vector = cvss_data.get("vectorString", "")
                severity = CVESeverity.from_cvss_score(cvss_score)

            cve_id = cve_data.get("id", "")
            description = cve_data.get("descriptions", [{}])[0].get("value", "")

            published_str = cve_data.get("published")
            modified_str = cve_data.get("lastModified")
            published = datetime.date.fromisoformat(published_str[:10]) if published_str else None
            modified = datetime.date.fromisoformat(modified_str[:10]) if modified_str else None

            # Create CVE for each affected package
            for affected in affected_packages:
                cve = CVE(
                    cve_id=cve_id,
                    package_name=affected["package"],
                    affected_versions=f"<={affected['version']}" if affected['version'] != '*' else "",
                    severity=severity,
                    cvss_score=cvss_score,
                    cvss_vector=cvss_vector,
                    description=description,
                    published_date=published,
                    modified_date=modified,
                )
                db.add_cve(cve)

        db.metadata["source_file"] = str(path)
        db.metadata["loaded_at"] = datetime.datetime.now().isoformat()
        db.metadata["format"] = "nvd_json"
        return db

    def load_from_osv(self, path: Path | str) -> AdvisoryDatabase:
        """Load from OSV JSON format."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"OSV file not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        db = AdvisoryDatabase()

        # Handle both single entry and list of entries
        entries = data if isinstance(data, list) else [data]

        for entry in entries:
            if isinstance(entry, dict) and "id" in entry:
                cve = CVE.from_osv(entry)
                db.add_cve(cve)

        db.metadata["source_file"] = str(path)
        db.metadata["loaded_at"] = datetime.datetime.now().isoformat()
        db.metadata["format"] = "osv"
        return db

    def save_to_json(self, db: AdvisoryDatabase, path: Path | str) -> None:
        """Save advisory database to JSON file."""
        path = Path(path)
        data = db.to_dict()
        data["metadata"]["saved_at"] = datetime.datetime.now().isoformat()

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def merge_databases(self, dbs: list[AdvisoryDatabase]) -> AdvisoryDatabase:
        """Merge multiple databases into one."""
        merged = AdvisoryDatabase()

        for db in dbs:
            for cve in db.cves.values():
                # Don't overwrite existing CVEs with older versions
                existing = merged.cves.get(cve.cve_id)
                if existing is None:
                    merged.add_cve(cve)
                elif cve.modified_date and existing.modified_date:
                    if cve.modified_date > existing.modified_date:
                        del merged.cves[cve.cve_id]
                        merged.add_cve(cve)

        merged.metadata["merged_at"] = datetime.datetime.now().isoformat()
        merged.metadata["source_count"] = len(dbs)
        return merged


class VulnerabilityChecker:
    """High-level vulnerability checking interface."""

    def __init__(self, database: AdvisoryDatabase | None = None) -> None:
        self._database = database or AdvisoryDatabase()

    def set_database(self, db: AdvisoryDatabase) -> None:
        """Set the vulnerability database."""
        self._database = db

    def check(
        self,
        package_name: str,
        version: str | None = None,
    ) -> dict[str, Any]:
        """
        Check a package version for vulnerabilities.

        Returns dict with:
            - is_vulnerable: bool
            - vulnerabilities: list of matching CVEs
            - advisory_count: total CVEs for this package
        """
        cves = self._database.get_for_package(package_name)

        if not cves:
            return {
                "is_vulnerable": False,
                "vulnerabilities": [],
                "advisory_count": 0,
            }

        if version is None:
            # Return all CVEs without version check
            return {
                "is_vulnerable": True,
                "vulnerabilities": [cve.to_dict() for cve in cves],
                "advisory_count": len(cves),
            }

        matching = []
        for cve in cves:
            if cve.matches_version(version):
                matching.append(cve)

        return {
            "is_vulnerable": len(matching) > 0,
            "vulnerabilities": [cve.to_dict() for cve in matching],
            "advisory_count": len(cves),
        }

    def batch_check(
        self,
        packages: list[tuple[str, str | None]],
    ) -> dict[str, dict[str, Any]]:
        """Check multiple packages at once."""
        results = {}
        for package_name, version in packages:
            results[package_name] = self.check(package_name, version)
        return results

    def generate_report(
        self,
        packages: list[tuple[str, str]],
    ) -> dict[str, Any]:
        """Generate a comprehensive vulnerability report."""
        results = self.batch_check(packages)

        summary = {
            "total_packages": len(packages),
            "vulnerable_packages": 0,
            "total_vulnerabilities": 0,
            "by_severity": {
                "critical": 0,
                "high": 0,
                "medium": 0,
                "low": 0,
            },
        }

        for package_name, result in results.items():
            if result["is_vulnerable"]:
                summary["vulnerable_packages"] += 1
                for vuln in result["vulnerabilities"]:
                    severity = vuln.get("severity", "MEDIUM").lower()
                    summary["by_severity"][severity] = summary["by_severity"].get(severity, 0) + 1
                    summary["total_vulnerabilities"] += 1

        return {
            "summary": summary,
            "packages": results,
            "database_summary": self._database.summary(),
        }


# Built-in advisory data
BUILTIN_ADVISORIES = [
    {
        "cve_id": "CVE-2018-18074",
        "package_name": "requests",
        "affected_versions": "<2.20.0",
        "fixed_version": "2.20.0",
        "severity": "HIGH",
        "cvss_score": 7.5,
        "summary": "Requests HTTP Authorization header leak to redirect targets",
    },
    {
        "cve_id": "CVE-2022-22817",
        "package_name": "pillow",
        "affected_versions": "<9.0.0",
        "fixed_version": "9.0.0",
        "severity": "CRITICAL",
        "cvss_score": 9.8,
        "summary": "PIL.ImageMath.eval allows arbitrary code execution",
    },
    {
        "cve_id": "CVE-2020-14343",
        "package_name": "pyyaml",
        "affected_versions": "<5.4",
        "fixed_version": "5.4",
        "severity": "CRITICAL",
        "cvss_score": 9.8,
        "summary": "PyYAML arbitrary code execution via yaml.load()",
    },
    {
        "cve_id": "CVE-2021-33503",
        "package_name": "urllib3",
        "affected_versions": "<1.26.5",
        "fixed_version": "1.26.5",
        "severity": "MEDIUM",
        "cvss_score": 5.3,
        "summary": "urllib3 ReDoS via crafted header value",
    },
    {
        "cve_id": "CVE-2023-23931",
        "package_name": "cryptography",
        "affected_versions": "<41.0.0",
        "fixed_version": "41.0.0",
        "severity": "HIGH",
        "cvss_score": 7.5,
        "summary": "Bleichenbacher timing oracle attack",
    },
    {
        "cve_id": "CVE-2022-42969",
        "package_name": "py",
        "affected_versions": "<1.11.0",
        "fixed_version": "1.11.0",
        "severity": "HIGH",
        "cvss_score": 8.1,
        "summary": "PyANSI-Codes local privilege escalation",
    },
    {
        "cve_id": "CVE-2023-32681",
        "package_name": "socketio",
        "affected_versions": "<6.5.0",
        "fixed_version": "6.5.0",
        "severity": "HIGH",
        "cvss_score": 7.5,
        "summary": "python-socketio path traversal vulnerability",
    },
    {
        "cve_id": "CVE-2022-21699",
        "package_name": "jupyter_server",
        "affected_versions": "<1.11.2",
        "fixed_version": "1.11.2",
        "severity": "HIGH",
        "cvss_score": 7.8,
        "summary": "Jupyter Server directory traversal vulnerability",
    },
]


def load_builtin_database() -> AdvisoryDatabase:
    """Load the built-in advisory database."""
    db = AdvisoryDatabase()
    for adv in BUILTIN_ADVISORIES:
        cve = CVE(
            cve_id=adv["cve_id"],
            package_name=adv["package_name"],
            affected_versions=adv["affected_versions"],
            fixed_version=adv["fixed_version"],
            severity=CVESeverity.from_string(adv["severity"]),
            cvss_score=adv.get("cvss_score", 0),
            summary=adv["summary"],
        )
        db.add_cve(cve)
    db.metadata["type"] = "builtin"
    db.metadata["loaded_at"] = datetime.datetime.now().isoformat()
    return db


# Global instance
_builtin_db: AdvisoryDatabase | None = None


def get_builtin_database() -> AdvisoryDatabase:
    """Get the built-in vulnerability database."""
    global _builtin_db
    if _builtin_db is None:
        _builtin_db = load_builtin_database()
    return _builtin_db