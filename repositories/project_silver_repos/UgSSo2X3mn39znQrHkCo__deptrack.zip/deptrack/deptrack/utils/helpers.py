"""General utility helpers for deptrack."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterator

from deptrack.models import Dependency, DepSource


SUPPORTED_FILES = {
    "requirements.txt": DepSource.REQUIREMENTS_TXT,
    "requirements-dev.txt": DepSource.REQUIREMENTS_TXT,
    "requirements-test.txt": DepSource.REQUIREMENTS_TXT,
    "pyproject.toml": DepSource.PYPROJECT_TOML,
    "setup.cfg": DepSource.SETUP_CFG,
}


def discover_dep_files(root: Path) -> Iterator[Path]:
    """Walk a directory and yield recognised dependency files."""
    for name in SUPPORTED_FILES:
        candidate = root / name
        if candidate.exists():
            yield candidate
    # Also find any requirements*.txt files
    for path in sorted(root.rglob("requirements*.txt")):
        if path.name not in SUPPORTED_FILES:
            yield path


def group_by_source(deps: list[Dependency]) -> dict[str, list[Dependency]]:
    """Group dependencies by their source file type."""
    result: dict[str, list[Dependency]] = {}
    for dep in deps:
        key = dep.source.value if dep.source else "unknown"
        result.setdefault(key, []).append(dep)
    return result


def filter_by_marker(deps: list[Dependency], platform: str = "linux") -> list[Dependency]:
    """
    Filter out dependencies whose markers exclude the given platform.
    This is a simplified heuristic, not a full PEP 508 marker evaluator.
    """
    filtered = []
    for dep in deps:
        if not dep.markers:
            filtered.append(dep)
            continue
        marker = dep.markers.lower()
        # Skip Windows-only deps on non-windows
        if platform != "windows" and re.search(r'sys_platform\s*==\s*["\']win32["\']', marker):
            continue
        # Skip darwin-only on non-darwin
        if platform != "darwin" and re.search(r'sys_platform\s*==\s*["\']darwin["\']', marker):
            continue
        filtered.append(dep)
    return filtered


def deduplicate(deps: list[Dependency]) -> list[Dependency]:
    """Return a deduplicated list, keeping the first occurrence of each canonical name."""
    seen: set[str] = set()
    result = []
    for dep in deps:
        if dep.canonical_name not in seen:
            seen.add(dep.canonical_name)
            result.append(dep)
    return result
