"""Lockfile management for reproducible dependency tracking."""

from __future__ import annotations

import json
from pathlib import Path

from deptrack.models import AuditResult, Dependency, LockEntry

LOCKFILE_NAME = "deptrack.lock"


def generate_lockfile(result: AuditResult) -> dict:
    """Generate a lockfile dict from an audit result."""
    entries = {}
    for dep in result.dependencies:
        entries[dep.canonical_name] = {
            "name": dep.name,
            "version": dep.version or "unspecified",
            "extras": dep.extras,
            "markers": dep.markers,
            "source": dep.source.value if dep.source else None,
        }
    return {
        "lockfile_version": 1,
        "packages": entries,
    }


def write_lockfile(result: AuditResult, path: Path | None = None) -> Path:
    """Write the lockfile to disk. Returns the path written."""
    target = path or Path.cwd() / LOCKFILE_NAME
    data = generate_lockfile(result)
    target.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return target


def load_lockfile(path: Path) -> dict:
    """Load a lockfile from disk."""
    if not path.exists():
        raise FileNotFoundError(f"Lockfile not found: {path}")
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def verify_lockfile(deps: list[Dependency], lockfile: dict) -> list[str]:
    """
    Compare current deps against a lockfile.
    Returns a list of discrepancy messages.
    """
    discrepancies: list[str] = []
    locked_packages = lockfile.get("packages", {})

    current_names = {d.canonical_name for d in deps}
    locked_names = set(locked_packages.keys())

    for name in current_names - locked_names:
        discrepancies.append(f"NEW: '{name}' is not in the lockfile.")

    for name in locked_names - current_names:
        discrepancies.append(f"REMOVED: '{name}' was in the lockfile but is no longer declared.")

    for dep in deps:
        if dep.canonical_name not in locked_packages:
            continue
        locked = locked_packages[dep.canonical_name]
        locked_version = locked.get("version", "unspecified")
        current_version = dep.version or "unspecified"
        if locked_version != current_version:
            discrepancies.append(
                f"VERSION MISMATCH: '{dep.canonical_name}' is {current_version!r} "
                f"but lockfile has {locked_version!r}."
            )

    return discrepancies


def lockfile_is_stale(deps: list, lockfile: dict) -> bool:
    """Quick check: return True if any discrepancies exist."""
    return len(verify_lockfile(deps, lockfile)) > 0
