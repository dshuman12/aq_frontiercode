"""deptrack - Utilities for lockfile handling."""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from deptrack.models import Dependency


# ---------------------------------------------------------------------------
# Lockfile representation
# ---------------------------------------------------------------------------

@dataclass
class LockfileEntry:
    """A single entry in a lockfile."""
    name: str
    version: str
    resolved_url: str | None = None
    integrity: str | None = None
    dependencies: list[str] = field(default_factory=list)
    build_metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Lockfile:
    """Represents a lockfile and its metadata."""
    path: Path
    format: str  # "pip", "npm", "cargo", etc.
    entries: list[LockfileEntry] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_file(cls, path: Path) -> Lockfile:
        """Load a lockfile from disk."""
        format = _detect_lockfile_format(path)
        if format is None:
            raise ValueError(f"Unknown lockfile format for {path}")

        if format == "pip":
            return cls._load_pip_lockfile(path)
        elif format == "npm":
            return cls._load_npm_lockfile(path)
        elif format == "cargo":
            return cls._load_cargo_lockfile(path)
        else:
            raise NotImplementedError(f"Format {format} not yet supported")

    @classmethod
    def _load_pip_lockfile(cls, path: Path) -> Lockfile:
        """Load a pip/pipenv lockfile."""
        with open(path) as f:
            data = json.load(f)

        entries = []
        for pkg_name, pkg_info in data.get("default", {}).items():
            version = pkg_info.get("version", "").lstrip("==")
            entry = LockfileEntry(
                name=pkg_name,
                version=version,
                resolved_url=pkg_info.get("url"),
                integrity=pkg_info.get("hashes", [None])[0] if pkg_info.get("hashes") else None,
                build_metadata=pkg_info,
            )
            entries.append(entry)

        return cls(
            path=path,
            format="pip",
            entries=entries,
            metadata={"version": data.get("version"), "hash": data.get("hash")},
        )

    @classmethod
    def _load_npm_lockfile(cls, path: Path) -> Lockfile:
        """Load an npm package-lock.json."""
        with open(path) as f:
            data = json.load(f)

        entries = []
        packages = data.get("packages", {})

        for pkg_path, pkg_info in packages.items():
            if pkg_path == "":  # Skip root
                continue

            name = pkg_path.split("node_modules/")[-1]
            entry = LockfileEntry(
                name=name,
                version=pkg_info.get("version", ""),
                resolved_url=pkg_info.get("resolved"),
                integrity=pkg_info.get("integrity"),
                dependencies=list(pkg_info.get("dependencies", {}).keys()),
                build_metadata=pkg_info,
            )
            entries.append(entry)

        return cls(
            path=path,
            format="npm",
            entries=entries,
            metadata={"lockfileVersion": data.get("lockfileVersion")},
        )

    @classmethod
    def _load_cargo_lockfile(cls, path: Path) -> Lockfile:
        """Load a Cargo.lock file."""
        entries = []
        current_pkg = None
        current_version = None
        current_source = None

        with open(path) as f:
            in_package = False
            deps = []

            for line in f:
                line = line.rstrip()

                if line == "[[package]]":
                    in_package = True
                    current_pkg = None
                    current_version = None
                    current_source = None
                    deps = []

                elif in_package:
                    if line.startswith("name = "):
                        current_pkg = line[7:].strip().strip('"')
                    elif line.startswith("version = "):
                        current_version = line[10:].strip().strip('"')
                    elif line.startswith("source = "):
                        current_source = line[9:].strip().strip('"')
                    elif line.startswith("[[") and line != "[[package]]":
                        # End of package
                        if current_pkg and current_version:
                            entries.append(LockfileEntry(
                                name=current_pkg,
                                version=current_version,
                                resolved_url=current_source,
                                dependencies=deps,
                            ))
                        in_package = False

        return cls(
            path=path,
            format="cargo",
            entries=entries,
        )

    def get_hash(self) -> str:
        """Get a hash of the lockfile contents."""
        content = json.dumps(
            [{"e.name": e.name, "e.version": e.version} for e in self.entries],
            sort_keys=True,
        )
        return hashlib.sha256(content.encode()).hexdigest()[:16]


def _detect_lockfile_format(path: Path) -> str | None:
    """Detect the format of a lockfile based on its path and contents."""
    name = path.name.lower()

    if name == "pipfile.lock" or name == "Pipfile.lock":
        return "pip"
    if name == "package-lock.json":
        return "npm"
    if name == "yarn.lock":
        return "yarn"
    if name == "cargo.lock":
        return "cargo"
    if name == "go.sum":
        return "go"
    if name == "composer.lock":
        return "composer"

    # Try to detect from contents
    try:
        with open(path) as f:
            content = f.read(1024)
            if content.startswith("{"):
                return "npm"
            if "[[package]]" in content:
                return "cargo"
            if "import (" in content:
                return "go"
    except (UnicodeDecodeError, OSError):
        pass

    return None


# ---------------------------------------------------------------------------
# Lockfile diffing
# ---------------------------------------------------------------------------

@dataclass
class LockDiff:
    """Represents a change between two lockfiles."""
    added: list[LockfileEntry] = field(default_factory=list)
    removed: list[LockfileEntry] = field(default_factory=list)
    version_changed: list[tuple[LockfileEntry, LockfileEntry]] = field(default_factory=list)


def diff_lockfiles(old: Lockfile, new: Lockfile) -> LockDiff:
    """Compare two lockfiles and return the differences."""
    old_entries = {e.name: e for e in old.entries}
    new_entries = {e.name: e for e in new.entries}

    diff = LockDiff()

    # Find added and changed
    for name, new_entry in new_entries.items():
        if name not in old_entries:
            diff.added.append(new_entry)
        elif old_entries[name].version != new_entry.version:
            diff.version_changed.append((old_entries[name], new_entry))

    # Find removed
    for name, old_entry in old_entries.items():
        if name not in new_entries:
            diff.removed.append(old_entry)

    return diff


# ---------------------------------------------------------------------------
# Lockfile verification
# ---------------------------------------------------------------------------

class LockVerifier:
    """Verify lockfiles against requirements."""

    def __init__(self, require_hash_match: bool = True):
        self.require_hash_match = require_hash_match

    def verify(self, requirements_path: Path, lockfile_path: Path) -> list[str]:
        """Verify a lockfile matches the requirements."""
        errors = []

        if not lockfile_path.exists():
            errors.append(f"Lockfile not found: {lockfile_path}")
            return errors

        try:
            lockfile = Lockfile.from_file(lockfile_path)
        except Exception as e:
            errors.append(f"Failed to parse lockfile: {e}")
            return errors

        # Check format consistency
        if self.require_hash_match:
            stored_hash = lockfile.metadata.get("hash", "")
            if stored_hash:
                actual_hash = lockfile.get_hash()
                if stored_hash != actual_hash:
                    errors.append(
                        f"Lockfile hash mismatch. Expected {stored_hash}, got {actual_hash}"
                    )

        return errors


# ---------------------------------------------------------------------------
# Requirements file helpers
# ---------------------------------------------------------------------------

def parse_requirements_file(path: Path) -> list[Dependency]:
    """Parse a requirements.txt file into Dependencies."""
    deps = []

    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            # Skip options
            if line.startswith("-"):
                continue

            # Parse name==version
            if "==" in line:
                name, version = line.split("==", 1)
                deps.append(Dependency(name=name.strip(), version=version.strip()))
            elif ">=" in line:
                name, version = line.split(">=", 1)
                deps.append(Dependency(name=name.strip(), version=f">={version.strip()}"))
            else:
                deps.append(Dependency(name=line, version="*"))

    return deps


def generate_requirements_lock(dependencies: list[Dependency], path: Path) -> None:
    """Generate a requirements.txt from a list of dependencies."""
    lines = []
    for dep in dependencies:
        if dep.version:
            lines.append(f"{dep.name}=={dep.version}")
        else:
            lines.append(dep.name)

    path.write_text("\n".join(lines))


# ---------------------------------------------------------------------------
# Virtual environment helpers
# ---------------------------------------------------------------------------

@dataclass
class VenvInfo:
    """Information about a Python virtual environment."""
    path: Path
    python_version: str
    site_packages: Path
    binary_path: Path


def detect_venv() -> VenvInfo | None:
    """Detect the active virtual environment."""
    # Check common venv markers
    path = Path.cwd()

    markers = ["venv", "env", ".venv", ".env", "virtualenv"]

    for marker in markers:
        venv_path = path / marker
        if venv_path.exists():
            if os.name == "nt":  # Windows
                python = venv_path / "Scripts" / "python.exe"
                site_packages = venv_path / "Lib" / "site-packages"
            else:  # Unix
                python = venv_path / "bin" / "python"
                site_packages = venv_path / "lib" / "python3.10" / "site-packages"

            if python.exists():
                return VenvInfo(
                    path=venv_path,
                    python_version="3.10",  # Would need to actually inspect
                    site_packages=site_packages,
                    binary_path=python,
                )

    return None


# ---------------------------------------------------------------------------
# Pip freeze export
# ---------------------------------------------------------------------------

def parse_pip_freeze(output: str) -> list[Dependency]:
    """Parse the output of `pip freeze` into Dependencies."""
    deps = []

    for line in output.strip().split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        # Handle @-style extras
        if " @ " in line:
            line = line.split(" @ ")[0]

        # Handle == style
        if "==" in line:
            name, version = line.split("==", 1)
            deps.append(Dependency(name=name.strip(), version=version.strip()))
        else:
            deps.append(Dependency(name=line, version="*"))

    return deps


# ---------------------------------------------------------------------------
# Export lockfile as requirements
# ---------------------------------------------------------------------------

def export_as_requirements(lockfile: Lockfile, path: Path) -> None:
    """Export a lockfile as a requirements.txt file."""
    lines = []

    for entry in sorted(lockfile.entries, key=lambda e: e.name):
        if entry.version:
            lines.append(f"{entry.name}=={entry.version}")
        else:
            lines.append(entry.name)

    path.write_text("\n".join(lines))