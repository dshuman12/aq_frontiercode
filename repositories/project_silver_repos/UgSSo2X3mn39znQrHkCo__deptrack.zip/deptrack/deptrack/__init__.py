"""deptrack - Python dependency auditing and tracking CLI tool."""

__version__ = "0.4.0"
__author__ = "Adil"

# Core models
from deptrack.models import (
    Dependency,
    Issue,
    AuditResult,
    VersionSpec,
    PackageMetadata,
    DependencySet,
    Severity,
    IssueType,
    DepSource,
)

# Core audit engine
from deptrack.audit import (
    DependencyAuditor,
    AuditConfig,
    get_default_auditor,
)

# Configuration
from deptrack.config import (
    Config,
    load_config,
    get_default_config_path,
)

# Security checking
from deptrack.security import (
    SecurityChecker,
    SecurityIssue,
    get_default_checker,
)

# PyPI integration
from deptrack.pypi import (
    PyPIClient,
    get_package_info,
    search_packages,
)

# Version resolution
from deptrack.resolver import (
    VersionResolver,
    ConflictError,
    resolve_dependencies,
)

# Advanced caching system
from deptrack.cache import (
    CacheEntry,
    CacheBackend,
    LRUCache,
    DiskCache,
    TieredCache,
    NullCache,
    CacheDecorator,
    cached,
    get_lru_cache,
    get_disk_cache,
    get_tiered_cache,
    clear_all_caches,
    DEFAULT_CACHE_DIR,
)

# Network layer
from deptrack.network import (
    Request,
    Response,
    RetryConfig,
    RateLimitConfig,
    TokenBucket,
    HostRateLimiter,
    NetworkClient,
    AsyncNetworkClient,
    PyPIAdapter,
    SecurityAdvisoryClient,
    NetworkError,
    RetryExhaustedError,
    RateLimitError,
)

# CVE and vulnerability database
from deptrack.cve import (
    CVESeverity,
    CVE,
    AdvisoryDatabase,
    AdvisoryDatabaseLoader,
    VulnerabilityChecker,
    load_builtin_database,
    BUILTIN_ADVISORIES,
)

# Policy engine
from deptrack.policy import (
    PolicyType,
    PolicyViolation,
    Policy,
    VersionConstraintPolicy,
    PackageAllowlistPolicy,
    PackageBlocklistPolicy,
    LicenseRequiredPolicy,
    LicenseForbiddenPolicy,
    MaintenanceStatusPolicy,
    CustomPolicy,
    PolicyResult,
    PolicyReport,
    PolicyEngine,
    create_policy,
    create_default_engine,
)

# Multi-language support
from deptrack.multilang import (
    Ecosystem,
    Package,
    RequirementsTxtParser,
    PipfileParser,
    PackageLockParser,
    NpmLockParser,
    YarnLockParser,
    PnpmLockParser,
    PomXmlParser,
    GoModParser,
    CargoTomlParser,
    GemfileParser,
    ComposerJsonParser,
    DotNetParser,
    PackageRegistry,
    detect_ecosystem,
)

# SBOM generation
from deptrack.sbom import (
    SBOMFormat,
    SBOMType,
    SBOMComponent,
    SBOMMetadata,
    SBOM,
    SBOMGenerator,
    SPDXGenerator,
    SPDXJsonGenerator,
    CycloneDXGenerator,
    SBOMExporter,
    create_sbom_from_dependencies,
    create_purl,
    parse_purl,
)

# Analytics and reporting
from deptrack.analytics import (
    Metric,
    AnalyticsReport,
    DependencyAnalyzer,
    TrendAnalyzer,
    RiskScorer,
    DependencyGraphAnalyzer,
    PrometheusExporter,
    calculate_security_score,
    calculate_maintainability_score,
    generate_dependency_health_report,
)

# CI/CD integrations
from deptrack.integrations import (
    CIProvider,
    WebhookEvent,
    CIContext,
    WebhookPayload,
    WebhookClient,
    NotificationFormatter,
    SlackFormatter,
    GitHubFormatter,
    TeamsFormatter,
    EmailFormatter,
    GitHubActionsIntegration,
    GitLabCIIntegration,
    JenkinsIntegration,
    configure_from_env,
)

# Interactive TUI
from deptrack.tui import (
    TUIRenderer,
    DependencyDashboard,
    DependenciesView,
    IssuesView,
    TUIApp,
    ProgressTracker,
    format_table,
    format_severity_badge,
    format_version_info,
)

__all__ = [
    # Version
    "__version__",
    # Models
    "Dependency",
    "Issue",
    "AuditResult",
    "VersionSpec",
    "PackageMetadata",
    "DependencySet",
    "Severity",
    "IssueType",
    "DepSource",
    # Audit
    "DependencyAuditor",
    "AuditConfig",
    "get_default_auditor",
    # Config
    "Config",
    "load_config",
    "get_default_config_path",
    # Security
    "SecurityChecker",
    "SecurityIssue",
    "get_default_checker",
    # PyPI
    "PyPIClient",
    "get_package_info",
    "search_packages",
    # Resolver
    "VersionResolver",
    "ConflictError",
    "resolve_dependencies",
    # Cache
    "CacheEntry",
    "CacheBackend",
    "LRUCache",
    "DiskCache",
    "TieredCache",
    "NullCache",
    "CacheDecorator",
    "cached",
    "get_lru_cache",
    "get_disk_cache",
    "get_tiered_cache",
    "clear_all_caches",
    "DEFAULT_CACHE_DIR",
    # Network
    "Request",
    "Response",
    "RetryConfig",
    "RateLimitConfig",
    "TokenBucket",
    "HostRateLimiter",
    "NetworkClient",
    "AsyncNetworkClient",
    "PyPIAdapter",
    "SecurityAdvisoryClient",
    "NetworkError",
    "RetryExhaustedError",
    "RateLimitError",
    # CVE
    "CVESeverity",
    "CVE",
    "AdvisoryDatabase",
    "AdvisoryDatabaseLoader",
    "VulnerabilityChecker",
    "load_builtin_database",
    "BUILTIN_ADVISORIES",
    # Policy
    "PolicyType",
    "PolicyViolation",
    "Policy",
    "VersionConstraintPolicy",
    "PackageAllowlistPolicy",
    "PackageBlocklistPolicy",
    "LicenseRequiredPolicy",
    "LicenseForbiddenPolicy",
    "MaintenanceStatusPolicy",
    "CustomPolicy",
    "PolicyResult",
    "PolicyReport",
    "PolicyEngine",
    "create_policy",
    "create_default_engine",
    # Multi-language
    "Ecosystem",
    "Package",
    "RequirementsTxtParser",
    "PipfileParser",
    "PackageLockParser",
    "NpmLockParser",
    "YarnLockParser",
    "PnpmLockParser",
    "PomXmlParser",
    "GoModParser",
    "CargoTomlParser",
    "GemfileParser",
    "ComposerJsonParser",
    "DotNetParser",
    "PackageRegistry",
    "detect_ecosystem",
    # SBOM
    "SBOMFormat",
    "SBOMType",
    "SBOMComponent",
    "SBOMMetadata",
    "SBOM",
    "SBOMGenerator",
    "SPDXGenerator",
    "SPDXJsonGenerator",
    "CycloneDXGenerator",
    "SBOMExporter",
    "create_sbom_from_dependencies",
    "create_purl",
    "parse_purl",
    # Analytics
    "Metric",
    "AnalyticsReport",
    "DependencyAnalyzer",
    "TrendAnalyzer",
    "RiskScorer",
    "DependencyGraphAnalyzer",
    "PrometheusExporter",
    "calculate_security_score",
    "calculate_maintainability_score",
    "generate_dependency_health_report",
    # Integrations
    "CIProvider",
    "WebhookEvent",
    "CIContext",
    "WebhookPayload",
    "WebhookClient",
    "NotificationFormatter",
    "SlackFormatter",
    "GitHubFormatter",
    "TeamsFormatter",
    "EmailFormatter",
    "GitHubActionsIntegration",
    "GitLabCIIntegration",
    "JenkinsIntegration",
    "configure_from_env",
    # TUI
    "TUIRenderer",
    "DependencyDashboard",
    "DependenciesView",
    "IssuesView",
    "TUIApp",
    "ProgressTracker",
    "format_table",
    "format_severity_badge",
    "format_version_info",
]