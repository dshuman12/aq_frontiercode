"""Parser for pyproject.toml dependency declarations."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterator

from deptrack.models import Dependency, DepSource

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


_PEP508_RE = re.compile(
    r"^(?P<name>[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)"
    r"(?:\[(?P<extras>[^\]]+)\])?"
    r"(?P<version>[^;@\s]*)?"
    r"(?:\s*;\s*(?P<markers>.+))?$"
)


def _parse_pep508(spec: str, source: DepSource) -> Dependency | None:
    """Parse a PEP 508 dependency string into a Dependency."""
    spec = spec.strip()
    m = _PEP508_RE.match(spec)
    if not m:
        return None
    name = m.group("name")
    extras_raw = m.group("extras") or ""
    extras = [e.strip() for e in extras_raw.split(",") if e.strip()]
    version = (m.group("version") or "").strip() or None
    markers = (m.group("markers") or "").strip() or None
    return Dependency(
        name=name,
        version=version,
        extras=extras,
        markers=markers,
        source=source,
        raw_line=spec,
    )


def parse_pyproject(path: Path) -> Iterator[Dependency]:
    """Parse dependencies from a pyproject.toml file."""
    if tomllib is None:
        raise RuntimeError(
            "tomllib/tomli is required to parse pyproject.toml. "
            "Install tomli on Python < 3.11: pip install tomli"
        )

    with open(path, "rb") as fh:
        data = tomllib.load(fh)

    # PEP 621 [project.dependencies]
    project = data.get("project", {})
    for spec in project.get("dependencies", []):
        dep = _parse_pep508(spec, DepSource.PYPROJECT_TOML)
        if dep:
            yield dep

    # PEP 621 [project.optional-dependencies]
    for _group, specs in project.get("optional-dependencies", {}).items():
        for spec in specs:
            dep = _parse_pep508(spec, DepSource.PYPROJECT_TOML)
            if dep:
                yield dep

    # Poetry [tool.poetry.dependencies]
    poetry = data.get("tool", {}).get("poetry", {})
    for name, constraint in poetry.get("dependencies", {}).items():
        if name.lower() == "python":
            continue
        if isinstance(constraint, str):
            version = constraint if constraint not in ("*", "") else None
        elif isinstance(constraint, dict):
            version = constraint.get("version")
        else:
            version = None
        yield Dependency(
            name=name,
            version=version,
            source=DepSource.PYPROJECT_TOML,
            raw_line=f"{name} = {constraint!r}",
        )


# TODO: add support for tool.pdm and tool.flit dependency sections
