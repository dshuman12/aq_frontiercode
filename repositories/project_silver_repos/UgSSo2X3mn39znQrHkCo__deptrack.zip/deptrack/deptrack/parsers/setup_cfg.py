"""Parser for setup.cfg dependency declarations."""

from __future__ import annotations

import configparser
import re
from pathlib import Path
from typing import Iterator

from deptrack.models import Dependency, DepSource

_PEP508_RE = re.compile(
    r"^(?P<name>[A-Za-z0-9][A-Za-z0-9._-]*)"
    r"(?:\[(?P<extras>[^\]]+)\])?"
    r"(?P<version>[^;@\s]*)?"
    r"(?:\s*;\s*(?P<markers>.+))?$"
)


def _parse_dep_line(line: str) -> Dependency | None:
    """Parse a single PEP 508 dependency line from setup.cfg."""
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    m = _PEP508_RE.match(line)
    if not m:
        return None
    name = m.group("name")
    extras_raw = m.group("extras") or ""
    extras = [e.strip() for e in extras_raw.split(",") if e.strip()]
    version = (m.group("version") or "").strip() or None
    markers = (m.group("markers") or "").strip() or None
    return Dependency(
        name=name,
        version=version,
        extras=extras,
        markers=markers,
        source=DepSource.SETUP_CFG,
        raw_line=line,
    )


def parse_setup_cfg(path: Path) -> Iterator[Dependency]:
    """Parse dependencies from a setup.cfg file."""
    config = configparser.ConfigParser()
    config.read(path, encoding="utf-8")

    # [options] install_requires
    if config.has_option("options", "install_requires"):
        raw = config.get("options", "install_requires")
        for line in raw.splitlines():
            dep = _parse_dep_line(line)
            if dep:
                yield dep

    # [options.extras_require]
    if config.has_section("options.extras_require"):
        for _key, value in config.items("options.extras_require"):
            for line in value.splitlines():
                dep = _parse_dep_line(line)
                if dep:
                    yield dep

    # [options] tests_require
    if config.has_option("options", "tests_require"):
        raw = config.get("options", "tests_require")
        for line in raw.splitlines():
            dep = _parse_dep_line(line)
            if dep:
                yield dep
