"""Parser for requirements.txt files.

Supports standard pip requirements format including extras, markers,
and inline comments.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterator

from deptrack.models import Dependency as Dep, DepSource

_REQ_RE = re.compile(
    r"^(?P<name>[A-Za-z0-9][A-Za-z0-9._-]*)"
    r"(?:\[(?P<extras>[^\]]+)\])?"
    r"(?P<version>[^;#\s]*)?"
    r"(?:\s*;\s*(?P<markers>[^#]+))?"
    r"(?:\s*#.*)?$"
)


def _is_skippable(line: str) -> bool:
    stripped = line.strip()
    return not stripped or stripped.startswith("#") or stripped.startswith("-")


def parse_requirements(path: Path) -> Iterator[Dep]:
    """Parse a requirements.txt file and yield Dependency objects."""
    with open(path, encoding="utf-8") as fh:
        for raw_line in fh:
            line = raw_line.strip()
            if _is_skippable(line):
                continue
            m = _REQ_RE.match(line)
            if not m:
                continue
            name = m.group("name")
            extras_raw = m.group("extras") or ""
            extras = [e.strip() for e in extras_raw.split(",") if e.strip()]
            version = (m.group("version") or "").strip() or None
            markers = (m.group("markers") or "").strip() or None
            yield Dep(
                name=name,
                version=version,
                extras=extras,
                markers=markers,
                source=DepSource.REQUIREMENTS_TXT,
                raw_line=raw_line.rstrip(),
            )
