"""Parsers for different dependency file formats."""

from deptrack.parsers.requirements import parse_requirements
from deptrack.parsers.pyproject import parse_pyproject

__all__ = ["parse_requirements", "parse_pyproject"]
from deptrack.parsers.setup_cfg import parse_setup_cfg
from deptrack.parsers.pipfile import parse_pipfile
