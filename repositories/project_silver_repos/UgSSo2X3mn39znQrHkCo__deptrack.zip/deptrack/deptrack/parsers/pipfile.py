"""Parser for Pipfile dependency declarations."""

from __future__ import annotations

from pathlib import Path
from typing import Iterator

from deptrack.models import Dependency, DepSource

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


def _normalize_version(constraint) -> str | None:
    """Normalise a Pipfile version constraint to a PEP 440-like string."""
    if constraint is None:
        return None
    if isinstance(constraint, str):
        if constraint in ("*", ""):
            return None
        return constraint
    if isinstance(constraint, dict):
        version = constraint.get("version")
        if version and version != "*":
            return version
    return None


def parse_pipfile(path: Path) -> Iterator[Dependency]:
    """Parse dependencies from a Pipfile."""
    if tomllib is None:
        raise RuntimeError(
            "tomllib/tomli is required to parse Pipfile. "
            "Install tomli on Python < 3.11."
        )

    with open(path, "rb") as fh:
        data = tomllib.load(fh)

    for section in ("packages", "dev-packages"):
        for name, constraint in data.get(section, {}).items():
            version = _normalize_version(constraint)
            extras: list[str] = []
            markers: str | None = None

            if isinstance(constraint, dict):
                extras_raw = constraint.get("extras", [])
                if isinstance(extras_raw, list):
                    extras = extras_raw
                markers = constraint.get("markers")

            yield Dependency(
                name=name,
                version=version,
                extras=extras,
                markers=markers,
                source=DepSource.PIPFILE,
                raw_line=f"{name} = {constraint!r}",
            )
