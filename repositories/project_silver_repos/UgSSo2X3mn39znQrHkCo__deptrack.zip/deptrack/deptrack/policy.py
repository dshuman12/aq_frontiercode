"""Policy engine for custom dependency rules and compliance checking."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from deptrack.models import Dependency, Severity


class PolicyType(Enum):
    """Types of policy rules."""

    VERSION_CONSTRAINT = "version_constraint"
    PACKAGE_ALLOWLIST = "package_allowlist"
    PACKAGE_BLOCKLIST = "package_blocklist"
    LICENSE_REQUIRED = "license_required"
    LICENSE_FORBIDDEN = "license_forbidden"
    MAINTENANCE_STATUS = "maintenance_status"
    SECURITY_UPDATES = "security_updates"
    CUSTOM = "custom"


class PolicyViolation(Exception):
    """Raised when a policy is violated."""

    def __init__(self, policy: "Policy", dep: Dependency, message: str) -> None:
        self.policy = policy
        self.dep = dep
        self.message = message
        super().__init__(f"Policy '{policy.name}' violated by {dep.name}: {message}")


@dataclass
class Policy:
    """A single policy rule."""

    name: str
    description: str
    policy_type: PolicyType
    enabled: bool = True
    severity: Severity = Severity.MEDIUM
    config: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """
        Evaluate this policy for a dependency.

        Returns (passed, message) tuple.
        """
        raise NotImplementedError("Subclasses must implement evaluate()")

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "type": self.policy_type.value,
            "enabled": self.enabled,
            "severity": self.severity.value,
            "config": self.config,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Policy":
        """Create policy from dictionary."""
        policy_type = PolicyType(data.get("type", "custom"))
        return create_policy(policy_type, data)


class VersionConstraintPolicy(Policy):
    """Policy that enforces version constraints."""

    def __init__(
        self,
        name: str,
        description: str,
        min_version: str | None = None,
        max_version: str | None = None,
        allowed_operators: list[str] | None = None,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            policy_type=PolicyType.VERSION_CONSTRAINT,
            config={
                "min_version": min_version,
                "max_version": max_version,
                "allowed_operators": allowed_operators or ["==", "~=", ">=", "<="],
            },
        )

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """Check version constraint policy."""
        if not dep.version:
            return True, "No version specified, skipping"

        version = dep.version
        config = self.config

        # Check operators
        allowed_ops = config.get("allowed_operators", [])
        for op in allowed_ops:
            if version.startswith(op):
                break
        else:
            return False, f"Version '{version}' uses forbidden operator. Allowed: {allowed_ops}"

        # Check min version
        min_ver = config.get("min_version")
        if min_ver and self._compare_versions(version, min_ver) < 0:
            return False, f"Version '{version}' is below minimum {min_ver}"

        # Check max version
        max_ver = config.get("max_version")
        if max_ver and self._compare_versions(version, max_ver) > 0:
            return False, f"Version '{version}' exceeds maximum {max_ver}"

        return True, "Version constraint satisfied"

    @staticmethod
    def _compare_versions(v1: str, v2: str) -> int:
        """Compare two version strings. Returns -1, 0, or 1."""
        import re

        def parse(v: str) -> list[int]:
            parts = re.split(r"[.\-_]", re.sub(r"^[><=!~^]+\s*", "", v))
            return [int(p) if p.isdigit() else 0 for p in parts]

        p1 = parse(v1)
        p2 = parse(v2)

        for i in range(max(len(p1), len(p2))):
            n1 = p1[i] if i < len(p1) else 0
            n2 = p2[i] if i < len(p2) else 0
            if n1 < n2:
                return -1
            if n1 > n2:
                return 1
        return 0


class PackageAllowlistPolicy(Policy):
    """Policy that only allows specific packages."""

    def __init__(
        self,
        name: str,
        description: str,
        allowed_packages: list[str],
        allow_internal: bool = True,
        allow_subpackages: bool = True,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            policy_type=PolicyType.PACKAGE_ALLOWLIST,
            config={
                "allowed_packages": allowed_packages,
                "allow_internal": allow_internal,
                "allow_subpackages": allow_subpackages,
            },
        )

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """Check if package is in allowlist."""
        allowed = self.config.get("allowed_packages", [])
        dep_name = dep.canonical_name

        # Check exact match
        if dep_name in [p.lower().replace("-", "_") for p in allowed]:
            return True, f"Package '{dep.name}' is in allowlist"

        # Check internal packages
        if self.config.get("allow_internal"):
            if dep_name.startswith("_") or dep.name.startswith("."):
                return True, "Internal package"

        # Check subpackages
        if self.config.get("allow_subpackages"):
            for pkg in allowed:
                pkg_norm = pkg.lower().replace("-", "_")
                if dep_name.startswith(pkg_norm + "."):
                    return True, f"Subpackage of allowed '{pkg}'"

        return False, f"Package '{dep.name}' is not in allowlist"


class PackageBlocklistPolicy(Policy):
    """Policy that blocks specific packages."""

    def __init__(
        self,
        name: str,
        description: str,
        blocked_packages: list[str],
        blocked_categories: list[str] | None = None,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            policy_type=PolicyType.PACKAGE_BLOCKLIST,
            config={
                "blocked_packages": blocked_packages,
                "blocked_categories": blocked_categories or [],
            },
        )

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """Check if package is blocked."""
        blocked = self.config.get("blocked_packages", [])
        dep_name = dep.canonical_name

        for pkg in blocked:
            pkg_norm = pkg.lower().replace("-", "_")
            if dep_name == pkg_norm:
                return False, f"Package '{dep.name}' is explicitly blocked"

            # Block entire namespace
            if dep_name.startswith(pkg_norm + "."):
                return False, f"Package '{dep.name}' is in blocked namespace '{pkg}'"

        return True, f"Package '{dep.name}' is not blocked"


class LicenseRequiredPolicy(Policy):
    """Policy that requires specific licenses."""

    def __init__(
        self,
        name: str,
        description: str,
        required_licenses: list[str],
        allow_multi_license: bool = True,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            policy_type=PolicyType.LICENSE_REQUIRED,
            config={
                "required_licenses": [l.upper() for l in required_licenses],
                "allow_multi_license": allow_multi_license,
            },
        )

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """Check if package has required license."""
        from deptrack.checkers.licenses import classify_license

        required = self.config.get("required_licenses", [])
        metadata = context.get("package_metadata", {}).get(dep.canonical_name)

        if not metadata:
            # Can't check without metadata
            return True, "No license metadata available, skipping"

        license_str = metadata.get("license", "")
        if not license_str:
            return False, f"No license information for '{dep.name}'"

        licenses = [l.strip().upper() for l in re.split(r"[,/]| OR ", license_str)]

        for req_license in required:
            for pkg_license in licenses:
                if req_license in pkg_license or pkg_license in req_license:
                    return True, f"License '{pkg_license}' satisfies requirement"

        return False, f"No required license found. Found: {', '.join(licenses)}"


class LicenseForbiddenPolicy(Policy):
    """Policy that forbids specific licenses."""

    def __init__(
        self,
        name: str,
        description: str,
        forbidden_licenses: list[str],
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            policy_type=PolicyType.LICENSE_FORBIDDEN,
            config={
                "forbidden_licenses": [l.upper() for l in forbidden_licenses],
            },
        )

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """Check if package has forbidden license."""
        forbidden = self.config.get("forbidden_licenses", [])
        metadata = context.get("package_metadata", {}).get(dep.canonical_name)

        if not metadata:
            return True, "No license metadata available, skipping"

        license_str = metadata.get("license", "")
        if not license_str:
            return True, "No license to check"

        pkg_licenses = [l.strip().upper() for l in re.split(r"[,/]| OR ", license_str)]

        for forb_license in forbidden:
            for pkg_license in pkg_licenses:
                if forb_license in pkg_license:
                    return False, f"Forbidden license '{pkg_license}'"

        return True, "No forbidden licenses found"


class MaintenanceStatusPolicy(Policy):
    """Policy that checks package maintenance status."""

    def __init__(
        self,
        name: str,
        description: str,
        max_stale_days: int = 365,
        require_releases: bool = True,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            policy_type=PolicyType.MAINTENANCE_STATUS,
            config={
                "max_stale_days": max_stale_days,
                "require_releases": require_releases,
            },
        )

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """Check package maintenance status."""
        import datetime

        config = self.config
        max_stale = config.get("max_stale_days", 365)
        metadata = context.get("package_metadata", {}).get(dep.canonical_name)

        if not metadata:
            return True, "No maintenance metadata available, skipping"

        # Check for yanked packages
        if metadata.get("yanked", False):
            return False, f"Package '{dep.name}' has been yanked from PyPI"

        # Check last release date
        last_release = metadata.get("last_release")
        if last_release:
            try:
                release_date = datetime.date.fromisoformat(last_release[:10])
                days_since = (datetime.date.today() - release_date).days
                if days_since > max_stale:
                    return False, (
                        f"Package '{dep.name}' has not been updated in {days_since} days "
                        f"(max allowed: {max_stale})"
                    )
            except (ValueError, TypeError):
                pass

        return True, "Maintenance status is acceptable"


class CustomPolicy(Policy):
    """Policy with custom evaluation function."""

    def __init__(
        self,
        name: str,
        description: str,
        evaluate_fn: Callable[[Dependency, dict[str, Any]], tuple[bool, str]],
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            policy_type=PolicyType.CUSTOM,
        )
        self._evaluate_fn = evaluate_fn

    def evaluate(self, dep: Dependency, context: dict[str, Any]) -> tuple[bool, str]:
        """Run custom evaluation function."""
        return self._evaluate_fn(dep, context)


def create_policy(
    policy_type: PolicyType,
    config: dict[str, Any],
) -> Policy:
    """Factory function to create policies from config."""
    if policy_type == PolicyType.VERSION_CONSTRAINT:
        return VersionConstraintPolicy(
            name=config.get("name", ""),
            description=config.get("description", ""),
            min_version=config.get("min_version"),
            max_version=config.get("max_version"),
            allowed_operators=config.get("allowed_operators"),
        )
    elif policy_type == PolicyType.PACKAGE_ALLOWLIST:
        return PackageAllowlistPolicy(
            name=config.get("name", ""),
            description=config.get("description", ""),
            allowed_packages=config.get("allowed_packages", []),
        )
    elif policy_type == PolicyType.PACKAGE_BLOCKLIST:
        return PackageBlocklistPolicy(
            name=config.get("name", ""),
            description=config.get("description", ""),
            blocked_packages=config.get("blocked_packages", []),
        )
    elif policy_type == PolicyType.LICENSE_REQUIRED:
        return LicenseRequiredPolicy(
            name=config.get("name", ""),
            description=config.get("description", ""),
            required_licenses=config.get("required_licenses", []),
        )
    elif policy_type == PolicyType.LICENSE_FORBIDDEN:
        return LicenseForbiddenPolicy(
            name=config.get("name", ""),
            description=config.get("description", ""),
            forbidden_licenses=config.get("forbidden_licenses", []),
        )
    elif policy_type == PolicyType.MAINTENANCE_STATUS:
        return MaintenanceStatusPolicy(
            name=config.get("name", ""),
            description=config.get("description", ""),
            max_stale_days=config.get("max_stale_days", 365),
        )
    else:
        return CustomPolicy(
            name=config.get("name", ""),
            description=config.get("description", ""),
            evaluate_fn=lambda d, c: (True, "Custom policy"),
        )


@dataclass
class PolicyResult:
    """Result of evaluating a single policy."""

    policy: Policy
    passed: bool
    message: str
    affected_dependencies: list[Dependency] = field(default_factory=list)

    @property
    def is_violation(self) -> bool:
        return not self.passed


@dataclass
class PolicyReport:
    """Report from policy evaluation."""

    results: list[PolicyResult] = field(default_factory=list)
    total_dependencies_checked: int = 0
    violations_by_policy: dict[str, list[Dependency]] = field(default_factory=dict)
    violations_by_package: dict[str, list[PolicyResult]] = field(default_factory=dict)

    @property
    def has_violations(self) -> bool:
        return any(not r.passed for r in self.results)

    @property
    def violation_count(self) -> int:
        return sum(1 for r in self.results if not r.passed)

    def summary(self) -> dict[str, Any]:
        """Generate summary statistics."""
        by_severity = {"critical": [], "high": [], "medium": [], "low": []}
        for result in self.results:
            if not result.passed:
                sev = result.policy.severity.value
                by_severity.setdefault(sev, []).append(result.policy.name)

        return {
            "total_policies": len(self.results),
            "policies_passed": sum(1 for r in self.results if r.passed),
            "policies_failed": sum(1 for r in self.results if not r.passed),
            "total_dependencies_checked": self.total_dependencies_checked,
            "by_severity": by_severity,
        }


class PolicyEngine:
    """Engine for evaluating dependency policies."""

    def __init__(self) -> None:
        self._policies: dict[str, Policy] = {}
        self._policy_groups: dict[str, set[str]] = {}

    def add_policy(self, policy: Policy, groups: list[str] | None = None) -> None:
        """Add a policy to the engine."""
        self._policies[policy.name] = policy
        if groups:
            for group in groups:
                if group not in self._policy_groups:
                    self._policy_groups[group] = set()
                self._policy_groups[group].add(policy.name)

    def remove_policy(self, name: str) -> bool:
        """Remove a policy by name. Returns True if removed."""
        if name in self._policies:
            del self._policies[name]
            for group in self._policy_groups.values():
                group.discard(name)
            return True
        return False

    def get_policy(self, name: str) -> Policy | None:
        """Get a policy by name."""
        return self._policies.get(name)

    def list_policies(self) -> list[Policy]:
        """List all policies."""
        return list(self._policies.values())

    def get_policies_by_group(self, group: str) -> list[Policy]:
        """Get policies in a specific group."""
        policy_names = self._policy_groups.get(group, set())
        return [self._policies[name] for name in policy_names if name in self._policies]

    def evaluate(
        self,
        dependencies: list[Dependency],
        context: dict[str, Any] | None = None,
        policy_filter: str | list[str] | None = None,
    ) -> PolicyReport:
        """Evaluate all policies against dependencies."""
        context = context or {}
        report = PolicyReport()
        report.total_dependencies_checked = len(dependencies)

        # Determine which policies to run
        policies_to_run = list(self._policies.values())

        if isinstance(policy_filter, str):
            policies_to_run = [self._policies[policy_filter]] if policy_filter in self._policies else []
        elif isinstance(policy_filter, list):
            policies_to_run = [self._policies[p] for p in policy_filter if p in self._policies]

        for policy in policies_to_run:
            if not policy.enabled:
                continue

            for dep in dependencies:
                passed, message = policy.evaluate(dep, context)

                result = PolicyResult(
                    policy=policy,
                    passed=passed,
                    message=message,
                    affected_dependencies=[dep] if not passed else [],
                )
                report.results.append(result)

                if not passed:
                    # Track violations
                    report.violations_by_policy.setdefault(policy.name, []).append(dep)
                    report.violations_by_package.setdefault(dep.canonical_name, []).append(result)

        return report

    def evaluate_single(
        self,
        dependency: Dependency,
        policy_name: str,
        context: dict[str, Any] | None = None,
    ) -> PolicyResult | None:
        """Evaluate a single policy against a single dependency."""
        policy = self._policies.get(policy_name)
        if not policy:
            return None

        context = context or {}
        passed, message = policy.evaluate(dependency, context)

        return PolicyResult(
            policy=policy,
            passed=passed,
            message=message,
            affected_dependencies=[dependency] if not passed else [],
        )

    def load_from_file(self, path: Path | str) -> None:
        """Load policies from a JSON or YAML file."""
        import json

        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Policy file not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        policies_data = data.get("policies", [])
        for policy_data in policies_data:
            policy_type = PolicyType(policy_data.get("type", "custom"))
            policy = create_policy(policy_type, policy_data)
            policy.enabled = policy_data.get("enabled", True)
            self.add_policy(policy, policy_data.get("groups"))

    def save_to_file(self, path: Path | str) -> None:
        """Save policies to a JSON file."""
        import json

        path = Path(path)
        data = {
            "policies": [
                {
                    **policy.to_dict(),
                    "groups": [
                        g for g, ps in self._policy_groups.items() if policy.name in ps
                    ],
                }
                for policy in self._policies.values()
            ]
        }

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)


# Built-in policy configurations
DEFAULT_POLICIES = {
    "block_known_vulnerable": {
        "name": "block_known_vulnerable",
        "description": "Block packages with known critical vulnerabilities",
        "type": "package_blocklist",
        "severity": "critical",
        "config": {
            "blocked_packages": [
                "telnetlib",  # Built-in, but sometimes exploited
            ],
            "blocked_categories": [],
        },
    },
    "require_security_updates": {
        "name": "require_security_updates",
        "description": "Require packages to have received updates within the last 180 days",
        "type": "maintenance_status",
        "severity": "high",
        "config": {
            "max_stale_days": 180,
            "require_releases": True,
        },
    },
    "no_gpl_without_exception": {
        "name": "no_gpl_without_exception",
        "description": "Require GPL-licensed packages to have commercial exceptions",
        "type": "license_forbidden",
        "severity": "medium",
        "config": {
            "forbidden_licenses": ["GPL-1.0", "GPL-2.0", "GPL-3.0"],
        },
    },
    "pin_critical_packages": {
        "name": "pin_critical_packages",
        "description": "Require exact pinning (==) for critical security packages",
        "type": "version_constraint",
        "severity": "high",
        "config": {
            "allowed_operators": ["=="],
            "packages": ["cryptography", "pyopenssl", "ssl"],
        },
    },
}


def create_default_engine() -> PolicyEngine:
    """Create a policy engine with default policies."""
    engine = PolicyEngine()

    for policy_config in DEFAULT_POLICIES.values():
        policy_type = PolicyType(policy_config.get("type", "custom"))
        policy = create_policy(policy_type, policy_config)
        engine.add_policy(policy)

    return engine