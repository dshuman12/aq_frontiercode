"""
Advanced export and formatting utilities for deptrack audit results.

Provides SARIF, CSV, Markdown, and JUnit XML export formats for
integration with CI/CD pipelines and security tooling.
"""

from __future__ import annotations

import csv
import io
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from deptrack.models import AuditResult, Issue, Severity


# ---------------------------------------------------------------------------
# SARIF export (Static Analysis Results Interchange Format)
# Used by GitHub Code Scanning, Azure DevOps, etc.
# ---------------------------------------------------------------------------

SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"
SARIF_VERSION = "2.1.0"

_SEVERITY_TO_SARIF_LEVEL = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
}

_SEVERITY_TO_SARIF_RANK = {
    Severity.CRITICAL: 9.0,
    Severity.HIGH: 7.5,
    Severity.MEDIUM: 5.0,
    Severity.LOW: 2.5,
}


def _build_sarif_rule(issue: Issue) -> dict[str, Any]:
    return {
        "id": issue.kind,
        "name": issue.kind.replace("_", " ").title(),
        "shortDescription": {"text": issue.kind.replace("_", " ").title()},
        "fullDescription": {"text": issue.message},
        "defaultConfiguration": {
            "level": _SEVERITY_TO_SARIF_LEVEL[issue.severity],
            "rank": _SEVERITY_TO_SARIF_RANK[issue.severity],
        },
        "help": {
            "text": issue.fix_suggestion or "No fix suggestion available.",
            "markdown": f"**Fix**: {issue.fix_suggestion}" if issue.fix_suggestion else "",
        },
    }


def _build_sarif_result(issue: Issue, source_file: str) -> dict[str, Any]:
    return {
        "ruleId": issue.kind,
        "level": _SEVERITY_TO_SARIF_LEVEL[issue.severity],
        "message": {"text": issue.message},
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": source_file,
                        "uriBaseId": "%SRCROOT%",
                    }
                }
            }
        ],
        "rank": _SEVERITY_TO_SARIF_RANK[issue.severity],
    }


def render_sarif(result: AuditResult, tool_version: str = "0.3.0") -> str:
    """Render the audit result as a SARIF 2.1.0 JSON string."""
    rules_seen: dict[str, dict] = {}
    sarif_results = []

    source_file = result.source_files[0] if result.source_files else "requirements.txt"

    for issue in result.issues:
        if issue.kind not in rules_seen:
            rules_seen[issue.kind] = _build_sarif_rule(issue)
        sarif_results.append(_build_sarif_result(issue, source_file))

    sarif = {
        "$schema": SARIF_SCHEMA,
        "version": SARIF_VERSION,
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "deptrack",
                        "version": tool_version,
                        "informationUri": "https://github.com/example/deptrack",
                        "rules": list(rules_seen.values()),
                    }
                },
                "results": sarif_results,
                "artifacts": [
                    {"location": {"uri": f}, "mimeType": "text/plain"}
                    for f in result.source_files
                ],
            }
        ],
    }
    return json.dumps(sarif, indent=2)


def write_sarif(result: AuditResult, path: Path, tool_version: str = "0.3.0") -> None:
    """Write a SARIF report to disk."""
    path.write_text(render_sarif(result, tool_version=tool_version), encoding="utf-8")


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------

_CSV_FIELDS = ["package", "version", "kind", "severity", "message", "fix"]


def render_csv(result: AuditResult) -> str:
    """Render the audit result as a CSV string."""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=_CSV_FIELDS, lineterminator="\n")
    writer.writeheader()
    for issue in result.issues:
        writer.writerow({
            "package": issue.dep.name,
            "version": issue.dep.version or "",
            "kind": issue.kind,
            "severity": issue.severity.value,
            "message": issue.message,
            "fix": issue.fix_suggestion or "",
        })
    return buf.getvalue()


def write_csv(result: AuditResult, path: Path) -> None:
    """Write a CSV report to disk."""
    path.write_text(render_csv(result), encoding="utf-8")


# ---------------------------------------------------------------------------
# Markdown export
# ---------------------------------------------------------------------------

_SEVERITY_EMOJI = {
    Severity.CRITICAL: "🔴",
    Severity.HIGH: "🟠",
    Severity.MEDIUM: "🟡",
    Severity.LOW: "🟢",
}


def render_markdown(result: AuditResult) -> str:
    """Render the audit result as a Markdown report."""
    lines: list[str] = []
    summary = result.summary()

    lines.append("# deptrack Audit Report\n")
    lines.append("## Summary\n")
    lines.append(f"| Metric | Value |")
    lines.append(f"|--------|-------|")
    lines.append(f"| Dependencies scanned | {summary['total_dependencies']} |")
    lines.append(f"| Total issues | {summary['total_issues']} |")
    lines.append(f"| 🔴 Critical | {summary['critical']} |")
    lines.append(f"| 🟠 High | {summary['high']} |")
    lines.append(f"| 🟡 Medium | {summary['medium']} |")
    lines.append(f"| 🟢 Low | {summary['low']} |")
    lines.append("")

    if result.source_files:
        lines.append("## Source Files\n")
        for f in result.source_files:
            lines.append(f"- `{f}`")
        lines.append("")

    if not result.issues:
        lines.append("## ✅ No Issues Found\n")
        return "\n".join(lines)

    lines.append("## Issues\n")
    lines.append("| Package | Version | Severity | Kind | Message |")
    lines.append("|---------|---------|----------|------|---------|")

    for issue in sorted(result.issues, key=lambda i: list(Severity).index(i.severity)):
        emoji = _SEVERITY_EMOJI[issue.severity]
        version = issue.dep.version or "–"
        msg = issue.message.replace("|", "\\|")
        lines.append(
            f"| `{issue.dep.name}` | `{version}` | {emoji} {issue.severity.value} "
            f"| `{issue.kind}` | {msg} |"
        )

    lines.append("")

    if any(i.fix_suggestion for i in result.issues):
        lines.append("## Fix Suggestions\n")
        for issue in result.issues:
            if issue.fix_suggestion:
                lines.append(
                    f"- **{issue.dep.name}** (`{issue.kind}`): {issue.fix_suggestion}"
                )
        lines.append("")

    return "\n".join(lines)


def write_markdown(result: AuditResult, path: Path) -> None:
    """Write a Markdown report to disk."""
    path.write_text(render_markdown(result), encoding="utf-8")


# ---------------------------------------------------------------------------
# JUnit XML export (for CI test result integration)
# ---------------------------------------------------------------------------

def render_junit_xml(result: AuditResult) -> str:
    """
    Render the audit result as JUnit XML.

    Each issue becomes a test failure; clean packages become passing tests.
    Compatible with Jenkins, CircleCI, GitLab CI, and GitHub Actions.
    """
    issues_by_package: dict[str, list[Issue]] = {}
    for issue in result.issues:
        issues_by_package.setdefault(issue.dep.name, []).append(issue)

    suite = ET.Element("testsuite")
    suite.set("name", "deptrack")
    suite.set("tests", str(len(result.dependencies)))
    suite.set("failures", str(len(result.issues)))
    suite.set("errors", "0")

    for dep in result.dependencies:
        case = ET.SubElement(suite, "testcase")
        case.set("classname", "deptrack.audit")
        case.set("name", f"{dep.name} ({dep.version or 'unpinned'})")

        dep_issues = issues_by_package.get(dep.name, [])
        for issue in dep_issues:
            failure = ET.SubElement(case, "failure")
            failure.set("type", issue.kind)
            failure.set("message", issue.message[:120])
            failure.text = (
                f"Kind: {issue.kind}\n"
                f"Severity: {issue.severity.value}\n"
                f"Message: {issue.message}\n"
                + (f"Fix: {issue.fix_suggestion}" if issue.fix_suggestion else "")
            )

    tree = ET.ElementTree(suite)
    return ET.tostring(suite, encoding="unicode", xml_declaration=True)


def write_junit_xml(result: AuditResult, path: Path) -> None:
    """Write a JUnit XML report to disk."""
    path.write_text(render_junit_xml(result), encoding="utf-8")


# ---------------------------------------------------------------------------
# Format dispatch
# ---------------------------------------------------------------------------

SUPPORTED_FORMATS = ["text", "json", "html", "markdown", "csv", "sarif", "junit"]


def render(result: AuditResult, fmt: str) -> str:
    """Dispatch to the correct renderer for the given format string."""
    from deptrack.reporters.text import render_text
    from deptrack.reporters.json_reporter import render_json
    from deptrack.reporters.html import render_html

    fmt = fmt.lower().strip()
    if fmt == "text":
        return render_text(result)
    if fmt == "json":
        return render_json(result)
    if fmt == "html":
        return render_html(result)
    if fmt == "markdown":
        return render_markdown(result)
    if fmt == "csv":
        return render_csv(result)
    if fmt == "sarif":
        return render_sarif(result)
    if fmt in ("junit", "junit-xml", "junitxml"):
        return render_junit_xml(result)
    raise ValueError(f"Unsupported format: {fmt!r}. Choose from: {SUPPORTED_FORMATS}")


def write_report(result: AuditResult, fmt: str, path: Path) -> None:
    """Write a report in the given format to the given path."""
    content = render(result, fmt)
    path.write_text(content, encoding="utf-8")
