"""JSON report formatter."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from deptrack.models import AuditResult


def render_json(result: AuditResult, indent: int = 2) -> str:
    """Render the audit result as a JSON string."""
    data: dict[str, Any] = {
        "summary": result.summary(),
        "source_files": result.source_files,
        "dependencies": [d.to_dict() for d in result.dependencies],
        "issues": [i.to_dict() for i in result.issues],
    }
    return json.dumps(data, indent=indent)


def write_json(result: AuditResult, path: Path, indent: int = 2) -> None:
    """Write the JSON report to a file."""
    path.write_text(render_json(result, indent=indent), encoding="utf-8")


def load_json_report(path: Path) -> dict:
    """Load a previously saved JSON report."""
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def diff_reports(old: dict, new: dict) -> dict:
    """Compare two JSON reports and return added/removed issues."""
    old_issues = {(i["package"], i["kind"], i["message"]) for i in old.get("issues", [])}
    new_issues = {(i["package"], i["kind"], i["message"]) for i in new.get("issues", [])}

    added = [
        i for i in new.get("issues", [])
        if (i["package"], i["kind"], i["message"]) in new_issues - old_issues
    ]
    resolved = [
        i for i in old.get("issues", [])
        if (i["package"], i["kind"], i["message"]) in old_issues - new_issues
    ]
    return {"added": added, "resolved": resolved}
