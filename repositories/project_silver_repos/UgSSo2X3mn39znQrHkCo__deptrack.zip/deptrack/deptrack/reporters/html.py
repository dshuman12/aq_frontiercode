"""HTML report formatter."""

from __future__ import annotations

from pathlib import Path

from deptrack.models import AuditResult, Severity

_SEVERITY_COLORS = {
    Severity.CRITICAL: "#c0392b",
    Severity.HIGH: "#e67e22",
    Severity.MEDIUM: "#f1c40f",
    Severity.LOW: "#2ecc71",
}

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>deptrack Audit Report</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body {{ font-family: sans-serif; margin: 2rem; background: #f9f9f9; }}
  h1 {{ color: #2c3e50; }}
  .summary {{ background: #fff; padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; }}
  .issue {{ background: #fff; padding: 1rem; border-left: 4px solid {color}; margin-bottom: 1rem; border-radius: 0 6px 6px 0; }}
  .badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; color: #fff; background: {color}; }}
  .fix {{ color: #27ae60; font-style: italic; }}
</style>
</head>
<body>
<h1>deptrack Audit Report</h1>
<div class="summary">
  <strong>Dependencies scanned:</strong> {total_deps}<br>
  <strong>Issues found:</strong> {total_issues}
  &nbsp;&nbsp;
  <span style="color:#c0392b">Critical: {critical}</span> &middot;
  <span style="color:#e67e22">High: {high}</span> &middot;
  <span style="color:#f1c40f">Medium: {medium}</span> &middot;
  <span style="color:#2ecc71">Low: {low}</span>
</div>
{issues_html}
</body>
</html>
"""

_ISSUE_TEMPLATE = """\
<div class="issue" style="border-color:{color}">
  <span class="badge" style="background:{color}">{severity}</span>
  <strong>{name}</strong>{version_str}<br>
  <em>Kind:</em> {kind}<br>
  {message}
  {fix_html}
</div>
"""


def render_html(result: AuditResult) -> str:
    """Render the audit result as an HTML page."""
    summary = result.summary()
    issues_parts: list[str] = []

    for issue in sorted(result.issues, key=lambda i: list(Severity).index(i.severity)):
        color = _SEVERITY_COLORS[issue.severity]
        version_str = f" ({issue.dep.version})" if issue.dep.version else ""
        fix_html = (
            f'<div class="fix">Fix: {issue.fix_suggestion}</div>'
            if issue.fix_suggestion
            else ""
        )
        issues_parts.append(
            _ISSUE_TEMPLATE.format(
                color=color,
                severity=issue.severity.value.upper(),
                name=issue.dep.name,
                version_str=version_str,
                kind=issue.kind,
                message=issue.message,
                fix_html=fix_html,
            )
        )

    return _HTML_TEMPLATE.format(
        color="#ccc",
        total_deps=summary["total_dependencies"],
        total_issues=summary["total_issues"],
        critical=summary["critical"],
        high=summary["high"],
        medium=summary["medium"],
        low=summary["low"],
        issues_html="\n".join(issues_parts) if issues_parts else "<p>No issues found.</p>",
    )


def write_html(result: AuditResult, path: Path) -> None:
    """Write the HTML report to a file."""
    path.write_text(render_html(result), encoding="utf-8")
