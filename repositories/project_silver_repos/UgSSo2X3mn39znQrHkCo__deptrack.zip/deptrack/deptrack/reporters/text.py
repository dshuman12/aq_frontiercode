"""Plain-text report formatter."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from io import StringIO
from typing import TextIO

from deptrack.models import AuditResult, Severity

_SEVERITY_SYMBOLS = {
    Severity.CRITICAL: "[CRITICAL]",
    Severity.HIGH: "[HIGH]    ",
    Severity.MEDIUM: "[MEDIUM]  ",
    Severity.LOW: "[LOW]     ",
}


def render_text(result: AuditResult, file: TextIO | None = None, color: bool = False) -> str:
    """Render the audit result as plain text, return the string and optionally write to file."""
    buf = StringIO()

    buf.write("=" * 60 + "\n")
    buf.write("deptrack Audit Report\n")
    buf.write("=" * 60 + "\n\n")

    summary = result.summary()
    buf.write(f"Dependencies scanned : {summary['total_dependencies']}\n")
    buf.write(f"Issues found         : {summary['total_issues']}\n")
    buf.write(
        f"  Critical: {summary['critical']}  High: {summary['high']}  "
        f"Medium: {summary['medium']}  Low: {summary['low']}\n"
    )
    buf.write("\n")

    if not result.issues:
        buf.write("No issues found. \n")
    else:
        buf.write("Issues\n")
        buf.write("-" * 60 + "\n")
        for issue in sorted(result.issues, key=lambda i: (list(Severity).index(i.severity), i.dep.name)):
            symbol = _SEVERITY_SYMBOLS[issue.severity]
            buf.write(f"{symbol} {issue.dep.name}")
            if issue.dep.version:
                buf.write(f" ({issue.dep.version})")
            buf.write(f"\n         Kind   : {issue.kind}\n")
            buf.write(f"         Detail : {issue.message}\n")
            if issue.fix_suggestion:
                buf.write(f"         Fix    : {issue.fix_suggestion}\n")
            buf.write("\n")

    buf.write("Source files:\n")
    for src in result.source_files:
        buf.write(f"  - {src}\n")

    text = buf.getvalue()
    if file:
        file.write(text)
    return text


def print_text(result: AuditResult, color: bool = True) -> None:
    """Print the audit result to stdout."""
    render_text(result, file=sys.stdout, color=color)


# ---------------------------------------------------------------------------
# Advanced text reporters
# ---------------------------------------------------------------------------

@dataclass
class TextReportConfig:
    show_success: bool = True
    show_summary: bool = True
    show_issues: bool = True
    color: bool = True
    verbose: bool = False


class Color:
    """ANSI color codes."""
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    RESET = "\033[0m"


def _severity_color(severity: Severity) -> str:
    """Get color code for severity."""
    colors = {
        Severity.CRITICAL: Color.RED,
        Severity.HIGH: Color.MAGENTA,
        Severity.MEDIUM: Color.YELLOW,
        Severity.LOW: Color.CYAN,
        Severity.INFO: Color.BLUE,
    }
    return colors.get(severity, Color.RESET)


def render_advanced_text(result: AuditResult, config: TextReportConfig | None = None) -> str:
    """Render audit result as advanced plain text with more features."""
    config = config or TextReportConfig()

    lines = []

    # Header
    lines.append("=" * 60)
    lines.append("DEPENDENCY AUDIT REPORT".center(60))
    lines.append("=" * 60)
    lines.append("")

    # Summary
    if config.show_summary:
        summary = result.summary()

        lines.append("SUMMARY")
        lines.append("-" * 40)
        lines.append(f"  Source files:     {', '.join(result.source_files) if result.source_files else 'N/A'}")
        lines.append(f"  Dependencies:     {summary['total_dependencies']}")
        lines.append(f"  Issues found:      {summary['total_issues']}")
        lines.append(f"  Status:            {'PASS' if result.passed else 'FAIL'}")

        if summary['total_issues'] > 0:
            lines.append("")
            lines.append("  Issues by severity:")
            lines.append(f"    Critical:        {summary['critical']}")
            lines.append(f"    High:            {summary['high']}")
            lines.append(f"    Medium:          {summary['medium']}")
            lines.append(f"    Low:             {summary['low']}")

        lines.append("")

    # Issues
    if config.show_issues and result.issues:
        lines.append("ISSUES")
        lines.append("-" * 40)

        for i, issue in enumerate(result.issues, 1):
            severity = issue.severity.value.upper()

            if config.color and sys.stdout.isatty():
                sev_color = _severity_color(issue.severity)
                lines.append(f"\n[{sev_color}{severity}{Color.RESET}] {issue.dep.name}")
            else:
                lines.append(f"\n[{severity}] {issue.dep.name}")

            if issue.dep.version:
                lines.append(f"  Version:   {issue.dep.version}")

            lines.append(f"  Kind:      {issue.kind}")

            if issue.message:
                lines.append(f"  Message:   {issue.message}")

            if issue.fix_suggestion and config.verbose:
                lines.append(f"  Fix:       {issue.fix_suggestion}")

        lines.append("")

    # Success message
    if config.show_success and result.passed and not result.issues:
        lines.append("")
        lines.append("✓ No issues found. All dependencies are secure.")
        lines.append("")

    return "\n".join(lines)


class TerminalReporter:
    """Render reports for terminal with colors and formatting."""

    def __init__(self, use_color: bool = True):
        self.use_color = use_color and sys.stdout.isatty()

    def print_summary(self, result: AuditResult) -> None:
        """Print summary to terminal."""
        summary = result.summary()

        if self.use_color:
            status_color = Color.GREEN if result.passed else Color.RED
            print(f"\n{'=' * 50}")
            print(f"DEPENDENCY AUDIT REPORT".center(50))
            print(f"{'=' * 50}\n")
            print(f"{Color.CYAN}Dependencies:{Color.RESET}   {summary['total_dependencies']}")
            print(f"{Color.CYAN}Issues:{Color.RESET}        {summary['total_issues']}")
            print(f"{Color.CYAN}Status:{Color.RESET}        {status_color}{'PASS' if result.passed else 'FAIL'}{Color.RESET}")
        else:
            print(f"\n{'=' * 50}")
            print(f"DEPENDENCY AUDIT REPORT".center(50))
            print(f"{'=' * 50}\n")
            print(f"Dependencies:   {summary['total_dependencies']}")
            print(f"Issues:        {summary['total_issues']}")
            print(f"Status:        {'PASS' if result.passed else 'FAIL'}")

    def print_issues(self, result: AuditResult) -> None:
        """Print issues to terminal."""
        if not result.issues:
            if self.use_color:
                print(f"\n{Color.GREEN}✓ No issues found!{Color.RESET}")
            else:
                print("\n✓ No issues found!")
            return

        print("\n" + "-" * 50)
        print("ISSUES")
        print("-" * 50)

        for issue in result.issues:
            severity = issue.severity.value.upper()

            if self.use_color:
                sev_color = _severity_color(issue.severity)
                print(f"\n[{sev_color}{severity}{Color.RESET}] {issue.dep.name}")
            else:
                print(f"\n[{severity}] {issue.dep.name}")

            if issue.dep.version:
                print(f"  Version: {issue.dep.version}")
            print(f"  Kind: {issue.kind}")

            if issue.message:
                print(f"  {issue.message}")

            if issue.fix_suggestion:
                print(f"  → {issue.fix_suggestion}")

    def print_full(self, result: AuditResult) -> None:
        """Print full report to terminal."""
        self.print_summary(result)
        self.print_issues(result)
