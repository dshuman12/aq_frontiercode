"""Plugin system for deptrack — allows third-party custom checkers."""

from __future__ import annotations

import importlib
import importlib.util
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from deptrack.models import AuditResult, Dependency

# Type alias for checker functions
CheckerFn = Callable[[list[Dependency], AuditResult], None]


@dataclass
class Plugin:
    """Represents a registered deptrack plugin."""

    name: str
    checker_fn: CheckerFn
    description: str = ""
    author: str = ""
    version: str = "0.0.1"

    def run(self, deps: list[Dependency], result: AuditResult) -> None:
        """Execute this plugin's checker."""
        self.checker_fn(deps, result)


class PluginRegistry:
    """Global registry of deptrack checker plugins."""

    def __init__(self) -> None:
        self._plugins: dict[str, Plugin] = {}

    def register(
        self,
        name: str,
        checker_fn: CheckerFn,
        description: str = "",
        author: str = "",
        version: str = "0.0.1",
    ) -> None:
        """Register a checker plugin by name."""
        if name in self._plugins:
            raise ValueError(f"Plugin '{name}' is already registered.")
        self._plugins[name] = Plugin(
            name=name,
            checker_fn=checker_fn,
            description=description,
            author=author,
            version=version,
        )

    def unregister(self, name: str) -> None:
        """Remove a plugin from the registry."""
        self._plugins.pop(name, None)

    def get(self, name: str) -> Plugin | None:
        return self._plugins.get(name)

    def all_plugins(self) -> list[Plugin]:
        return list(self._plugins.values())

    def run_all(self, deps: list[Dependency], result: AuditResult) -> None:
        """Run all registered plugins."""
        for plugin in self._plugins.values():
            plugin.run(deps, result)

    def run_selected(
        self, names: list[str], deps: list[Dependency], result: AuditResult
    ) -> None:
        """Run only the named plugins."""
        for name in names:
            plugin = self._plugins.get(name)
            if plugin:
                plugin.run(deps, result)

    def list_names(self) -> list[str]:
        return list(self._plugins.keys())

    def __len__(self) -> int:
        return len(self._plugins)

    def __contains__(self, name: str) -> bool:
        return name in self._plugins


# Global registry instance
_registry = PluginRegistry()


def register_plugin(
    name: str,
    checker_fn: CheckerFn,
    description: str = "",
    author: str = "",
    version: str = "0.0.1",
) -> None:
    """Register a plugin in the global registry."""
    _registry.register(name, checker_fn, description=description, author=author, version=version)


def get_registry() -> PluginRegistry:
    """Return the global plugin registry."""
    return _registry


def load_plugin_from_file(path: Path) -> None:
    """
    Dynamically load a Python file as a plugin module.

    The module is expected to call register_plugin() at import time,
    or define a `register(registry)` function that accepts the registry.
    """
    spec = importlib.util.spec_from_file_location("deptrack_plugin", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load plugin from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules["deptrack_plugin"] = module
    spec.loader.exec_module(module)  # type: ignore[union-attr]

    # If module has a register() function, call it with the global registry
    if hasattr(module, "register") and callable(module.register):
        module.register(_registry)


def load_plugin_from_module(module_name: str) -> None:
    """
    Import a Python module by name and register its plugins.

    The module must call register_plugin() at import time or define register().
    """
    module = importlib.import_module(module_name)
    if hasattr(module, "register") and callable(module.register):
        module.register(_registry)


def plugin(
    name: str,
    description: str = "",
    author: str = "",
    version: str = "0.0.1",
) -> Callable[[CheckerFn], CheckerFn]:
    """
    Decorator to register a function as a deptrack plugin.

    Example::

        @plugin("my-checker", description="Checks for banned packages")
        def check_banned(deps, result):
            ...
    """
    def decorator(fn: CheckerFn) -> CheckerFn:
        register_plugin(name, fn, description=description, author=author, version=version)
        return fn
    return decorator
