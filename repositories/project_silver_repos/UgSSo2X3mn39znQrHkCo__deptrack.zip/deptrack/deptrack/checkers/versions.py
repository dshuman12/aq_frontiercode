"""Checker for unpinned, loose, or missing version constraints."""

from __future__ import annotations

import re

from deptrack.models import AuditResult, Dependency, Issue, Severity

# Matches a pinned exact version: ==1.2.3
_PINNED_RE = re.compile(r"^==\s*[\d]+\.[\d]+")
# Matches any version specifier present
_HAS_SPEC_RE = re.compile(r"[><=!~^]")


def _is_pinned(version: str | None) -> bool:
    if not version:
        return False
    return bool(_PINNED_RE.match(version.strip()))


def _has_constraint(version: str | None) -> bool:
    if not version:
        return False
    return bool(_HAS_SPEC_RE.search(version))


def _is_upper_bounded(version: str | None) -> bool:
    """Return True if version has an upper bound (<, <=, or ~=)."""
    if not version:
        return False
    return bool(re.search(r"(<=?|~=)", version))


def check_unpinned(deps: list[Dependency], result: AuditResult) -> None:
    """Flag dependencies with no version constraint at all."""
    for dep in deps:
        if not dep.version or not _has_constraint(dep.version):
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="unpinned",
                    message=f"'{dep.name}' has no version constraint.",
                    severity=Severity.MEDIUM,
                    fix_suggestion=(
                        f"Pin or constrain '{dep.name}', e.g. '{dep.name}>=1.0,<2.0'."
                    ),
                )
            )


def check_wildcard(deps: list[Dependency], result: AuditResult) -> None:
    """Flag dependencies using wildcard (.*) version specifiers."""
    for dep in deps:
        if dep.version and ".*" in dep.version:
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="wildcard_version",
                    message=f"'{dep.name}' uses a wildcard version specifier: {dep.version!r}.",
                    severity=Severity.LOW,
                    fix_suggestion=(
                        f"Replace the wildcard with an explicit range for '{dep.name}'."
                    ),
                )
            )


def check_missing_upper_bound(deps: list[Dependency], result: AuditResult) -> None:
    """Flag dependencies that have a lower bound but no upper bound."""
    for dep in deps:
        if not dep.version:
            continue
        has_lower = bool(re.search(r"(>=|>)", dep.version))
        if has_lower and not _is_upper_bounded(dep.version) and not _is_pinned(dep.version):
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="missing_upper_bound",
                    message=(
                        f"'{dep.name}' has a lower bound ({dep.version!r}) "
                        f"but no upper bound. A future major release could break your project."
                    ),
                    severity=Severity.LOW,
                    fix_suggestion=(
                        f"Add an upper bound, e.g. change to '{dep.version},<X.0'."
                    ),
                )
            )


def check_prerelease(deps: list, result: "AuditResult") -> None:
    """Flag dependencies pinned to pre-release versions."""
    import re
    prerelease_re = re.compile(r"(a|b|rc|alpha|beta|dev)\d*", re.IGNORECASE)
    for dep in deps:
        if dep.version and prerelease_re.search(dep.version):
            from deptrack.models import Issue, Severity
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="prerelease",
                    message=f"'{dep.name}' is pinned to a pre-release version: {dep.version!r}.",
                    severity=Severity.MEDIUM,
                    fix_suggestion=f"Use a stable release of '{dep.name}' in production.",
                )
            )
