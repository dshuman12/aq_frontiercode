"""License compliance checker — flag packages with disallowed licenses."""

from __future__ import annotations

import re
from typing import Sequence

from deptrack.models import AuditResult, Dependency, Issue, Severity

# Common SPDX-style license identifiers grouped by permissiveness
PERMISSIVE_LICENSES = frozenset([
    "MIT", "BSD", "BSD-2-CLAUSE", "BSD-3-CLAUSE", "APACHE-2.0",
    "APACHE 2.0", "ISC", "UNLICENSE", "CC0-1.0", "WTFPL", "ZLIB",
    "PSF", "PYTHON SOFTWARE FOUNDATION", "PUBLIC DOMAIN",
])

COPYLEFT_LICENSES = frozenset([
    "GPL", "GPL-2.0", "GPL-3.0", "LGPL", "LGPL-2.0", "LGPL-2.1",
    "LGPL-3.0", "AGPL", "AGPL-3.0", "MPL", "MPL-2.0", "EUPL",
    "GPL-2.0-ONLY", "GPL-3.0-ONLY", "GPL-2.0-OR-LATER", "GPL-3.0-OR-LATER",
])

PROPRIETARY_LICENSES = frozenset([
    "PROPRIETARY", "COMMERCIAL", "ALL RIGHTS RESERVED",
    "CLOSED SOURCE",
])

UNKNOWN_LICENSE_STRINGS = frozenset([
    "UNKNOWN", "", "NONE", "N/A",
])


def _normalise_license(lic: str | None) -> str:
    if not lic:
        return ""
    return re.sub(r"\s+", " ", lic.strip().upper())


def classify_license(license_str: str | None) -> str:
    """
    Classify a license string as 'permissive', 'copyleft', 'proprietary', or 'unknown'.
    """
    normalised = _normalise_license(license_str)
    if not normalised or normalised in UNKNOWN_LICENSE_STRINGS:
        return "unknown"
    for token in COPYLEFT_LICENSES:
        if token in normalised:
            return "copyleft"
    for token in PROPRIETARY_LICENSES:
        if token in normalised:
            return "proprietary"
    for token in PERMISSIVE_LICENSES:
        if token in normalised:
            return "permissive"
    return "unknown"




class LicensePolicy:
    """
    Defines which license categories are allowed or denied.

    Usage::

        policy = LicensePolicy(deny=["copyleft", "proprietary"])
        check_licenses(deps, result, policy=policy)
    """

    def __init__(
        self,
        allow: list[str] | None = None,
        deny: list[str] | None = None,
        deny_unknown: bool = False,
    ) -> None:
        self.allow = [a.lower() for a in (allow or [])]
        self.deny = [d.lower() for d in (deny or [])]
        self.deny_unknown = deny_unknown

    def is_allowed(self, classification: str) -> bool:
        """Return True if the license classification is permitted."""
        classification = classification.lower()
        if self.allow:
            return classification in self.allow
        if classification in self.deny:
            return False
        if classification == "unknown" and self.deny_unknown:
            return False
        return True


def check_licenses(
    deps: list[Dependency],
    result: AuditResult,
    license_map: dict[str, str] | None = None,
    policy: LicensePolicy | None = None,
) -> None:
    """
    Check dependency licenses against a policy.

    Parameters
    ----------
    deps:
        List of dependencies to check.
    result:
        AuditResult to append issues to.
    license_map:
        Optional mapping of package name -> license string.
        If not provided, license info must be fetched externally.
    policy:
        License policy. Defaults to flagging copyleft and proprietary licenses.
    """
    if policy is None:
        policy = LicensePolicy(deny=["copyleft", "proprietary"], deny_unknown=False)

    if license_map is None:
        license_map = {}

    for dep in deps:
        license_str = license_map.get(dep.canonical_name)
        if license_str is None:
            continue

        classification = classify_license(license_str)
        if not policy.is_allowed(classification):
            severity = (
                Severity.HIGH if classification == "copyleft" else Severity.MEDIUM
            )
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="license_violation",
                    message=(
                        f"'{dep.name}' uses a {classification} license: {license_str!r}. "
                        f"This may conflict with your project's licensing requirements."
                    ),
                    severity=severity,
                    fix_suggestion=(
                        f"Review the license of '{dep.name}' and replace with a "
                        f"permissively-licensed alternative if needed."
                    ),
                )
            )
