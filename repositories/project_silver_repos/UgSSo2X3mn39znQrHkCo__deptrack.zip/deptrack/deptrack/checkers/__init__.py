"""Checkers for dependency issues."""

from deptrack.checkers.duplicates import check_duplicates, check_name_variants
from deptrack.checkers.versions import check_unpinned, check_wildcard, check_missing_upper_bound
from deptrack.checkers.security import check_vulnerabilities

__all__ = [
    "check_duplicates",
    "check_name_variants",
    "check_unpinned",
    "check_wildcard",
    "check_missing_upper_bound",
    "check_vulnerabilities",
]
from deptrack.checkers.licenses import check_licenses, LicensePolicy, classify_license
