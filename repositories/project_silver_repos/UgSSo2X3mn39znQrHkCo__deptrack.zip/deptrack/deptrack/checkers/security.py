"""Security checker — flags known-vulnerable packages against a local advisory db."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from deptrack.models import AuditResult, Dependency, Issue, Severity

# Bundled minimal advisory database (subset for demonstration)
_BUILTIN_ADVISORIES: list[dict[str, Any]] = [
    {
        "package": "requests",
        "affected_below": "2.20.0",
        "cve": "CVE-2018-18074",
        "summary": "Requests sends HTTP Authorization header to redirect target.",
        "severity": "high",
    },
    {
        "package": "pillow",
        "affected_below": "9.0.0",
        "cve": "CVE-2022-22817",
        "summary": "PIL.ImageMath.eval allows arbitrary code execution.",
        "severity": "critical",
    },
    {
        "package": "pyyaml",
        "affected_below": "5.4",
        "cve": "CVE-2020-14343",
        "summary": "PyYAML arbitrary code execution via yaml.load().",
        "severity": "critical",
    },
    {
        "package": "urllib3",
        "affected_below": "1.26.5",
        "cve": "CVE-2021-33503",
        "summary": "urllib3 ReDoS via evil header value.",
        "severity": "medium",
    },
    {
        "package": "cryptography",
        "affected_below": "41.0.0",
        "cve": "CVE-2023-23931",
        "summary": "Bleichenbacher timing oracle attack.",
        "severity": "high",
    },
]

_SEVERITY_MAP = {
    "low": Severity.LOW,
    "medium": Severity.MEDIUM,
    "high": Severity.HIGH,
    "critical": Severity.CRITICAL,
}


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple, ignoring non-numeric parts."""
    import re
    parts = re.split(r"[.\-]", v)
    result = []
    for p in parts:
        try:
            result.append(int(p))
        except ValueError:
            break
    return tuple(result)


def _is_affected(dep_version: str | None, below: str) -> bool:
    """Return True if dep_version is below the fixed version."""
    if not dep_version:
        return False
    # Strip leading specifiers like ==, >=, ~=
    import re
    raw = re.sub(r"^[><=!~^]+\s*", "", dep_version).strip()
    if not raw:
        return False
    try:
        dep_tuple = _parse_version(raw)
        fix_tuple = _parse_version(below)
        return dep_tuple < fix_tuple  # strict less-than: affected if below fixed version
    except Exception:
        return False


def load_advisories(extra_db: Path | None = None) -> list[dict[str, Any]]:
    """Load advisories from builtin list and optionally an external JSON file."""
    advisories = list(_BUILTIN_ADVISORIES)
    if extra_db and extra_db.exists():
        with open(extra_db, encoding="utf-8") as fh:
            extra = json.load(fh)
            if isinstance(extra, list):
                advisories.extend(extra)
    return advisories


def check_vulnerabilities(
    deps: list[Dependency],
    result: AuditResult,
    extra_db: Path | None = None,
) -> None:
    """Check dependencies against known vulnerability advisories."""
    advisories = load_advisories(extra_db)

    for dep in deps:
        for advisory in advisories:
            if dep.canonical_name != Dependency.normalize_name(advisory["package"]):
                continue
            if _is_affected(dep.version, advisory["affected_below"]):
                severity = _SEVERITY_MAP.get(advisory["severity"], Severity.MEDIUM)
                result.issues.append(
                    Issue(
                        dep=dep,
                        kind="vulnerability",
                        message=(
                            f"{advisory['cve']}: {advisory['summary']} "
                            f"(affects versions below {advisory['affected_below']})"
                        ),
                        severity=severity,
                        fix_suggestion=(
                            f"Upgrade '{dep.name}' to at least {advisory['affected_below']}."
                        ),
                    )
                )


def check_yanked(
    deps: list[Dependency],
    result: AuditResult,
    yanked_map: dict[str, bool] | None = None,
) -> None:
    """
    Flag dependencies whose pinned version has been yanked on PyPI.

    Parameters
    ----------
    deps:
        Dependencies to check.
    result:
        AuditResult to append issues to.
    yanked_map:
        Optional pre-fetched mapping of canonical name -> yanked bool.
        If None, no yanked check is performed (requires network).
    """
    if yanked_map is None:
        return
    for dep in deps:
        if dep.canonical_name in yanked_map and yanked_map[dep.canonical_name]:
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="yanked",
                    message=(
                        f"'{dep.name}' version {dep.version!r} has been yanked from PyPI. "
                        "Yanked releases are considered broken or unsafe."
                    ),
                    severity=Severity.HIGH,
                    fix_suggestion=(
                        f"Upgrade or downgrade '{dep.name}' to a non-yanked release."
                    ),
                )
            )


def check_unmaintained(
    deps: list[Dependency],
    result: AuditResult,
    last_release_map: dict[str, str] | None = None,
    stale_years: int = 3,
) -> None:
    """
    Flag dependencies that haven't had a release in `stale_years` years.

    Parameters
    ----------
    deps:
        Dependencies to check.
    result:
        AuditResult to append issues to.
    last_release_map:
        Mapping of canonical name -> ISO date string of last release.
    stale_years:
        Number of years without a release to consider unmaintained.
    """
    if last_release_map is None:
        return

    import datetime
    cutoff = datetime.date.today() - datetime.timedelta(days=stale_years * 365)

    for dep in deps:
        last_release_str = last_release_map.get(dep.canonical_name)
        if not last_release_str:
            continue
        try:
            last_release = datetime.date.fromisoformat(last_release_str[:10])
        except ValueError:
            continue

        if last_release < cutoff:
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="unmaintained",
                    message=(
                        f"'{dep.name}' has not had a release since {last_release_str[:10]} "
                        f"({(datetime.date.today() - last_release).days // 365} years ago). "
                        "It may be unmaintained."
                    ),
                    severity=Severity.LOW,
                    fix_suggestion=(
                        f"Consider replacing '{dep.name}' with an actively maintained alternative."
                    ),
                )
            )


def load_advisories(extra_db: Path | None = None) -> list[dict]:
    """Load advisories from the builtin list and an optional external JSON file."""
    advisories = list(_BUILTIN_ADVISORIES)
    if extra_db and extra_db.exists():
        with open(extra_db, encoding="utf-8") as fh:
            extra = json.load(fh)
            if isinstance(extra, list):
                advisories.extend(extra)
    return advisories


def summarise_vulnerabilities(issues: list) -> dict:
    """
    Produce a summary dict of vulnerability issues grouped by severity.

    Parameters
    ----------
    issues:
        List of Issue objects (filtered to kind == 'vulnerability').
    """
    summary: dict[str, list[str]] = {
        "critical": [],
        "high": [],
        "medium": [],
        "low": [],
    }
    for issue in issues:
        if issue.kind != "vulnerability":
            continue
        key = issue.severity.value
        if key in summary:
            summary[key].append(issue.dep.name)
    return {k: v for k, v in summary.items() if v}
