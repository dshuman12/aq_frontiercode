"""Checker for duplicate and conflicting dependency declarations."""

from __future__ import annotations

from collections import defaultdict

from deptrack.models import AuditResult, Dependency, Issue, Severity


def check_duplicates(deps: list[Dependency], result: AuditResult) -> None:
    """Detect packages declared more than once, possibly with conflicting versions."""
    seen: dict[str, list[Dependency]] = defaultdict(list)
    for dep in deps:
        seen[dep.canonical_name].append(dep)

    for name, occurrences in seen.items():
        if len(occurrences) < 2:
            continue

        versions = {d.version for d in occurrences if d.version}
        if len(versions) > 1:
            # Conflicting versions — higher severity
            result.issues.append(
                Issue(
                    dep=occurrences[0],
                    kind="conflicting_versions",
                    message=(
                        f"Package '{name}' is declared {len(occurrences)} times "
                        f"with conflicting versions: {sorted(versions)}"
                    ),
                    severity=Severity.HIGH,
                    fix_suggestion=f"Keep only one declaration of '{name}' with a single version.",
                )
            )
        else:
            result.issues.append(
                Issue(
                    dep=occurrences[0],
                    kind="duplicate",
                    message=(
                        f"Package '{name}' is declared {len(occurrences)} times."
                    ),
                    severity=Severity.LOW,
                    fix_suggestion=f"Remove duplicate entries for '{name}'.",
                )
            )


def check_name_variants(deps: list[Dependency], result: AuditResult) -> None:
    """Detect packages that differ only in name normalisation (e.g. Pillow vs pillow)."""
    canonical_map: dict[str, list[Dependency]] = defaultdict(list)
    for dep in deps:
        canonical_map[dep.canonical_name].append(dep)

    for canonical, group in canonical_map.items():
        raw_names = {d.name for d in group}
        if len(raw_names) > 1:
            result.issues.append(
                Issue(
                    dep=group[0],
                    kind="name_variant",
                    message=(
                        f"Package '{canonical}' appears under multiple name variants: "
                        f"{sorted(raw_names)}. This may cause installation issues."
                    ),
                    severity=Severity.MEDIUM,
                    fix_suggestion=f"Standardise all references to '{canonical}'.",
                )
            )
