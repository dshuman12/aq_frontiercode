"""PyPI integration — fetch package metadata and latest versions."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

PYPI_JSON_URL = "https://pypi.org/pypi/{package}/json"
PYPI_TIMEOUT = 10  # seconds


@dataclass
class PyPIPackageInfo:
    """Metadata for a package fetched from PyPI."""

    name: str
    latest_version: str
    summary: str
    home_page: str | None
    license: str | None
    requires_python: str | None
    yanked: bool = False

    @classmethod
    def from_pypi_response(cls, data: dict[str, Any]) -> "PyPIPackageInfo":
        info = data.get("info", {})
        return cls(
            name=info.get("name", ""),
            latest_version=info.get("version", ""),
            summary=info.get("summary", ""),
            home_page=info.get("home_page") or info.get("project_url"),
            license=info.get("license"),
            requires_python=info.get("requires_python"),
            yanked=info.get("yanked", False),
        )


class PyPIClient:
    """Simple client for the PyPI JSON API."""

    def __init__(self, timeout: int = PYPI_TIMEOUT) -> None:
        self.timeout = timeout
        self._cache: dict[str, PyPIPackageInfo | None] = {}

    def fetch(self, package_name: str) -> PyPIPackageInfo | None:
        """Fetch package metadata from PyPI. Returns None on error."""
        key = package_name.lower()
        if key in self._cache:
            return self._cache[key]

        url = PYPI_JSON_URL.format(package=package_name)
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "deptrack/0.2.0 (dependency auditor)"},
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            result = PyPIPackageInfo.from_pypi_response(data)
            self._cache[key] = result
            return result
        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError):
            self._cache[key] = None
            return None

    def get_latest_version(self, package_name: str) -> str | None:
        """Return the latest version string for a package, or None."""
        info = self.fetch(package_name)
        return info.latest_version if info else None

    def is_yanked(self, package_name: str) -> bool:
        """Return True if the latest version is yanked."""
        info = self.fetch(package_name)
        return info.yanked if info else False

    def clear_cache(self) -> None:
        self._cache.clear()


def _strip_specifier(version: str | None) -> str | None:
    """Strip leading specifier characters from a version string."""
    import re
    if not version:
        return None
    return re.sub(r"^[><=!~^]+\s*", "", version).strip() or None


def _parse_version_tuple(v: str) -> tuple[int, ...]:
    """Parse a version string to a sortable tuple."""
    import re
    parts = re.split(r"[.\-]", v)
    result = []
    for p in parts:
        try:
            result.append(int(p))
        except ValueError:
            break
    return tuple(result)


def check_outdated(
    deps: list,
    result: "AuditResult",  # type: ignore[name-defined]
    client: PyPIClient | None = None,
) -> None:
    """
    Check if any dependencies have newer versions available on PyPI.
    Requires network access — skipped if PyPI is unreachable.
    """
    from deptrack.models import Issue, Severity

    pypi = client or PyPIClient()

    for dep in deps:
        current_raw = _strip_specifier(dep.version)
        if not current_raw:
            continue

        latest = pypi.get_latest_version(dep.name)
        if not latest:
            continue

        try:
            current_tuple = _parse_version_tuple(current_raw)
            latest_tuple = _parse_version_tuple(latest)
        except Exception:
            continue

        if latest_tuple > current_tuple:
            result.issues.append(
                Issue(
                    dep=dep,
                    kind="outdated",
                    message=(
                        f"'{dep.name}' is at {current_raw!r} but "
                        f"{latest!r} is available on PyPI."
                    ),
                    severity=Severity.LOW,
                    fix_suggestion=f"Upgrade '{dep.name}' to =={latest}.",
                )
            )
