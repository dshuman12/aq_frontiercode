"""deptrack - Database models for persistent storage."""

import json
import sqlite3
from abc import ABC, abstractmethod
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any, Generator

from deptrack.models import Dependency, Issue, AuditResult, Severity


class DatabaseError(Exception):
    """Base exception for database errors."""
    pass


class SchemaError(DatabaseError):
    """Error when database schema is invalid."""
    pass


class DatabaseConnection:
    """Manages SQLite database connections with migrations."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._connection: Optional[sqlite3.Connection] = None

    @property
    def connection(self) -> sqlite3.Connection:
        """Get or create database connection."""
        if self._connection is None:
            self._connection = sqlite3.connect(self.db_path)
            self._connection.row_factory = sqlite3.Row
            self._connection.execute("PRAGMA foreign_keys = ON")
        return self._connection

    @contextmanager
    def transaction(self) -> Generator[sqlite3.Connection, None, None]:
        """Context manager for database transactions."""
        conn = self.connection
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    def close(self) -> None:
        """Close the database connection."""
        if self._connection:
            self._connection.close()
            self._connection = None

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a SQL statement."""
        return self.connection.execute(sql, params)

    def executemany(self, sql: str, params: List[tuple]) -> sqlite3.Cursor:
        """Execute a SQL statement with multiple parameters."""
        return self.connection.executemany(sql, params)

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[sqlite3.Row]:
        """Execute a query and fetch one result."""
        cursor = self.connection.execute(sql, params)
        return cursor.fetchone()

    def fetchall(self, sql: str, params: tuple = ()) -> List[sqlite3.Row]:
        """Execute a query and fetch all results."""
        cursor = self.connection.execute(sql, params)
        return cursor.fetchall()


class Migration:
    """Represents a database migration."""

    def __init__(self, version: int, name: str, sql: str):
        self.version = version
        self.name = name
        self.sql = sql

    def apply(self, db: DatabaseConnection) -> None:
        """Apply this migration to the database."""
        with db.transaction() as conn:
            conn.executescript(self.sql)


MIGRATIONS = [
    Migration(1, "initial_schema", """
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY,
            applied_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            version TEXT,
            source TEXT,
            is_dev BOOLEAN DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS issues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dependency_id INTEGER NOT NULL,
            issue_type TEXT NOT NULL,
            severity TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            created_at TEXT NOT NULL,
            dismissed BOOLEAN DEFAULT 0,
            dismissed_reason TEXT,
            FOREIGN KEY (dependency_id) REFERENCES dependencies(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS audits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            started_at TEXT NOT NULL,
            completed_at TEXT,
            total_dependencies INTEGER DEFAULT 0,
            total_issues INTEGER DEFAULT 0,
            passed BOOLEAN DEFAULT 1,
            config TEXT,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            audit_id INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            data TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
            FOREIGN KEY (audit_id) REFERENCES audits(id) ON DELETE CASCADE
        );

        CREATE INDEX idx_dependencies_project ON dependencies(project_id);
        CREATE INDEX idx_issues_dependency ON issues(dependency_id);
        CREATE INDEX idx_audits_project ON audits(project_id);
        CREATE INDEX idx_snapshots_project ON snapshots(project_id);
    """),

    Migration(2, "add_vulnerability_tracking", """
        CREATE TABLE IF NOT EXISTS vulnerabilities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cve_id TEXT NOT NULL UNIQUE,
            package_name TEXT NOT NULL,
            affected_versions TEXT NOT NULL,
            fixed_version TEXT,
            severity TEXT NOT NULL,
            cvss_score REAL,
            description TEXT,
            references TEXT,
            published_at TEXT,
            updated_at TEXT
        );

        CREATE INDEX idx_vulns_package ON vulnerabilities(package_name);
        CREATE INDEX idx_vulns_severity ON vulnerabilities(severity);
    """),

    Migration(3, "add_policy_tracking", """
        CREATE TABLE IF NOT EXISTS policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            policy_type TEXT NOT NULL,
            config TEXT NOT NULL,
            severity TEXT NOT NULL,
            enabled BOOLEAN DEFAULT 1,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS policy_violations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            audit_id INTEGER NOT NULL,
            policy_id INTEGER NOT NULL,
            dependency_name TEXT NOT NULL,
            dependency_version TEXT,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (audit_id) REFERENCES audits(id) ON DELETE CASCADE,
            FOREIGN KEY (policy_id) REFERENCES policies(id)
        );

        CREATE INDEX idx_policies_type ON policies(policy_type);
        CREATE INDEX idx_policy_violations_audit ON policy_violations(audit_id);
    """),

    Migration(4, "add_sbom_tracking", """
        CREATE TABLE IF NOT EXISTS sboms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            format TEXT NOT NULL,
            version TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        );

        CREATE INDEX idx_sboms_project ON sboms(project_id);
    """),
]


class DatabaseSchemaManager:
    """Manages database schema and migrations."""

    def __init__(self, db: DatabaseConnection):
        self.db = db

    def initialize_schema(self) -> None:
        """Initialize the database schema."""
        for migration in MIGRATIONS:
            self._apply_migration(migration)

    def _apply_migration(self, migration: Migration) -> None:
        """Apply a single migration if not already applied."""
        result = self.db.fetchone(
            "SELECT version FROM schema_version WHERE version = ?",
            (migration.version,)
        )

        if result is None:
            migration.apply(self.db)
            self.db.execute(
                "INSERT INTO schema_version (version, applied_at) VALUES (?, ?)",
                (migration.version, datetime.utcnow().isoformat())
            )

    def get_current_version(self) -> int:
        """Get the current schema version."""
        result = self.db.fetchone("SELECT MAX(version) as v FROM schema_version")
        return result["v"] if result and result["v"] else 0


class Repository(ABC):
    """Base class for data repositories."""

    def __init__(self, db: DatabaseConnection):
        self.db = db

    @abstractmethod
    def create(self, data: Dict[str, Any]) -> int:
        """Create a new record."""
        pass

    @abstractmethod
    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get a record by ID."""
        pass

    @abstractmethod
    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update a record."""
        pass

    @abstractmethod
    def delete(self, id: int) -> bool:
        """Delete a record."""
        pass

    @abstractmethod
    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all records with pagination."""
        pass


class ProjectRepository(Repository):
    """Repository for project management."""

    def create(self, data: Dict[str, Any]) -> int:
        """Create a new project."""
        now = datetime.utcnow().isoformat()
        cursor = self.db.execute(
            """
            INSERT INTO projects (name, description, created_at, updated_at)
            VALUES (?, ?, ?, ?)
            """,
            (data["name"], data.get("description"), now, now)
        )
        return cursor.lastrowid

    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get project by ID."""
        return self.db.fetchone(
            "SELECT * FROM projects WHERE id = ?",
            (id,)
        )

    def get_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Get project by name."""
        return self.db.fetchone(
            "SELECT * FROM projects WHERE name = ?",
            (name,)
        )

    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update a project."""
        data["updated_at"] = datetime.utcnow().isoformat()
        self.db.execute(
            """
            UPDATE projects
            SET name = COALESCE(?, name),
                description = COALESCE(?, description),
                updated_at = ?
            WHERE id = ?
            """,
            (data.get("name"), data.get("description"), data["updated_at"], id)
        )
        return self.db.connection.total_changes > 0

    def delete(self, id: int) -> bool:
        """Delete a project and all related data."""
        self.db.execute("DELETE FROM projects WHERE id = ?", (id,))
        return self.db.connection.total_changes > 0

    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all projects."""
        return self.db.fetchall(
            "SELECT * FROM projects ORDER BY updated_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )


class DependencyRepository(Repository):
    """Repository for dependency management."""

    def create(self, data: Dict[str, Any]) -> int:
        """Create a new dependency."""
        now = datetime.utcnow().isoformat()
        cursor = self.db.execute(
            """
            INSERT INTO dependencies
            (project_id, name, version, source, is_dev, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                data["project_id"],
                data["name"],
                data.get("version"),
                data.get("source"),
                data.get("is_dev", False),
                now
            )
        )
        return cursor.lastrowid

    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get dependency by ID."""
        return self.db.fetchone(
            "SELECT * FROM dependencies WHERE id = ?",
            (id,)
        )

    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update a dependency."""
        self.db.execute(
            """
            UPDATE dependencies
            SET name = COALESCE(?, name),
                version = COALESCE(?, version),
                source = COALESCE(?, source),
                is_dev = COALESCE(?, is_dev)
            WHERE id = ?
            """,
            (data.get("name"), data.get("version"), data.get("source"),
             data.get("is_dev"), id)
        )
        return self.db.connection.total_changes > 0

    def delete(self, id: int) -> bool:
        """Delete a dependency."""
        self.db.execute("DELETE FROM dependencies WHERE id = ?", (id,))
        return self.db.connection.total_changes > 0

    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all dependencies."""
        return self.db.fetchall(
            "SELECT * FROM dependencies ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )

    def list_by_project(self, project_id: int) -> List[Dict[str, Any]]:
        """List all dependencies for a project."""
        return self.db.fetchall(
            "SELECT * FROM dependencies WHERE project_id = ?",
            (project_id,)
        )

    def find_by_name_version(
        self,
        project_id: int,
        name: str,
        version: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Find a dependency by name and optional version."""
        if version:
            return self.db.fetchone(
                """
                SELECT * FROM dependencies
                WHERE project_id = ? AND name = ? AND version = ?
                """,
                (project_id, name, version)
            )
        return self.db.fetchone(
            "SELECT * FROM dependencies WHERE project_id = ? AND name = ?",
            (project_id, name)
        )

    def bulk_create(self, project_id: int, deps: List[Dict[str, Any]]) -> List[int]:
        """Bulk create dependencies."""
        now = datetime.utcnow().isoformat()
        rows = [
            (project_id, d["name"], d.get("version"), d.get("source"),
             d.get("is_dev", False), now)
            for d in deps
        ]
        self.db.executemany(
            """
            INSERT INTO dependencies
            (project_id, name, version, source, is_dev, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            rows
        )
        # Get the last inserted IDs
        cursor = self.db.execute("SELECT last_insert_rowid()")
        ids = []
        for row in cursor:
            ids.append(row[0] - len(rows) + 1)
            # Move to next row
        return list(range(cursor.lastrowid - len(rows) + 1, cursor.lastrowid + 1))


class IssueRepository(Repository):
    """Repository for issue management."""

    def create(self, data: Dict[str, Any]) -> int:
        """Create a new issue."""
        now = datetime.utcnow().isoformat()
        cursor = self.db.execute(
            """
            INSERT INTO issues
            (dependency_id, issue_type, severity, title, description, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                data["dependency_id"],
                data["issue_type"],
                data["severity"],
                data["title"],
                data.get("description"),
                now
            )
        )
        return cursor.lastrowid

    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get issue by ID."""
        return self.db.fetchone("SELECT * FROM issues WHERE id = ?", (id,))

    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update an issue."""
        self.db.execute(
            """
            UPDATE issues
            SET dismissed = COALESCE(?, dismissed),
                dismissed_reason = COALESCE(?, dismissed_reason)
            WHERE id = ?
            """,
            (data.get("dismissed"), data.get("dismissed_reason"), id)
        )
        return self.db.connection.total_changes > 0

    def delete(self, id: int) -> bool:
        """Delete an issue."""
        self.db.execute("DELETE FROM issues WHERE id = ?", (id,))
        return self.db.connection.total_changes > 0

    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all issues."""
        return self.db.fetchall(
            "SELECT * FROM issues ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )

    def list_by_dependency(self, dependency_id: int) -> List[Dict[str, Any]]:
        """List all issues for a dependency."""
        return self.db.fetchall(
            "SELECT * FROM issues WHERE dependency_id = ?",
            (dependency_id,)
        )

    def list_by_severity(self, severity: str) -> List[Dict[str, Any]]:
        """List all issues by severity."""
        return self.db.fetchall(
            "SELECT * FROM issues WHERE severity = ? ORDER BY created_at DESC",
            (severity,)
        )

    def list_active(self) -> List[Dict[str, Any]]:
        """List all non-dismissed issues."""
        return self.db.fetchall(
            "SELECT * FROM issues WHERE dismissed = 0 ORDER BY created_at DESC"
        )


class AuditRepository(Repository):
    """Repository for audit records."""

    def create(self, data: Dict[str, Any]) -> int:
        """Create a new audit record."""
        now = datetime.utcnow().isoformat()
        cursor = self.db.execute(
            """
            INSERT INTO audits
            (project_id, started_at, config)
            VALUES (?, ?, ?)
            """,
            (data["project_id"], now, json.dumps(data.get("config", {})))
        )
        return cursor.lastrowid

    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get audit by ID."""
        return self.db.fetchone("SELECT * FROM audits WHERE id = ?", (id,))

    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update an audit record."""
        if "completed_at" in data:
            self.db.execute(
                """
                UPDATE audits
                SET completed_at = ?,
                    total_dependencies = COALESCE(?, total_dependencies),
                    total_issues = COALESCE(?, total_issues),
                    passed = COALESCE(?, passed)
                WHERE id = ?
                """,
                (data["completed_at"], data.get("total_dependencies"),
                 data.get("total_issues"), data.get("passed"), id)
            )
        return self.db.connection.total_changes > 0

    def delete(self, id: int) -> bool:
        """Delete an audit record."""
        self.db.execute("DELETE FROM audits WHERE id = ?", (id,))
        return self.db.connection.total_changes > 0

    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all audits."""
        return self.db.fetchall(
            "SELECT * FROM audits ORDER BY started_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )

    def list_by_project(self, project_id: int) -> List[Dict[str, Any]]:
        """List all audits for a project."""
        return self.db.fetchall(
            "SELECT * FROM audits WHERE project_id = ? ORDER BY started_at DESC",
            (project_id,)
        )

    def get_latest(self, project_id: int) -> Optional[Dict[str, Any]]:
        """Get the most recent audit for a project."""
        return self.db.fetchone(
            """
            SELECT * FROM audits
            WHERE project_id = ?
            ORDER BY started_at DESC
            LIMIT 1
            """,
            (project_id,)
        )


class VulnerabilityRepository(Repository):
    """Repository for vulnerability database."""

    def create(self, data: Dict[str, Any]) -> int:
        """Create a new vulnerability record."""
        cursor = self.db.execute(
            """
            INSERT OR REPLACE INTO vulnerabilities
            (cve_id, package_name, affected_versions, fixed_version,
             severity, cvss_score, description, references,
             published_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data["cve_id"],
                data["package_name"],
                data["affected_versions"],
                data.get("fixed_version"),
                data["severity"],
                data.get("cvss_score"),
                data.get("description"),
                json.dumps(data.get("references", [])),
                data.get("published_at"),
                data.get("updated_at", datetime.utcnow().isoformat())
            )
        )
        return cursor.lastrowid

    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get vulnerability by ID (rowid)."""
        return self.db.fetchone(
            "SELECT rowid, * FROM vulnerabilities WHERE rowid = ?",
            (id,)
        )

    def get_by_cve_id(self, cve_id: str) -> Optional[Dict[str, Any]]:
        """Get vulnerability by CVE ID."""
        return self.db.fetchone(
            "SELECT * FROM vulnerabilities WHERE cve_id = ?",
            (cve_id,)
        )

    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update a vulnerability record."""
        self.db.execute(
            """
            UPDATE vulnerabilities
            SET package_name = COALESCE(?, package_name),
                affected_versions = COALESCE(?, affected_versions),
                fixed_version = COALESCE(?, fixed_version),
                severity = COALESCE(?, severity),
                cvss_score = COALESCE(?, cvss_score),
                description = COALESCE(?, description),
                updated_at = ?
            WHERE rowid = ?
            """,
            (data.get("package_name"), data.get("affected_versions"),
             data.get("fixed_version"), data.get("severity"),
             data.get("cvss_score"), data.get("description"),
             datetime.utcnow().isoformat(), id)
        )
        return self.db.connection.total_changes > 0

    def delete(self, id: int) -> bool:
        """Delete a vulnerability."""
        self.db.execute("DELETE FROM vulnerabilities WHERE rowid = ?", (id,))
        return self.db.connection.total_changes > 0

    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all vulnerabilities."""
        return self.db.fetchall(
            "SELECT * FROM vulnerabilities ORDER BY published_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )

    def list_by_package(self, package_name: str) -> List[Dict[str, Any]]:
        """List all vulnerabilities for a package."""
        return self.db.fetchall(
            "SELECT * FROM vulnerabilities WHERE package_name = ?",
            (package_name,)
        )

    def list_by_severity(self, severity: str) -> List[Dict[str, Any]]:
        """List all vulnerabilities by severity."""
        return self.db.fetchall(
            "SELECT * FROM vulnerabilities WHERE severity = ?",
            (severity,)
        )

    def search(self, query: str) -> List[Dict[str, Any]]:
        """Search vulnerabilities by CVE ID or package name."""
        return self.db.fetchall(
            """
            SELECT * FROM vulnerabilities
            WHERE cve_id LIKE ? OR package_name LIKE ?
            ORDER BY published_at DESC
            """,
            (f"%{query}%", f"%{query}%")
        )


class PolicyRepository(Repository):
    """Repository for policy management."""

    def create(self, data: Dict[str, Any]) -> int:
        """Create a new policy."""
        now = datetime.utcnow().isoformat()
        cursor = self.db.execute(
            """
            INSERT INTO policies
            (name, description, policy_type, config, severity, enabled, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data["name"],
                data.get("description"),
                data["policy_type"],
                json.dumps(data["config"]),
                data["severity"],
                data.get("enabled", True),
                now
            )
        )
        return cursor.lastrowid

    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get policy by ID."""
        return self.db.fetchone("SELECT * FROM policies WHERE id = ?", (id,))

    def get_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Get policy by name."""
        return self.db.fetchone("SELECT * FROM policies WHERE name = ?", (name,))

    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update a policy."""
        self.db.execute(
            """
            UPDATE policies
            SET name = COALESCE(?, name),
                description = COALESCE(?, description),
                config = COALESCE(?, config),
                severity = COALESCE(?, severity),
                enabled = COALESCE(?, enabled)
            WHERE id = ?
            """,
            (data.get("name"), data.get("description"),
             json.dumps(data["config"]) if "config" in data else None,
             data.get("severity"), data.get("enabled"), id)
        )
        return self.db.connection.total_changes > 0

    def delete(self, id: int) -> bool:
        """Delete a policy."""
        self.db.execute("DELETE FROM policies WHERE id = ?", (id,))
        return self.db.connection.total_changes > 0

    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all policies."""
        return self.db.fetchall(
            "SELECT * FROM policies ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )

    def list_enabled(self) -> List[Dict[str, Any]]:
        """List all enabled policies."""
        return self.db.fetchall("SELECT * FROM policies WHERE enabled = 1")


class SBOMRepository(Repository):
    """Repository for SBOM storage."""

    def create(self, data: Dict[str, Any]) -> int:
        """Create a new SBOM record."""
        now = datetime.utcnow().isoformat()
        cursor = self.db.execute(
            """
            INSERT INTO sboms
            (project_id, format, version, content, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                data["project_id"],
                data["format"],
                data["version"],
                data["content"],
                now
            )
        )
        return cursor.lastrowid

    def get(self, id: int) -> Optional[Dict[str, Any]]:
        """Get SBOM by ID."""
        return self.db.fetchone("SELECT * FROM sboms WHERE id = ?", (id,))

    def update(self, id: int, data: Dict[str, Any]) -> bool:
        """Update an SBOM record."""
        self.db.execute(
            """
            UPDATE sboms
            SET format = COALESCE(?, format),
                version = COALESCE(?, version),
                content = COALESCE(?, content)
            WHERE id = ?
            """,
            (data.get("format"), data.get("version"), data.get("content"), id)
        )
        return self.db.connection.total_changes > 0

    def delete(self, id: int) -> bool:
        """Delete an SBOM."""
        self.db.execute("DELETE FROM sboms WHERE id = ?", (id,))
        return self.db.connection.total_changes > 0

    def list_all(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List all SBOMs."""
        return self.db.fetchall(
            "SELECT * FROM sboms ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )

    def list_by_project(self, project_id: int) -> List[Dict[str, Any]]:
        """List all SBOMs for a project."""
        return self.db.fetchall(
            "SELECT * FROM sboms WHERE project_id = ? ORDER BY created_at DESC",
            (project_id,)
        )

    def get_latest(self, project_id: int) -> Optional[Dict[str, Any]]:
        """Get the most recent SBOM for a project."""
        return self.db.fetchone(
            """
            SELECT * FROM sboms
            WHERE project_id = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (project_id,)
        )


class UnitOfWork:
    """Unit of Work pattern for transaction management."""

    def __init__(self, db_path: str):
        self.db = DatabaseConnection(db_path)
        self.schema_manager = DatabaseSchemaManager(self.db)
        self.projects = ProjectRepository(self.db)
        self.dependencies = DependencyRepository(self.db)
        self.issues = IssueRepository(self.db)
        self.audits = AuditRepository(self.db)
        self.vulnerabilities = VulnerabilityRepository(self.db)
        self.policies = PolicyRepository(self.db)
        self.sboms = SBOMRepository(self.db)

    def initialize(self) -> None:
        """Initialize database and schema."""
        self.schema_manager.initialize_schema()

    def close(self) -> None:
        """Close the database connection."""
        self.db.close()


def create_unit_of_work(db_path: str = ".deptrack.db") -> UnitOfWork:
    """Create and initialize a UnitOfWork instance."""
    uow = UnitOfWork(db_path)
    uow.initialize()
    return uow


@contextmanager
def unit_of_work(db_path: str = ".deptrack.db") -> Generator[UnitOfWork, None, None]:
    """Context manager for UnitOfWork."""
    uow = create_unit_of_work(db_path)
    try:
        yield uow
    finally:
        uow.close()


def get_default_db_path() -> Path:
    """Get the default database path."""
    return Path.home() / ".deptrack" / "deptrack.db"