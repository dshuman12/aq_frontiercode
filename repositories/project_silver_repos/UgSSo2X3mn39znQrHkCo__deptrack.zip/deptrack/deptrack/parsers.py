"""deptrack - Advanced parsing utilities for various lockfile formats."""

import re
import json
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple, Any, Set
from dataclasses import dataclass


@dataclass
class ParsedDependency:
    """Represents a parsed dependency."""
    name: str
    version: str
    source: Optional[str] = None
    resolved_url: Optional[str] = None
    checksum: Optional[str] = None
    dependencies: List[str] = None
    is_dev: bool = False
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []
        if self.metadata is None:
            self.metadata = {}


class LockfileParser(ABC):
    """Base class for lockfile parsers."""

    @abstractmethod
    def can_parse(self, content: str) -> bool:
        """Check if this parser can handle the content."""
        pass

    @abstractmethod
    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse lockfile content and return dependencies."""
        pass

    @abstractmethod
    def get_ecosystem(self) -> str:
        """Return the ecosystem this parser handles."""
        pass


class PythonRequirementsParser(LockfileParser):
    """Parser for requirements.txt files."""

    def can_parse(self, content: str) -> bool:
        """Check if content looks like requirements.txt."""
        lines = content.strip().split('\n')
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # Look for package==version pattern
            if '==' in line or '>=' in line or '~=' in line or '<=' in line:
                return True
            if line.startswith('-'):
                continue
            return True
        return False

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse requirements.txt content."""
        deps = []
        lines = content.strip().split('\n')

        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            # Skip options like -r, -e, --index-url, etc.
            if line.startswith('-'):
                continue

            # Parse package specification
            name, version = self._parse_specification(line)
            if name:
                deps.append(ParsedDependency(
                    name=name,
                    version=version or "unknown",
                    source="pypi",
                ))

        return deps

    def get_ecosystem(self) -> str:
        return "python"

    def _parse_specification(self, spec: str) -> Tuple[Optional[str], Optional[str]]:
        """Parse a single requirement specification."""
        # Handle extras like package[extra]==1.0.0
        spec = spec.split('[')[0]

        # Handle environment markers like ; python_version > "3.5"
        if ';' in spec:
            spec = spec.split(';')[0]

        # Handle version specifiers
        operators = ['==', '>=', '<=', '~=', '!=', '>', '<']
        for op in operators:
            if op in spec:
                parts = spec.split(op)
                return parts[0].strip(), op + parts[1].strip()

        return spec.strip(), None


class PipfileLockParser(LockfileParser):
    """Parser for Pipfile.lock files."""

    def can_parse(self, content: str) -> bool:
        """Check if content is JSON with package data."""
        try:
            data = json.loads(content)
            return "default" in data or "develop" in data
        except json.JSONDecodeError:
            return False

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse Pipfile.lock content."""
        deps = []
        data = json.loads(content)

        # Parse default packages
        for name, info in data.get("default", {}).items():
            version = info.get("version", "unknown")
            deps.append(ParsedDependency(
                name=name,
                version=version,
                source="pypi",
                resolved_url=info.get("url"),
                checksum=info.get("hashes", [None])[0] if info.get("hashes") else None,
            ))

        # Parse develop packages
        for name, info in data.get("develop", {}).items():
            version = info.get("version", "unknown")
            deps.append(ParsedDependency(
                name=name,
                version=version,
                source="pypi",
                resolved_url=info.get("url"),
                is_dev=True,
            ))

        return deps

    def get_ecosystem(self) -> str:
        return "python"


class PackageLockParser(LockfileParser):
    """Parser for package-lock.json files."""

    def can_parse(self, content: str) -> bool:
        """Check if content is package-lock.json format."""
        try:
            data = json.loads(content)
            return "packages" in data or "dependencies" in data
        except json.JSONDecodeError:
            return False

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse package-lock.json content."""
        deps = []
        data = json.loads(content)

        # Handle lockfileVersion 2/3 format
        if "packages" in data:
            for path, info in data["packages"].items():
                if path == "":
                    continue  # Skip root package

                name = self._extract_name_from_path(path)
                version = info.get("version", "unknown")

                dep = ParsedDependency(
                    name=name,
                    version=version,
                    source="npm",
                    resolved_url=info.get("resolved"),
                    checksum=info.get("integrity"),
                )

                # Handle nested dependencies
                if "dependencies" in info:
                    dep.dependencies = list(info["dependencies"].keys())

                deps.append(dep)

        # Handle lockfileVersion 1 format
        elif "dependencies" in data:
            deps.extend(self._parse_dependencies_v1(data["dependencies"], ""))

        return deps

    def get_ecosystem(self) -> str:
        return "npm"

    def _parse_dependencies_v1(self, deps: Dict, parent_path: str) -> List[ParsedDependency]:
        """Recursively parse dependencies from v1 format."""
        result = []

        for name, info in deps.items():
            version = info.get("version", "unknown") if isinstance(info, dict) else info

            dep = ParsedDependency(
                name=name,
                version=version,
                source="npm",
            )

            if isinstance(info, dict):
                dep.resolved_url = info.get("resolved")
                dep.dependencies = list(info.get("requires", {}).keys())

                # Recurse into nested dependencies
                if "dependencies" in info:
                    result.extend(self._parse_dependencies_v1(info["dependencies"], f"{parent_path}/{name}"))

            result.append(dep)

        return result

    def _extract_name_from_path(self, path: str) -> str:
        """Extract package name from path like 'node_modules/foo'."""
        if path.startswith("node_modules/"):
            path = path[13:]

        # Handle scoped packages
        if path.startswith("@"):
            parts = path.split("/")
            return "/".join(parts[:2])

        return path.split("/")[0]


class YarnLockParser(LockfileParser):
    """Parser for yarn.lock files."""

    def can_parse(self, content: str) -> bool:
        """Check if content looks like yarn.lock."""
        return "yarn.lock" in content[:100] or content.strip().startswith("#")

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse yarn.lock content."""
        deps = []
        current_package = None
        current_version = None
        current_info = {}

        lines = content.strip().split('\n')

        for line in lines:
            line = line.rstrip()

            # Package header line
            if line and not line.startswith(" ") and not line.startswith("#"):
                # Save previous package
                if current_package:
                    deps.append(ParsedDependency(
                        name=current_package,
                        version=current_version,
                        source="npm",
                        resolved_url=current_info.get("resolved"),
                        checksum=current_info.get("integrity"),
                        dependencies=[d.strip() for d in current_info.get("dependencies", "").split(",") if d.strip()],
                    ))

                # Parse new package header
                if "@" in line and line.count("@") >= 2:
                    # Scoped package
                    match = re.match(r'(@[^/]+/[^@]+)@([^\s,]+)', line)
                    if match:
                        current_package = match.group(1)
                        current_version = match.group(2)
                else:
                    # Regular package
                    match = re.match(r'([^@]+)@([^\s,]+)', line)
                    if match:
                        current_package = match.group(1)
                        current_version = match.group(2)

                current_info = {}

            # Property lines
            elif current_package and line.strip():
                if line.startswith("resolved "):
                    current_info["resolved"] = line[9:].strip().strip('"')
                elif line.startswith("integrity "):
                    current_info["integrity"] = line[10:].strip()
                elif line.startswith("dependencies "):
                    current_info["dependencies"] = line[14:].strip()

        # Don't forget the last package
        if current_package:
            deps.append(ParsedDependency(
                name=current_package,
                version=current_version,
                source="npm",
                resolved_url=current_info.get("resolved"),
                checksum=current_info.get("integrity"),
                dependencies=[d.strip() for d in current_info.get("dependencies", "").split(",") if d.strip()],
            ))

        return deps

    def get_ecosystem(self) -> str:
        return "npm"


class GoSumParser(LockfileParser):
    """Parser for go.sum files."""

    def can_parse(self, content: str) -> bool:
        """Check if content looks like go.sum."""
        lines = content.strip().split('\n')
        if not lines:
            return False

        # go.sum format: module version hash
        pattern = re.compile(r'^[\w\-\./]+\s+v?\d+\.\d+\.\d+[\s\-]')
        return bool(pattern.match(lines[0]))

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse go.sum content."""
        deps = []
        seen = set()  # Avoid duplicates from go.sum

        for line in content.strip().split('\n'):
            if not line.strip() or line.startswith("#"):
                continue

            parts = line.split()
            if len(parts) >= 2:
                module = parts[0]
                version = parts[1]

                key = f"{module}@{version}"
                if key in seen:
                    continue
                seen.add(key)

                deps.append(ParsedDependency(
                    name=module,
                    version=version,
                    source="go",
                ))

        return deps

    def get_ecosystem(self) -> str:
        return "go"


class CargoLockParser(LockfileParser):
    """Parser for Cargo.lock files."""

    def can_parse(self, content: str) -> bool:
        """Check if content is Cargo.lock format."""
        return "[[package]]" in content

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse Cargo.lock content."""
        deps = []
        current_package = None
        current_version = None
        current_source = None

        in_package = False
        lines = content.strip().split('\n')

        for line in lines:
            line = line.rstrip()

            if line == "[[package]]":
                in_package = True
                current_package = None
                current_version = None
                current_source = None

            elif in_package:
                if line.startswith("name = "):
                    current_package = line[7:].strip().strip('"')
                elif line.startswith("version = "):
                    current_version = line[10:].strip().strip('"')
                elif line.startswith("source = "):
                    current_source = line[9:].strip().strip('"')

                # End of package definition
                elif line.startswith("["):
                    if current_package and current_version:
                        deps.append(ParsedDependency(
                            name=current_package,
                            version=current_version,
                            source=current_source or "crates.io",
                        ))
                    in_package = False

        # Don't forget the last package
        if current_package and current_version:
            deps.append(ParsedDependency(
                name=current_package,
                version=current_version,
                source=current_source or "crates.io",
            ))

        return deps

    def get_ecosystem(self) -> str:
        return "cargo"


class ComposerLockParser(LockfileParser):
    """Parser for composer.lock files."""

    def can_parse(self, content: str) -> bool:
        """Check if content is composer.lock format."""
        try:
            data = json.loads(content)
            return "packages" in data or "packages-dev" in data
        except json.JSONDecodeError:
            return False

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse composer.lock content."""
        deps = []
        data = json.loads(content)

        all_packages = data.get("packages", []) + data.get("packages-dev", [])

        for pkg in all_packages:
            name = pkg.get("name", "unknown")
            version = pkg.get("version", "unknown")

            dep = ParsedDependency(
                name=name,
                version=version.lstrip("v"),  # Normalize v prefix
                source="packagist",
                resolved_url=pkg.get("dist", {}).get("url"),
                checksum=pkg.get("dist", {}).get("reference"),
            )

            # Add dependencies
            if "require" in pkg:
                dep.dependencies = list(pkg["require"].keys())

            # Mark dev dependencies
            dep.is_dev = pkg.get("extra", {}).get("branch-alias", {}).get("dev-master") is not None

            deps.append(dep)

        return deps

    def get_ecosystem(self) -> str:
        return "composer"


class PomXmlParser(LockfileParser):
    """Parser for Maven pom.xml files."""

    def can_parse(self, content: str) -> bool:
        """Check if content is pom.xml format."""
        return "<project" in content or "<dependency" in content

    def parse(self, content: str) -> List[ParsedDependency]:
        """Parse pom.xml content (simplified)."""
        deps = []

        # Simple regex-based parsing
        dep_pattern = re.compile(
            r'<groupId>([^<]+)</groupId>\s*<artifactId>([^<]+)</artifactId>\s*(?:<version>([^<]+)</version>)?',
            re.MULTILINE
        )

        for match in dep_pattern.finditer(content):
            group_id = match.group(1)
            artifact_id = match.group(2)
            version = match.group(3) or "unknown"

            name = f"{group_id}:{artifact_id}"
            deps.append(ParsedDependency(
                name=name,
                version=version,
                source="maven",
            ))

        return deps

    def get_ecosystem(self) -> str:
        return "maven"


class ParserRegistry:
    """Registry for all lockfile parsers."""

    def __init__(self):
        self.parsers: List[LockfileParser] = []
        self._register_default_parsers()

    def _register_default_parsers(self) -> None:
        """Register all default parsers."""
        self.register(PythonRequirementsParser())
        self.register(PipfileLockParser())
        self.register(PackageLockParser())
        self.register(YarnLockParser())
        self.register(GoSumParser())
        self.register(CargoLockParser())
        self.register(ComposerLockParser())
        self.register(PomXmlParser())

    def register(self, parser: LockfileParser) -> None:
        """Register a parser."""
        self.parsers.append(parser)

    def find_parser(self, content: str) -> Optional[LockfileParser]:
        """Find the best parser for given content."""
        for parser in self.parsers:
            if parser.can_parse(content):
                return parser
        return None

    def parse(self, content: str, ecosystem: Optional[str] = None) -> List[ParsedDependency]:
        """Parse content using appropriate parser."""
        if ecosystem:
            for parser in self.parsers:
                if parser.get_ecosystem() == ecosystem:
                    if parser.can_parse(content):
                        return parser.parse(content)
            return []

        parser = self.find_parser(content)
        if parser:
            return parser.parse(content)

        return []

    def get_supported_ecosystems(self) -> List[str]:
        """Get list of supported ecosystems."""
        return list(set(p.get_ecosystem() for p in self.parsers))


def detect_lockfile_format(filepath: str) -> Optional[str]:
    """Detect lockfile format from filename."""
    filename = filepath.lower()

    if "requirements" in filename and ".txt" in filename:
        return "python"
    if "pipfile.lock" in filename:
        return "python"
    if "package-lock.json" in filename:
        return "npm"
    if "yarn.lock" in filename:
        return "yarn"
    if "go.sum" in filename:
        return "go"
    if "cargo.lock" in filename:
        return "cargo"
    if "composer.lock" in filename:
        return "composer"
    if "pom.xml" in filename:
        return "maven"

    return None


def parse_lockfile(filepath: str, content: Optional[str] = None) -> List[ParsedDependency]:
    """Parse a lockfile from path or content."""
    if content is None:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

    registry = ParserRegistry()
    return registry.parse(content)


def parse_multiple_lockfiles(filepaths: List[str]) -> Dict[str, List[ParsedDependency]]:
    """Parse multiple lockfiles and return results by ecosystem."""
    results = {}

    for filepath in filepaths:
        deps = parse_lockfile(filepath)
        ecosystem = detect_lockfile_format(filepath) or "unknown"

        if ecosystem not in results:
            results[ecosystem] = []

        results[ecosystem].extend(deps)

    return results