"""Advanced caching system for deptrack with TTL, LRU, and disk persistence."""

from __future__ import annotations

import base64
import gzip
import hashlib
import json
import os
import pickle
import threading
import time
from abc import ABC, abstractmethod
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Generic, TypeVar, cast

T = TypeVar("T")

DEFAULT_CACHE_DIR = Path.home() / ".cache" / "deptrack"
DEFAULT_TTL = 3600  # 1 hour


@dataclass
class CacheEntry(Generic[T]):
    """A single cache entry with metadata."""

    key: str
    value: T
    created_at: float
    accessed_at: float
    access_count: int = 0
    size_bytes: int = 0
    compressed: bool = False

    @property
    def age_seconds(self) -> float:
        """Return the age of this entry in seconds."""
        return time.time() - self.created_at

    @property
    def is_expired(self) -> bool:
        """Return True if this entry has exceeded its TTL."""
        return False  # TTL check is done by the cache

    def touch(self) -> None:
        """Update access time and increment counter."""
        self.accessed_at = time.time()
        self.access_count += 1

    def to_bytes(self) -> bytes:
        """Serialize this entry to bytes for disk storage."""
        data = {
            "key": self.key,
            "value": self.value,
            "created_at": self.created_at,
            "accessed_at": self.accessed_at,
            "access_count": self.access_count,
            "size_bytes": self.size_bytes,
            "compressed": self.compressed,
        }
        return pickle.dumps(data)

    @classmethod
    def from_bytes(cls, data: bytes) -> "CacheEntry":
        """Deserialize entry from bytes."""
        obj = pickle.loads(data)
        entry = cls(
            key=obj["key"],
            value=obj["value"],
            created_at=obj["created_at"],
            accessed_at=obj["accessed_at"],
            access_count=obj["access_count"],
            size_bytes=obj["size_bytes"],
            compressed=obj["compressed"],
        )
        return entry


class CacheBackend(ABC, Generic[T]):
    """Abstract base class for cache backends."""

    @abstractmethod
    def get(self, key: str) -> CacheEntry[T] | None:
        """Get a value from the cache."""
        pass

    @abstractmethod
    def set(self, entry: CacheEntry[T]) -> None:
        """Set a value in the cache."""
        pass

    @abstractmethod
    def delete(self, key: str) -> bool:
        """Delete a key from the cache. Returns True if it existed."""
        pass

    @abstractmethod
    def clear(self) -> None:
        """Clear all entries from the cache."""
        pass

    @abstractmethod
    def keys(self) -> list[str]:
        """Return all keys in the cache."""
        pass

    @abstractmethod
    def size(self) -> int:
        """Return the number of entries in the cache."""
        pass

    @abstractmethod
    def stats(self) -> dict[str, Any]:
        """Return statistics about the cache."""
        pass


class LRUCache(CacheBackend[T]):
    """In-memory LRU cache with optional TTL and size limits."""

    def __init__(
        self,
        max_size: int = 1000,
        ttl: float = DEFAULT_TTL,
        thread_safe: bool = True,
    ) -> None:
        self._max_size = max_size
        self._ttl = ttl
        self._thread_safe = thread_safe
        self._lock = threading.RLock() if thread_safe else _DummyLock()
        self._store: OrderedDict[str, CacheEntry[T]] = OrderedDict()
        self._stats = {
            "hits": 0,
            "misses": 0,
            "evictions": 0,
            "expirations": 0,
            "total_sets": 0,
        }

    def get(self, key: str) -> CacheEntry[T] | None:
        """Get a value from the cache."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._stats["misses"] += 1
                return None

            # Check TTL
            if time.time() - entry.created_at > self._ttl:
                del self._store[key]
                self._stats["expirations"] += 1
                self._stats["misses"] += 1
                return None

            # Move to end (most recently used)
            self._store.move_to_end(key)
            entry.touch()
            self._stats["hits"] += 1
            return entry

    def set(self, entry: CacheEntry[T]) -> None:
        """Set a value in the cache."""
        with self._lock:
            self._stats["total_sets"] += 1

            # If key exists, update it
            if entry.key in self._store:
                self._store[entry.key] = entry
                self._store.move_to_end(entry.key)
                return

            # Evict oldest entries if at capacity
            while len(self._store) >= self._max_size:
                oldest_key = next(iter(self._store))
                del self._store[oldest_key]
                self._stats["evictions"] += 1

            self._store[entry.key] = entry

    def delete(self, key: str) -> bool:
        """Delete a key from the cache."""
        with self._lock:
            if key in self._store:
                del self._store[key]
                return True
            return False

    def clear(self) -> None:
        """Clear all entries from the cache."""
        with self._lock:
            self._store.clear()
            self._stats["hits"] = 0
            self._stats["misses"] = 0
            self._stats["evictions"] = 0
            self._stats["expirations"] = 0
            self._stats["total_sets"] = 0

    def keys(self) -> list[str]:
        """Return all keys in the cache."""
        with self._lock:
            return list(self._store.keys())

    def size(self) -> int:
        """Return the number of entries in the cache."""
        with self._lock:
            return len(self._store)

    def stats(self) -> dict[str, Any]:
        """Return statistics about the cache."""
        with self._lock:
            total = self._stats["hits"] + self._stats["misses"]
            hit_rate = (
                self._stats["hits"] / total if total > 0 else 0.0
            )
            return {
                **self._stats,
                "size": len(self._store),
                "max_size": self._max_size,
                "hit_rate": hit_rate,
            }

    def prune_expired(self) -> int:
        """Remove all expired entries. Returns count of removed entries."""
        with self._lock:
            now = time.time()
            expired_keys = [
                k for k, e in self._store.items()
                if now - e.created_at > self._ttl
            ]
            for key in expired_keys:
                del self._store[key]
                self._stats["expirations"] += 1
            return len(expired_keys)


class DiskCache(CacheBackend[T]):
    """Persistent disk-based cache with gzip compression."""

    def __init__(
        self,
        cache_dir: Path | str | None = None,
        ttl: float = DEFAULT_TTL * 24,  # 24 hours default for disk
        compress: bool = True,
        max_size_mb: float = 100.0,
    ) -> None:
        self._cache_dir = Path(cache_dir) if cache_dir else DEFAULT_CACHE_DIR
        self._ttl = ttl
        self._compress = compress
        self._max_size_bytes = int(max_size_mb * 1024 * 1024)
        self._lock = threading.Lock()
        self._memory_index: dict[str, float] = {}

        # Ensure cache directory exists
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._index_file = self._cache_dir / "index.json"
        self._load_index()

    def _load_index(self) -> None:
        """Load the on-disk index of cache entries."""
        if self._index_file.exists():
            try:
                with open(self._index_file, "r", encoding="utf-8") as f:
                    self._memory_index = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._memory_index = {}
        else:
            self._memory_index = {}

    def _save_index(self) -> None:
        """Persist the index to disk."""
        with open(self._index_file, "w", encoding="utf-8") as f:
            json.dump(self._memory_index, f)

    def _entry_path(self, key: str) -> Path:
        """Get the file path for a cache entry."""
        key_hash = hashlib.sha256(key.encode()).hexdigest()[:16]
        return self._cache_dir / f"{key_hash}.cache"

    def get(self, key: str) -> CacheEntry[T] | None:
        """Get a value from the disk cache."""
        with self._lock:
            if key not in self._memory_index:
                return None

            meta = self._memory_index[key]
            if time.time() - meta["created_at"] > self._ttl:
                self._remove_entry(key)
                return None

            path = self._entry_path(key)
            if not path.exists():
                del self._memory_index[key]
                self._save_index()
                return None

            try:
                data = path.read_bytes()
                if meta.get("compressed"):
                    data = gzip.decompress(data)
                entry = CacheEntry.from_bytes(data)
                entry.touch()
                self._memory_index[key]["accessed_at"] = entry.accessed_at
                self._memory_index[key]["access_count"] = entry.access_count
                return entry
            except Exception:
                self._remove_entry(key)
                return None

    def set(self, entry: CacheEntry[T]) -> None:
        """Set a value in the disk cache."""
        with self._lock:
            # Check size limit
            current_size = self._calculate_total_size()
            entry_bytes = entry.to_bytes()
            entry_size = len(entry_bytes)

            if current_size + entry_size > self._max_size_bytes:
                self._evict_oldest(int(entry_size * 1.5))

            # Write to disk
            data = entry_bytes
            if self._compress and entry_size > 1024:
                data = gzip.compress(data)
                entry.compressed = True

            path = self._entry_path(entry.key)
            path.write_bytes(data)

            # Update index
            self._memory_index[entry.key] = {
                "created_at": entry.created_at,
                "accessed_at": entry.accessed_at,
                "access_count": entry.access_count,
                "size_bytes": len(data),
                "compressed": entry.compressed,
            }
            self._save_index()

    def _remove_entry(self, key: str) -> None:
        """Remove a cache entry from disk."""
        path = self._entry_path(key)
        if path.exists():
            path.unlink()
        if key in self._memory_index:
            del self._memory_index[key]

    def delete(self, key: str) -> bool:
        """Delete a key from the cache."""
        with self._lock:
            if key not in self._memory_index:
                return False
            self._remove_entry(key)
            self._save_index()
            return True

    def clear(self) -> None:
        """Clear all entries from the cache."""
        with self._lock:
            for key in list(self._memory_index.keys()):
                self._remove_entry(key)
            self._save_index()

    def keys(self) -> list[str]:
        """Return all keys in the cache."""
        with self._lock:
            return list(self._memory_index.keys())

    def size(self) -> int:
        """Return the number of entries in the cache."""
        with self._lock:
            return len(self._memory_index)

    def _calculate_total_size(self) -> int:
        """Calculate total size of all cache files."""
        return sum(m["size_bytes"] for m in self._memory_index.values())

    def _evict_oldest(self, needed_bytes: int) -> None:
        """Evict oldest entries until we have enough space."""
        # Sort by last access time
        sorted_keys = sorted(
            self._memory_index.keys(),
            key=lambda k: self._memory_index[k].get("accessed_at", 0),
        )

        freed = 0
        for key in sorted_keys:
            if freed >= needed_bytes:
                break
            freed += self._memory_index[key]["size_bytes"]
            self._remove_entry(key)

        self._save_index()

    def stats(self) -> dict[str, Any]:
        """Return statistics about the disk cache."""
        with self._lock:
            total_size = self._calculate_total_size()
            return {
                "entries": len(self._memory_index),
                "total_size_bytes": total_size,
                "total_size_mb": total_size / (1024 * 1024),
                "max_size_mb": self._max_size_bytes / (1024 * 1024),
                "compression": self._compress,
                "ttl_seconds": self._ttl,
            }


class TieredCache(CacheBackend[T]):
    """Multi-tier cache: L1 (memory) + L2 (disk)."""

    def __init__(
        self,
        l1_size: int = 1000,
        l2_dir: Path | str | None = None,
        ttl: float = DEFAULT_TTL,
        thread_safe: bool = True,
    ) -> None:
        self._l1 = LRUCache[T](max_size=l1_size, ttl=ttl, thread_safe=thread_safe)
        self._l2 = DiskCache[T](cache_dir=l2_dir, ttl=ttl * 24)
        self._write_through = True  # Write to both L1 and L2

    def get(self, key: str) -> CacheEntry[T] | None:
        """Get from L1, fall back to L2, promote to L1."""
        entry = self._l1.get(key)
        if entry is not None:
            return entry

        # Try L2
        entry = self._l2.get(key)
        if entry is not None:
            # Promote to L1
            self._l1.set(entry)
            return entry

        return None

    def set(self, entry: CacheEntry[T]) -> None:
        """Write to both tiers."""
        self._l1.set(entry)
        if self._write_through:
            self._l2.set(entry)

    def delete(self, key: str) -> bool:
        """Delete from both tiers."""
        l1_ok = self._l1.delete(key)
        l2_ok = self._l2.delete(key)
        return l1_ok or l2_ok

    def clear(self) -> None:
        """Clear both tiers."""
        self._l1.clear()
        self._l2.clear()

    def keys(self) -> list[str]:
        """Return all keys from both tiers."""
        l1_keys = set(self._l1.keys())
        l2_keys = set(self._l2.keys())
        return list(l1_keys | l2_keys)

    def size(self) -> int:
        """Return total entries across both tiers."""
        return self._l1.size() + self._l2.size()

    def stats(self) -> dict[str, Any]:
        """Return combined statistics."""
        l1_stats = self._l1.stats()
        l2_stats = self._l2.stats()
        return {
            "l1": l1_stats,
            "l2": l2_stats,
            "total_entries": l1_stats["size"] + l2_stats["entries"],
        }

    def invalidate_l1(self) -> None:
        """Clear only L1 cache."""
        self._l1.clear()

    def sync_to_disk(self) -> None:
        """Write all L1 entries to L2."""
        for key in self._l1.keys():
            entry = self._l1.get(key)
            if entry is not None:
                self._l2.set(entry)


class CacheDecorator(Generic[T]):
    """Decorator for adding caching to any function."""

    def __init__(
        self,
        cache: CacheBackend[T],
        key_func: Callable[..., str] | None = None,
        ttl: float | None = None,
    ) -> None:
        self._cache = cache
        self._key_func = key_func or self._default_key_func
        self._ttl = ttl

    @staticmethod
    def _default_key_func(*args: Any, **kwargs: Any) -> str:
        """Generate a cache key from function arguments."""
        key_data = {
            "args": args,
            "kwargs": kwargs,
        }
        serialized = json.dumps(key_data, sort_keys=True, default=str)
        return hashlib.sha256(serialized.encode()).hexdigest()

    def __call__(self, func: Callable[..., T]) -> Callable[..., T]:
        """Wrap a function with caching."""

        def wrapper(*args: Any, **kwargs: Any) -> T:
            # Generate cache key
            key = self._key_func(*args, **kwargs)

            # Check cache
            entry = self._cache.get(key)
            if entry is not None:
                return entry.value

            # Execute function
            result = func(*args, **kwargs)

            # Cache result
            now = time.time()
            cache_entry = CacheEntry(
                key=key,
                value=result,
                created_at=now,
                accessed_at=now,
            )
            self._cache.set(cache_entry)

            return result

        return cast(Callable[..., T], wrapper)

    def invalidate(self, *args: Any, **kwargs: Any) -> bool:
        """Invalidate cache for specific arguments."""
        key = self._key_func(*args, **kwargs)
        return self._cache.delete(key)

    def clear(self) -> None:
        """Clear all cached values."""
        self._cache.clear()


def cached(
    cache: CacheBackend[T],
    key_func: Callable[..., str] | None = None,
) -> CacheDecorator[T]:
    """Decorator factory for creating cached functions."""
    return CacheDecorator(cache=cache, key_func=key_func)


class NullCache(CacheBackend[T]):
    """A no-op cache that always misses."""

    def get(self, key: str) -> None:
        return None

    def set(self, entry: CacheEntry[T]) -> None:
        pass

    def delete(self, key: str) -> bool:
        return False

    def clear(self) -> None:
        pass

    def keys(self) -> list[str]:
        return []

    def size(self) -> int:
        return 0

    def stats(self) -> dict[str, Any]:
        return {"type": "null", "hits": 0, "misses": 0}


class _DummyLock:
    """Dummy lock for single-threaded mode."""

    def __enter__(self) -> None:
        pass

    def __exit__(self, *args: Any) -> None:
        pass


# Global cache instances
_lru_cache: LRUCache | None = None
_disk_cache: DiskCache | None = None
_tiered_cache: TieredCache | None = None
_cache_lock = threading.Lock()


def get_lru_cache(
    max_size: int = 1000,
    ttl: float = DEFAULT_TTL,
) -> LRUCache:
    """Get or create the global LRU cache instance."""
    global _lru_cache
    with _cache_lock:
        if _lru_cache is None:
            _lru_cache = LRUCache(max_size=max_size, ttl=ttl)
        return _lru_cache


def get_disk_cache(
    cache_dir: Path | str | None = None,
    ttl: float = DEFAULT_TTL * 24,
) -> DiskCache:
    """Get or create the global disk cache instance."""
    global _disk_cache
    with _cache_lock:
        if _disk_cache is None:
            _disk_cache = DiskCache(cache_dir=cache_dir, ttl=ttl)
        return _disk_cache


def get_tiered_cache(
    l1_size: int = 1000,
    l2_dir: Path | str | None = None,
    ttl: float = DEFAULT_TTL,
) -> TieredCache:
    """Get or create the global tiered cache instance."""
    global _tiered_cache
    with _cache_lock:
        if _tiered_cache is None:
            _tiered_cache = TieredCache(
                l1_size=l1_size,
                l2_dir=l2_dir,
                ttl=ttl,
            )
        return _tiered_cache


def clear_all_caches() -> None:
    """Clear all global cache instances."""
    global _lru_cache, _disk_cache, _tiered_cache
    with _cache_lock:
        if _lru_cache:
            _lru_cache.clear()
        if _disk_cache:
            _disk_cache.clear()
        if _tiered_cache:
            _tiered_cache.clear()