"""SBOM (Software Bill of Materials) generation and export."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Any

from deptrack.models import Dependency


class SBOMFormat(Enum):
    """Supported SBOM formats."""

    SPDX_2_2 = "spdx_2.2"
    SPDX_2_3 = "spdx_2.3"
    CYCLONEDX_1_4 = "cyclonedx_1.4"
    CYCLONEDX_1_5 = "cyclonedx_1.5"
    CYCLONEDX_1_6 = "cyclonedx_1.6"
    JSON = "json"
    TEXT = "text"


class SBOMType(Enum):
    """Type of SBOM."""

    LIBRARY = "library"
    APPLICATION = "application"
    FRAMEWORK = "framework"
    CONTAINER = "container"
    OPERATING_SYSTEM = "operating-system"
    DEVICE = "device"
    FIRMWARE = "firmware"
    FILE = "file"


@dataclass
class SBOMComponent:
    """A component in an SBOM."""

    name: str
    version: str = "unknown"
    package_type: str = "library"
    supplier: str | None = None
    supplier_url: str | None = None
    download_location: str | None = None
    license_concluded: str | None = None
    license_declared: str | None = None
    copyright: str | None = None
    description: str | None = None
    homepage: str | None = None
    source_repo: str | None = None
    hashes: dict[str, str] = field(default_factory=dict)
    external_refs: list[dict[str, str]] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    properties: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
            "type": self.package_type,
            "supplier": self.supplier,
            "download_location": self.download_location,
            "license_concluded": self.license_concluded,
            "license_declared": self.license_declared,
            "copyright": self.copyright,
            "description": self.description,
            "homepage": self.homepage,
            "source_repo": self.source_repo,
            "hashes": self.hashes,
            "external_refs": self.external_refs,
            "dependencies": self.dependencies,
            "properties": self.properties,
        }


@dataclass
class SBOMMetadata:
    """Metadata for an SBOM document."""

    document_name: str
    document_namespace: str
    sbom_version: str = "1.0"
    sbom_type: SBOMType = SBOMType.LIBRARY
    creator: str = "deptrack"
    created_date: datetime = field(default_factory=datetime.now)
    license: str = "CC0-1.0"
    comment: str | None = None
    tools: list[str] = field(default_factory=lambda: ["deptrack"])

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_name": self.document_name,
            "document_namespace": self.document_namespace,
            "sbom_version": self.sbom_version,
            "sbom_type": self.sbom_type.value,
            "creator": self.creator,
            "created_date": self.created_date.isoformat(),
            "license": self.license,
            "comment": self.comment,
            "tools": self.tools,
        }


@dataclass
class SBOM:
    """Software Bill of Materials document."""

    metadata: SBOMMetadata
    components: list[SBOMComponent] = field(default_factory=list)

    def add_component(self, component: SBOMComponent) -> None:
        """Add a component to the SBOM."""
        self.components.append(component)

    def add_dependency(
        self,
        component_name: str,
        dependency_name: str,
    ) -> None:
        """Add a dependency relationship."""
        for comp in self.components:
            if comp.name == component_name:
                if dependency_name not in comp.dependencies:
                    comp.dependencies.append(dependency_name)
                break

    def get_component(self, name: str) -> SBOMComponent | None:
        """Get a component by name."""
        for comp in self.components:
            if comp.name == name:
                return comp
        return None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "metadata": self.metadata.to_dict(),
            "components": [c.to_dict() for c in self.components],
            "total_components": len(self.components),
        }


class SBOMGenerator:
    """Generator for SBOM documents."""

    def __init__(self) -> None:
        self._components: dict[str, SBOMComponent] = {}
        self._metadata: SBOMMetadata | None = None

    def set_metadata(
        self,
        name: str,
        namespace: str,
        sbom_type: SBOMType = SBOMType.LIBRARY,
    ) -> None:
        """Set SBOM metadata."""
        self._metadata = SBOMMetadata(
            document_name=name,
            document_namespace=namespace,
            sbom_type=sbom_type,
        )

    def add_package(
        self,
        name: str,
        version: str | None = None,
        ecosystem: str = "pypi",
        license_info: str | None = None,
        description: str | None = None,
        homepage: str | None = None,
        source_url: str | None = None,
        dependencies: list[str] | None = None,
        properties: dict[str, str] | None = None,
    ) -> None:
        """Add a package to the SBOM."""
        comp = SBOMComponent(
            name=name,
            version=version or "unknown",
            package_type=self._map_ecosystem_to_type(ecosystem),
            license_concluded=license_info,
            description=description,
            homepage=homepage,
            source_repo=source_url,
            dependencies=dependencies or [],
            properties=properties or {},
        )

        # Map ecosystem to package type
        if ecosystem == "npm":
            comp.package_type = "npm"
        elif ecosystem == "maven":
            comp.package_type = "maven"

        self._components[name] = comp

    def add_from_dependency(self, dep: Dependency) -> None:
        """Add a dependency to the SBOM."""
        self._components[dep.name] = SBOMComponent(
            name=dep.name,
            version=dep.version or "unknown",
            package_type="library",
            license_concluded=dep.markers,  # Use markers field for license
        )

    def build(self) -> SBOM:
        """Build the SBOM document."""
        if self._metadata is None:
            self._metadata = SBOMMetadata(
                document_name="Generated SBOM",
                document_namespace="https://example.com/sbom",
            )

        sbom = SBOM(metadata=self._metadata)

        for comp in self._components.values():
            sbom.add_component(comp)

        return sbom

    @staticmethod
    def _map_ecosystem_to_type(ecosystem: str) -> str:
        """Map ecosystem to SBOM package type."""
        mapping = {
            "pypi": "pypi",
            "npm": "npm",
            "maven": "maven",
            "go": "golang",
            "cargo": "cargo",
            "rubygems": "rubygems",
            "packagist": "packagist",
            "nuget": "nuget",
        }
        return mapping.get(ecosystem, "library")


class SPDXGenerator:
    """Generator for SPDX format SBOMs."""

    VERSION = "SPDX-2.3"

    def generate(self, sbom: SBOM) -> str:
        """Generate SPDX SBOM in tag-value format."""
        lines = []
        doc = sbom.metadata

        # Document header
        lines.append(f"SPDXVersion: {self.VERSION}")
        lines.append(f"DataLicense: {doc.license}")
        lines.append(f"SPDXID: {doc.document_namespace}/#{doc.document_name}")
        lines.append(f"DocumentName: {doc.document_name}")
        lines.append(f"DocumentNamespace: {doc.document_namespace}")
        lines.append(f"Creator: Tool: {doc.creator}")
        lines.append(f"Created: {doc.created_date.strftime('%Y-%m-%dT%H:%M:%SZ')}")
        lines.append("")

        # Package information
        for comp in sbom.components:
            lines.append(f"PackageName: {comp.name}")
            lines.append(f"SPDXID: {doc.document_namespace}/#{comp.name}")
            lines.append(f"PackageVersion: {comp.version}")

            if comp.supplier:
                lines.append(f"PackageSupplier: Organization: {comp.supplier}")

            if comp.download_location:
                lines.append(f"PackageDownloadLocation: {comp.download_location}")
            else:
                lines.append("PackageDownloadLocation: NOASSERTION")

            if comp.files_analyzed:
                lines.append(f"FilesAnalyzed: {'true' if comp.files_analyzed else 'false'}")
            else:
                lines.append("FilesAnalyzed: false")

            lines.append(f"PackageVerificationCode: {comp.verification_code or '0' * 40} ( Calculated)")

            if comp.license_concluded:
                lines.append(f"PackageLicenseConcluded: {comp.license_concluded}")
            else:
                lines.append("PackageLicenseConcluded: NOASSERTION")

            lines.append("PackageLicenseDeclared: NOASSERTION")
            lines.append(f"PackageCopyrightText: {comp.copyright or 'NOASSERTION'}")

            if comp.description:
                lines.append(f"PackageComment: {comp.description}")

            lines.append("")

        # Relationships
        for comp in sbom.components:
            lines.append(f"Relationship: {doc.document_namespace}/#{doc.document_name} DESCRIBES {doc.document_namespace}/#{comp.name}")

            for dep in comp.dependencies:
                lines.append(f"Relationship: {doc.document_namespace}/#{comp.name} DEPENDENCY_OF {doc.document_namespace}/#{dep}")

        return "\n".join(lines)


class SPDXJsonGenerator:
    """Generator for SPDX JSON format."""

    VERSION = "SPDX-2.3"

    def generate(self, sbom: SBOM) -> str:
        """Generate SPDX SBOM in JSON format."""
        doc = sbom.metadata

        spdx_doc = {
            "spdxVersion": self.VERSION,
            "dataLicense": doc.license,
            "SPDXID": f"{doc.document_namespace}/#{doc.document_name}",
            "name": doc.document_name,
            "documentNamespace": doc.document_namespace,
            "creationInfo": {
                "created": doc.created_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "creators": [f"Tool: {doc.creator}"],
            },
            "packages": [],
            "relationships": [],
        }

        # Packages
        for comp in sbom.components:
            pkg = {
                "name": comp.name,
                "SPDXID": f"{doc.document_namespace}/#{comp.name}",
                "versionInfo": comp.version,
                "downloadLocation": comp.download_location or "NOASSERTION",
                "filesAnalyzed": False,
                "licenseConcluded": comp.license_concluded or "NOASSERTION",
                "licenseDeclared": "NOASSERTION",
                "copyrightText": comp.copyright or "NOASSERTION",
            }

            if comp.supplier:
                pkg["supplier"] = f"Organization: {comp.supplier}"

            if comp.hashes:
                pkg["checksums"] = [
                    {"algorithm": algo.upper(), "value": value}
                    for algo, value in comp.hashes.items()
                ]

            spdx_doc["packages"].append(pkg)

        # Relationships
        for comp in sbom.components:
            spdx_doc["relationships"].append({
                "spdxElementId": f"{doc.document_namespace}/#{doc.document_name}",
                "relationshipType": "DESCRIBES",
                "relatedSpdxElement": f"{doc.document_namespace}/#{comp.name}",
            })

            for dep in comp.dependencies:
                spdx_doc["relationships"].append({
                    "spdxElementId": f"{doc.document_namespace}/#{comp.name}",
                    "relationshipType": "DEPENDENCY_OF",
                    "relatedSpdxElement": f"{doc.document_namespace}/#{dep}",
                })

        return json.dumps(spdx_doc, indent=2)


class CycloneDXGenerator:
    """Generator for CycloneDX format SBOMs."""

    def __init__(self, version: str = "1.5") -> None:
        self.version = version

    def generate(self, sbom: SBOM) -> str:
        """Generate CycloneDX SBOM."""
        doc = sbom.metadata

        if self.version.startswith("1."):
            return self._generate_v1(sbom)
        return self._generate_v1(sbom)  # Default to v1

    def _generate_v1(self, sbom: SBOM) -> str:
        """Generate CycloneDX v1.x format."""
        doc = sbom.metadata

        cbom = {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "version": 1,
            "metadata": {
                "timestamp": doc.created_date.isoformat(),
                "tools": [
                    {"name": "deptrack", "version": "0.4.0"}
                ],
                "component": {
                    "type": doc.sbom_type.value,
                    "name": doc.document_name,
                    "version": doc.sbom_version,
                },
            },
            "components": [],
        }

        for comp in sbom.components:
            component = {
                "type": comp.package_type,
                "name": comp.name,
                "version": comp.version,
            }

            if comp.group:
                component["group"] = comp.group

            if comp.license_concluded:
                component["license"] = {"id": comp.license_concluded}

            if comp.purl:
                component["purl"] = comp.purl

            if comp.hashes:
                component["hashes"] = [
                    {"alg": algo.upper(), "content": value}
                    for algo, value in comp.hashes.items()
                ]

            if comp.external_refs:
                component["externalReferences"] = [
                    {"type": ref_type, "url": ref_url}
                    for ref_type, ref_url in comp.external_refs
                ]

            if comp.properties:
                component["properties"] = [
                    {"name": k, "value": v}
                    for k, v in comp.properties.items()
                ]

            cbom["components"].append(component)

        return json.dumps(cbom, indent=2)


class SBOMExporter:
    """Export SBOM to various formats."""

    def __init__(self) -> None:
        self._generators = {
            SBOMFormat.SPDX_2_2: SPDXGenerator(),
            SBOMFormat.SPDX_2_3: SPDXGenerator(),
            SBOMFormat.SPDX_2_3: SPDXJsonGenerator(),
            SBOMFormat.CYCLONEDX_1_4: CycloneDXGenerator("1.4"),
            SBOMFormat.CYCLONEDX_1_5: CycloneDXGenerator("1.5"),
            SBOMFormat.CYCLONEDX_1_6: CycloneDXGenerator("1.6"),
        }

    def export(
        self,
        sbom: SBOM,
        format: SBOMFormat,
    ) -> str:
        """Export SBOM to specified format."""
        if format == SBOMFormat.JSON:
            return json.dumps(sbom.to_dict(), indent=2)

        generator = self._generators.get(format)
        if generator:
            return generator.generate(sbom)

        # Default JSON
        return json.dumps(sbom.to_dict(), indent=2)

    def save(
        self,
        sbom: SBOM,
        path: Path,
        format: SBOMFormat = SBOMFormat.CYCLONEDX_1_5,
    ) -> None:
        """Save SBOM to file."""
        content = self.export(sbom, format)

        # Set appropriate extension
        if path.suffix == ".json":
            pass  # Already correct
        elif path.suffix == ".xml":
            pass  # SPDX tag-value format
        else:
            path = path.with_suffix(".json")

        path.write_text(content, encoding="utf-8")


def create_sbom_from_dependencies(
    dependencies: list[Dependency],
    name: str,
    namespace: str,
    format: SBOMFormat = SBOMFormat.CYCLONEDX_1_5,
) -> SBOM:
    """Create an SBOM from a list of dependencies."""
    generator = SBOMGenerator()
    generator.set_metadata(name, namespace)

    for dep in dependencies:
        generator.add_from_dependency(dep)

    return generator.build()


def export_sbom(
    sbom: SBOM,
    output_path: Path,
    format: SBOMFormat = SBOMFormat.CYCLONEDX_1_5,
) -> None:
    """Export SBOM to file."""
    exporter = SBOMExporter()
    exporter.save(sbom, output_path, format)


# CycloneDX purl utilities
def create_purl(
    ecosystem: str,
    name: str,
    version: str | None = None,
    subpath: str | None = None,
    qualifiers: dict[str, str] | None = None,
) -> str:
    """Create a Package URL (purl) per spec."""
    # Standard purl format: pkg:ecosystem/name@version?qualifiers#subpath
    parts = [f"pkg:{ecosystem}/{name}"]

    if version:
        parts.append(f"@{version}")

    if qualifiers:
        qs = "&".join(f"{k}={v}" for k, v in qualifiers.items())
        parts.append(f"?{qs}")

    if subpath:
        parts.append(f"#{subpath}")

    return "".join(parts)


def parse_purl(purl: str) -> dict[str, str | None]:
    """Parse a Package URL into components."""
    # Simple parser for purl
    result = {
        "type": None,
        "namespace": None,
        "name": None,
        "version": None,
        "subpath": None,
        "qualifiers": {},
    }

    # Remove scheme
    if purl.startswith("pkg:"):
        purl = purl[4:]

    # Split at @
    if "@" in purl:
        main, version = purl.split("@", 1)
        result["version"] = version
    else:
        main = purl

    # Split at ?
    if "?" in main:
        main, qual_str = main.split("?", 1)
        for q in qual_str.split("&"):
            if "=" in q:
                k, v = q.split("=", 1)
                result["qualifiers"][k] = v

    # Split at #
    if "#" in main:
        main, subpath = main.split("#", 1)
        result["subpath"] = subpath

    # Split at first /
    if "/" in main:
        ecosystem, name = main.split("/", 1)
        result["type"] = ecosystem
        result["name"] = name
    else:
        result["name"] = main

    return result