"""Core audit engine — orchestrates parsing, checking, and reporting."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

from deptrack.checkers import (
    check_duplicates,
    check_missing_upper_bound,
    check_name_variants,
    check_unpinned,
    check_vulnerabilities,
    check_wildcard,
)
from deptrack.models import AuditResult, Dependency, DepSource
from deptrack.parsers import parse_pyproject, parse_requirements


def _parse_file(path: Path) -> list[Dependency]:
    """Dispatch to the correct parser based on filename.

    Returns an empty list for unrecognised file types rather than raising.
    """
    name = path.name.lower()
    if name == "pyproject.toml":
        return list(parse_pyproject(path))
    if "requirements" in name and name.endswith(".txt"):
        return list(parse_requirements(path))
    return []


def run_audit(
    paths: Sequence[Path | str],
    check_vuln: bool = True,
    check_pins: bool = True,
    advisory_db: Path | None = None,
) -> AuditResult:
    """
    Run a full dependency audit across one or more dependency files.

    Parameters
    ----------
    paths:
        One or more paths to requirements.txt / pyproject.toml files.
    check_vuln:
        Whether to check for known vulnerabilities.
    check_pins:
        Whether to check version pinning / constraints.
    advisory_db:
        Optional path to an external JSON advisory database.

    Returns
    -------
    AuditResult with all discovered dependencies and issues.
    """
    result = AuditResult()

    all_deps: list[Dependency] = []
    for raw_path in paths:
        path = Path(raw_path)
        if not path.exists():
            raise FileNotFoundError(f"Dependency file not found: {path}")
        deps = _parse_file(path)
        all_deps.extend(deps)
        result.source_files.append(str(path))

    result.dependencies = all_deps

    # Run checkers
    check_duplicates(all_deps, result)
    check_name_variants(all_deps, result)

    if check_pins:
        check_unpinned(all_deps, result)
        check_wildcard(all_deps, result)
        check_missing_upper_bound(all_deps, result)

    if check_vuln:
        check_vulnerabilities(all_deps, result, extra_db=advisory_db)

    return result


def audit_directory(
    root: Path,
    check_vuln: bool = True,
    check_pins: bool = True,
) -> AuditResult:
    """Discover and audit all dependency files under a directory."""
    from deptrack.utils.helpers import discover_dep_files

    paths = list(discover_dep_files(root))
    if not paths:
        raise FileNotFoundError(f"No dependency files found under {root}")
    return run_audit(paths, check_vuln=check_vuln, check_pins=check_pins)


def run_audit_with_config(
    paths: Sequence[Path | str],
    config: "DeptrackConfig | None" = None,
) -> AuditResult:
    """
    Run a full audit using a DeptrackConfig object.

    This is the recommended entry point for programmatic use — it respects
    all settings in the config (ignore lists, enabled checkers, etc.).
    """
    from deptrack.config import DeptrackConfig

    cfg = config or DeptrackConfig()

    result = run_audit(
        paths,
        check_vuln=cfg.check_vulnerabilities,
        check_pins=cfg.check_unpinned or cfg.check_wildcard or cfg.check_missing_upper_bound,
    )

    # Apply ignore_packages filter
    if cfg.ignore_packages:
        ignore_set = {Dependency.normalize_name(n) for n in cfg.ignore_packages}
        result.issues = [
            i for i in result.issues
            if i.dep.canonical_name not in ignore_set
        ]

    # Apply ignore_kinds filter
    if cfg.ignore_kinds:
        ignore_kinds = set(cfg.ignore_kinds)
        result.issues = [i for i in result.issues if i.kind not in ignore_kinds]

    return result


def audit_files_from_config(config: "DeptrackConfig", root: Path) -> AuditResult:
    """
    Discover and audit dependency files from a root directory,
    excluding any paths listed in config.exclude_paths.
    """
    from deptrack.config import DeptrackConfig
    from deptrack.utils.helpers import discover_dep_files

    all_paths = list(discover_dep_files(root))
    if config.exclude_paths:
        excluded = {Path(p) for p in config.exclude_paths}
        all_paths = [p for p in all_paths if p not in excluded]

    if not all_paths:
        raise FileNotFoundError(f"No dependency files found under {root}")

    return run_audit_with_config(all_paths, config=config)


def compare_audits(before: AuditResult, after: AuditResult) -> dict:
    """
    Compare two AuditResult objects and return a diff of issues.

    Useful for CI — detect newly introduced issues between two states.
    """
    def issue_key(issue) -> tuple:
        return (issue.dep.canonical_name, issue.kind, issue.message)

    before_keys = {issue_key(i) for i in before.issues}
    after_keys = {issue_key(i) for i in after.issues}

    new_issues = [i for i in after.issues if issue_key(i) not in before_keys]
    resolved_issues = [i for i in before.issues if issue_key(i) not in after_keys]

    return {
        "new_issues": [i.to_dict() for i in new_issues],
        "resolved_issues": [i.to_dict() for i in resolved_issues],
        "new_count": len(new_issues),
        "resolved_count": len(resolved_issues),
        "regression": len(new_issues) > 0,
    }


def filter_issues_by_severity(result: AuditResult, min_severity: str) -> AuditResult:
    """
    Return a new AuditResult with only issues at or above `min_severity`.

    Parameters
    ----------
    result:
        The original AuditResult.
    min_severity:
        One of 'low', 'medium', 'high', 'critical'.
    """
    from deptrack.models import Severity

    order = [Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]
    try:
        threshold = next(s for s in order if s.value == min_severity.lower())
    except StopIteration:
        raise ValueError(f"Unknown severity: {min_severity!r}")

    threshold_idx = order.index(threshold)
    filtered = AuditResult(
        dependencies=result.dependencies,
        source_files=result.source_files,
        issues=[
            i for i in result.issues
            if order.index(i.severity) >= threshold_idx
        ],
    )
    return filtered
