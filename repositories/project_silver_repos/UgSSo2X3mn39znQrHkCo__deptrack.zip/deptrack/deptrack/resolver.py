"""
Dependency version conflict resolver.

Attempts to find a compatible set of versions across all declared
dependencies, detecting conflicts where constraints are mutually exclusive.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterator

from deptrack.models import Dependency, VersionSpec


@dataclass
class VersionRange:
    """
    Represents the intersection of all version constraints on a single package.

    Tracks lower bounds, upper bounds, exact pins, and exclusions separately
    so conflicts can be reported with maximum clarity.
    """

    package: str
    lower_bound: tuple[int, ...] | None = None
    lower_inclusive: bool = True
    upper_bound: tuple[int, ...] | None = None
    upper_inclusive: bool = False
    exact_pins: list[tuple[int, ...]] = field(default_factory=list)
    exclusions: list[tuple[int, ...]] = field(default_factory=list)
    raw_specs: list[str] = field(default_factory=list)

    def is_satisfiable(self) -> bool:
        """Return False if constraints are self-contradictory."""
        # Multiple conflicting exact pins
        if len(self.exact_pins) > 1 and len(set(self.exact_pins)) > 1:
            return False
        # Exact pin excluded
        for pin in self.exact_pins:
            if pin in self.exclusions:
                return False
        # Lower > upper
        if self.lower_bound and self.upper_bound:
            if self.lower_bound > self.upper_bound:
                return False
            if self.lower_bound == self.upper_bound:
                if not self.lower_inclusive or not self.upper_inclusive:
                    return False
        return True

    def conflict_reason(self) -> str | None:
        """Return a human-readable reason if not satisfiable, else None."""
        if len(self.exact_pins) > 1 and len(set(self.exact_pins)) > 1:
            pins = [".".join(str(p) for p in pin) for pin in self.exact_pins]
            return f"Conflicting exact pins: {pins}"
        for pin in self.exact_pins:
            if pin in self.exclusions:
                pin_str = ".".join(str(p) for p in pin)
                return f"Version {pin_str} is both required (==) and excluded (!=)"
        if self.lower_bound and self.upper_bound:
            if self.lower_bound > self.upper_bound:
                lo = ".".join(str(p) for p in self.lower_bound)
                hi = ".".join(str(p) for p in self.upper_bound)
                return f"Lower bound {lo} exceeds upper bound {hi}"
        return None

    def add_spec(self, spec_str: str) -> None:
        """Ingest a version specifier string into this range."""
        self.raw_specs.append(spec_str)
        spec = VersionSpec.parse(spec_str)
        if spec is None:
            return
        vt = spec.version_tuple
        op = spec.operator
        if op == "==":
            self.exact_pins.append(vt)
        elif op == "!=":
            self.exclusions.append(vt)
        elif op in (">", ">="):
            inclusive = op == ">="
            if self.lower_bound is None or vt > self.lower_bound:
                self.lower_bound = vt
                self.lower_inclusive = inclusive
        elif op in ("<", "<="):
            inclusive = op == "<="
            if self.upper_bound is None or vt < self.upper_bound:
                self.upper_bound = vt
                self.upper_inclusive = inclusive

    def summary(self) -> str:
        parts = self.raw_specs or ["(unconstrained)"]
        return ", ".join(parts)


class ConflictError(Exception):
    """Raised when dependency constraints cannot be resolved."""

    def __init__(self, package: str, reason: str) -> None:
        self.package = package
        self.reason = reason
        super().__init__(f"Conflict for '{package}': {reason}")


@dataclass
class ResolverResult:
    """Output of the resolver."""

    ranges: dict[str, VersionRange] = field(default_factory=dict)
    conflicts: list[ConflictError] = field(default_factory=list)

    @property
    def has_conflicts(self) -> bool:
        return bool(self.conflicts)

    def conflict_packages(self) -> list[str]:
        return [c.package for c in self.conflicts]

    def to_dict(self) -> dict:
        return {
            "conflicts": [
                {"package": c.package, "reason": c.reason}
                for c in self.conflicts
            ],
            "ranges": {
                name: r.summary()
                for name, r in self.ranges.items()
            },
        }


class DependencyResolver:
    """
    Simple version constraint resolver.

    Collects all version specs for each package across all dependency files
    and checks whether the combined constraints are satisfiable.

    This is not a full SAT-based resolver (like pip's) — it checks
    single-package satisfiability only, without transitive graph resolution.
    """

    def __init__(self) -> None:
        self._ranges: dict[str, VersionRange] = {}

    def add_dependency(self, dep: Dependency) -> None:
        """Register a dependency's version constraint."""
        name = dep.canonical_name
        if name not in self._ranges:
            self._ranges[name] = VersionRange(package=name)

        if dep.version:
            # A version string may contain multiple comma-separated specs
            for spec_str in self._split_specs(dep.version):
                self._ranges[name].add_spec(spec_str.strip())

    def _split_specs(self, version_str: str) -> list[str]:
        """Split a multi-spec version string like '>=1.0,<2.0' into parts."""
        return [s.strip() for s in version_str.split(",") if s.strip()]

    def resolve(self) -> ResolverResult:
        """
        Check all collected constraints for satisfiability.

        Returns a ResolverResult describing any conflicts found.
        """
        result = ResolverResult(ranges=dict(self._ranges))
        for name, vrange in self._ranges.items():
            if not vrange.is_satisfiable():
                reason = vrange.conflict_reason() or "Unsatisfiable constraints"
                result.conflicts.append(ConflictError(name, reason))
        return result

    def packages(self) -> list[str]:
        return list(self._ranges.keys())

    def range_for(self, name: str) -> VersionRange | None:
        return self._ranges.get(Dependency.normalize_name(name))


def resolve_dependencies(deps: list[Dependency]) -> ResolverResult:
    """
    Convenience function: resolve a list of dependencies and return results.

    Parameters
    ----------
    deps:
        List of Dependency objects (may include duplicates with different specs).

    Returns
    -------
    ResolverResult with any detected conflicts.
    """
    resolver = DependencyResolver()
    for dep in deps:
        resolver.add_dependency(dep)
    return resolver.resolve()


def check_conflicts_via_resolver(
    deps: list[Dependency],
    result: "AuditResult",  # noqa: F821
) -> None:
    """
    Run the resolver and add any conflicts as HIGH issues to result.

    This is a checker-style wrapper around resolve_dependencies for use
    in the audit pipeline.
    """
    from deptrack.models import Issue, Severity

    resolver_result = resolve_dependencies(deps)
    dep_map = {d.canonical_name: d for d in deps}

    for conflict in resolver_result.conflicts:
        dep = dep_map.get(conflict.package, Dependency(name=conflict.package))
        result.issues.append(
            Issue(
                dep=dep,
                kind="version_conflict",
                message=(
                    f"Version constraints for '{conflict.package}' cannot be satisfied: "
                    f"{conflict.reason}"
                ),
                severity=Severity.HIGH,
                fix_suggestion=(
                    f"Reconcile the conflicting constraints for '{conflict.package}'. "
                    f"Current constraints: "
                    f"{resolver_result.ranges[conflict.package].summary()}"
                ),
            )
        )
