"""deptrack - Report generators for audit results and analytics."""

import json
import textwrap
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path

from deptrack.models import AuditResult, Dependency, Issue, Severity


class Formatter(ABC):
    """Base class for report formatters."""

    @abstractmethod
    def format(self, data: Dict[str, Any]) -> str:
        """Format data into a string representation."""
        pass

    @abstractmethod
    def format_result(self, result: AuditResult) -> str:
        """Format an audit result."""
        pass


class TextFormatter(Formatter):
    """Plain text formatter for reports."""

    def __init__(self, width: int = 80, indent: str = "  "):
        self.width = width
        self.indent = indent

    def format(self, data: Dict[str, Any]) -> str:
        """Format data as plain text."""
        lines = []

        for key, value in data.items():
            formatted_key = key.replace("_", " ").title()
            if isinstance(value, dict):
                lines.append(f"{formatted_key}:")
                for sub_key, sub_value in value.items():
                    lines.append(f"{self.indent}{sub_key}: {sub_value}")
            elif isinstance(value, list):
                lines.append(f"{formatted_key}:")
                for item in value:
                    lines.append(f"{self.indent}- {item}")
            else:
                lines.append(f"{formatted_key}: {value}")

        return "\n".join(lines)

    def format_result(self, result: AuditResult) -> str:
        """Format an audit result as text."""
        lines = []
        divider = "=" * self.width

        lines.append(divider)
        lines.append("DEPENDENCY AUDIT REPORT".center(self.width))
        lines.append(divider)
        lines.append("")

        # Summary
        lines.append("SUMMARY")
        lines.append("-" * 40)
        lines.append(f"Total Dependencies: {len(result.dependencies)}")
        lines.append(f"Total Issues: {len(result.issues)}")
        lines.append(f"Pass Status: {'PASS' if result.passed else 'FAIL'}")

        if result.duration:
            lines.append(f"Duration: {result.duration:.2f}s")

        lines.append("")

        # Issues by severity
        if result.issues:
            lines.append("ISSUES BY SEVERITY")
            lines.append("-" * 40)

            by_severity = {}
            for issue in result.issues:
                severity = issue.severity.value if hasattr(issue.severity, 'value') else str(issue.severity)
                by_severity[severity] = by_severity.get(severity, 0) + 1

            for severity, count in sorted(by_severity.items(), key=lambda x: self._severity_order(x[0])):
                lines.append(f"  {severity}: {count}")

            lines.append("")

        # Issue details
        if result.issues:
            lines.append("ISSUE DETAILS")
            lines.append("-" * 40)

            for i, issue in enumerate(result.issues, 1):
                lines.append(f"\n{i}. {issue.title}")
                lines.append(f"   Package: {issue.package}")
                lines.append(f"   Severity: {issue.severity.value if hasattr(issue.severity, 'value') else issue.severity}")
                lines.append(f"   Type: {issue.issue_type.value if hasattr(issue.issue_type, 'value') else issue.issue_type}")

                if issue.description:
                    lines.append(f"   Description: {issue.description}")

                if issue.fix_available:
                    lines.append(f"   Fix Available: {issue.fix_available}")

            lines.append("")

        # Dependencies summary
        lines.append("DEPENDENCIES")
        lines.append("-" * 40)

        for dep in result.dependencies:
            version = dep.version or "unknown"
            lines.append(f"  - {dep.name} ({version})")

        lines.append("")
        lines.append(divider)

        return "\n".join(lines)

    def _severity_order(self, severity: str) -> int:
        """Get sort order for severity levels."""
        order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        return order.get(severity.upper(), 5)


class JSONFormatter(Formatter):
    """JSON formatter for reports."""

    def __init__(self, pretty: bool = True, indent: int = 2):
        self.pretty = pretty
        self.indent = indent

    def format(self, data: Dict[str, Any]) -> str:
        """Format data as JSON."""
        if self.pretty:
            return json.dumps(data, indent=self.indent, default=str)
        return json.dumps(data, default=str)

    def format_result(self, result: AuditResult) -> str:
        """Format an audit result as JSON."""
        output = {
            "generated_at": datetime.utcnow().isoformat(),
            "summary": {
                "total_dependencies": len(result.dependencies),
                "total_issues": len(result.issues),
                "passed": result.passed,
                "duration_seconds": result.duration,
            },
            "dependencies": [
                {
                    "name": d.name,
                    "version": d.version,
                    "source": d.source,
                }
                for d in result.dependencies
            ],
            "issues": [
                {
                    "package": i.package,
                    "title": i.title,
                    "severity": i.severity.value if hasattr(i.severity, 'value') else i.severity,
                    "type": i.issue_type.value if hasattr(i.issue_type, 'value') else i.issue_type,
                    "description": i.description,
                    "fix_available": i.fix_available,
                }
                for i in result.issues
            ],
        }

        return self.format(output)


class MarkdownFormatter(Formatter):
    """Markdown formatter for reports."""

    def format(self, data: Dict[str, Any]) -> str:
        """Format data as Markdown."""
        lines = []

        for key, value in data.items():
            formatted_key = key.replace("_", " ").title()
            if isinstance(value, dict):
                lines.append(f"### {formatted_key}")
                lines.append("")
                for sub_key, sub_value in value.items():
                    lines.append(f"- **{sub_key}**: {sub_value}")
                lines.append("")
            elif isinstance(value, list):
                lines.append(f"### {formatted_key}")
                lines.append("")
                for item in value:
                    lines.append(f"- {item}")
                lines.append("")
            else:
                lines.append(f"**{formatted_key}**: {value}")

        return "\n".join(lines)

    def format_result(self, result: AuditResult) -> str:
        """Format an audit result as Markdown."""
        lines = []

        # Header
        lines.append("# Dependency Audit Report")
        lines.append("")
        lines.append(f"**Generated**: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}")
        lines.append("")

        # Summary
        lines.append("## Summary")
        lines.append("")
        lines.append(f"| Metric | Value |")
        lines.append(f"|--------|-------|")
        lines.append(f"| Total Dependencies | {len(result.dependencies)} |")
        lines.append(f"| Total Issues | {len(result.issues)} |")
        lines.append(f"| Status | {'✅ PASS' if result.passed else '❌ FAIL'} |")
        if result.duration:
            lines.append(f"| Duration | {result.duration:.2f}s |")
        lines.append("")

        # Issues by severity
        if result.issues:
            lines.append("## Issues by Severity")
            lines.append("")

            by_severity = {}
            for issue in result.issues:
                severity = issue.severity.value if hasattr(issue.severity, 'value') else str(issue.severity)
                by_severity[severity] = by_severity.get(severity, 0) + 1

            lines.append("| Severity | Count |")
            lines.append("|----------|-------|")
            for severity, count in sorted(by_severity.items()):
                lines.append(f"| {severity} | {count} |")
            lines.append("")

        # Issue details
        if result.issues:
            lines.append("## Issue Details")
            lines.append("")

            for i, issue in enumerate(result.issues, 1):
                severity = issue.severity.value if hasattr(issue.severity, 'value') else issue.severity
                issue_type = issue.issue_type.value if hasattr(issue.issue_type, 'value') else issue.issue_type

                lines.append(f"### {i}. {issue.title}")
                lines.append("")
                lines.append(f"**Package**: `{issue.package}`")
                lines.append(f"**Severity**: {severity}")
                lines.append(f"**Type**: {issue_type}")

                if issue.description:
                    lines.append("")
                    lines.append(f"{issue.description}")

                if issue.fix_available:
                    lines.append("")
                    lines.append(f"**Fix Available**: {issue.fix_available}")

                lines.append("")

        # Dependencies
        lines.append("## Dependencies")
        lines.append("")
        lines.append("| Package | Version | Source |")
        lines.append("|---------|---------|--------|")

        for dep in result.dependencies:
            version = dep.version or "unknown"
            source = dep.source or "N/A"
            lines.append(f"| {dep.name} | {version} | {source} |")

        lines.append("")

        return "\n".join(lines)


class HTMLFormatter(Formatter):
    """HTML formatter for reports."""

    TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dependency Audit Report</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
        }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }}
        .card {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .card-title {{
            color: #666;
            font-size: 14px;
            text-transform: uppercase;
        }}
        .card-value {{
            font-size: 32px;
            font-weight: bold;
            color: #333;
        }}
        .status {{
            padding: 10px 20px;
            border-radius: 20px;
            display: inline-block;
        }}
        .status.pass {{ background: #4caf50; color: white; }}
        .status.fail {{ background: #f44336; color: white; }}
        .severity-critical {{ color: #d32f2f; }}
        .severity-high {{ color: #f57c00; }}
        .severity-medium {{ color: #fbc02d; }}
        .severity-low {{ color: #388e3c; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        th, td {{
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }}
        th {{
            background: #f5f5f5;
            font-weight: 600;
        }}
        .issue {{ background: white; padding: 20px; margin-bottom: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
    </style>
</head>
<body>
    {content}
</body>
</html>"""

    def format(self, data: Dict[str, Any]) -> str:
        """Format data as HTML."""
        content = self._generate_summary(data)
        return self.TEMPLATE.format(content=content)

    def format_result(self, result: AuditResult) -> str:
        """Format an audit result as HTML."""
        content = []

        # Header
        content.append('<div class="header">')
        content.append('<h1>Dependency Audit Report</h1>')
        content.append(f'<p>Generated: {datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")}</p>')
        content.append('</div>')

        # Summary cards
        content.append('<div class="summary">')
        content.append(f'<div class="card"><div class="card-title">Dependencies</div><div class="card-value">{len(result.dependencies)}</div></div>')
        content.append(f'<div class="card"><div class="card-title">Issues</div><div class="card-value">{len(result.issues)}</div></div>')
        status_class = "pass" if result.passed else "fail"
        status_text = "PASS" if result.passed else "FAIL"
        content.append(f'<div class="card"><div class="card-title">Status</div><div class="card-value"><span class="status {status_class}">{status_text}</span></div></div>')
        if result.duration:
            content.append(f'<div class="card"><div class="card-title">Duration</div><div class="card-value">{result.duration:.2f}s</div></div>')
        content.append('</div>')

        # Issues
        if result.issues:
            content.append('<h2>Issues</h2>')
            for issue in result.issues:
                severity = issue.severity.value if hasattr(issue.severity, 'value') else str(issue.severity)
                issue_type = issue.issue_type.value if hasattr(issue.issue_type, 'value') else str(issue.issue_type)
                severity_class = f"severity-{severity.lower()}"

                content.append('<div class="issue">')
                content.append(f'<h3 class="{severity_class}">{issue.title}</h3>')
                content.append(f'<p><strong>Package:</strong> {issue.package}</p>')
                content.append(f'<p><strong>Severity:</strong> <span class="{severity_class}">{severity}</span></p>')
                content.append(f'<p><strong>Type:</strong> {issue_type}</p>')
                if issue.description:
                    content.append(f'<p>{issue.description}</p>')
                if issue.fix_available:
                    content.append(f'<p><strong>Fix:</strong> {issue.fix_available}</p>')
                content.append('</div>')

        # Dependencies table
        content.append('<h2>Dependencies</h2>')
        content.append('<table>')
        content.append('<thead><tr><th>Package</th><th>Version</th><th>Source</th></tr></thead>')
        content.append('<tbody>')
        for dep in result.dependencies:
            version = dep.version or "unknown"
            source = dep.source or "N/A"
            content.append(f'<tr><td>{dep.name}</td><td>{version}</td><td>{source}</td></tr>')
        content.append('</tbody>')
        content.append('</table>')

        return self.TEMPLATE.format(content="\n".join(content))

    def _generate_summary(self, data: Dict[str, Any]) -> str:
        """Generate summary HTML."""
        return json.dumps(data)


class CSVFormatter(Formatter):
    """CSV formatter for reports."""

    def format(self, data: Dict[str, Any]) -> str:
        """Format data as CSV (dependencies only)."""
        if "dependencies" in data:
            return self._format_dependencies(data["dependencies"])
        return ""

    def format_result(self, result: AuditResult) -> str:
        """Format an audit result as CSV."""
        return self._format_dependencies(result.dependencies)

    def _format_dependencies(self, dependencies: List[Dependency]) -> str:
        """Format dependencies as CSV."""
        lines = ["Name,Version,Source"]
        for dep in dependencies:
            name = dep.name.replace(",", ";")
            version = (dep.version or "").replace(",", ";")
            source = (dep.source or "").replace(",", ";")
            lines.append(f"{name},{version},{source}")
        return "\n".join(lines)


class SARIFFormatter(Formatter):
    """SARIF (Static Analysis Results Interchange Format) formatter."""

    def __init__(self):
        self.version = "2.1.0"
        self.schema_uri = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"

    def format(self, data: Dict[str, Any]) -> str:
        """Format data as SARIF."""
        return self.format_result(self._data_to_result(data))

    def format_result(self, result: AuditResult) -> str:
        """Format an audit result as SARIF."""
        runs = []

        run = {
            "tool": {
                "driver": {
                    "name": "deptrack",
                    "version": "0.4.0",
                    "informationUri": "https://github.com/example/deptrack",
                }
            },
            "results": []
        }

        for issue in result.issues:
            severity = issue.severity.value if hasattr(issue.severity, 'value') else str(issue.severity)
            issue_type = issue.issue_type.value if hasattr(issue.issue_type, 'value') else str(issue.issue_type)

            # Map severity to SARIF level
            level = "error"
            if severity.upper() == "CRITICAL":
                level = "error"
            elif severity.upper() == "HIGH":
                level = "error"
            elif severity.upper() == "MEDIUM":
                level = "warning"
            elif severity.upper() == "LOW":
                level = "note"

            result_entry = {
                "level": level,
                "message": {
                    "text": f"{issue.title}: {issue.description or 'No description'}"
                },
                "locations": [{
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": f"package://{issue.package}"
                        },
                        "region": {
                            "startLine": 1
                        }
                    }
                }],
                "properties": {
                    "package": issue.package,
                    "issueType": issue_type,
                    "fixAvailable": issue.fix_available,
                }
            }

            run["results"].append(result_entry)

        runs.append(run)

        sarif = {
            "version": self.version,
            "$schema": self.schema_uri,
            "runs": runs
        }

        return json.dumps(sarif, indent=2)

    def _data_to_result(self, data: Dict[str, Any]) -> AuditResult:
        """Convert data dict to AuditResult."""
        # Simple conversion for format method
        from deptrack.models import AuditResult, Dependency, Issue

        deps = [Dependency(name=d["name"], version=d.get("version")) for d in data.get("dependencies", [])]
        issues = [
            Issue(
                package=i["package"],
                title=i.get("title", "Issue"),
                severity=Severity.MEDIUM,
                issue_type=None,
            )
            for i in data.get("issues", [])
        ]

        return AuditResult(
            passed=data.get("passed", True),
            dependencies=deps,
            issues=issues,
        )


class ReportGenerator:
    """Main report generator that supports multiple formats."""

    FORMATTERS = {
        "text": TextFormatter,
        "json": JSONFormatter,
        "markdown": MarkdownFormatter,
        "html": HTMLFormatter,
        "csv": CSVFormatter,
        "sarif": SARIFFormatter,
    }

    def __init__(self, default_format: str = "text"):
        self.default_format = default_format
        self.formatters = {name: cls() for name, cls in self.FORMATTERS.items()}

    def generate(
        self,
        result: AuditResult,
        format: Optional[str] = None,
        output_file: Optional[Path] = None
    ) -> str:
        """Generate a report in the specified format."""
        format_name = format or self.default_format

        formatter = self.formatters.get(format_name)
        if not formatter:
            raise ValueError(f"Unknown format: {format_name}")

        output = formatter.format_result(result)

        if output_file:
            output_file.write_text(output)

        return output

    def generate_summary(self, result: AuditResult) -> Dict[str, Any]:
        """Generate a summary dictionary from a result."""
        by_severity = {}
        by_type = {}

        for issue in result.issues:
            severity = issue.severity.value if hasattr(issue.severity, 'value') else str(issue.severity)
            issue_type = issue.issue_type.value if hasattr(issue.issue_type, 'value') else str(issue.issue_type)

            by_severity[severity] = by_severity.get(severity, 0) + 1
            by_type[issue_type] = by_type.get(issue_type, 0) + 1

        return {
            "total_dependencies": len(result.dependencies),
            "total_issues": len(result.issues),
            "passed": result.passed,
            "duration": result.duration,
            "by_severity": by_severity,
            "by_type": by_type,
        }


def create_report_generator(format: str = "text") -> ReportGenerator:
    """Create a report generator instance."""
    return ReportGenerator(default_format=format)


def generate_report(
    result: AuditResult,
    format: str = "text",
    output_file: Optional[Path] = None
) -> str:
    """Generate a report from an audit result."""
    generator = create_report_generator(format)
    return generator.generate(result, format, output_file)


def generate_summary(result: AuditResult) -> Dict[str, Any]:
    """Generate a summary from an audit result."""
    generator = create_report_generator()
    return generator.generate_summary(result)