"""Advanced network layer with retry logic, rate limiting, and async support."""

from __future__ import annotations

import asyncio
import gzip
import hashlib
import json
import os
import random
import socket
import ssl
import time
import urllib.error
import urllib.request
import zlib
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, TypeVar
from urllib.parse import urlparse

from deptrack.cache import CacheEntry, get_tiered_cache, TieredCache

T = TypeVar("T")

DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 3
DEFAULT_BACKOFF_FACTOR = 2.0
DEFAULT_RATE_LIMIT = 10  # requests per second


class HTTPMethod(Enum):
    """Supported HTTP methods."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"


class NetworkError(Exception):
    """Base exception for network-related errors."""

    def __init__(self, message: str, original: Exception | None = None) -> None:
        super().__init__(message)
        self.original = original


class RateLimitError(NetworkError):
    """Raised when rate limit is exceeded."""

    def __init__(self, retry_after: float | None = None) -> None:
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit exceeded. Retry after {retry_after}s" if retry_after else "Rate limit exceeded"
        )


class TimeoutError(NetworkError):
    """Raised when a request times out."""

    pass


class HTTPError(NetworkError):
    """Raised for HTTP errors."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        super().__init__(f"HTTP {status_code}: {message}")


@dataclass
class Request:
    """A network request."""

    url: str
    method: HTTPMethod = HTTPMethod.GET
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes | None = None
    timeout: float = DEFAULT_TIMEOUT
    allow_redirects: bool = True

    def to_urllib_request(self) -> urllib.request.Request:
        """Convert to urllib Request object."""
        req = urllib.request.Request(
            url=self.url,
            data=self.body,
            method=self.method.value,
            headers=self.headers,
        )
        return req


@dataclass
class Response:
    """A network response."""

    url: str
    status_code: int
    headers: dict[str, str]
    content: bytes
    encoding: str = "utf-8"
    elapsed_ms: float = 0.0
    from_cache: bool = False

    @property
    def text(self) -> str:
        """Decode content as text."""
        return self.content.decode(self.encoding, errors="replace")

    @property
    def ok(self) -> bool:
        """Return True for 2xx status codes."""
        return 200 <= self.status_code < 300

    def json(self) -> Any:
        """Parse content as JSON."""
        return json.loads(self.content)

    def raise_for_status(self) -> None:
        """Raise HTTPError if response is not OK."""
        if not self.ok:
            raise HTTPError(self.status_code, f"Request failed: {self.url}")


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""

    max_retries: int = DEFAULT_MAX_RETRIES
    backoff_factor: float = DEFAULT_BACKOFF_FACTOR
    backoff_max: float = 60.0
    retry_on: tuple[int, ...] = (429, 500, 502, 503, 504)
    jitter: bool = True


@dataclass
class RateLimitConfig:
    """Configuration for rate limiting."""

    requests_per_second: float = DEFAULT_RATE_LIMIT
    burst_size: int = 5
    per_host: bool = True


class TokenBucket:
    """Token bucket algorithm for rate limiting."""

    def __init__(self, rate: float, capacity: int) -> None:
        self._rate = rate
        self._capacity = capacity
        self._tokens = float(capacity)
        self._last_update = time.time()
        self._lock = asyncio.Lock() if hasattr(asyncio, "Lock") else None

    def consume(self, tokens: int = 1) -> float:
        """Consume tokens and return time to wait in seconds."""
        now = time.time()
        elapsed = now - self._last_update
        self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)
        self._last_update = now

        if self._tokens >= tokens:
            self._tokens -= tokens
            return 0.0

        needed = tokens - self._tokens
        return needed / self._rate

    async def async_consume(self, tokens: int = 1) -> float:
        """Async version of consume."""
        if self._lock:
            async with self._lock:
                return self.consume(tokens)
        return self.consume(tokens)


class HostRateLimiter:
    """Rate limiter that tracks limits per host."""

    def __init__(self, config: RateLimitConfig) -> None:
        self._config = config
        self._buckets: dict[str, TokenBucket] = {}

    def _get_bucket(self, host: str) -> TokenBucket:
        """Get or create bucket for a host."""
        if host not in self._buckets:
            self._buckets[host] = TokenBucket(
                rate=self._config.requests_per_second,
                capacity=self._config.burst_size,
            )
        return self._buckets[host]

    def _extract_host(self, url: str) -> str:
        """Extract host from URL."""
        parsed = urlparse(url)
        return parsed.netloc or "default"

    def wait_time(self, url: str) -> float:
        """Get wait time for a URL in seconds."""
        host = self._extract_host(url)
        bucket = self._get_bucket(host)
        return bucket.consume(1)

    def check_limit(self, url: str) -> float:
        """Check if request is allowed, returns wait time."""
        return self.wait_time(url)


class NetworkClient:
    """Advanced network client with caching, retry, and rate limiting."""

    def __init__(
        self,
        timeout: float = DEFAULT_TIMEOUT,
        retry_config: RetryConfig | None = None,
        rate_limit_config: RateLimitConfig | None = None,
        cache: TieredCache | None = None,
        user_agent: str = "deptrack/0.4.0",
        ssl_verify: bool = True,
    ) -> None:
        self._timeout = timeout
        self._retry_config = retry_config or RetryConfig()
        self._rate_limiter = HostRateLimiter(rate_limit_config or RateLimitConfig())
        self._cache = cache or get_tiered_cache()
        self._user_agent = user_agent
        self._ssl_verify = ssl_verify
        self._session_headers: dict[str, str] = {
            "User-Agent": user_agent,
            "Accept-Encoding": "gzip, deflate",
            "Accept": "*/*",
        }

    def _build_request(self, request: Request) -> urllib.request.Request:
        """Build a urllib Request with proper headers."""
        headers = {**self._session_headers, **request.headers}
        req = urllib.request.Request(
            url=request.url,
            data=request.body,
            method=request.method.value,
            headers=headers,
        )
        return req

    def _get_ssl_context(self) -> ssl.SSLContext | None:
        """Get SSL context for requests."""
        if not self._ssl_verify:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            return ctx
        return None

    def _calculate_etag(self, content: bytes) -> str:
        """Calculate ETag for content."""
        return hashlib.md5(content).hexdigest()

    def _make_request(self, request: Request) -> Response:
        """Make a single HTTP request."""
        start_time = time.time()
        req = self._build_request(request)

        ssl_context = self._get_ssl_context()

        try:
            with urllib.request.urlopen(
                req,
                timeout=request.timeout,
                context=ssl_context,
            ) as resp:
                content = resp.read()

                # Decompress if necessary
                encoding = resp.headers.get("Content-Encoding", "")
                if encoding == "gzip":
                    content = gzip.decompress(content)
                elif encoding == "deflate":
                    try:
                        content = zlib.decompress(content)
                    except zlib.error:
                        pass

                elapsed = (time.time() - start_time) * 1000

                headers = dict(resp.headers)

                return Response(
                    url=resp.url or request.url,
                    status_code=resp.status,
                    headers=headers,
                    content=content,
                    elapsed_ms=elapsed,
                )

        except urllib.error.HTTPError as e:
            raise HTTPError(e.code, str(e)) from e
        except urllib.error.URLError as e:
            raise TimeoutError(f"Connection error: {e.reason}") from e
        except socket.timeout:
            raise TimeoutError(f"Request timed out after {request.timeout}s") from e

    def _should_retry(self, response: Response | None, error: Exception | None) -> bool:
        """Determine if request should be retried."""
        if not self._retry_config:
            return False

        if error:
            # Retry on timeout, connection errors
            if isinstance(error, (TimeoutError, socket.timeout)):
                return True
            if isinstance(error, HTTPError) and error.status_code in self._retry_config.retry_on:
                return True
            return False

        if response:
            return response.status_code in self._retry_config.retry_on

        return False

    def _calculate_backoff(self, attempt: int) -> float:
        """Calculate backoff delay for retry attempt."""
        delay = self._retry_config.backoff_factor ** attempt
        delay = min(delay, self._retry_config.backoff_max)

        if self._retry_config.jitter:
            delay *= 0.5 + random.random()  # 50-150% of base delay

        return delay

    def request(
        self,
        url: str,
        method: HTTPMethod = HTTPMethod.GET,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
        use_cache: bool = True,
    ) -> Response:
        """Make an HTTP request with retry and rate limiting."""
        # Rate limiting
        wait_time = self._rate_limiter.check_limit(url)
        if wait_time > 0:
            time.sleep(wait_time)

        # Check cache for GET requests
        cache_key = f"{method.value}:{url}"
        if method == HTTPMethod.GET and use_cache:
            entry = self._cache.get(cache_key)
            if entry is not None:
                entry.value.from_cache = True
                return entry.value

        # Build request
        request = Request(
            url=url,
            method=method,
            headers=headers or {},
            body=body,
            timeout=self._timeout,
        )

        # Retry loop
        last_error: Exception | None = None
        for attempt in range(self._retry_config.max_retries + 1):
            try:
                response = self._make_request(request)

                # Cache successful GET responses
                if method == HTTPMethod.GET and use_cache:
                    cache_entry = CacheEntry(
                        key=cache_key,
                        value=response,
                        created_at=time.time(),
                        accessed_at=time.time(),
                    )
                    self._cache.set(cache_entry)

                return response

            except Exception as e:
                last_error = e
                if not self._should_retry(None, e):
                    raise

                if attempt < self._retry_config.max_retries:
                    backoff = self._calculate_backoff(attempt)
                    time.sleep(backoff)

        raise NetworkError(f"Max retries exceeded", last_error)

    def get(self, url: str, headers: dict[str, str] | None = None) -> Response:
        """Convenience method for GET requests."""
        return self.request(url, HTTPMethod.GET, headers)

    def post(
        self,
        url: str,
        data: dict[str, Any] | bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> Response:
        """Convenience method for POST requests."""
        if isinstance(data, dict):
            body = json.dumps(data).encode("utf-8")
            headers = headers or {}
            headers["Content-Type"] = "application/json"
        else:
            body = data

        return self.request(url, HTTPMethod.POST, headers, body, use_cache=False)

    def download_file(
        self,
        url: str,
        destination: Path,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> Path:
        """Download a file to disk with optional progress reporting."""
        response = self.get(url)

        total_size = int(response.headers.get("Content-Length", 0))

        with open(destination, "wb") as f:
            downloaded = 0
            for chunk in self._chunked_read(response.content, 8192):
                f.write(chunk)
                downloaded += len(chunk)
                if progress_callback and total_size > 0:
                    progress_callback(downloaded, total_size)

        return destination

    @staticmethod
    def _chunked_read(content: bytes, chunk_size: int) -> list[bytes]:
        """Split content into chunks for progress reporting."""
        for i in range(0, len(content), chunk_size):
            yield content[i : i + chunk_size]


class AsyncNetworkClient:
    """Async network client for concurrent requests."""

    def __init__(
        self,
        timeout: float = DEFAULT_TIMEOUT,
        retry_config: RetryConfig | None = None,
        rate_limit_config: RateLimitConfig | None = None,
        max_concurrent: int = 10,
    ) -> None:
        self._timeout = timeout
        self._retry_config = retry_config or RetryConfig()
        self._rate_limiter = HostRateLimiter(rate_limit_config or RateLimitConfig())
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._session_headers = {
            "User-Agent": "deptrack/0.4.0",
            "Accept-Encoding": "gzip, deflate",
        }

    async def request(
        self,
        url: str,
        method: HTTPMethod = HTTPMethod.GET,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
    ) -> Response:
        """Make an async HTTP request."""
        async with self._semaphore:
            # Rate limiting
            wait_time = self._rate_limiter.check_limit(url)
            if wait_time > 0:
                await asyncio.sleep(wait_time)

            return await self._async_request(url, method, headers, body)

    async def _async_request(
        self,
        url: str,
        method: HTTPMethod,
        headers: dict[str, str] | None,
        body: bytes | None,
    ) -> Response:
        """Internal async request implementation."""
        import aiohttp

        request_headers = {**self._session_headers, **(headers or {})}
        start_time = time.time()

        last_error: Exception | None = None
        for attempt in range(self._retry_config.max_retries + 1):
            try:
                timeout = aiohttp.ClientTimeout(total=self._timeout)

                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.request(
                        method=method.value,
                        url=url,
                        headers=request_headers,
                        data=body,
                    ) as resp:
                        content = await resp.read()
                        elapsed = (time.time() - start_time) * 1000

                        return Response(
                            url=str(resp.url),
                            status_code=resp.status,
                            headers=dict(resp.headers),
                            content=content,
                            elapsed_ms=elapsed,
                        )

            except Exception as e:
                last_error = e
                if attempt < self._retry_config.max_retries:
                    backoff = self._retry_config.backoff_factor ** attempt
                    if self._retry_config.jitter:
                        backoff *= 0.5 + random.random()
                    await asyncio.sleep(backoff)
                    continue
                break

        raise NetworkError(f"Max retries exceeded", last_error)

    async def get(self, url: str, headers: dict[str, str] | None = None) -> Response:
        """Convenience method for GET."""
        return await self.request(url, HTTPMethod.GET, headers)

    async def gather(self, urls: list[str]) -> list[Response]:
        """Execute multiple requests concurrently."""
        tasks = [self.get(url) for url in urls]
        return await asyncio.gather(*tasks, return_exceptions=True)

    def request_batch(self, urls: list[str]) -> list[Response]:
        """Synchronous wrapper for batch requests."""
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(self.gather(urls))
        finally:
            loop.close()


# Global client instances
_client: NetworkClient | None = None


def get_network_client(
    timeout: float = DEFAULT_TIMEOUT,
    use_cache: bool = True,
) -> NetworkClient:
    """Get or create the global network client."""
    global _client
    if _client is None:
        _client = NetworkClient(timeout=timeout)
    return _client


def set_network_client(client: NetworkClient) -> None:
    """Set the global network client."""
    global _client
    _client = client


class PyPIAdapter:
    """Adapter for PyPI API with specialized methods."""

    BASE_URL = "https://pypi.org/pypi"

    def __init__(self, client: NetworkClient | None = None) -> None:
        self._client = client or get_network_client()

    def get_package_json(self, package_name: str) -> dict[str, Any]:
        """Fetch package metadata as JSON."""
        url = f"{self.BASE_URL}/{package_name}/json"
        response = self._client.get(url)
        response.raise_for_status()
        return response.json()

    def get_package_versions(self, package_name: str) -> list[str]:
        """Get all available versions for a package."""
        data = self.get_package_json(package_name)
        return list(data.get("releases", {}).keys())

    def get_latest_version(self, package_name: str) -> str | None:
        """Get the latest version of a package."""
        data = self.get_package_json(package_name)
        return data.get("info", {}).get("version")

    def search_packages(self, query: str, page: int = 1) -> dict[str, Any]:
        """Search PyPI for packages."""
        # PyPI simple search API
        url = f"https://pypi.org/search/?q={urllib.request.quote(query)}&page={page}"
        response = self._client.get(url)
        response.raise_for_status()
        # Note: Simple page scraping, consider using warehouse API for structured data
        return {"url": url, "content": response.text}


class SecurityAdvisoryClient:
    """Client for fetching security advisories from various sources."""

    def __init__(
        self,
        client: NetworkClient | None = None,
        sources: list[str] | None = None,
    ) -> None:
        self._client = client or get_network_client()
        self._sources = sources or [
            "https://osv.io/list/vulns/affected",
            "https://gh.api.mzff.win/vulns/python",
        ]

    def fetch_osv_advisories(self, package_name: str) -> list[dict[str, Any]]:
        """Fetch advisories from OSV database."""
        url = f"https://api.osv.dev/v1/query"
        data = {
            "package": {
                "name": package_name,
                "ecosystem": "PyPI",
            }
        }
        response = self._client.post(url, data=data)
        if response.ok:
            return response.json().get("vulns", [])
        return []

    def fetch_github_advisories(self, package_name: str) -> list[dict[str, Any]]:
        """Fetch GitHub Security Advisories for a package."""
        url = f"https://api.github.com/advisories?affects={package_name}&ecosystem=pypi"
        headers = {"Accept": "application/vnd.github+json"}
        response = self._client.get(url, headers=headers)
        if response.ok:
            return response.json()
        return []

    def fetch_all_advisories(self, package_name: str) -> dict[str, list[dict[str, Any]]]:
        """Fetch advisories from all configured sources."""
        return {
            "osv": self.fetch_osv_advisories(package_name),
            "github": self.fetch_github_advisories(package_name),
        }


def create_session(
    base_url: str,
    auth_token: str | None = None,
    timeout: float = DEFAULT_TIMEOUT,
) -> NetworkClient:
    """Create a configured network client for a specific service."""
    client = NetworkClient(timeout=timeout)
    if auth_token:
        client._session_headers["Authorization"] = f"Bearer {auth_token}"
    return client