"""Analytics and metrics collection for dependency analysis."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any

from deptrack.models import Dependency, Issue, Severity


class MetricType(Enum):
    """Types of metrics."""

    COUNT = "count"
    PERCENTAGE = "percentage"
    RATIO = "ratio"
    DISTRIBUTION = "distribution"
    TREND = "trend"
    SCORE = "score"


@dataclass
class Metric:
    """A single metric value."""

    name: str
    value: float | int | str
    metric_type: MetricType
    category: str = "general"
    description: str = ""
    tags: list[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "value": self.value,
            "type": self.metric_type.value,
            "category": self.category,
            "description": self.description,
            "tags": self.tags,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class AnalyticsReport:
    """Comprehensive analytics report."""

    metrics: list[Metric] = field(default_factory=list)
    distributions: dict[str, dict[str, int]] = field(default_factory=dict)
    scores: dict[str, float] = field(default_factory=dict)
    recommendations: list[str] = field(default_factory=list)
    generated_at: datetime = field(default_factory=datetime.now)

    def add_metric(self, metric: Metric) -> None:
        """Add a metric to the report."""
        self.metrics.append(metric)

    def set_distribution(
        self,
        name: str,
        distribution: dict[str, int],
    ) -> None:
        """Set a distribution in the report."""
        self.distributions[name] = distribution

    def set_score(self, name: str, score: float) -> None:
        """Set a score in the report."""
        self.scores[name] = score

    def add_recommendation(self, text: str) -> None:
        """Add a recommendation."""
        self.recommendations.append(text)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "metrics": [m.to_dict() for m in self.metrics],
            "distributions": self.distributions,
            "scores": self.scores,
            "recommendations": self.recommendations,
            "generated_at": self.generated_at.isoformat(),
        }

    def summary(self) -> str:
        """Generate a text summary of the report."""
        lines = ["# Dependency Analytics Report", ""]
        lines.append(f"Generated: {self.generated_at.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")

        # Metrics summary
        lines.append("## Key Metrics")
        for metric in self.metrics:
            if isinstance(metric.value, (int, float)):
                if metric.metric_type == MetricType.PERCENTAGE:
                    lines.append(f"- {metric.name}: {metric.value:.1f}%")
                else:
                    lines.append(f"- {metric.name}: {metric.value}")
        lines.append("")

        # Scores
        if self.scores:
            lines.append("## Scores")
            for name, score in self.scores.items():
                lines.append(f"- {name}: {score:.2f}/10")
            lines.append("")

        # Recommendations
        if self.recommendations:
            lines.append("## Recommendations")
            for i, rec in enumerate(self.recommendations, 1):
                lines.append(f"{i}. {rec}")
            lines.append("")

        return "\n".join(lines)


class DependencyAnalyzer:
    """Analyzer for dependency metrics and statistics."""

    def __init__(self) -> None:
        self._dependencies: list[Dependency] = []
        self._issues: list[Issue] = []

    def add_dependencies(self, dependencies: list[Dependency]) -> None:
        """Add dependencies for analysis."""
        self._dependencies.extend(dependencies)

    def add_issues(self, issues: list[Issue]) -> None:
        """Add issues for analysis."""
        self._issues.extend(issues)

    def analyze(self) -> AnalyticsReport:
        """Generate comprehensive analytics report."""
        report = AnalyticsReport()

        # Basic counts
        self._analyze_counts(report)

        # Version analysis
        self._analyze_versions(report)

        # Security analysis
        self._analyze_security(report)

        # License analysis
        self._analyze_licenses(report)

        # Maintenance analysis
        self._analyze_maintenance(report)

        # Calculate scores
        self._calculate_scores(report)

        # Generate recommendations
        self._generate_recommendations(report)

        return report

    def _analyze_counts(self, report: AnalyticsReport) -> None:
        """Analyze basic dependency counts."""
        total = len(self._dependencies)

        # By source
        source_dist = Counter(d.source.value if d.source else "unknown" for d in self._dependencies)
        report.set_distribution("dependencies_by_source", dict(source_dist))

        # With/without versions
        with_version = sum(1 for d in self._dependencies if d.version)
        without_version = total - with_version
        report.add_metric(Metric(
            name="total_dependencies",
            value=total,
            metric_type=MetricType.COUNT,
            category="counts",
            description="Total number of dependencies",
        ))
        report.add_metric(Metric(
            name="dependencies_pinned",
            value=with_version,
            metric_type=MetricType.COUNT,
            category="counts",
            description="Dependencies with explicit versions",
        ))
        report.add_metric(Metric(
            name="dependencies_unpinned",
            value=without_version,
            metric_type=MetricType.COUNT,
            category="counts",
            description="Dependencies without explicit versions",
        ))

    def _analyze_versions(self, report: AnalyticsReport) -> None:
        """Analyze version patterns."""
        version_patterns = {
            "exact": 0,
            "range": 0,
            "wildcard": 0,
            "greater_than": 0,
            "less_than": 0,
        }

        for dep in self._dependencies:
            if not dep.version:
                continue

            version = dep.version
            if version.startswith("=="):
                version_patterns["exact"] += 1
            elif version.startswith((">=", "<=", "~=", "^", "~")):
                version_patterns["range"] += 1
            elif "*" in version or "x" in version.lower():
                version_patterns["wildcard"] += 1
            elif version.startswith((">", "<")):
                version_patterns["greater_than" if ">" in version else "less_than"] += 1

        report.set_distribution("version_patterns", version_patterns)

        # Calculate pinning rate
        total = len([d for d in self._dependencies if d.version])
        if total > 0:
            pinning_rate = (version_patterns["exact"] / total) * 100
        else:
            pinning_rate = 0

        report.add_metric(Metric(
            name="pinning_rate",
            value=pinning_rate,
            metric_type=MetricType.PERCENTAGE,
            category="versions",
            description="Percentage of dependencies with exact pins",
        ))

    def _analyze_security(self, report: AnalyticsReport) -> None:
        """Analyze security metrics."""
        # Severity distribution
        severity_dist = Counter(i.severity.value for i in self._issues)
        report.set_distribution("issues_by_severity", dict(severity_dist))

        # Issue types
        issue_types = Counter(i.kind for i in self._issues)
        report.set_distribution("issues_by_type", dict(issue_types))

        # Total issues
        total_issues = len(self._issues)
        critical_issues = sum(1 for i in self._issues if i.severity == Severity.CRITICAL)
        high_issues = sum(1 for i in self._issues if i.severity == Severity.HIGH)

        report.add_metric(Metric(
            name="total_issues",
            value=total_issues,
            metric_type=MetricType.COUNT,
            category="security",
            description="Total number of issues found",
        ))
        report.add_metric(Metric(
            name="critical_issues",
            value=critical_issues,
            metric_type=MetricType.COUNT,
            category="security",
            description="Critical severity issues",
        ))
        report.add_metric(Metric(
            name="high_issues",
            value=high_issues,
            metric_type=MetricType.COUNT,
            category="security",
            description="High severity issues",
        ))

    def _analyze_licenses(self, report: AnalyticsReport) -> None:
        """Analyze license distribution."""
        # This would need metadata from packages
        report.set_distribution("licenses", {})

    def _analyze_maintenance(self, report: AnalyticsReport) -> None:
        """Analyze maintenance metrics."""
        # Placeholder for maintenance analysis
        pass

    def _calculate_scores(self, report: AnalyticsReport) -> None:
        """Calculate composite scores."""
        # Dependency health score (0-10)
        health_score = 10.0

        # Deduct for unpinned dependencies
        unpinned = sum(1 for m in report.metrics if m.name == "dependencies_unpinned" for _ in [m.value])
        total_deps = sum(1 for m in report.metrics if m.name == "total_dependencies" for _ in [m.value])
        if total_deps > 0:
            health_score -= (unpinned / total_deps) * 3

        # Deduct for security issues
        critical = sum(1 for i in self._issues if i.severity == Severity.CRITICAL)
        high = sum(1 for i in self._issues if i.severity == Severity.HIGH)
        health_score -= critical * 1.5
        health_score -= high * 0.5

        # Deduct for wildcard versions
        wildcards = report.distributions.get("version_patterns", {}).get("wildcard", 0)
        if total_deps > 0:
            health_score -= (wildcards / total_deps) * 2

        report.set_score("dependency_health", max(0, min(10, health_score)))

        # Security score
        security_score = 10.0
        security_score -= critical * 2
        security_score -= high * 1
        security_score -= sum(1 for i in self._issues if i.severity == Severity.MEDIUM) * 0.2
        report.set_score("security", max(0, min(10, security_score)))

        # Supply chain score
        supply_chain_score = 10.0
        supply_chain_score -= (unpinned / max(total_deps, 1)) * 4
        supply_chain_score -= (wildcards / max(total_deps, 1)) * 2
        report.set_score("supply_chain", max(0, min(10, supply_chain_score)))

    def _generate_recommendations(self, report: AnalyticsReport) -> None:
        """Generate recommendations based on analysis."""
        # Check unpinned dependencies
        unpinned = sum(1 for d in self._dependencies if not d.version)
        if unpinned > 0:
            report.add_recommendation(
                f"Pin {unpinned} unpinned dependencies to ensure reproducible builds."
            )

        # Check security issues
        critical = sum(1 for i in self._issues if i.severity == Severity.CRITICAL)
        if critical > 0:
            report.add_recommendation(
                f"Address {critical} critical security vulnerabilities immediately."
            )

        # Check wildcards
        wildcards = sum(
            1 for d in self._dependencies
            if d.version and ("*" in d.version or "x" in d.version.lower())
        )
        if wildcards > 0:
            report.add_recommendation(
                f"Replace {wildcards} wildcard version specifiers with exact pins."
            )

        # Check for outdated dependencies
        outdated = sum(1 for i in self._issues if i.kind == "outdated")
        if outdated > 0:
            report.add_recommendation(
                f"Update {outdated} outdated dependencies to their latest versions."
            )


class TrendAnalyzer:
    """Analyzer for tracking dependency trends over time."""

    def __init__(self) -> None:
        self._history: list[dict[str, Any]] = []

    def record_snapshot(
        self,
        dependencies: list[Dependency],
        issues: list[Issue],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record a snapshot of the current state."""
        snapshot = {
            "timestamp": datetime.now().isoformat(),
            "total_dependencies": len(dependencies),
            "pinned_dependencies": sum(1 for d in dependencies if d.version),
            "total_issues": len(issues),
            "critical_issues": sum(1 for i in issues if i.severity == Severity.CRITICAL),
            "high_issues": sum(1 for i in issues if i.severity == Severity.HIGH),
            "metadata": metadata or {},
        }
        self._history.append(snapshot)

    def get_trends(
        self,
        days: int = 30,
    ) -> dict[str, list[dict[str, Any]]]:
        """Get trend data for the specified period."""
        cutoff = datetime.now() - timedelta(days=days)
        recent = [
            s for s in self._history
            if datetime.fromisoformat(s["timestamp"]) >= cutoff
        ]

        return {
            "dependencies": [
                {"date": s["timestamp"], "value": s["total_dependencies"]}
                for s in recent
            ],
            "issues": [
                {"date": s["timestamp"], "value": s["total_issues"]}
                for s in recent
            ],
            "security": [
                {
                    "date": s["timestamp"],
                    "critical": s["critical_issues"],
                    "high": s["high_issues"],
                }
                for s in recent
            ],
        }

    def calculate_velocity(
        self,
        metric: str,
        days: int = 30,
    ) -> float:
        """Calculate the rate of change for a metric (per day)."""
        trends = self.get_trends(days)
        metric_data = trends.get(metric, [])

        if len(metric_data) < 2:
            return 0.0

        first = metric_data[0]["value"]
        last = metric_data[-1]["value"]

        return (last - first) / max(days, 1)


class RiskScorer:
    """Score dependency risk factors."""

    RISK_WEIGHTS = {
        "unpinned": 2.0,
        "wildcard": 1.5,
        "critical_vuln": 5.0,
        "high_vuln": 3.0,
        "medium_vuln": 1.0,
        "low_vuln": 0.3,
        "unmaintained": 2.0,
        "yanked": 3.0,
        "outdated_major": 2.0,
        "outdated_minor": 0.5,
    }

    @classmethod
    def score_dependency(cls, dep: Dependency, issues: list[Issue]) -> float:
        """Calculate risk score for a single dependency (0-100)."""
        score = 0.0

        # Version issues
        if not dep.version:
            score += cls.RISK_WEIGHTS["unpinned"]
        elif "*" in (dep.version or "") or "x" in (dep.version or "").lower():
            score += cls.RISK_WEIGHTS["wildcard"]

        # Issue-based scoring
        for issue in issues:
            if issue.dep.name != dep.name:
                continue

            if issue.kind == "vulnerability":
                if issue.severity == Severity.CRITICAL:
                    score += cls.RISK_WEIGHTS["critical_vuln"]
                elif issue.severity == Severity.HIGH:
                    score += cls.RISK_WEIGHTS["high_vuln"]
                elif issue.severity == Severity.MEDIUM:
                    score += cls.RISK_WEIGHTS["medium_vuln"]
                else:
                    score += cls.RISK_WEIGHTS["low_vuln"]
            elif issue.kind == "yanked":
                score += cls.RISK_WEIGHTS["yanked"]
            elif issue.kind == "unmaintained":
                score += cls.RISK_WEIGHTS["unmaintained"]
            elif issue.kind == "outdated":
                # Major version updates
                score += cls.RISK_WEIGHTS["outdated_major"]

        return min(100.0, score)

    @classmethod
    def score_manifest(cls, deps: list[Dependency], issues: list[Issue]) -> float:
        """Calculate overall risk score for a dependency manifest."""
        if not deps:
            return 0.0

        total_score = sum(
            cls.score_dependency(dep, [i for i in issues if i.dep.name == dep.name])
            for dep in deps
        )

        return min(100.0, total_score / len(deps))


class DependencyGraphAnalyzer:
    """Analyze dependency graph characteristics."""

    def __init__(self, dependencies: list[Dependency]) -> None:
        self._deps = dependencies
        self._adjacency: dict[str, set[str]] = defaultdict(set)

        # Build adjacency list
        for dep in dependencies:
            self._adjacency[dep.name] = set(dep.dependencies)

    def get_transitive_dependencies(self, package: str) -> set[str]:
        """Get all transitive dependencies of a package."""
        visited = set()
        to_visit = [package]

        while to_visit:
            current = to_visit.pop()
            if current in visited:
                continue
            visited.add(current)
            to_visit.extend(self._adjacency.get(current, []))

        return visited - {package}

    def find_circular_dependencies(self) -> list[list[str]]:
        """Find circular dependency chains."""
        cycles = []
        visited = set()
        rec_stack = set()

        def dfs(node: str, path: list[str]) -> None:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in self._adjacency.get(node, []):
                if neighbor not in visited:
                    dfs(neighbor, path[:])
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:] + [neighbor])

            rec_stack.remove(node)

        for dep in self._deps:
            if dep.name not in visited:
                dfs(dep.name, [])

        return cycles

    def calculate_depth(self) -> dict[str, int]:
        """Calculate maximum depth of each package in the dependency tree."""
        depths: dict[str, int] = {}

        def calc_depth(pkg: str, seen: set[str]) -> int:
            if pkg in seen:
                return 0
            if pkg in depths:
                return depths[pkg]

            max_child_depth = 0
            for child in self._adjacency.get(pkg, []):
                if child not in seen:
                    child_depth = calc_depth(child, seen | {pkg})
                    max_child_depth = max(max_child_depth, child_depth)

            depth = max_child_depth + 1
            depths[pkg] = depth
            return depth

        for dep in self._deps:
            calc_depth(dep.name, set())

        return depths

    def find_shared_dependencies(self) -> dict[str, list[str]]:
        """Find dependencies used by multiple packages."""
        usage: dict[str, list[str]] = defaultdict(list)

        for pkg, deps in self._adjacency.items():
            for dep in deps:
                usage[dep].append(pkg)

        return {k: v for k, v in usage.items() if len(v) > 1}

    def get_graph_statistics(self) -> dict[str, Any]:
        """Get statistics about the dependency graph."""
        all_deps: set[str] = set()
        all_refs: set[str] = set()

        for pkg, deps in self._adjacency.items():
            all_refs.add(pkg)
            all_deps.update(deps)

        return {
            "total_packages": len(all_refs),
            "total_unique_dependencies": len(all_deps),
            "external_dependencies": list(all_deps - all_refs),
            "cycles": self.find_circular_dependencies(),
            "max_depth": max(self.calculate_depth().values()) if self.calculate_depth() else 0,
        }


def generate_full_report(
    dependencies: list[Dependency],
    issues: list[Issue],
) -> AnalyticsReport:
    """Generate a complete analytics report."""
    analyzer = DependencyAnalyzer()
    analyzer.add_dependencies(dependencies)
    analyzer.add_issues(issues)
    return analyzer.analyze()


def export_metrics(
    report: AnalyticsReport,
    format: str = "json",
) -> str:
    """Export metrics to specified format."""
    if format == "json":
        return json.dumps(report.to_dict(), indent=2)
    elif format == "prometheus":
        return _export_prometheus(report)
    elif format == "text":
        return report.summary()
    else:
        return json.dumps(report.to_dict(), indent=2)


def _export_prometheus(report: AnalyticsReport) -> str:
    """Export metrics in Prometheus format."""
    lines = []

    for metric in report.metrics:
        name = metric.name.replace(" ", "_").lower()

        # Metric type
        if metric.metric_type == MetricType.COUNT:
            metric_type = "counter"
        elif metric.metric_type == MetricType.PERCENTAGE:
            metric_type = "gauge"
        else:
            metric_type = "gauge"

        lines.append(f"# TYPE deptrack_{name} {metric_type}")
        lines.append(f"deptrack_{name}{{{','.join(f'{k}="{v}"' for k, v in _get_metric_labels(metric).items())}}} {metric.value}")

    return "\n".join(lines)


def _get_metric_labels(metric: Metric) -> dict[str, str]:
    """Get labels for a metric."""
    return {
        "category": metric.category,
        "type": metric.metric_type.value,
    }