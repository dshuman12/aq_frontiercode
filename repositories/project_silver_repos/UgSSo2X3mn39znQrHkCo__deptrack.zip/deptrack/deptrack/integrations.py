"""CI/CD integrations for deptrack including GitHub Actions, GitLab CI, Jenkins, and webhooks."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from deptrack.models import AuditResult


class CIProvider(Enum):
    """Supported CI providers."""

    GITHUB_ACTIONS = "github_actions"
    GITLAB_CI = "gitlab_ci"
    JENKINS = "jenkins"
    CIRCLECI = "circleci"
    TRAVIS = "travis"
    AZURE_DEVOPS = "azure_devops"
    GENERIC = "generic"


class WebhookEvent(Enum):
    """Webhook event types."""

    AUDIT_COMPLETED = "audit_completed"
    CRITICAL_VULNERABILITY = "critical_vulnerability"
    BLOCKED_PACKAGE = "blocked_package"
    POLICY_VIOLATION = "policy_violation"
    NEW_ISSUE = "new_issue"
    RESOLVED_ISSUE = "resolved_issue"


@dataclass
class CIContext:
    """Context information from CI environment."""

    provider: CIProvider = CIProvider.GENERIC
    commit_sha: str = ""
    branch: str = ""
    pull_request: str | None = None
    repository: str = ""
    owner: str = ""
    job_url: str = ""
    run_id: str = ""
    is_pull_request: bool = False
    commit_message: str = ""
    author: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_environment(cls) -> "CIContext":
        """Detect CI environment and extract context."""
        # GitHub Actions
        if os.getenv("GITHUB_ACTIONS"):
            return cls._from_github_actions()

        # GitLab CI
        if os.getenv("GITLAB_CI"):
            return cls._from_gitlab_ci()

        # Jenkins
        if os.getenv("JENKINS_URL"):
            return cls._from_jenkins()

        # CircleCI
        if os.getenv("CIRCLECI"):
            return cls._from_circleci()

        # Azure DevOps
        if os.getenv("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI"):
            return cls._from_azure_devops()

        # Generic / unknown
        return cls(
            provider=CIProvider.GENERIC,
            commit_sha=os.getenv("CI_COMMIT_SHA", ""),
            branch=os.getenv("CI_BRANCH", os.getenv("GIT_BRANCH", "")),
            repository=os.getenv("CI_REPOSITORY", os.getenv("GIT_REPOSITORY", "")),
        )

    @classmethod
    def _from_github_actions(cls) -> "CIContext":
        """Extract context from GitHub Actions environment."""
        pr_number = os.getenv("PR_NUMBER")
        pull_request = None
        is_pr = False

        if pr_number:
            pull_request = f"#{pr_number}"
            is_pr = True

        return cls(
            provider=CIProvider.GITHUB_ACTIONS,
            commit_sha=os.getenv("GITHUB_SHA", ""),
            branch=os.getenv("GITHUB_REF_NAME", ""),
            pull_request=pull_request,
            repository=os.getenv("GITHUB_REPOSITORY", ""),
            owner=os.getenv("GITHUB_REPOSITORY_OWNER", ""),
            job_url=os.getenv("GITHUB_SERVER_URL", ""),
            run_id=os.getenv("GITHUB_RUN_ID", ""),
            is_pull_request=is_pr,
            commit_message=os.getenv("GITHUB_COMMIT_MESSAGE", ""),
            author=os.getenv("GITHUB_ACTOR", ""),
            metadata={
                "workflow": os.getenv("GITHUB_WORKFLOW"),
                "job": os.getenv("GITHUB_JOB"),
                "run_number": os.getenv("GITHUB_RUN_NUMBER"),
            },
        )

    @classmethod
    def _from_gitlab_ci(cls) -> "CIContext":
        """Extract context from GitLab CI environment."""
        pr = None
        is_pr = False

        merge_request_iid = os.getenv("CI_MERGE_REQUEST_IID")
        if merge_request_iid:
            pr = f"!{merge_request_iid}"
            is_pr = True

        return cls(
            provider=CIProvider.GITLAB_CI,
            commit_sha=os.getenv("CI_COMMIT_SHA", ""),
            branch=os.getenv("CI_COMMIT_REF_NAME", ""),
            pull_request=pr,
            repository=os.getenv("CI_PROJECT_PATH", ""),
            owner=os.getenv("CI_PROJECT_NAMESPACE", ""),
            job_url=os.getenv("CI_JOB_URL", ""),
            run_id=os.getenv("CI_JOB_ID", ""),
            is_pull_request=is_pr,
            commit_message=os.getenv("CI_COMMIT_MESSAGE", ""),
            author=os.getenv("GITLAB_USER_LOGIN", ""),
            metadata={
                "pipeline_id": os.getenv("CI_PIPELINE_ID"),
                "job": os.getenv("CI_JOB_NAME"),
            },
        )

    @classmethod
    def _from_jenkins(cls) -> "CIContext":
        """Extract context from Jenkins environment."""
        return cls(
            provider=CIProvider.JENKINS,
            commit_sha=os.getenv("GIT_COMMIT", ""),
            branch=os.getenv("GIT_BRANCH", ""),
            repository=os.getenv("GIT_URL", ""),
            job_url=os.getenv("BUILD_URL", ""),
            run_id=os.getenv("BUILD_NUMBER", ""),
            metadata={
                "job_name": os.getenv("JOB_NAME"),
                "build_tag": os.getenv("BUILD_TAG"),
            },
        )

    @classmethod
    def _from_circleci(cls) -> "CIContext":
        """Extract context from CircleCI environment."""
        pr = None
        is_pr = False

        pr_number = os.getenv("CIRCLE_PR_NUMBER")
        if pr_number:
            pr = f"#{pr_number}"
            is_pr = True

        return cls(
            provider=CIProvider.CIRCLECI,
            commit_sha=os.getenv("CIRCLE_SHA1", ""),
            branch=os.getenv("CIRCLE_BRANCH", ""),
            pull_request=pr,
            repository=os.getenv("CIRCLE_REPOSITORY_URL", ""),
            job_url=os.getenv("CIRCLE_BUILD_URL", ""),
            run_id=os.getenv("CIRCLE_BUILD_NUM", ""),
            is_pull_request=is_pr,
            author=os.getenv("CIRCLE_USERNAME", ""),
        )

    @classmethod
    def _from_azure_devops(cls) -> "CIContext":
        """Extract context from Azure DevOps environment."""
        pr = None
        is_pr = False

        pr_id = os.getenv("SYSTEM_PULLREQUEST_PULLREQUESTNUMBER")
        if pr_id:
            pr = f"#{pr_id}"
            is_pr = True

        return cls(
            provider=CIProvider.AZURE_DEVOPS,
            commit_sha=os.getenv("BUILD_SOURCEVERSION", ""),
            branch=os.getenv("BUILD_SOURCEBRANCHNAME", ""),
            pull_request=pr,
            repository=os.getenv("SYSTEM_TEAMPROJECT"),
            owner=os.getenv("BUILD_REPOSITORY_OWNER"),
            job_url=os.getenv("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI"),
            run_id=os.getenv("BUILD_BUILDID", ""),
            is_pull_request=is_pr,
            author=os.getenv("BUILD_REQUESTEDFOR", ""),
        )

    def get_commit_url(self) -> str:
        """Get the URL for the commit."""
        if self.provider == CIProvider.GITHUB_ACTIONS:
            return f"https://github.com/{self.repository}/commit/{self.commit_sha}"
        elif self.provider == CIProvider.GITLAB_CI:
            return f"https://gitlab.com/{self.repository}/-/commit/{self.commit_sha}"
        return ""

    def get_branch_url(self) -> str:
        """Get the URL for the branch."""
        if self.provider == CIProvider.GITHUB_ACTIONS:
            return f"https://github.com/{self.repository}/tree/{self.branch}"
        elif self.provider == CIProvider.GITLAB_CI:
            return f"https://gitlab.com/{self.repository}/-/tree/{self.branch}"
        return ""

    def get_pr_url(self) -> str | None:
        """Get the URL for the pull request."""
        if not self.pull_request:
            return None
        if self.provider == CIProvider.GITHUB_ACTIONS:
            return f"https://github.com/{self.repository}/pull/{self.pull_request[1:]}"
        elif self.provider == CIProvider.GITLAB_CI:
            return f"https://gitlab.com/{self.repository}/-/merge_requests/{self.pull_request[1:]}"
        return None


class WebhookPayload:
    """Webhook payload for notifications."""

    def __init__(
        self,
        event: WebhookEvent,
        context: CIContext,
        data: dict[str, Any],
    ) -> None:
        self.event = event
        self.context = context
        self.data = data
        self.timestamp = time.time()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "event": self.event.value,
            "timestamp": self.timestamp,
            "context": {
                "provider": self.context.provider.value,
                "commit_sha": self.context.commit_sha,
                "branch": self.context.branch,
                "pull_request": self.context.pull_request,
                "repository": self.context.repository,
                "job_url": self.context.job_url,
                "is_pull_request": self.context.is_pull_request,
            },
            "data": self.data,
        }


class WebhookClient:
    """Client for sending webhook notifications."""

    def __init__(
        self,
        secret: str | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._secret = secret
        self._timeout = timeout
        self._client: Any = None

    def _get_client(self) -> Any:
        """Get HTTP client (lazily initialized)."""
        if self._client is None:
            try:
                import requests
                self._client = requests
            except ImportError:
                import urllib.request
                import json
                self._client = urllib.request

        return self._client

    def _sign_payload(self, payload: str) -> str:
        """Generate HMAC signature for payload."""
        if not self._secret:
            return ""

        signature = hmac.new(
            self._secret.encode("utf-8"),
            payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        return f"sha256={signature}"

    def send(
        self,
        url: str,
        payload: WebhookPayload,
        headers: dict[str, str] | None = None,
    ) -> bool:
        """Send webhook notification."""
        client = self._get_client()
        data = json.dumps(payload.to_dict()).encode("utf-8")

        request_headers = {
            "Content-Type": "application/json",
            "User-Agent": "deptrack-webhook/0.4.0",
        }

        if self._secret:
            request_headers["X-Webhook-Signature"] = self._sign_payload(data.decode("utf-8"))

        if headers:
            request_headers.update(headers)

        try:
            if hasattr(client, "post"):
                # requests
                response = client.post(
                    url,
                    data=data,
                    headers=request_headers,
                    timeout=self._timeout,
                )
                return 200 <= response.status_code < 300
            else:
                # urllib
                from urllib.request import Request, urlopen
                request = Request(url, data=data, headers=request_headers)
                with urlopen(request, timeout=self._timeout) as response:
                    return 200 <= response.status < 300
        except Exception:
            return False


class NotificationFormatter:
    """Format notifications for different channels."""

    @staticmethod
    def format_slack(
        payload: WebhookPayload,
        audit_result: AuditResult,
    ) -> dict[str, Any]:
        """Format notification for Slack."""
        summary = audit_result.summary()

        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"DepTrack Audit: {payload.context.branch}",
                }
            }
        ]

        # Status
        if summary["critical"] > 0:
            status_emoji = ":red_circle:"
            status_text = "Critical issues found"
        elif summary["high"] > 0:
            status_emoji = ":orange_circle:"
            status_text = "High severity issues found"
        elif summary["total_issues"] > 0:
            status_emoji = ":yellow_circle:"
            status_text = "Issues found"
        else:
            status_emoji = ":white_check_mark:"
            status_text = "No issues found"

        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"{status_emoji} *{status_text}*\n"
                       f"Total dependencies: {summary['total_dependencies']}\n"
                       f"Total issues: {summary['total_issues']}",
            }
        })

        # Issue breakdown
        issue_text = []
        if summary["critical"] > 0:
            issue_text.append(f"- {summary['critical']} Critical")
        if summary["high"] > 0:
            issue_text.append(f"- {summary['high']} High")
        if summary["medium"] > 0:
            issue_text.append(f"- {summary['medium']} Medium")
        if summary["low"] > 0:
            issue_text.append(f"- {summary['low']} Low")

        if issue_text:
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "\n".join(issue_text),
                }
            })

        # Links
        if payload.context.pull_request:
            pr_url = payload.context.get_pr_url()
            if pr_url:
                blocks.append({
                    "type": "context",
                    "elements": [
                        {"type": "mrkdwn", "text": f"<{pr_url}|View Pull Request> | <{payload.context.get_commit_url()}|View Commit>"}
                    ]
                })

        return {"blocks": blocks}

    @staticmethod
    def format_github(
        payload: WebhookPayload,
        audit_result: AuditResult,
    ) -> dict[str, Any]:
        """Format notification for GitHub Checks API."""
        summary = audit_result.summary()

        # Determine status
        if summary["critical"] > 0:
            status = "action_required"
            conclusion = "action_required"
        elif summary["high"] > 0:
            status = "action_required"
            conclusion = "action_required"
        elif summary["total_issues"] > 0:
            status = "action_required"
            conclusion = "neutral"
        else:
            status = "success"
            conclusion = "success"

        output = {
            "title": f"Dependency Audit: {summary['total_issues']} issues found",
            "summary": f"Found {summary['total_issues']} issues across {summary['total_dependencies']} dependencies.\n\n"
                      f"- Critical: {summary['critical']}\n"
                      f"- High: {summary['high']}\n"
                      f"- Medium: {summary['medium']}\n"
                      f"- Low: {summary['low']}",
            "text": "",
        }

        # Add annotations for critical/high issues
        annotations = []
        for issue in audit_result.critical_issues[:10]:
            annotations.append({
                "path": f"dependency:{issue.dep.name}",
                "start_line": 1,
                "end_line": 1,
                "annotation_level": "failure",
                "message": issue.message,
            })

        for issue in audit_result.high_issues[:10]:
            annotations.append({
                "path": f"dependency:{issue.dep.name}",
                "start_line": 1,
                "end_line": 1,
                "annotation_level": "warning",
                "message": issue.message,
            })

        output["annotations"] = annotations[:50]  # GitHub limits to 50

        return {
            "status": status,
            "conclusion": conclusion,
            "output": output,
        }

    @staticmethod
    def format_teams(
        payload: WebhookPayload,
        audit_result: AuditResult,
    ) -> dict[str, Any]:
        """Format notification for Microsoft Teams."""
        summary = audit_result.summary()

        if summary["critical"] > 0:
            theme_color = "FF0000"
            status = "Critical"
        elif summary["high"] > 0:
            theme_color = "FFA500"
            status = "High"
        elif summary["total_issues"] > 0:
            theme_color = "FFFF00"
            status = "Warning"
        else:
            theme_color = "00FF00"
            status = "Success"

        return {
            "@type": "MessageCard",
            "@context": "https://schema.org/extensions",
            "summary": f"DepTrack: {status}",
            "themeColor": theme_color,
            "title": f"Dependency Audit: {status}",
            "sections": [
                {
                    "activityTitle": f"{payload.context.branch}",
                    "facts": [
                        {"name": "Total Dependencies", "value": str(summary["total_dependencies"])},
                        {"name": "Total Issues", "value": str(summary["total_issues"])},
                        {"name": "Critical", "value": str(summary["critical"])},
                        {"name": "High", "value": str(summary["high"])},
                        {"name": "Medium", "value": str(summary["medium"])},
                        {"name": "Low", "value": str(summary["low"])},
                    ],
                }
            ],
            "potentialAction": [
                {
                    "@type": "OpenUri",
                    "name": "View Details",
                    "targets": [
                        {"os": "default", "uri": payload.context.job_url}
                    ]
                }
            ]
        }

    @staticmethod
    def format_email(
        payload: WebhookPayload,
        audit_result: AuditResult,
    ) -> dict[str, Any]:
        """Format notification for email."""
        summary = audit_result.summary()

        subject = f"[DepTrack] {'Critical' if summary['critical'] > 0 else 'Warning'}: "
        subject += f"{summary['total_issues']} issues in {payload.context.branch}"

        body = f"""
DepTrack Dependency Audit Report
{'=' * 40}

Repository: {payload.context.repository}
Branch: {payload.context.branch}
Commit: {payload.context.commit_sha[:8]}
{'Pull Request: ' + payload.context.pull_request if payload.context.pull_request else ''}

Summary
-------
Total Dependencies: {summary['total_dependencies']}
Total Issues: {summary['total_issues']}

By Severity:
- Critical: {summary['critical']}
- High: {summary['high']}
- Medium: {summary['medium']}
- Low: {summary['low']}

"""

        # Add critical issues
        if audit_result.critical_issues:
            body += "\nCritical Issues\n"
            body += "-" * 40 + "\n"
            for issue in audit_result.critical_issues:
                body += f"\n[{issue.dep.name}] {issue.message}\n"
                if issue.fix_suggestion:
                    body += f"  Fix: {issue.fix_suggestion}\n"

        return {
            "subject": subject,
            "body": body,
        }


class CIIntegration:
    """Base class for CI/CD integrations."""

    def __init__(self, context: CIContext) -> None:
        self.context = context

    def format_annotations(
        self,
        audit_result: AuditResult,
    ) -> list[dict[str, Any]]:
        """Format issues as CI annotations."""
        annotations = []

        for issue in audit_result.critical_issues:
            annotations.append({
                "path": f"deptrack://{issue.dep.name}",
                "line": 1,
                "message": f"[{issue.severity.value.upper()}] {issue.message}",
                "severity": "error" if issue.severity.value in ("critical", "high") else "warning",
            })

        for issue in audit_result.high_issues:
            annotations.append({
                "path": f"deptrack://{issue.dep.name}",
                "line": 1,
                "message": f"[{issue.severity.value.upper()}] {issue.message}",
                "severity": "error" if issue.severity.value in ("critical", "high") else "warning",
            })

        return annotations


class GitHubActionsIntegration(CIIntegration):
    """GitHub Actions specific integration."""

    def set_output(self, name: str, value: str) -> None:
        """Set a GitHub Actions output."""
        with open(os.environ.get("GITHUB_OUTPUT", "/dev/stdout"), "a") as f:
            f.write(f"{name}={value}\n")

    def add_summary(self, content: str) -> None:
        """Add content to GitHub Actions summary."""
        summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
        if summary_path:
            with open(summary_path, "a") as f:
                f.write(content)
        else:
            print(content)

    def format_summary_markdown(
        self,
        audit_result: AuditResult,
    ) -> str:
        """Format audit result as GitHub Actions summary markdown."""
        summary = audit_result.summary()

        md = [
            "## DepTrack Dependency Audit",
            "",
            f"| Metric | Value |",
            f"|--------|-------|",
            f"| Total Dependencies | {summary['total_dependencies']} |",
            f"| Total Issues | {summary['total_issues']} |",
            f"| Critical | {summary['critical']} |",
            f"| High | {summary['high']} |",
            f"| Medium | {summary['medium']} |",
            f"| Low | {summary['low']} |",
            "",
        ]

        # Add issues table
        if audit_result.issues:
            md.append("### Issues")
            md.append("")
            md.append("| Package | Version | Severity | Issue |")
            md.append("|---------|---------|----------|-------|")

            for issue in audit_result.issues[:20]:
                md.append(
                    f"| `{issue.dep.name}` | {issue.dep.version or 'N/A'} | "
                    f"{issue.severity.value} | {issue.message[:80]} |"
                )

        # Set outputs
        self.set_output("total_issues", str(summary["total_issues"]))
        self.set_output("critical_issues", str(summary["critical"]))
        self.set_output("high_issues", str(summary["high"]))

        return "\n".join(md)


class GitLabCIIntegration(CIIntegration):
    """GitLab CI specific integration."""

    def set_variable(self, name: str, value: str) -> None:
        """Set a GitLab CI variable through dotenv file."""
        dotenv_path = Path.cwd() / ".gitlab-ci-env"
        with open(dotenv_path, "a") as f:
            f.write(f"{name}={value}\n")

    def create_report(
        self,
        audit_result: AuditResult,
        output_path: Path,
    ) -> None:
        """Create a GitLab CI security report."""
        report = {
            "version": "14.0.0",
            "vulnerabilities": [],
            "scan": {
                "scanner": {
                    "id": "deptrack",
                    "name": "DepTrack",
                    "vendor": {"name": "DepTrack"},
                },
                "type": "dependency_scanning",
                "start_time": datetime.now().isoformat(),
                "end_time": datetime.now().isoformat(),
            },
        }

        for issue in audit_result.issues:
            vuln = {
                "id": hashlib.sha256(
                    f"{issue.dep.name}{issue.message}".encode()
                ).hexdigest()[:8],
                "group": "dependency",
                "state": "detected",
                "name": f"{issue.dep.name}: {issue.kind}",
                "message": issue.message,
                "description": issue.fix_suggestion or "",
                "severity": issue.severity.value.upper(),
                "confidence": "high",
                "identifiers": [
                    {"identifier": issue.kind, "name": issue.kind.upper()}
                ],
                "location": {
                    "file": issue.dep.source.value if issue.dep.source else "requirements.txt",
                    "dependency": {
                        "package": {"name": issue.dep.name},
                        "version": issue.dep.version or "*",
                    },
                },
            }
            report["vulnerabilities"].append(vuln)

        output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")


class JenkinsIntegration(CIIntegration):
    """Jenkins specific integration."""

    def create_artifact(
        self,
        audit_result: AuditResult,
        output_path: Path,
    ) -> None:
        """Create a Jenkins-compatible report artifact."""
        report = audit_result.to_dict() if hasattr(audit_result, "to_dict") else {
            "summary": audit_result.summary(),
        }

        # Also save as HTML
        from deptrack.reporters import render_html
        html = render_html(audit_result)
        output_path.with_suffix(".json").write_text(
            json.dumps(report, indent=2),
            encoding="utf-8"
        )
        output_path.with_suffix(".html").write_text(html, encoding="utf-8")


def detect_and_create_integration() -> CIIntegration | None:
    """Detect CI environment and create appropriate integration."""
    context = CIContext.from_environment()

    if context.provider == CIProvider.GITHUB_ACTIONS:
        return GitHubActionsIntegration(context)
    elif context.provider == CIProvider.GITLAB_CI:
        return GitLabCIIntegration(context)
    elif context.provider == CIProvider.JENKINS:
        return JenkinsIntegration(context)

    return None


def send_audit_webhooks(
    audit_result: AuditResult,
    webhook_urls: list[str],
    secret: str | None = None,
) -> dict[str, bool]:
    """Send audit results to multiple webhooks."""
    context = CIContext.from_environment()
    payload = WebhookPayload(
        event=WebhookEvent.AUDIT_COMPLETED,
        context=context,
        data={
            "summary": audit_result.summary(),
            "total_issues": len(audit_result.issues),
            "critical": len(audit_result.critical_issues),
        },
    )

    client = WebhookClient(secret=secret)
    results = {}

    for url in webhook_urls:
        results[url] = client.send(url, payload)

    return results


# Environment variable helpers
def get_env_int(name: str, default: int) -> int:
    """Get integer from environment variable."""
    value = os.getenv(name)
    if value:
        try:
            return int(value)
        except ValueError:
            pass
    return default


def get_env_bool(name: str, default: bool) -> bool:
    """Get boolean from environment variable."""
    value = os.getenv(name)
    if value:
        return value.lower() in ("true", "1", "yes", "on")
    return default


def get_env_list(name: str, default: list[str] | None = None) -> list[str]:
    """Get list from environment variable (comma-separated)."""
    value = os.getenv(name)
    if value:
        return [v.strip() for v in value.split(",") if v.strip()]
    return default or []


def configure_from_env(prefix: str = "DEPTRACK_") -> dict[str, Any]:
    """Configure deptrack from environment variables."""
    config = {}

    # Webhooks
    webhook_urls = get_env_list(f"{prefix}WEBHOOK_URLS")
    if webhook_urls:
        config["webhook_urls"] = webhook_urls

    config["webhook_secret"] = os.getenv(f"{prefix}WEBHOOK_SECRET")

    # Thresholds
    config["fail_on_critical"] = get_env_bool(f"{prefix}FAIL_ON_CRITICAL", False)
    config["fail_on_high"] = get_env_bool(f"{prefix}FAIL_ON_HIGH", False)
    config["fail_on_any"] = get_env_bool(f"{prefix}FAIL_ON_ANY", False)

    # Output
    config["output_format"] = os.getenv(f"{prefix}OUTPUT_FORMAT", "text")
    config["output_path"] = os.getenv(f"{prefix}OUTPUT_PATH")

    # Notifications
    config["notify_slack"] = get_env_bool(f"{prefix}NOTIFY_SLACK", False)
    config["slack_webhook"] = os.getenv(f"{prefix}SLACK_WEBHOOK")

    config["notify_teams"] = get_env_bool(f"{prefix}NOTIFY_TEAMS", False)
    config["teams_webhook"] = os.getenv(f"{prefix}TEAMS_WEBHOOK")

    config["notify_email"] = get_env_bool(f"{prefix}NOTIFY_EMAIL", False)
    config["email_to"] = os.getenv(f"{prefix}EMAIL_TO")

    # GitHub specific
    config["github_token"] = os.getenv("GITHUB_TOKEN")
    config["github_check_name"] = os.getenv(f"{prefix}GITHUB_CHECK_NAME", "DepTrack Audit")

    # GitLab specific
    config["gitlab_token"] = os.getenv("GITLAB_TOKEN")

    return config