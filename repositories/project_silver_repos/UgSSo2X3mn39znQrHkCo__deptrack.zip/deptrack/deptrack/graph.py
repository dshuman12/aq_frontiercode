"""Dependency graph analysis — build and query a dependency graph."""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Iterator, Any

from deptrack.models import Dependency


@dataclass
class GraphNode:
    """A node in the dependency graph."""

    dep: Dependency
    dependents: list[str] = field(default_factory=list)   # packages that depend on this
    dependencies: list[str] = field(default_factory=list)  # packages this depends on

    @property
    def name(self) -> str:
        return self.dep.canonical_name

    def is_leaf(self) -> bool:
        """Return True if this package has no declared sub-dependencies."""
        return len(self.dependencies) == 0

    def is_root(self) -> bool:
        """Return True if nothing depends on this package (top-level dep)."""
        return len(self.dependents) == 0


class DependencyGraph:
    """
    Directed graph of package dependencies.

    Nodes are canonical package names; edges represent 'depends on' relationships.
    """

    def __init__(self) -> None:
        self._nodes: dict[str, GraphNode] = {}

    def add_dependency(self, dep: Dependency) -> None:
        """Add a dependency as a node (no edges yet)."""
        name = dep.canonical_name
        if name not in self._nodes:
            self._nodes[name] = GraphNode(dep=dep)

    def add_edge(self, from_name: str, to_name: str) -> None:
        """
        Add a directed edge: `from_name` depends on `to_name`.
        Both nodes must already exist.
        """
        from_name = Dependency.normalize_name(from_name)
        to_name = Dependency.normalize_name(to_name)
        if from_name not in self._nodes or to_name not in self._nodes:
            return
        node = self._nodes[from_name]
        if to_name not in node.dependencies:
            node.dependencies.append(to_name)
        dependent_node = self._nodes[to_name]
        if from_name not in dependent_node.dependents:
            dependent_node.dependents.append(from_name)

    def get_node(self, name: str) -> GraphNode | None:
        return self._nodes.get(Dependency.normalize_name(name))

    def nodes(self) -> Iterator[GraphNode]:
        yield from self._nodes.values()

    def root_nodes(self) -> list[GraphNode]:
        """Return nodes that nothing depends on (top-level dependencies)."""
        return [n for n in self._nodes.values() if n.is_root()]

    def leaf_nodes(self) -> list[GraphNode]:
        """Return nodes with no outgoing edges (no sub-dependencies declared)."""
        return [n for n in self._nodes.values() if n.is_leaf()]

    def transitive_dependencies(self, name: str) -> set[str]:
        """
        Return the set of all transitive dependencies of `name` via BFS.
        Does not include `name` itself.
        """
        name = Dependency.normalize_name(name)
        visited: set[str] = set()
        queue: deque[str] = deque()

        start = self._nodes.get(name)
        if start is None:
            return visited

        for dep_name in start.dependencies:
            queue.append(dep_name)

        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            node = self._nodes.get(current)
            if node:
                for dep_name in node.dependencies:
                    if dep_name not in visited:
                        queue.append(dep_name)

        return visited

    def detect_cycles(self) -> list[list[str]]:
        """
        Detect circular dependency chains using DFS.
        Returns a list of cycles, each cycle being a list of package names.
        """
        visited: set[str] = set()
        rec_stack: set[str] = set()
        cycles: list[list[str]] = []

        def dfs(name: str, path: list[str]) -> None:
            visited.add(name)
            rec_stack.add(name)
            path.append(name)

            node = self._nodes.get(name)
            if node:
                for dep_name in node.dependencies:
                    if dep_name not in visited:
                        dfs(dep_name, path)
                    elif dep_name in rec_stack:
                        # Found a cycle
                        cycle_start = path.index(dep_name)
                        cycles.append(path[cycle_start:] + [dep_name])

            path.pop()
            rec_stack.discard(name)

        for name in self._nodes:
            if name not in visited:
                dfs(name, [])

        return cycles

    def depth(self, name: str) -> int:
        """
        Return the maximum dependency depth of `name`.
        Depth 0 means no dependencies. Uses BFS.
        """
        name = Dependency.normalize_name(name)
        node = self._nodes.get(name)
        if node is None or not node.dependencies:
            return 0

        max_depth = 0
        queue: deque[tuple[str, int]] = deque([(name, 0)])
        visited: set[str] = set()

        while queue:
            current, d = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            max_depth = max(max_depth, d)
            n = self._nodes.get(current)
            if n:
                for dep_name in n.dependencies:
                    if dep_name not in visited:
                        queue.append((dep_name, d + 1))

        return max_depth

    def most_depended_upon(self, top_n: int = 10) -> list[tuple[str, int]]:
        """Return the top N packages by number of dependents."""
        counts = [(n.name, len(n.dependents)) for n in self._nodes.values()]
        return sorted(counts, key=lambda x: x[1], reverse=True)[:top_n]

    def to_dict(self) -> dict:
        """Serialise the graph to a JSON-compatible dict."""
        return {
            name: {
                "version": node.dep.version,
                "dependencies": node.dependencies,
                "dependents": node.dependents,
            }
            for name, node in self._nodes.items()
        }


def build_graph(deps: list[Dependency]) -> DependencyGraph:
    """Build a DependencyGraph from a flat list of dependencies (no edge info)."""
    graph = DependencyGraph()
    for dep in deps:
        graph.add_dependency(dep)
    return graph


# ---------------------------------------------------------------------------
# Advanced Graph Analytics
# ---------------------------------------------------------------------------

class GraphAnalyzer:
    """Provides advanced analytics for dependency graphs."""

    def __init__(self, graph: DependencyGraph):
        self.graph = graph

    def calculate_metrics(self) -> dict[str, Any]:
        """Calculate comprehensive graph metrics."""
        nodes = list(self.graph.nodes())
        total_nodes = len(nodes)

        if total_nodes == 0:
            return {
                "total_nodes": 0,
                "total_edges": 0,
                "average_dependencies": 0.0,
                "max_depth": 0,
                "orphans": 0,
                "cycles": 0,
            }

        total_edges = sum(len(n.dependencies) for n in nodes)
        average_deps = total_edges / total_nodes if total_nodes > 0 else 0

        depths = [self.graph.depth(n.name) for n in nodes]
        max_depth = max(depths) if depths else 0

        orphans = sum(1 for n in nodes if n.is_leaf() and n.is_root())

        cycles = self.graph.detect_cycles()

        return {
            "total_nodes": total_nodes,
            "total_edges": total_edges,
            "average_dependencies": average_deps,
            "max_depth": max_depth,
            "orphans": orphans,
            "cycles": len(cycles),
            "cycle_details": [cycle[::-1] for cycle in cycles],  # Show in dependency order
        }

    def find_heavy_dependencies(self, top_n: int = 10) -> list[tuple[str, int]]:
        """Find packages with the most transitive dependencies."""
        counts = []
        for node in self.graph.nodes():
            transitive = self.graph.transitive_dependencies(node.name)
            counts.append((node.name, len(transitive)))
        return sorted(counts, key=lambda x: x[1], reverse=True)[:top_n]

    def find_critical_packages(self, threshold: int = 5) -> list[str]:
        """Find packages that many others depend on (high impact)."""
        critical = []
        for node in self.graph.nodes():
            if len(node.dependents) >= threshold:
                critical.append(node.name)
        return sorted(critical, key=lambda n: len(self.graph.get_node(n).dependents), reverse=True)

    def suggest_simplification(self) -> list[dict[str, Any]]:
        """Suggest ways to simplify the dependency tree."""
        suggestions = []

        # Check for deep dependency chains
        for node in self.graph.nodes():
            depth = self.graph.depth(node.name)
            if depth > 5:
                suggestions.append({
                    "type": "deep_chain",
                    "package": node.name,
                    "depth": depth,
                    "message": f"{node.name} has {depth} levels of dependencies",
                })

        # Check for packages with many direct dependents
        for node in self.graph.nodes():
            if len(node.dependents) > 10:
                suggestions.append({
                    "type": "high_coupling",
                    "package": node.name,
                    "dependents": len(node.dependents),
                    "message": f"{node.name} is depended on by {len(node.dependents)} packages",
                })

        return suggestions


class CycleBreaker:
    """Utilities for breaking circular dependencies."""

    def __init__(self, graph: DependencyGraph):
        self.graph = graph

    def suggest_removals(self) -> list[dict[str, Any]]:
        """Suggest which edges to remove to break cycles."""
        cycles = self.graph.detect_cycles()
        if not cycles:
            return []

        # Score each edge by how many cycles it appears in
        edge_scores: dict[tuple[str, str], int] = {}
        for cycle in cycles:
            for i in range(len(cycle) - 1):
                edge = (cycle[i], cycle[i + 1])
                edge_scores[edge] = edge_scores.get(edge, 0) + 1

        # Sort edges by score (most cycles first)
        sorted_edges = sorted(edge_scores.items(), key=lambda x: x[1], reverse=True)

        suggestions = []
        for (from_node, to_node), score in sorted_edges[:5]:
            suggestions.append({
                "from": from_node,
                "to": to_node,
                "cycles_affected": score,
                "recommendation": f"Consider removing dependency of {from_node} on {to_node}",
            })

        return suggestions

    def break_cycle(self, from_node: str, to_node: str) -> bool:
        """Attempt to break a cycle by removing an edge."""
        from_node = Dependency.normalize_name(from_node)
        to_node = Dependency.normalize_name(to_node)

        node = self.graph.get_node(from_node)
        if node and to_node in node.dependencies:
            node.dependencies.remove(to_node)

            dep_node = self.graph.get_node(to_node)
            if dep_node and from_node in dep_node.dependents:
                dep_node.dependents.remove(from_node)
            return True
        return False


def visualize_ascii(graph: DependencyGraph) -> str:
    """Create an ASCII visualization of the dependency tree."""
    lines = ["Dependency Graph", "=" * 50, ""]

    roots = graph.root_nodes()
    for root in roots:
        _render_node_ascii(root, graph, lines, indent=0, visited=set())

    return "\n".join(lines)


def _render_node_ascii(node: GraphNode, graph: DependencyGraph, lines: list[str], indent: int, visited: set[str]) -> None:
    """Helper to render a node and its children."""
    if node.name in visited:
        lines.append("  " * indent + f"└─ {node.name} (...)")
        return

    visited.add(node.name)
    prefix = "  " * indent

    if node.is_root():
        lines.append(f"{prefix}📦 {node.name} ({node.dep.version or 'unknown'})")
    else:
        lines.append(f"{prefix}└─ {node.name} ({node.dep.version or 'unknown'})")

    for dep_name in node.dependencies:
        dep_node = graph.get_node(dep_name)
        if dep_node:
            _render_node_ascii(dep_node, graph, lines, indent + 1, visited)
