"""
PEP 508 environment marker evaluation.

Evaluates dependency markers against a given environment to determine
whether a dependency applies.
"""

from __future__ import annotations

import platform
import re
import sys
from dataclasses import dataclass
from typing import Any


@dataclass
class Environment:
    """Represents a Python environment for marker evaluation."""

    os_name: str = ""
    sys_platform: str = ""
    platform_machine: str = ""
    platform_python_implementation: str = ""
    platform_release: str = ""
    platform_system: str = ""
    platform_version: str = ""
    python_version: str = ""
    python_full_version: str = ""
    implementation_name: str = ""
    implementation_version: str = ""
    extra: str = ""

    @classmethod
    def current(cls) -> "Environment":
        """Return an Environment reflecting the currently running Python."""
        return cls(
            os_name=__import__("os").name,
            sys_platform=sys.platform,
            platform_machine=platform.machine(),
            platform_python_implementation=platform.python_implementation(),
            platform_release=platform.release(),
            platform_system=platform.system(),
            platform_version=platform.version(),
            python_version=".".join(str(v) for v in sys.version_info[:2]),
            python_full_version=".".join(str(v) for v in sys.version_info[:3]),
            implementation_name=platform.python_implementation().lower(),
            implementation_version=".".join(str(v) for v in sys.version_info[:3]),
        )

    def as_dict(self) -> dict[str, str]:
        return {
            "os.name": self.os_name,
            "sys_platform": self.sys_platform,
            "platform_machine": self.platform_machine,
            "platform_python_implementation": self.platform_python_implementation,
            "platform_release": self.platform_release,
            "platform_system": self.platform_system,
            "platform_version": self.platform_version,
            "python_version": self.python_version,
            "python_full_version": self.python_full_version,
            "implementation_name": self.implementation_name,
            "implementation_version": self.implementation_version,
            "extra": self.extra,
        }


def _parse_version(v: str) -> tuple[int, ...]:
    parts = re.split(r"[.\-]", v.strip())
    result = []
    for p in parts:
        try:
            result.append(int(p))
        except ValueError:
            break
    return tuple(result)


def _compare(lhs: str, op: str, rhs: str) -> bool:
    """Evaluate a single marker comparison."""
    op = op.strip()
    lhs = lhs.strip().strip("'\"")
    rhs = rhs.strip().strip("'\"")

    # Try numeric version comparison first
    try:
        lv = _parse_version(lhs)
        rv = _parse_version(rhs)
        if lv and rv:
            if op == "==":
                return lv == rv
            if op == "!=":
                return lv != rv
            if op == "<":
                return lv < rv
            if op == "<=":
                return lv <= rv
            if op == ">":
                return lv > rv
            if op == ">=":
                return lv >= rv
            if op == "~=":
                # Compatible release: >= rhs, == rhs[:-1].*
                return lv >= rv and lv[: len(rv) - 1] == rv[: len(rv) - 1]
    except Exception:
        pass

    # Fall back to string comparison
    if op == "==":
        return lhs == rhs
    if op == "!=":
        return lhs != rhs
    if op == "in":
        return lhs in rhs
    if op == "not in":
        return lhs not in rhs
    return False


_COMPARISON_RE = re.compile(
    r"(['\"]?[\w._\s]+['\"]?)\s*(==|!=|<=|>=|~=|<|>|not in|in)\s*(['\"]?[\w._\s]+['\"]?)"
)


def evaluate_marker(marker: str, env: Environment | None = None) -> bool:
    """
    Evaluate a PEP 508 marker string against an environment.

    This is a simplified evaluator that handles common cases.
    Full PEP 508 compliance requires a dedicated parser.

    Returns True if the dependency should be included, False otherwise.
    """
    if not marker or not marker.strip():
        return True

    env = env or Environment.current()
    env_dict = env.as_dict()

    # Substitute environment variables
    expr = marker
    for key, value in env_dict.items():
        expr = expr.replace(key, f'"{value}"')

    # Handle 'and' / 'or' by splitting (simplified, no parentheses support)
    if " and " in expr.lower():
        parts = re.split(r"\s+and\s+", expr, flags=re.IGNORECASE)
        return all(_eval_single(p.strip()) for p in parts)

    if " or " in expr.lower():
        parts = re.split(r"\s+or\s+", expr, flags=re.IGNORECASE)
        return any(_eval_single(p.strip()) for p in parts)

    return _eval_single(expr.strip())


def _eval_single(expr: str) -> bool:
    """Evaluate a single (non-compound) marker expression."""
    m = _COMPARISON_RE.search(expr)
    if not m:
        return True  # Can't parse → include by default
    lhs, op, rhs = m.group(1), m.group(2), m.group(3)
    return _compare(lhs, op, rhs)


def filter_deps_by_env(
    deps: list,
    env: Environment | None = None,
) -> list:
    """
    Filter a list of Dependency objects, returning only those whose
    markers evaluate to True for the given environment.
    """
    env = env or Environment.current()
    result = []
    for dep in deps:
        if not dep.markers or evaluate_marker(dep.markers, env):
            result.append(dep)
    return result
