"""deptrack - Advanced checkers for dependency analysis."""

from __future__ import annotations

import re
import subprocess
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import ClassVar

from deptrack.models import Dependency, Issue, Severity


# ---------------------------------------------------------------------------
# Checker base
# ---------------------------------------------------------------------------

class Checker(ABC):
    """Base class for all dependency checkers."""

    name: ClassVar[str]
    description: ClassVar[str]

    @abstractmethod
    def check(self, dep: Dependency) -> list[Issue]:
        """Run this checker against a dependency. Returns any issues found."""
        ...


# ---------------------------------------------------------------------------
# License checker
# ---------------------------------------------------------------------------

_ALLOWED_LICENSES = {
    "MIT", "Apache-2.0", "Apache 2.0", "BSD-2-Clause", "BSD-3-Clause",
    "ISC", "Unlicense", "Zlib", "PostgreSQL", " Artistic-2.0",
    "Python-2.0", "CC0-1.0", "CC-BY-3.0", "CC-BY-4.0",
}

_COPYLEFT_LICENSES = {
    "GPL-2.0", "GPL-3.0", "LGPL-2.1", "LGPL-3.0", "AGPL-3.0",
    "MPL-2.0", "EUPL-1.2",
}

_FORBIDDEN_LICENSES = {
    "GPL-1.0", "LGPL-2.0",
}


class LicenseChecker(Checker):
    """Check for problematic or disallowed licenses."""

    name = "license"
    description = "Detects packages with problematic licenses"

    def __init__(
        self,
        allowed: set[str] | None = None,
        forbidden: set[str] | None = None,
        warn_copyleft: bool = True,
    ):
        self.allowed = allowed or _ALLOWED_LICENSES
        self.forbidden = forbidden or _FORBIDDEN_LICENSES
        self.warn_copyleft = warn_copyleft

    def check(self, dep: Dependency) -> list[Issue]:
        issues = []
        license_str = dep.metadata.get("license", "") if dep.metadata else ""

        if not license_str:
            issues.append(Issue(
                dep=dep,
                kind="unknown_license",
                severity=Severity.INFO,
                message="No license information available",
            ))
            return issues

        license_upper = license_str.upper()

        # Check forbidden
        for forbidden in self.forbidden:
            if forbidden.upper() in license_upper:
                issues.append(Issue(
                    dep=dep,
                    kind="forbidden_license",
                    severity=Severity.HIGH,
                    message=f"Package has forbidden license: {license_str}",
                    fix_suggestion="Replace with a package that has a permissive license",
                ))

        # Check copyleft warning
        if self.warn_copyleft:
            for copyleft in _COPYLEFT_LICENSES:
                if copyleft.upper() in license_upper:
                    issues.append(Issue(
                        dep=dep,
                        kind="copyleft_license",
                        severity=Severity.MEDIUM,
                        message=f"Package has copyleft license ({license_str}). "
                                f"This may impose license obligations on your project.",
                        fix_suggestion="Consider using a package with a permissive license like MIT or Apache-2.0",
                    ))

        # Check allowed list (warn if not in it)
        if license_str not in self.allowed and not issues:
            issues.append(Issue(
                dep=dep,
                kind="unknown_license_type",
                severity=Severity.INFO,
                message=f"License '{license_str}' is not in the approved list",
            ))

        return issues


# ---------------------------------------------------------------------------
# Popularity / maintenance checker
# ---------------------------------------------------------------------------

_MAINTENANCE_STATUSES = {
    "act": "active",
    "mat": "maintained",
    "dep": "deprecated",
    "not": "not maintained",
    "hpf": "help wanted",
}


@dataclass
class PopularityData:
    downloads_30d: int = 0
    downloads_7d: int = 0
    dependents_count: int = 0
    maintenance_status: str = "unknown"
    commits_90d: int = 0


class PopularityChecker(Checker):
    """Check package popularity and maintenance status."""

    name = "popularity"
    description = "Checks package popularity and maintenance status"

    def __init__(
        self,
        min_downloads_30d: int = 100,
        require_active: bool = True,
        require_commits_90d: int = 0,
    ):
        self.min_downloads_30d = min_downloads_30d
        self.require_active = require_active
        self.require_commits_90d = require_commits_90d

    def check(self, dep: Dependency) -> list[Issue]:
        issues = []
        meta = dep.metadata or {}

        downloads = meta.get("downloads_30d", 0)
        if downloads < self.min_downloads_30d:
            issues.append(Issue(
                dep=dep,
                kind="low_downloads",
                severity=Severity.LOW,
                message=f"Package has only {downloads:,} downloads in the last 30 days",
            ))

        status = meta.get("maintenance_status", "unknown")
        if status != "unknown":
            status_code = status.lower()[:3]
            status_text = _MAINTENANCE_STATUSES.get(status_code, status)

            if status in ("not", "hpf"):
                issues.append(Issue(
                    dep=dep,
                    kind="unmaintained",
                    severity=Severity.HIGH,
                    message=f"Package is marked as '{status_text}' on PyPI",
                    fix_suggestion=f"Consider using a more actively maintained alternative",
                ))
            elif status == "dep":
                issues.append(Issue(
                    dep=dep,
                    kind="deprecated",
                    severity=Severity.HIGH,
                    message="Package is deprecated on PyPI",
                    fix_suggestion="Replace with the recommended alternative package",
                ))

        commits = meta.get("commits_90d", 0)
        if self.require_commits_90d > 0 and commits < self.require_commits_90d:
            issues.append(Issue(
                dep=dep,
                kind="low_activity",
                severity=Severity.MEDIUM,
                message=f"Package has only {commits} commits in the last 90 days",
            ))

        return issues


# ---------------------------------------------------------------------------
# Python version compatibility checker
# ---------------------------------------------------------------------------

@dataclass
class PythonVersion:
    major: int
    minor: int
    micro: int = 0

    @classmethod
    def parse(cls, s: str) -> PythonVersion | None:
        try:
            parts = s.lstrip("v").split(".")
            major = int(parts[0])
            minor = int(parts[1]) if len(parts) > 1 else 0
            micro = int(parts[2]) if len(parts) > 2 else 0
            return cls(major, minor, micro)
        except (ValueError, IndexError):
            return None

    def __str__(self) -> str:
        if self.micro:
            return f"{self.major}.{self.minor}.{self.micro}"
        return f"{self.major}.{self.minor}"


class PythonVersionChecker(Checker):
    """Check if a package supports the required Python versions."""

    name = "python_version"
    description = "Checks Python version compatibility"

    def __init__(
        self,
        required: tuple[int, int] = (3, 9),
        drop_support_after: int | None = None,
    ):
        self.required = required
        self.drop_support_after = drop_support_after

    def check(self, dep: Dependency) -> list[Issue]:
        issues = []
        requires_python = dep.metadata.get("requires_python", "") if dep.metadata else ""

        if not requires_python:
            issues.append(Issue(
                dep=dep,
                kind="unknown_python_version",
                severity=Severity.INFO,
                message="No Python version requirements specified",
            ))
            return issues

        # Parse the requires-python spec
        try:
            if not self._supports_version(requires_python, self.required):
                issues.append(Issue(
                    dep=dep,
                    kind="incompatible_python",
                    severity=Severity.HIGH,
                    message=f"Package does not support Python {self.required[0]}.{self.required[1]}",
                    fix_suggestion=f"Use a different version of the package or upgrade Python",
                ))
        except Exception:
            pass  # Skip if we can't parse

        return issues

    def _supports_version(self, spec: str, target: tuple[int, int]) -> bool:
        """Check if a version specifier supports a given Python version."""
        # Simple check for common operators
        ops = [">=", "<", ">", "~=", "!="]

        for op in ops:
            if op in spec:
                try:
                    version_part = spec.split(op)[1].strip()
                    version = PythonVersion.parse(version_part.strip())

                    if version:
                        if op == ">=":
                            if target < (version.major, version.minor):
                                return False
                        elif op == "<":
                            if target >= (version.major, version.minor):
                                return False
                        elif op == ">":
                            if target <= (version.major, version.minor):
                                return False

                except (ValueError, IndexError):
                    pass

        # If we see a lower bound and target is below it, return False
        bound_match = re.search(r">=(\d+)\.(\d+)", spec)
        if bound_match:
            bound = (int(bound_match.group(1)), int(bound_match.group(2)))
            if target < bound:
                return False

        return True


# ---------------------------------------------------------------------------
# Typosquatting / name similarity checker
# ---------------------------------------------------------------------------

class TyposquatChecker(Checker):
    """Check for packages with names similar to popular packages (typosquatting)."""

    name = "typosquat"
    description = "Detects packages with names similar to popular packages"

    # Common legitimate packages that are often mimicked
    KNOWN_TARGETS = {
        "requests", "numpy", "pandas", "django", "flask", "tensorflow",
        "keras", "scikit-learn", "scipy", "matplotlib", "pytest",
        "beautifulsoup4", "sqlalchemy", "cryptography", "pillow", "pyyaml",
        "boto3", "botocore", "paramiko", "psycopg2", "mysql-connector",
    }

    def __init__(self, similarity_threshold: float = 0.85):
        self.threshold = similarity_threshold

    def check(self, dep: Dependency) -> list[Issue]:
        issues = []

        # Check for direct matches with known targets
        lower_name = dep.name.lower()

        for target in self.KNOWN_TARGETS:
            # Check for common typosquatting patterns
            if self._is_similar(lower_name, target):
                issues.append(Issue(
                    dep=dep,
                    kind="typosquat_detected",
                    severity=Severity.CRITICAL,
                    message=f"Package name '{dep.name}' is similar to popular package '{target}'",
                    fix_suggestion=f"Did you mean '{target}'? This might be a typosquatting attempt.",
                ))
                break

        # Check for common character additions/remplacements
        patterns = [
            r"^py",  # prefixed with 'py'
            r"-py$",  # suffixed with '-py'
            r"^i",  # prefixed with 'i'
            r"^e",  # prefixed with 'e'
        ]

        for pattern in patterns:
            if re.match(pattern, lower_name):
                base = re.sub(pattern, "", lower_name)
                if base in self.KNOWN_TARGETS:
                    issues.append(Issue(
                        dep=dep,
                        kind="suspicious_name",
                        severity=Severity.HIGH,
                        message=f"Package name '{dep.name}' starts/ends with a common prefix/suffix",
                    ))

        return issues

    def _is_similar(self, name1: str, name2: str) -> bool:
        """Check if two names are similar using Levenshtein distance."""
        # Exact match
        if name1 == name2:
            return False  # It's the same package, not typosquatting

        # Length difference check
        if abs(len(name1) - len(name2)) > 2:
            return False

        # Check common prefix
        common_prefix = 0
        for c1, c2 in zip(name1, name2):
            if c1 == c2:
                common_prefix += 1
            else:
                break

        if common_prefix >= 5:
            # Similar prefix, do Levenshtein check
            dist = self._levenshtein(name1, name2)
            max_len = max(len(name1), len(name2))
            similarity = 1 - (dist / max_len)
            return similarity >= self.threshold

        return False

    def _levenshtein(self, s1: str, s2: str) -> int:
        """Calculate Levenshtein distance between two strings."""
        if len(s1) < len(s2):
            return self._levenshtein(s2, s1)

        if len(s2) == 0:
            return len(s1)

        previous_row = list(range(len(s2) + 1))
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row

        return previous_row[-1]


# ---------------------------------------------------------------------------
# Security checker (malware detection)
# ---------------------------------------------------------------------------

class SecurityChecker(Checker):
    """Check for known malicious packages."""

    name = "security"
    description = "Detects known malicious packages"

    # Known malicious package patterns (this is a simplified example)
    KNOWN_MALICIOUS = {
        "malicious-package",
        "bad-package",
    }

    # Suspicious patterns in package names
    SUSPICIOUS_PATTERNS = [
        r"^install-",
        r"-setup$",
        r"^free-",
        r"^pro-",
        r"test123",
        r"^dev-",
    ]

    def __init__(self, block_malicious: bool = True):
        self.block_malicious = block_malicious

    def check(self, dep: Dependency) -> list[Issue]:
        issues = []
        lower_name = dep.name.lower()

        # Check known malicious list
        if lower_name in self.KNOWN_MALICIOUS:
            issues.append(Issue(
                dep=dep,
                kind="known_malicious",
                severity=Severity.CRITICAL,
                message="Package is known to be malicious",
                fix_suggestion="Remove this package immediately",
            ))

        # Check for suspicious patterns
        for pattern in self.SUSPICIOUS_PATTERNS:
            if re.search(pattern, lower_name):
                issues.append(Issue(
                    dep=dep,
                    kind="suspicious_name_pattern",
                    severity=Severity.MEDIUM,
                    message=f"Package name matches suspicious pattern: {pattern}",
                    fix_suggestion="Verify this package is from a trusted source",
                ))

        # Check for package with network access but no source available
        if dep.version and dep.version not in ("*", "any"):
            # Package with pinned version should have source
            pass

        return issues


# ---------------------------------------------------------------------------
# Development dependency checker
# ---------------------------------------------------------------------------

class DevDependencyChecker(Checker):
    """Warn about development dependencies in production."""

    name = "dev_dependency"
    description = "Warns when dev dependencies might be used in production"

    COMMON_DEV_PACKAGES = {
        "pytest", "pytest-cov", "pytest-mock", "pytest-asyncio",
        "black", "flake8", "isort", "mypy", "pylint",
        "coverage", "tox", "nox", "pre-commit",
        "sphinx", "sphinx-rtd-theme",
        "ipython", "jupyter", "jupyterlab",
        "pyright", "ruff",
    }

    def __init__(self, warn_in_prod: bool = True):
        self.warn_in_prod = warn_in_prod

    def check(self, dep: Dependency) -> list[Issue]:
        issues = []

        if not self.warn_in_prod:
            return issues

        lower_name = dep.name.lower().split("[")[0]  # Remove extras

        if lower_name in self.COMMON_DEV_PACKAGES:
            issues.append(Issue(
                dep=dep,
                kind="dev_dependency_in_prod",
                severity=Severity.LOW,
                message=f"'{dep.name}' is typically a development dependency",
                fix_suggestion="Consider marking this as a dev-only dependency if not needed in production",
            ))

        # Check for test-related patterns
        if "test" in lower_name or "spec" in lower_name or "mock" in lower_name:
            if lower_name not in self.COMMON_DEV_PACKAGES:
                issues.append(Issue(
                    dep=dep,
                    kind="test_dependency",
                    severity=Severity.INFO,
                    message=f"'{dep.name}' appears to be a testing dependency",
                ))

        # Check for linting/formatting patterns
        if any(x in lower_name for x in ["lint", "format", "style", "check"]):
            issues.append(Issue(
                dep=dep,
                kind="lint_dependency",
                severity=Severity.INFO,
                message=f"'{dep.name}' appears to be a linting/formatting tool",
            ))

        return issues


# ---------------------------------------------------------------------------
# Version pinning checker
# ---------------------------------------------------------------------------

class VersionPinChecker(Checker):
    """Check that dependencies are properly version-pinned."""

    name = "version_pin"
    description = "Ensures dependencies have proper version constraints"

    def __init__(
        self,
        require_pin: bool = True,
        allow_specifiers: bool = True,
        min_pin_length: int = 3,
    ):
        self.require_pin = require_pin
        self.allow_specifiers = allow_specifiers
        self.min_pin_length = min_pin_length

    def check(self, dep: Dependency) -> list[Issue]:
        issues = []

        if not dep.version or dep.version == "*":
            if self.require_pin:
                issues.append(Issue(
                    dep=dep,
                    kind="unpinned",
                    severity=Severity.MEDIUM,
                    message="Dependency is not pinned to a specific version",
                    fix_suggestion="Pin to a specific version or version range for reproducible builds",
                ))
            return issues

        version = dep.version

        # Check for minimum pin length
        if version.startswith(("==", ">=", "<=", "~=", "!=")):
            version = version[2:] if len(version) > 2 else version

        if len(version) < self.min_pin_length and not version.startswith("0"):
            issues.append(Issue(
                dep=dep,
                kind="short_pin",
                severity=Severity.LOW,
                message=f"Version pin '{dep.version}' is very short",
            ))

        # Check for floating references
        if any(x in dep.version.lower() for x in ["latest", "current", "newest"]):
            issues.append(Issue(
                dep=dep,
                kind="floating_version",
                severity=Severity.HIGH,
                message=f"Version specification uses a floating reference: {dep.version}",
                fix_suggestion="Use a specific version instead of 'latest', 'current', etc.",
            ))

        return issues


# ---------------------------------------------------------------------------
# Checker registry
# ---------------------------------------------------------------------------

class CheckerRegistry:
    """Registry of available checkers."""

    def __init__(self) -> None:
        self._checkers: list[Checker] = []

    def register(self, checker: Checker) -> None:
        self._checkers.append(checker)

    def check(self, dep: Dependency) -> list[Issue]:
        all_issues = []
        for checker in self._checkers:
            all_issues.extend(checker.check(dep))
        return all_issues

    def check_all(self, deps: list[Dependency]) -> list[Issue]:
        all_issues = []
        for dep in deps:
            all_issues.extend(self.check(dep))
        return all_issues


def default_checker_registry() -> CheckerRegistry:
    """Build the default checker registry with all built-in checkers."""
    registry = CheckerRegistry()
    registry.register(LicenseChecker())
    registry.register(PopularityChecker())
    registry.register(TyposquatChecker())
    registry.register(SecurityChecker())
    registry.register(DevDependencyChecker())
    registry.register(VersionPinChecker())
    return registry