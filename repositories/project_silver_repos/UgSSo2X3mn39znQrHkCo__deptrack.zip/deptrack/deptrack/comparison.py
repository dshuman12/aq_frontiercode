"""deptrack - Advanced comparison utilities for dependency analysis."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Dependency comparison
# ---------------------------------------------------------------------------

@dataclass
class DependencyDiff:
    """Represents differences between two dependency versions."""
    name: str
    version_old: str | None = None
    version_new: str | None = None
    added: bool = False
    removed: bool = False
    changed: bool = False

    @property
    def change_type(self) -> str:
        if self.added:
            return "added"
        if self.removed:
            return "removed"
        if self.changed:
            return "changed"
        return "unchanged"


def compare_dependencies(old_deps: list[dict], new_deps: list[dict]) -> list[DependencyDiff]:
    """Compare two lists of dependencies and return differences."""
    old_map = {d["name"]: d.get("version") for d in old_deps}
    new_map = {d["name"]: d.get("version") for d in new_deps}

    diffs = []

    # Find added and changed
    for name, version in new_map.items():
        if name not in old_map:
            diffs.append(DependencyDiff(name=name, version_new=version, added=True))
        elif old_map[name] != version:
            diffs.append(DependencyDiff(
                name=name,
                version_old=old_map[name],
                version_new=version,
                changed=True
            ))

    # Find removed
    for name, version in old_map.items():
        if name not in new_map:
            diffs.append(DependencyDiff(name=name, version_old=version, removed=True))

    return diffs


# ---------------------------------------------------------------------------
# Version comparison utilities
# ---------------------------------------------------------------------------

def parse_version(version: str) -> tuple[int, ...]:
    """Parse a version string into a tuple of integers."""
    parts = version.lstrip("v").split(".")
    return tuple(int(p) for p in parts if p.isdigit())


def compare_versions(v1: str, v2: str) -> int:
    """Compare two version strings. Returns -1, 0, or 1."""
    parts1 = parse_version(v1)
    parts2 = parse_version(v2)

    # Pad to same length
    max_len = max(len(parts1), len(parts2))
    parts1 = parts1 + (0,) * (max_len - len(parts1))
    parts2 = parts2 + (0,) * (max_len - len(parts2))

    if parts1 < parts2:
        return -1
    elif parts1 > parts2:
        return 1
    return 0


def is_compatible(required: str, actual: str) -> bool:
    """Check if an actual version satisfies a requirement spec."""
    import re

    if required == "*":
        return True

    # Handle pinned version
    if required.startswith("=="):
        return parse_version(actual) == parse_version(required[2:].strip())

    # Handle greater-than-or-equal
    if required.startswith(">="):
        base_version = required[2:].strip()
        return compare_versions(actual, base_version) >= 0

    # Handle less-than
    if required.startswith("<"):
        base_version = required[1:].strip()
        return compare_versions(actual, base_version) <= 0

    # Handle caret (^)
    if required.startswith("^"):
        base_version = parse_version(required[1:].strip())
        if not base_version:
            return True
        actual_parts = parse_version(actual)
        if len(actual_parts) < len(base_version):
            return False
        return actual_parts[:len(base_version)] == base_version

    # Handle tilde (~)
    if required.startswith("~"):
        base_version = required[1:].strip()
        parts = parse_version(base_version)
        if not parts:
            return True
        actual_parts = parse_version(actual)
        if len(actual_parts) < len(parts):
            return False
        return actual_parts[:len(parts) - 1] == parts[:len(parts) - 1] and actual_parts[len(parts) - 1] >= parts[len(parts) - 1]

    # Exact match fallback
    return parse_version(actual) == parse_version(required)


# ---------------------------------------------------------------------------
# Security delta analysis
# ---------------------------------------------------------------------------

@dataclass
class SecurityDelta:
    """Changes in security posture between two audits."""
    new_vulnerabilities: list[dict] = field(default_factory=list)
    fixed_vulnerabilities: list[dict] = field(default_factory=list)
    escalated_vulnerabilities: list[dict] = field(default_factory=list)
    deescalated_vulnerabilities: list[dict] = field(default_factory=list)

    @property
    def net_change(self) -> int:
        return (len(self.new_vulnerabilities) +
                len(self.escalated_vulnerabilities) -
                len(self.fixed_vulnerabilities) -
                len(self.deescalated_vulnerabilities))

    def is_worse(self) -> bool:
        return self.net_change > 0

    def is_better(self) -> bool:
        return self.net_change < 0


def calculate_security_delta(old_issues: list[dict], new_issues: list[dict]) -> SecurityDelta:
    """Calculate security changes between two audit results."""
    old_map = {(i.get("package"), i.get("kind")): i for i in old_issues}
    new_map = {(i.get("package"), i.get("kind")): i for i in new_issues}

    delta = SecurityDelta()

    # New vulnerabilities (in new but not in old)
    for key, issue in new_map.items():
        if key not in old_map:
            delta.new_vulnerabilities.append(issue)

    # Fixed vulnerabilities (in old but not in new)
    for key, issue in old_map.items():
        if key not in new_map:
            delta.fixed_vulnerabilities.append(issue)

    # Check for severity changes
    for key, new_issue in new_map.items():
        if key in old_map:
            old_severity = old_map[key].get("severity", "LOW")
            new_severity = new_issue.get("severity", "LOW")

            # Define severity order
            order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}

            old_level = order.get(old_severity, 99)
            new_level = order.get(new_severity, 99)

            if new_level < old_level:  # Higher severity
                delta.escalated_vulnerabilities.append(new_issue)
            elif new_level > old_level:  # Lower severity
                delta.deescalated_vulnerabilities.append(new_issue)

    return delta


# ---------------------------------------------------------------------------
# Dependency graph comparison
# ---------------------------------------------------------------------------

@dataclass
class GraphDiff:
    """Differences between two dependency graphs."""
    added_nodes: set[str] = field(default_factory=set)
    removed_nodes: set[str] = field(default_factory=set)
    added_edges: list[tuple[str, str]] = field(default_factory=list)
    removed_edges: list[tuple[str, str]] = field(default_factory=list)

    @property
    def total_changes(self) -> int:
        return (len(self.added_nodes) + len(self.removed_nodes) +
                len(self.added_edges) + len(self.removed_edges))

    def is_empty(self) -> bool:
        return self.total_changes == 0


def compare_graphs(old_edges: dict[str, list[str]], new_edges: dict[str, list[str]]) -> GraphDiff:
    """Compare two dependency graphs and return differences."""
    diff = GraphDiff()

    # Find added and removed nodes
    old_nodes = set(old_edges.keys())
    new_nodes = set(new_edges.keys())

    diff.added_nodes = new_nodes - old_nodes
    diff.removed_nodes = old_nodes - new_nodes

    # Find added and removed edges
    old_edge_set = set()
    for node, deps in old_edges.items():
        for dep in deps:
            old_edge_set.add((node, dep))

    new_edge_set = set()
    for node, deps in new_edges.items():
        for dep in deps:
            new_edge_set.add((node, dep))

    diff.added_edges = list(new_edge_set - old_edge_set)
    diff.removed_edges = list(old_edge_set - new_edge_set)

    return diff


# ---------------------------------------------------------------------------
# License compliance checking
# ---------------------------------------------------------------------------

@dataclass
class LicenseIssue:
    """A license compliance issue."""
    package: str
    license: str
    category: str  # "forbidden", "copyleft", "unknown"
    severity: str = "medium"


ALLOWED_LICENSES = {
    "MIT", "Apache-2.0", "Apache 2.0", "BSD-2-Clause", "BSD-3-Clause",
    "ISC", "Unlicense", "Zlib", "PostgreSQL", "Artistic-2.0",
    "Python-2.0", "CC0-1.0", "CC-BY-3.0", "CC-BY-4.0",
}

COPYLEFT_LICENSES = {
    "GPL-2.0", "GPL-3.0", "LGPL-2.1", "LGPL-3.0", "AGPL-3.0",
}

FORBIDDEN_LICENSES = {
    "GPL-1.0", "LGPL-2.0",
}


def check_license_compliance(dependencies: list[dict]) -> list[LicenseIssue]:
    """Check dependencies for license compliance issues."""
    issues = []

    for dep in dependencies:
        license_str = dep.get("license", "").strip()
        if not license_str:
            issues.append(LicenseIssue(
                package=dep["name"],
                license="UNKNOWN",
                category="unknown",
                severity="low"
            ))
            continue

        # Check forbidden licenses
        for forbidden in FORBIDDEN_LICENSES:
            if forbidden.upper() in license_str.upper():
                issues.append(LicenseIssue(
                    package=dep["name"],
                    license=license_str,
                    category="forbidden",
                    severity="high"
                ))

        # Check copyleft licenses
        for copyleft in COPYLEFT_LICENSES:
            if copyleft.upper() in license_str.upper():
                issues.append(LicenseIssue(
                    package=dep["name"],
                    license=license_str,
                    category="copyleft",
                    severity="medium"
                ))

        # Check if not in allowed list
        if license_str not in ALLOWED_LICENSES:
            # Only add if not already flagged
            if not any(i.package == dep["name"] for i in issues):
                issues.append(LicenseIssue(
                    package=dep["name"],
                    license=license_str,
                    category="unknown",
                    severity="low"
                ))

    return issues


# ---------------------------------------------------------------------------
# Package size estimation
# ---------------------------------------------------------------------------

def estimate_package_size(dependencies: list[dict]) -> dict[str, int]:
    """Estimate total size of dependencies in MB."""
    # Rough estimates based on common package sizes
    size_estimates = {
        "numpy": 20,
        "pandas": 25,
        "tensorflow": 450,
        "torch": 500,
        "scipy": 40,
        "matplotlib": 30,
        "pillow": 10,
        "cryptography": 5,
        "django": 15,
        "flask": 1,
    }

    total_mb = 0
    details = {}

    for dep in dependencies:
        name = dep.get("name", "").lower()
        size = size_estimates.get(name, 2)  # Default 2MB
        total_mb += size
        details[name] = size

    return {
        "total_mb": total_mb,
        "details": details,
        "count": len(dependencies),
    }


# ---------------------------------------------------------------------------
# Outdated version analysis
# ---------------------------------------------------------------------------

@dataclass
class OutdatedPackage:
    """A package with an outdated version."""
    name: str
    current_version: str
    latest_version: str
    age_days: int = 0
    update_priority: str = "low"  # "low", "medium", "high", "critical"

    @property
    def major_diff(self) -> bool:
        """Check if there's a major version difference."""
        try:
            current = int(self.current_version.split(".")[0])
            latest = int(self.latest_version.split(".")[0])
            return latest > current
        except (ValueError, IndexError):
            return False


def check_outdated_packages(
    dependencies: list[dict],
    latest_versions: dict[str, str]
) -> list[OutdatedPackage]:
    """Check which packages have outdated versions."""
    outdated = []

    for dep in dependencies:
        name = dep.get("name")
        current = dep.get("version", "0")

        if name not in latest_versions:
            continue

        latest = latest_versions[name]

        if current != latest:
            priority = "low"
            if self.major_diff if hasattr(self, 'major_diff') else False:
                priority = "critical"
            elif self._version_distance(current, latest) > 2:
                priority = "high"
            elif self._version_distance(current, latest) > 0:
                priority = "medium"

            outdated.append(OutdatedPackage(
                name=name,
                current_version=current,
                latest_version=latest,
                update_priority=priority
            ))

    return outdated


def _version_distance(v1: str, v2: str) -> int:
    """Calculate a rough distance between versions."""
    try:
        parts1 = [int(p) for p in v1.split(".") if p.isdigit()]
        parts2 = [int(p) for p in v2.split(".") if p.isdigit()]

        # Compare major.minor
        d1 = parts1[0] if parts1 else 0
        d2 = parts2[0] if parts2 else 0
        dist = abs(d2 - d1) * 100

        m1 = parts1[1] if len(parts1) > 1 else 0
        m2 = parts2[1] if len(parts2) > 1 else 0
        dist += abs(m2 - m1) * 10

        p1 = parts1[2] if len(parts1) > 2 else 0
        p2 = parts2[2] if len(parts2) > 2 else 0
        dist += abs(p2 - p1)

        return dist
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# Compatibility matrix generation
# ---------------------------------------------------------------------------

@dataclass
class CompatibilityEntry:
    """An entry in a compatibility matrix."""
    package_a: str
    package_b: str
    version_a: str
    version_b: str
    compatible: bool
    notes: str = ""


def generate_compatibility_matrix(
    packages: list[str],
    versions: dict[str, list[str]]
) -> list[CompatibilityEntry]:
    """Generate a matrix of package compatibility."""
    matrix = []

    for i, pkg_a in enumerate(packages):
        for j, pkg_b in enumerate(packages):
            if i >= j:  # Only check each pair once
                continue

            # Simple heuristic: assume compatible unless known incompatible
            compatible = True
            notes = ""

            # Check for known incompatibilities
            known_issues = {
                ("numpy", "pandas"): True,
                ("python2", "python3"): False,
            }

            key = (pkg_a.lower(), pkg_b.lower())
            if key in known_issues:
                compatible = known_issues[key]
                notes = "Known compatibility issue" if not compatible else ""

            matrix.append(CompatibilityEntry(
                package_a=pkg_a,
                package_b=pkg_b,
                version_a=versions.get(pkg_a, ["unknown"])[0],
                version_b=versions.get(pkg_b, ["unknown"])[0],
                compatible=compatible,
                notes=notes
            ))

    return matrix


# ---------------------------------------------------------------------------
# Risk scoring utilities
# ---------------------------------------------------------------------------

def calculate_dependency_risk(
    package: str,
    vulnerabilities: list[dict],
    outdated: bool,
    license_allowed: bool,
    maintenance_status: str = "active"
) -> dict[str, Any]:
    """Calculate a risk score for a dependency."""
    score = 0

    # Vulnerability scoring (0-40 points)
    severity_weights = {
        "CRITICAL": 15,
        "HIGH": 10,
        "MEDIUM": 5,
        "LOW": 2,
    }

    for vuln in vulnerabilities:
        severity = vuln.get("severity", "LOW")
        score += severity_weights.get(severity, 1)

    # Outdated penalty (0-20 points)
    if outdated:
        score += 20

    # License penalty (0-15 points)
    if not license_allowed:
        score += 15

    # Maintenance penalty (0-25 points)
    if maintenance_status == "deprecated":
        score += 25
    elif maintenance_status == "not maintained":
        score += 20
    elif maintenance_status == "help wanted":
        score += 10

    # Determine risk category
    if score >= 50:
        category = "critical"
    elif score >= 30:
        category = "high"
    elif score >= 15:
        category = "medium"
    else:
        category = "low"

    return {
        "package": package,
        "score": score,
        "category": category,
        "max_score": 100,
        "risk_factors": {
            "vulnerabilities": len(vulnerabilities),
            "outdated": outdated,
            "license_allowed": license_allowed,
            "maintenance": maintenance_status,
        }
    }