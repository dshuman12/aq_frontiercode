"""Interactive TUI (Text User Interface) for deptrack."""

from __future__ import annotations

import asyncio
import curses
import os
import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Iterator

from deptrack.models import AuditResult, Dependency, Issue, Severity


class ColorPair(Enum):
    """Color pairs for the TUI."""

    DEFAULT = 1
    TITLE = 2
    HEADER = 3
    SUCCESS = 4
    WARNING = 5
    ERROR = 6
    INFO = 7
    HIGHLIGHT = 8
    MUTED = 9


@dataclass
class TableColumn:
    """A column definition for tables."""

    name: str
    width: int
    alignment: str = "<"  # <, >, ^
    truncate: bool = True


@dataclass
class TableRow:
    """A row of data for a table."""

    cells: list[str]
    selected: bool = False
    data: Any = None


class ViewState(Enum):
    """Application view states."""

    LOADING = "loading"
    DASHBOARD = "dashboard"
    DEPENDENCIES = "dependencies"
    ISSUES = "issues"
    DETAIL = "detail"
    SETTINGS = "settings"
    HELP = "help"
    QUIT = "quit"


@dataclass
class AppState:
    """Global application state."""

    current_view: ViewState = ViewState.LOADING
    audit_result: AuditResult | None = None
    selected_index: int = 0
    search_query: str = ""
    filter_severity: Severity | None = None
    sort_by: str = "severity"
    sort_reverse: bool = True
    loading_message: str = ""
    error_message: str | None = None
    scroll_offset: int = 0
    max_visible: int = 20


@dataclass
class TUIRenderer:
    """Renderer for the TUI."""

    stdscr: Any = None
    color_pairs: dict[ColorPair, int] = field(default_factory=dict)
    width: int = 0
    height: int = 0

    def init(self, stdscr: Any) -> None:
        """Initialize the renderer."""
        self.stdscr = stdscr
        curses.curs_set(0)  # Hide cursor
        stdscr.nodelay(True)  # Non-blocking input
        stdscr.timeout(100)  # Update every 100ms

        # Initialize colors
        if curses.has_colors():
            curses.start_color()
            curses.use_default_colors()

            # Define color pairs
            self.color_pairs = {
                ColorPair.DEFAULT: curses.init_pair(1, curses.COLOR_WHITE, -1),
                ColorPair.TITLE: curses.init_pair(2, curses.COLOR_CYAN, -1),
                ColorPair.HEADER: curses.init_pair(3, curses.COLOR_YELLOW, -1),
                ColorPair.SUCCESS: curses.init_pair(4, curses.COLOR_GREEN, -1),
                ColorPair.WARNING: curses.init_pair(5, curses.COLOR_YELLOW, -1),
                ColorPair.ERROR: curses.init_pair(6, curses.COLOR_RED, -1),
                ColorPair.INFO: curses.init_pair(7, curses.COLOR_BLUE, -1),
                ColorPair.HIGHLIGHT: curses.init_pair(8, curses.COLOR_BLACK, curses.COLOR_CYAN),
                ColorPair.MUTED: curses.init_pair(9, curses.COLOR_WHITE, -1),
            }

        self.update_size()

    def update_size(self) -> None:
        """Update terminal dimensions."""
        self.height, self.width = self.stdscr.getmaxyx()

    def clear(self) -> None:
        """Clear the screen."""
        self.stdscr.clear()

    def refresh(self) -> None:
        """Refresh the display."""
        self.stdscr.refresh()

    def get_color(self, pair: ColorPair) -> int:
        """Get a color pair attribute."""
        return curses.color_pair(pair.value)

    def draw_box(
        self,
        y: int,
        x: int,
        height: int,
        width: int,
        title: str = "",
        double: bool = False,
    ) -> None:
        """Draw a box with optional title."""
        h_line = "\u2550" if double else "\u2500"
        v_line = "\u2551" if double else "\u2502"
        tl = "\u2554" if double else "\u250c"
        tr = "\u2557" if double else "\u2510"
        bl = "\u255A" if double else "\u2514"
        br = "\u255D" if double else "\u2518"

        # Top border with title
        self.stdscr.addstr(y, x, tl + (h_line * (width - 2)) + tr)

        if title:
            title_str = f" {title} "
            title_len = len(title_str)
            start = x + (width - title_len) // 2
            self.stdscr.addstr(y, x, tl + (h_line * (start - x - 1)))
            self.stdscr.addstr(y, start, title_str, self.get_color(ColorPair.HEADER))
            self.stdscr.addstr(y, start + title_len, (h_line * (x + width - start - title_len - 1)) + tr)
        else:
            self.stdscr.addstr(y, x, tl + (h_line * (width - 2)) + tr)

        # Side borders
        for i in range(1, height - 1):
            self.stdscr.addstr(y + i, x, v_line)
            self.stdscr.addstr(y + i, x + width - 1, v_line)

        # Bottom border
        self.stdscr.addstr(y + height - 1, x, bl + (h_line * (width - 2)) + br)

    def draw_text(
        self,
        y: int,
        x: int,
        text: str,
        max_width: int = -1,
        color: ColorPair = ColorPair.DEFAULT,
        attr: int = 0,
    ) -> int:
        """Draw text and return the number of lines used."""
        if max_width > 0:
            # Word wrap
            words = text.split()
            line = ""
            lines = 0

            for word in words:
                test_line = line + (" " if line else "") + word
                if len(test_line) <= max_width:
                    line = test_line
                else:
                    if line:
                        self.stdscr.addstr(y + lines, x, line[:max_width], self.get_color(color) | attr)
                        lines += 1
                    line = word

            if line:
                self.stdscr.addstr(y + lines, x, line[:max_width], self.get_color(color) | attr)
                lines += 1

            return max(1, lines)

        else:
            self.stdscr.addstr(y, x, text, self.get_color(color) | attr)
            return 1

    def draw_progress_bar(
        self,
        y: int,
        x: int,
        width: int,
        progress: float,
        label: str = "",
    ) -> None:
        """Draw a progress bar."""
        filled = int(width * progress)
        empty = width - filled

        bar = f"[{'#' * filled}{'-' * empty}]"
        if label:
            bar += f" {label}"

        self.stdscr.addstr(y, x, bar[:width], self.get_color(ColorPair.INFO))


class DependencyDashboard:
    """Dashboard view showing dependency summary."""

    def __init__(self, renderer: TUIRenderer) -> None:
        self.renderer = renderer

    def draw(self, state: AppState) -> None:
        """Draw the dashboard."""
        if state.audit_result is None:
            return

        result = state.audit_result
        summary = result.summary()

        r = self.renderer

        # Header
        r.stdscr.addstr(0, 0, " DepTrack Dependency Dashboard ", r.get_color(ColorPair.TITLE) | curses.A_BOLD)
        r.stdscr.addstr(0, r.width - 15, f" [{result.source_files[0] if result.source_files else 'N/A'}]", r.get_color(ColorPair.MUTED))

        # Summary boxes
        box_y = 2
        boxes = [
            ("Total Dependencies", str(summary["total_dependencies"]), ColorPair.INFO),
            ("Total Issues", str(summary["total_issues"]), ColorPair.WARNING if summary["total_issues"] > 0 else ColorPair.SUCCESS),
            ("Critical", str(summary["critical"]), ColorPair.ERROR),
            ("High", str(summary["high"]), ColorPair.WARNING),
        ]

        box_width = (r.width - 10) // len(boxes)
        for i, (label, value, color) in enumerate(boxes):
            x = 5 + i * (box_width + 1)
            r.draw_box(box_y, x, 5, box_width, label)
            r.stdscr.addstr(box_y + 2, x + 2, value, r.get_color(color) | curses.A_BOLD)

        # Issues breakdown
        issues_y = 9
        r.draw_text(issues_y, 5, "Issue Breakdown:", color=ColorPair.HEADER)
        issues_y += 2

        issues_by_sev = result.issues_by_severity()
        for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
            sev_key = severity.value
            count = len(issues_by_sev.get(sev_key, []))
            if count > 0:
                color = {
                    Severity.CRITICAL: ColorPair.ERROR,
                    Severity.HIGH: ColorPair.WARNING,
                    Severity.MEDIUM: ColorPair.WARNING,
                    Severity.LOW: ColorPair.INFO,
                }[severity]

                r.stdscr.addstr(issues_y, 7, f"{severity.value.upper()}: {count}", r.get_color(color))
                issues_y += 1

        # Dependency health score
        health_y = issues_y + 2
        r.draw_text(health_y, 5, "Dependency Health:", color=ColorPair.HEADER)
        health_y += 2

        health_score = self._calculate_health_score(result)
        bar_width = 50
        r.draw_progress_bar(health_y, 7, bar_width, health_score / 100, f"{health_score:.0f}/100")

        # Quick actions
        actions_y = health_y + 3
        r.draw_text(actions_y, 5, "Actions:", color=ColorPair.HEADER)
        r.draw_text(actions_y + 1, 7, "[D] View Dependencies  [I] View Issues  [Q] Quit", color=ColorPair.MUTED)

        # Footer
        footer_y = r.height - 1
        r.stdscr.addstr(footer_y, 0, "Press ? for help", r.get_color(ColorPair.MUTED))
        r.stdscr.addstr(footer_y, r.width - 20, "Press q to quit", r.get_color(ColorPair.MUTED))

    def _calculate_health_score(self, result: AuditResult) -> float:
        """Calculate a health score from 0-100."""
        if not result.dependencies:
            return 100.0

        score = 100.0

        # Deduct for unpinned
        unpinned = sum(1 for d in result.dependencies if not d.version)
        score -= (unpinned / len(result.dependencies)) * 20

        # Deduct for issues
        for issue in result.issues:
            if issue.severity == Severity.CRITICAL:
                score -= 10
            elif issue.severity == Severity.HIGH:
                score -= 5
            elif issue.severity == Severity.MEDIUM:
                score -= 2
            else:
                score -= 1

        return max(0.0, min(100.0, score))


class DependenciesView:
    """View for browsing dependencies."""

    def __init__(self, renderer: TUIRenderer) -> None:
        self.renderer = renderer

    def draw(self, state: AppState) -> None:
        """Draw the dependencies view."""
        if state.audit_result is None:
            return

        result = state.audit_result
        r = self.renderer

        # Header
        r.stdscr.addstr(0, 0, " Dependencies ", r.get_color(ColorPair.TITLE) | curses.A_BOLD)
        r.stdscr.addstr(0, r.width - 20, f" {len(result.dependencies)} total ", r.get_color(ColorPair.INFO))

        # Table header
        header_y = 2
        columns = [
            ("Name", 30),
            ("Version", 15),
            ("Source", 15),
            ("Issues", 8),
        ]

        x = 2
        for name, width in columns:
            r.stdscr.addstr(header_y, x, f"{name:<{width}}", r.get_color(ColorPair.HEADER) | curses.A_UNDERLINE)
            x += width

        # Filter info
        if state.search_query or state.filter_severity:
            filter_text = []
            if state.search_query:
                filter_text.append(f"Search: {state.search_query}")
            if state.filter_severity:
                filter_text.append(f"Severity: {state.filter_severity.value}")
            r.stdscr.addstr(header_y, r.width - 40, " | ".join(filter_text), r.get_color(ColorPair.MUTED))

        # Dependencies
        deps = self._filter_dependencies(result, state)
        visible_deps = deps[state.scroll_offset:state.scroll_offset + state.max_visible]

        for i, dep in enumerate(visible_deps):
            row_y = header_y + 1 + i
            dep_issues = [issue for issue in result.issues if issue.dep.name == dep.name]
            issue_count = len(dep_issues)

            # Selection highlight
            display_index = state.scroll_offset + i
            if display_index == state.selected_index:
                attr = curses.A_REVERSE
            else:
                attr = 0

            x = 2
            r.stdscr.addstr(row_y, x, f"{dep.name:<30}", r.get_color(ColorPair.DEFAULT) | attr)
            x += 30
            r.stdscr.addstr(row_y, x, f"{dep.version or 'N/A':<15}", r.get_color(ColorPair.DEFAULT) | attr)
            x += 15
            r.stdscr.addstr(row_y, x, f"{(dep.source.value if dep.source else 'N/A'):<15}", r.get_color(ColorPair.MUTED) | attr)
            x += 15

            if issue_count > 0:
                issue_color = ColorPair.ERROR if any(
                    iss.severity in (Severity.CRITICAL, Severity.HIGH) for iss in dep_issues
                ) else ColorPair.WARNING
                r.stdscr.addstr(row_y, x, f"{issue_count:>5}", r.get_color(issue_color) | attr)
            else:
                r.stdscr.addstr(row_y, x, "     0", r.get_color(ColorPair.SUCCESS) | attr)

        # Scroll indicator
        if len(deps) > state.max_visible:
            scroll_info = f"Scroll: {state.scroll_offset + 1}-{min(state.scroll_offset + state.max_visible, len(deps))}/{len(deps)}"
            r.stdscr.addstr(r.height - 2, r.width - len(scroll_info) - 2, scroll_info, r.get_color(ColorPair.MUTED))

        # Footer
        r.stdscr.addstr(r.height - 1, 0, "[↑/↓] Navigate  [Enter] Details  [/] Search  [Esc] Back", r.get_color(ColorPair.MUTED))

    def _filter_dependencies(self, result: AuditResult, state: AppState) -> list[Dependency]:
        """Filter and sort dependencies based on state."""
        deps = list(result.dependencies)

        # Search filter
        if state.search_query:
            query = state.search_query.lower()
            deps = [d for d in deps if query in d.name.lower()]

        # Sort
        if state.sort_by == "name":
            deps.sort(key=lambda d: d.name.lower())
        elif state.sort_by == "version":
            deps.sort(key=lambda d: d.version or "")
        elif state.sort_by == "severity":
            # Sort by number of critical issues first
            deps.sort(
                key=lambda d: sum(
                    10 if i.severity == Severity.CRITICAL
                    else 5 if i.severity == Severity.HIGH
                    else 1
                    for i in result.issues if i.dep.name == d.name
                ),
                reverse=True,
            )

        if state.sort_reverse and state.sort_by != "severity":
            deps.reverse()

        return deps


class IssuesView:
    """View for browsing issues."""

    def __init__(self, renderer: TUIRenderer) -> None:
        self.renderer = renderer

    def draw(self, state: AppState) -> None:
        """Draw the issues view."""
        if state.audit_result is None:
            return

        result = state.audit_result
        r = self.renderer

        # Header
        r.stdscr.addstr(0, 0, " Issues ", r.get_color(ColorPair.TITLE) | curses.A_BOLD)

        total = len(result.issues)
        critical = len([i for i in result.issues if i.severity == Severity.CRITICAL])
        high = len([i for i in result.issues if i.severity == Severity.HIGH])

        status = f" {total} issues "
        if critical > 0:
            status += f"({critical} critical!)"
        elif high > 0:
            status += f"({high} high)"

        r.stdscr.addstr(0, r.width - len(status) - 2, status, r.get_color(ColorPair.WARNING if total > 0 else ColorPair.SUCCESS))

        # Severity filter tabs
        tabs = ["All", "Critical", "High", "Medium", "Low"]
        tab_x = 2
        for tab in tabs:
            active = False
            if tab == "All" and state.filter_severity is None:
                active = True
            elif state.filter_severity and state.filter_severity.value.lower() == tab.lower():
                active = True

            color = ColorPair.HIGHLIGHT if active else ColorPair.DEFAULT
            r.stdscr.addstr(2, tab_x, f"[{tab}]", r.get_color(color) | curses.A_BOLD if active else 0)
            tab_x += len(tab) + 3

        # Issues list
        issues = self._filter_issues(result, state)
        visible_issues = issues[state.scroll_offset:state.scroll_offset + state.max_visible]

        for i, issue in enumerate(visible_issues):
            row_y = 4 + i

            display_index = state.scroll_offset + i
            is_selected = display_index == state.selected_index
            attr = curses.A_REVERSE if is_selected else 0

            # Severity indicator
            sev_color = {
                Severity.CRITICAL: ColorPair.ERROR,
                Severity.HIGH: ColorPair.WARNING,
                Severity.MEDIUM: ColorPair.WARNING,
                Severity.LOW: ColorPair.INFO,
            }[issue.severity]

            sev_indicator = {
                Severity.CRITICAL: "[!]",
                Severity.HIGH: "[W]",
                Severity.MEDIUM: "[w]",
                Severity.LOW: "[i]",
            }[issue.severity]

            # Draw row
            r.stdscr.addstr(row_y, 2, sev_indicator, r.get_color(sev_color) | attr)
            r.stdscr.addstr(row_y, 6, f"{issue.dep.name:<25}", r.get_color(ColorPair.DEFAULT) | attr)
            r.stdscr.addstr(row_y, 32, f"{issue.kind:<15}", r.get_color(ColorPair.MUTED) | attr)

            # Truncate message
            msg = issue.message[:r.width - 60]
            r.stdscr.addstr(row_y, 48, msg, r.get_color(ColorPair.DEFAULT) | attr)

        # Scroll indicator
        if len(issues) > state.max_visible:
            scroll_info = f"Scroll: {state.scroll_offset + 1}-{min(state.scroll_offset + state.max_visible, len(issues))}/{len(issues)}"
            r.stdscr.addstr(r.height - 2, r.width - len(scroll_info) - 2, scroll_info, r.get_color(ColorPair.MUTED))

        # Footer
        r.stdscr.addstr(r.height - 1, 0, "[↑/↓] Navigate  [Enter] Details  [1-4] Filter  [Esc] Back", r.get_color(ColorPair.MUTED))

    def _filter_issues(self, result: AuditResult, state: AppState) -> list[Issue]:
        """Filter issues based on state."""
        issues = list(result.issues)

        # Severity filter
        if state.filter_severity:
            issues = [i for i in issues if i.severity == state.filter_severity]

        # Search filter
        if state.search_query:
            query = state.search_query.lower()
            issues = [
                i for i in issues
                if query in i.dep.name.lower() or query in i.message.lower()
            ]

        # Sort by severity
        severity_order = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2, Severity.LOW: 3}
        issues.sort(key=lambda i: (severity_order.get(i.severity, 99), i.dep.name))

        return issues


class TUIApp:
    """Main TUI application."""

    def __init__(
        self,
        audit_result: AuditResult,
        on_quit: Callable[[], None] | None = None,
    ) -> None:
        self.state = AppState()
        self.state.audit_result = audit_result
        self.state.current_view = ViewState.DASHBOARD
        self.state.max_visible = 20
        self.on_quit = on_quit

    def run(self, stdscr: Any) -> None:
        """Run the TUI application."""
        self.renderer = TUIRenderer()
        self.renderer.init(stdscr)

        # Initialize views
        self.views = {
            ViewState.DASHBOARD: DependencyDashboard(self.renderer),
            ViewState.DEPENDENCIES: DependenciesView(self.renderer),
            ViewState.ISSUES: IssuesView(self.renderer),
        }

        self.state.current_view = ViewState.DASHBOARD

        # Main loop
        running = True
        while running:
            self.renderer.update_size()
            self.state.max_visible = self.renderer.height - 6

            self.renderer.clear()

            # Draw current view
            view = self.views.get(self.state.current_view)
            if view:
                view.draw(self.state)

            # Handle input
            key = stdscr.getch()
            running = self._handle_input(key)

            self.renderer.refresh()

            # Small delay to prevent CPU spinning
            time.sleep(0.05)

    def _handle_input(self, key: int) -> bool:
        """Handle keyboard input. Returns False to quit."""
        # Handle navigation
        if key in (curses.KEY_UP, ord("k")):
            if self.state.selected_index > 0:
                self.state.selected_index -= 1
                if self.state.selected_index < self.state.scroll_offset:
                    self.state.scroll_offset = self.state.selected_index
        elif key in (curses.KEY_DOWN, ord("j")):
            max_index = self._get_max_index()
            if self.state.selected_index < max_index:
                self.state.selected_index += 1
                if self.state.selected_index >= self.state.scroll_offset + self.state.max_visible:
                    self.state.scroll_offset = self.state.selected_index - self.state.max_visible + 1
        elif key in (curses.KEY_PPAGE,):
            # Page up
            self.state.scroll_offset = max(0, self.state.scroll_offset - self.state.max_visible)
        elif key in (curses.KEY_NPAGE,):
            # Page down
            max_index = self._get_max_index()
            self.state.scroll_offset = min(
                max(0, max_index - self.state.max_visible + 1),
                self.state.scroll_offset + self.state.max_visible
            )

        # Handle view switching
        elif key in (ord("d"), ord("D")):
            self.state.current_view = ViewState.DEPENDENCIES
            self.state.selected_index = 0
            self.state.scroll_offset = 0
        elif key in (ord("i"), ord("I")):
            self.state.current_view = ViewState.ISSUES
            self.state.selected_index = 0
            self.state.scroll_offset = 0
        elif key in (ord("q"), ord("Q")):
            return False

        # Handle severity filters
        elif key == ord("1"):
            self.state.filter_severity = Severity.CRITICAL
        elif key == ord("2"):
            self.state.filter_severity = Severity.HIGH
        elif key == ord("3"):
            self.state.filter_severity = Severity.MEDIUM
        elif key == ord("4"):
            self.state.filter_severity = Severity.LOW
        elif key == ord("0"):
            self.state.filter_severity = None

        # Search
        elif key == ord("/"):
            # TODO: Implement search input
            pass

        # Go back
        elif key in (27,):  # Escape
            self.state.current_view = ViewState.DASHBOARD

        # Help
        elif key == ord("?"):
            self.state.current_view = ViewState.HELP

        return True

    def _get_max_index(self) -> int:
        """Get the maximum valid index for the current view."""
        if self.state.audit_result is None:
            return 0

        if self.state.current_view == ViewState.DEPENDENCIES:
            return len(self.state.audit_result.dependencies) - 1
        elif self.state.current_view == ViewState.ISSUES:
            return len(self.state.audit_result.issues) - 1

        return 0


def run_tui(audit_result: AuditResult) -> None:
    """Run the TUI application."""
    def cleanup():
        pass

    curses.wrapper(lambda stdscr: TUIApp(audit_result).run(stdscr))


def run_tui_async(audit_result: AuditResult) -> None:
    """Run TUI in async mode (for Jupyter notebooks)."""
    import threading

    def run_in_thread():
        curses.wrapper(lambda stdscr: TUIApp(audit_result).run(stdscr))

    thread = threading.Thread(target=run_in_thread, daemon=True)
    thread.start()

    try:
        while thread.is_alive():
            thread.join(timeout=0.1)
    except KeyboardInterrupt:
        pass


class ProgressTracker:
    """Track and display progress for long-running operations."""

    def __init__(self, total: int, description: str = "Processing") -> None:
        self.total = total
        self.current = 0
        self.description = description
        self.start_time = time.time()

    def update(self, amount: int = 1) -> None:
        """Update progress by amount."""
        self.current = min(self.total, self.current + amount)

    def set_progress(self, value: int) -> None:
        """Set absolute progress value."""
        self.current = min(self.total, max(0, value))

    @property
    def percent(self) -> float:
        """Get completion percentage."""
        if self.total == 0:
            return 100.0
        return (self.current / self.total) * 100

    @property
    def elapsed(self) -> float:
        """Get elapsed time in seconds."""
        return time.time() - self.start_time

    @property
    def estimated_remaining(self) -> float | None:
        """Estimate remaining time in seconds."""
        if self.current == 0:
            return None
        elapsed = self.elapsed
        rate = self.current / elapsed
        if rate == 0:
            return None
        remaining = self.total - self.current
        return remaining / rate

    def format_bar(self, width: int = 50) -> str:
        """Format progress as a text bar."""
        filled = int(width * self.current / max(self.total, 1))
        empty = width - filled

        # Calculate ETA
        eta = self.estimated_remaining
        if eta is not None:
            eta_str = f"ETA: {eta:.0f}s"
        else:
            eta_str = ""

        return f"[{'#' * filled}{'-' * empty}] {self.current}/{self.total} {self.percent:.1f}% {eta_str}"

    def __str__(self) -> str:
        return self.format_bar()


def format_table(
    headers: list[str],
    rows: list[list[str]],
    column_widths: list[int] | None = None,
    max_width: int = 80,
) -> str:
    """Format data as an ASCII table."""
    if not headers or not rows:
        return ""

    # Calculate column widths if not provided
    if column_widths is None:
        column_widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                if i < len(column_widths):
                    column_widths[i] = max(column_widths[i], len(str(cell)))

        # Respect max width
        total = sum(column_widths) + len(headers) * 3 + 1
        if total > max_width:
            scale = max_width / total
            column_widths = [max(5, int(w * scale)) for w in column_widths]

    # Build table
    lines = []

    # Header
    header_line = "|".join(
        f" {h:<{w}} " for h, w in zip(headers, column_widths)
    )
    lines.append("+" + "-" * (len(header_line) - 2) + "+")
    lines.append(header_line)
    lines.append("+" + "=" * (len(header_line) - 2) + "+")

    # Rows
    for row in rows:
        row_cells = []
        for i, cell in enumerate(row):
            if i < len(column_widths):
                cell_str = str(cell)[:column_widths[i]]
                row_cells.append(f" {cell_str:<{column_widths[i]}} ")
            else:
                row_cells.append(f" {str(cell)[:20]:<20} ")

        lines.append("|" + "|".join(row_cells) + "|")

    lines.append("+" + "-" * (len(header_line) - 2) + "+")

    return "\n".join(lines)