"""Configuration loader for deptrack.

Reads .deptrack.toml or deptrack section in pyproject.toml.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]

CONFIG_FILENAME = ".deptrack.toml"


@dataclass
class DeptrackConfig:
    """Runtime configuration for deptrack."""

    # Checkers to enable/disable
    check_unpinned: bool = True
    check_wildcard: bool = True
    check_missing_upper_bound: bool = True
    check_duplicates: bool = True
    check_vulnerabilities: bool = True
    check_prerelease: bool = False  # off by default — common in dev environments

    # Severity thresholds
    fail_on: str = "none"  # none, any, high, critical

    # Packages to ignore
    ignore_packages: list[str] = field(default_factory=list)
    ignore_kinds: list[str] = field(default_factory=list)

    # Advisory database
    advisory_db: str | None = None

    # Reporting
    default_format: str = "text"  # text, json, html

    # File discovery
    exclude_paths: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeptrackConfig":
        """Create a config from a dictionary (e.g. parsed TOML)."""
        cfg = cls()
        for key, value in data.items():
            if hasattr(cfg, key):
                setattr(cfg, key, value)
        return cfg

    def to_dict(self) -> dict[str, Any]:
        return {
            "check_unpinned": self.check_unpinned,
            "check_wildcard": self.check_wildcard,
            "check_missing_upper_bound": self.check_missing_upper_bound,
            "check_duplicates": self.check_duplicates,
            "check_vulnerabilities": self.check_vulnerabilities,
            "check_prerelease": self.check_prerelease,
            "fail_on": self.fail_on,
            "ignore_packages": self.ignore_packages,
            "ignore_kinds": self.ignore_kinds,
            "advisory_db": self.advisory_db,
            "default_format": self.default_format,
            "exclude_paths": self.exclude_paths,
        }


def load_config(root: Path | None = None) -> DeptrackConfig:
    """
    Load deptrack configuration from the nearest config file.

    Search order:
    1. .deptrack.toml in root (or cwd)
    2. [tool.deptrack] section in pyproject.toml
    3. Default config if nothing found
    """
    search_root = root or Path.cwd()

    # Try .deptrack.toml first
    config_path = search_root / CONFIG_FILENAME
    if config_path.exists():
        return _load_toml_config(config_path, section=None)

    # Try pyproject.toml [tool.deptrack]
    pyproject_path = search_root / "pyproject.toml"
    if pyproject_path.exists():
        cfg = _load_pyproject_config(pyproject_path)
        if cfg is not None:
            return cfg

    return DeptrackConfig()


def _load_toml_config(path: Path, section: str | None) -> DeptrackConfig:
    """Load config from a TOML file, optionally under a section key."""
    if tomllib is None:
        return DeptrackConfig()
    try:
        with open(path, "rb") as fh:
            data = tomllib.load(fh)
        if section:
            data = data.get(section, {})
        return DeptrackConfig.from_dict(data)
    except Exception:
        return DeptrackConfig()


def _load_pyproject_config(path: Path) -> DeptrackConfig | None:
    """Load [tool.deptrack] section from pyproject.toml."""
    if tomllib is None:
        return None
    try:
        with open(path, "rb") as fh:
            data = tomllib.load(fh)
        section = data.get("tool", {}).get("deptrack")
        if section is None:
            return None
        return DeptrackConfig.from_dict(section)
    except Exception:
        return None


def write_default_config(path: Path) -> None:
    """Write a default .deptrack.toml to the given path."""
    cfg = DeptrackConfig()
    lines = ["# deptrack configuration\n\n"]
    d = cfg.to_dict()
    for key, value in d.items():
        if isinstance(value, bool):
            lines.append(f"{key} = {'true' if value else 'false'}\n")
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"\n')
        elif isinstance(value, list):
            if value:
                items = ", ".join(f'"{v}"' for v in value)
                lines.append(f"{key} = [{items}]\n")
            else:
                lines.append(f"{key} = []\n")
        elif value is None:
            lines.append(f"# {key} = \"\"\n")
    path.write_text("".join(lines), encoding="utf-8")
