"""Core data models for deptrack."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Severity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DepSource(Enum):
    REQUIREMENTS_TXT = "requirements.txt"
    PYPROJECT_TOML = "pyproject.toml"
    SETUP_CFG = "setup.cfg"
    SETUP_PY = "setup.py"
    PIPFILE = "Pipfile"


@dataclass
class Dependency:
    """Represents a single Python dependency."""

    name: str
    version: Optional[str] = None
    extras: list[str] = field(default_factory=list)
    markers: Optional[str] = None
    source: Optional[DepSource] = None
    raw_line: Optional[str] = None

    def __post_init__(self) -> None:
        self.name = self.normalize_name(self.name)

    @staticmethod
    def normalize_name(name: str) -> str:
        """Normalize package name per PEP 503."""
        import re
        return re.sub(r"[-_.]+", "-", name).lower()

    @property
    def canonical_name(self) -> str:
        return self.normalize_name(self.name)

    def __hash__(self) -> int:
        return hash(self.canonical_name)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Dependency):
            return NotImplemented
        return self.canonical_name == other.canonical_name

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "extras": self.extras,
            "markers": self.markers,
            "source": self.source.value if self.source else None,
        }


@dataclass
class Issue:
    """Represents a detected dependency issue."""

    dep: Dependency
    kind: str
    message: str
    severity: Severity = Severity.MEDIUM
    fix_suggestion: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "package": self.dep.name,
            "version": self.dep.version,
            "kind": self.kind,
            "message": self.message,
            "severity": self.severity.value,
            "fix": self.fix_suggestion,
        }


@dataclass
class AuditResult:
    """Aggregated result of a full dependency audit."""

    dependencies: list[Dependency] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    source_files: list[str] = field(default_factory=list)

    @property
    def has_issues(self) -> bool:
        return len(self.issues) > 0

    @property
    def critical_issues(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == Severity.CRITICAL]

    @property
    def high_issues(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == Severity.HIGH]

    def issues_by_severity(self) -> dict[str, list[Issue]]:
        result: dict[str, list[Issue]] = {}
        for issue in self.issues:
            key = issue.severity.value
            result.setdefault(key, []).append(issue)
        return result

    def summary(self) -> dict:
        by_sev = self.issues_by_severity()
        return {
            "total_dependencies": len(self.dependencies),
            "total_issues": len(self.issues),
            "critical": len(by_sev.get("critical", [])),
            "high": len(by_sev.get("high", [])),
            "medium": len(by_sev.get("medium", [])),
            "low": len(by_sev.get("low", [])),
        }


@dataclass
class LockEntry:
    """An entry in deptrack's lockfile."""

    name: str
    version: str
    hash_sha256: str
    dependencies: list[str] = field(default_factory=list)

    @classmethod
    def from_dependency(cls, dep: Dependency, content: bytes) -> "LockEntry":
        sha = hashlib.sha256(content).hexdigest()
        return cls(
            name=dep.name,
            version=dep.version or "unknown",
            hash_sha256=sha,
            dependencies=[],
        )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "hash_sha256": self.hash_sha256,
            "dependencies": self.dependencies,
        }


def get_severity_order(severity: Severity) -> int:
    """Return sort order for severity (lower = more severe)."""
    order = {
        Severity.CRITICAL: 0,
        Severity.HIGH: 1,
        Severity.MEDIUM: 2,
        Severity.LOW: 3,
    }
    return order.get(severity, 99)

    def issues_by_package(self) -> dict[str, list["Issue"]]:
        """Group issues by package name."""
        result: dict[str, list["Issue"]] = {}
        for issue in self.issues:
            result.setdefault(issue.dep.name, []).append(issue)
        return result


@dataclass
class ResolutionResult:
    """Result of attempting to resolve a set of dependencies."""

    resolved: list[Dependency] = field(default_factory=list)
    unresolved: list[str] = field(default_factory=list)
    conflicts: list[tuple[Dependency, Dependency]] = field(default_factory=list)

    @property
    def is_clean(self) -> bool:
        return not self.unresolved and not self.conflicts

    def to_dict(self) -> dict:
        return {
            "resolved": [d.to_dict() for d in self.resolved],
            "unresolved": self.unresolved,
            "conflicts": [
                {"a": a.to_dict(), "b": b.to_dict()} for a, b in self.conflicts
            ],
        }


@dataclass
class VersionSpec:
    """Parsed version specifier with operator and version tuple."""

    operator: str
    version_str: str
    version_tuple: tuple[int, ...]

    @classmethod
    def parse(cls, spec: str) -> Optional["VersionSpec"]:
        import re
        m = re.match(r"^(==|!=|<=|>=|~=|<|>)\s*([\d.]+)", spec.strip())
        if not m:
            return None
        op = m.group(1)
        ver_str = m.group(2)
        parts = []
        for p in ver_str.split("."):
            try:
                parts.append(int(p))
            except ValueError:
                break
        return cls(operator=op, version_str=ver_str, version_tuple=tuple(parts))

    def matches(self, version_tuple: tuple[int, ...]) -> bool:
        """Check whether a given version tuple satisfies this specifier."""
        op = self.operator
        lhs = version_tuple
        rhs = self.version_tuple
        # Pad shorter tuple with zeros
        max_len = max(len(lhs), len(rhs))
        lhs = lhs + (0,) * (max_len - len(lhs))
        rhs = rhs + (0,) * (max_len - len(rhs))
        if op == "==":
            return lhs == rhs
        if op == "!=":
            return lhs != rhs
        if op == "<":
            return lhs < rhs
        if op == "<=":
            return lhs <= rhs
        if op == ">":
            return lhs > rhs
        if op == ">=":
            return lhs >= rhs
        if op == "~=":
            return lhs >= rhs and lhs[: len(rhs) - 1] == rhs[: len(rhs) - 1]
        return False

    def __str__(self) -> str:
        return f"{self.operator}{self.version_str}"


@dataclass
class PackageMetadata:
    """Extended metadata for a package, typically fetched from PyPI."""

    name: str
    version: str
    summary: str = ""
    author: str = ""
    author_email: str = ""
    license: str = ""
    home_page: str = ""
    requires_python: str = ""
    keywords: list[str] = field(default_factory=list)
    classifiers: list[str] = field(default_factory=list)
    requires_dist: list[str] = field(default_factory=list)
    project_urls: dict[str, str] = field(default_factory=dict)
    yanked: bool = False
    yanked_reason: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "summary": self.summary,
            "author": self.author,
            "license": self.license,
            "home_page": self.home_page,
            "requires_python": self.requires_python,
            "yanked": self.yanked,
        }

    @property
    def is_yanked(self) -> bool:
        return self.yanked

    def supports_python(self, python_version: str) -> bool:
        """Check if this package supports the given Python version string."""
        if not self.requires_python:
            return True
        spec = VersionSpec.parse(self.requires_python)
        if spec is None:
            return True
        parts = []
        for p in python_version.split("."):
            try:
                parts.append(int(p))
            except ValueError:
                break
        return spec.matches(tuple(parts))


# --- Optional type import for older Python compat ---
from typing import Optional  # noqa: E402


@dataclass
class DependencySet:
    """
    An ordered, deduplicated collection of dependencies with fast lookup.

    Behaves like a list but provides O(1) membership tests by canonical name.
    """

    _deps: list[Dependency] = field(default_factory=list)
    _index: dict[str, int] = field(default_factory=dict)

    def add(self, dep: Dependency) -> bool:
        """Add a dependency. Returns True if added, False if already present."""
        name = dep.canonical_name
        if name in self._index:
            return False
        self._index[name] = len(self._deps)
        self._deps.append(dep)
        return True

    def get(self, name: str) -> Optional[Dependency]:
        """Look up a dependency by name (case-insensitive, normalised)."""
        idx = self._index.get(Dependency.normalize_name(name))
        if idx is None:
            return None
        return self._deps[idx]

    def remove(self, name: str) -> bool:
        """Remove a dependency by name. Returns True if it existed."""
        norm = Dependency.normalize_name(name)
        if norm not in self._index:
            return False
        idx = self._index.pop(norm)
        self._deps.pop(idx)
        # Rebuild index after removal
        self._index = {d.canonical_name: i for i, d in enumerate(self._deps)}
        return True

    def __contains__(self, name: str) -> bool:
        return Dependency.normalize_name(name) in self._index

    def __iter__(self):
        return iter(self._deps)

    def __len__(self) -> int:
        return len(self._deps)

    def __repr__(self) -> str:
        return f"DependencySet({[d.name for d in self._deps]!r})"

    def to_list(self) -> list[Dependency]:
        return list(self._deps)

    def names(self) -> list[str]:
        return [d.canonical_name for d in self._deps]

    def merge(self, other: "DependencySet") -> "DependencySet":
        """Return a new DependencySet containing deps from both sets."""
        result = DependencySet()
        for dep in self._deps:
            result.add(dep)
        for dep in other:
            result.add(dep)
        return result

    def filter(self, predicate) -> "DependencySet":
        """Return a new DependencySet containing only deps matching predicate."""
        result = DependencySet()
        for dep in self._deps:
            if predicate(dep):
                result.add(dep)
        return result
