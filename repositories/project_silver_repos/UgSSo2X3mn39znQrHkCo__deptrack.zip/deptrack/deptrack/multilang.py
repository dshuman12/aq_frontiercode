"""Multi-language package ecosystem support beyond Python/PyPI.

This module provides parsers and checkers for:
- JavaScript/TypeScript (npm, yarn, pnpm)
- Java (Maven, Gradle)
- Go (go.mod)
- Rust (Cargo)
- Ruby (Gemfile)
- PHP (composer)
- .NET (PackageReference, paket)
"""

from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Iterator


class Ecosystem(Enum):
    """Supported package ecosystems."""

    PYTHON = "python"
    NPM = "npm"
    YARN = "yarn"
    PNPM = "pnpm"
    MAVEN = "maven"
    GRADLE = "gradle"
    GO = "go"
    CARGO = "cargo"
    RUBY = "ruby"
    COMPOSER = "composer"
    DOTNET = "dotnet"
    PAKET = "paket"


@dataclass
class Package:
    """A generic package representation across ecosystems."""

    name: str
    version: str | None = None
    ecosystem: Ecosystem = Ecosystem.PYTHON
    raw_line: str = ""
    source_file: str = ""
    dev_dependency: bool = False
    optional: bool = False
    extras: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def canonical_name(self) -> str:
        """Normalize package name for comparison."""
        return self.name.lower().replace("-", "_").replace(".", "-")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
            "ecosystem": self.ecosystem.value,
            "dev_dependency": self.dev_dependency,
            "optional": self.optional,
        }

    def to_cyclonedx(self) -> dict[str, Any]:
        """Convert to CycloneDX format."""
        return {
            "name": self.name,
            "version": self.version or "unknown",
            "scope": "required" if not self.dev_dependency else "optional",
        }


class PackageLockParser(ABC):
    """Abstract base class for package lock file parsers."""

    @abstractmethod
    def parse(self, path: Path) -> list[Package]:
        """Parse a lock file and return list of packages."""
        pass

    @abstractmethod
    def get_lockfile_name(self) -> str:
        """Return the expected lockfile name."""
        pass

    def supports_file(self, path: Path) -> bool:
        """Check if this parser supports a given file."""
        return path.name == self.get_lockfile_name()


class RequirementsTxtParser:
    """Parser for Python requirements.txt files."""

    def parse(self, content: str) -> Iterator[Package]:
        """Parse requirements.txt content."""
        for line_num, line in enumerate(content.splitlines(), 1):
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            # Handle -r include directives
            if line.startswith("-r ") or line.startswith("--requirement "):
                continue

            # Handle -e editable installs
            if line.startswith("-e ") or line.startswith("--editable "):
                continue

            # Parse package specification
            pkg = self._parse_line(line)
            if pkg:
                pkg.source_file = "requirements.txt"
                yield pkg

    def _parse_line(self, line: str) -> Package | None:
        """Parse a single requirements line."""
        # Remove comments
        if " #" in line:
            line = line.split(" #")[0].strip()

        # Parse extras and markers
        extras = []
        markers = None

        # Check for environment markers
        marker_match = re.search(r";\s*(.+)$", line)
        if marker_match:
            markers = marker_match.group(1).strip()
            line = line[:marker_match.start()].strip()

        # Check for extras
        extra_match = re.match(r"^(.+?)\s*\[([^\]]+)\]", line)
        if extra_match:
            line = extra_match.group(1)
            extras = [e.strip() for e in extra_match.group(2).split(",")]

        # Parse version specifier
        version_match = re.match(r"^([a-zA-Z0-9_\-\.]+)\s*([<>=!~]+.*)?$", line)
        if not version_match:
            return None

        name = version_match.group(1)
        version = version_match.group(2) if version_match.group(2) else None

        return Package(
            name=name,
            version=version,
            ecosystem=Ecosystem.PYTHON,
            raw_line=line,
            extras=extras,
            metadata={"markers": markers},
        )


class PipfileParser:
    """Parser for Pipfile and Pipfile.lock."""

    def parse(self, path: Path) -> list[Package]:
        """Parse Pipfile or Pipfile.lock."""
        packages = []

        if path.name == "Pipfile.lock" and path.exists():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            for section, deps in data.get("default", {}).items():
                if isinstance(deps, dict):
                    pkg = Package(
                        name=section,
                        version=deps.get("version", ""),
                        ecosystem=Ecosystem.PYTHON,
                        source_file=str(path),
                    )
                    packages.append(pkg)

            for section, deps in data.get("develop", {}).items():
                if isinstance(deps, dict):
                    pkg = Package(
                        name=section,
                        version=deps.get("version", ""),
                        ecosystem=Ecosystem.PYTHON,
                        source_file=str(path),
                        dev_dependency=True,
                    )
                    packages.append(pkg)
        elif path.name == "Pipfile" and path.exists():
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()

            in_packages = False
            in_dev_packages = False

            for line in content.splitlines():
                line = line.strip()

                if line == "[packages]":
                    in_packages = True
                    in_dev_packages = False
                    continue
                elif line == "[dev-packages]":
                    in_packages = False
                    in_dev_packages = True
                    continue
                elif line.startswith("["):
                    in_packages = False
                    in_dev_packages = False
                    continue

                if not line or line.startswith("#"):
                    continue

                if "=" in line:
                    name, version = line.split("=", 1)
                    name = name.strip()
                    version = version.strip().strip('"').strip("'")

                    pkg = Package(
                        name=name,
                        version=version if version != "*" else None,
                        ecosystem=Ecosystem.PYTHON,
                        source_file=str(path),
                        dev_dependency=in_dev_packages,
                    )
                    packages.append(pkg)

        return packages


class NpmLockParser(PackageLockParser):
    """Parser for package-lock.json (npm) and yarn.lock."""

    def parse(self, path: Path) -> list[Package]:
        """Parse package-lock.json."""
        packages = []

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # npm v2/v3 format
        if "dependencies" in data:
            packages.extend(self._parse_npm_deps(data["dependencies"], ""))

        # npm v7+ format (lockfileVersion 2)
        if "packages" in data:
            for pkg_path, pkg_data in data["packages"].items():
                if pkg_path == "":  # Skip root
                    continue

                name = pkg_path.split("node_modules/")[-1]
                version = pkg_data.get("version")

                pkg = Package(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.NPM,
                    source_file=str(path),
                    dev_dependency=pkg_data.get("dev", False),
                    optional=pkg_data.get("optional", False),
                    metadata=pkg_data,
                )
                packages.append(pkg)

        return packages

    def _parse_npm_deps(
        self,
        deps: dict,
        parent_path: str,
    ) -> list[Package]:
        """Recursively parse npm dependencies."""
        packages = []

        for name, data in deps.items():
            if isinstance(data, str):
                version = data
            elif isinstance(data, dict):
                version = data.get("version")
            else:
                continue

            pkg = Package(
                name=name,
                version=version,
                ecosystem=Ecosystem.NPM,
                source_file=parent_path,
            )
            packages.append(pkg)

            if isinstance(data, dict) and "requires" in data:
                pkg.dependencies = list(data["requires"].keys())

            if isinstance(data, dict) and "dependencies" in data:
                packages.extend(self._parse_npm_deps(data["dependencies"], f"{parent_path}/{name}"))

        return packages

    def get_lockfile_name(self) -> str:
        return "package-lock.json"


class YarnLockParser(PackageLockParser):
    """Parser for yarn.lock files."""

    def parse(self, path: Path) -> list[Package]:
        """Parse yarn.lock."""
        packages = []

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        current_package = None
        current_version = None
        current_data: dict[str, Any] = {}

        for line in content.splitlines():
            if not line.strip():
                continue

            # Check if this is a package header
            match = re.match(r'^"?(@?[^"@\s]+)@([^"\s]+)"?:?$', line)
            if match:
                # Save previous package
                if current_package:
                    pkg = Package(
                        name=current_package,
                        version=current_version,
                        ecosystem=Ecosystem.YARN,
                        source_file=str(path),
                        metadata=current_data,
                    )
                    packages.append(pkg)

                current_package = match.group(1)
                current_version = match.group(2)
                current_data = {}
                continue

            # Parse property lines
            prop_match = re.match(r'^\s+([a-z_]+):\s*(.+)$', line)
            if prop_match and current_package:
                key = prop_match.group(1)
                value = prop_match.group(2).strip().strip('"')
                current_data[key] = value

        # Don't forget the last package
        if current_package:
            pkg = Package(
                name=current_package,
                version=current_version,
                ecosystem=Ecosystem.YARN,
                source_file=str(path),
                metadata=current_data,
            )
            packages.append(pkg)

        return packages

    def get_lockfile_name(self) -> str:
        return "yarn.lock"


class PnpmLockParser(PackageLockParser):
    """Parser for pnpm-lock.yaml."""

    def parse(self, path: Path) -> list[Package]:
        """Parse pnpm-lock.yaml."""
        packages = []

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        # pnpm lockfile format
        current_spec = None
        current_version = None

        for line in content.splitlines():
            if not line.strip() or line.startswith("#"):
                continue

            # Package specifier
            if not line.startswith("  ") and ":" in line:
                spec = line.split(":")[0].strip()
                if "/" in spec or spec.startswith("@"):
                    current_spec = spec

            # Version line
            version_match = re.match(r"^\s+version:\s*['\"]?([^'\"\s]+)['\"]?", line)
            if version_match and current_spec:
                current_version = version_match.group(1)

                pkg = Package(
                    name=current_spec,
                    version=current_version,
                    ecosystem=Ecosystem.PNPM,
                    source_file=str(path),
                )
                packages.append(pkg)

        return packages

    def get_lockfile_name(self) -> str:
        return "pnpm-lock.yaml"


class PomXmlParser:
    """Parser for Maven pom.xml files."""

    def parse(self, path: Path) -> list[Package]:
        """Parse pom.xml and extract dependencies."""
        packages = []

        tree = ET.parse(path)
        root = tree.getroot()

        # Handle XML namespaces
        ns = {"m": "http://maven.apache.org/POM/4.0.0"}

        # Parse dependencies
        deps = root.findall(".//m:dependency", ns)
        if not deps:
            # Try without namespace
            deps = root.findall(".//dependency")

        for dep in deps:
            group_id = self._get_text(dep, "groupId", ns)
            artifact_id = self._get_text(dep, "artifactId", ns)
            version = self._get_text(dep, "version", ns)

            # Handle version placeholders
            if version and version.startswith("${"):
                version = None

            if artifact_id:
                name = f"{group_id}:{artifact_id}" if group_id else artifact_id
                pkg = Package(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.MAVEN,
                    source_file=str(path),
                )
                packages.append(pkg)

        return packages

    @staticmethod
    def _get_text(elem: ET.Element, tag: str, ns: dict[str, str]) -> str | None:
        """Get text content of an element."""
        child = elem.find(f"m:{tag}", ns)
        if child is None:
            child = elem.find(tag)
        if child is not None and child.text:
            return child.text.strip()
        return None


class GoModParser:
    """Parser for go.mod files."""

    def parse(self, path: Path) -> list[Package]:
        """Parse go.mod file."""
        packages = []

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        in_require = False
        in_replace = False

        for line in content.splitlines():
            line = line.strip()

            if line == "require (":
                in_require = True
                continue
            elif line == "replace (":
                in_replace = True
                continue
            elif line == ")":
                in_require = False
                in_replace = False
                continue

            if line.startswith("module "):
                continue

            if in_replace:
                continue

            if in_require or line:
                # Parse require lines
                match = re.match(r"^\s*([^\s]+)\s+v?([^\s]+)", line)
                if match:
                    name, version = match.groups()

                    # Skip pseudo-versions
                    if not re.match(r"^v?\d+\.\d+", version):
                        continue

                    pkg = Package(
                        name=name,
                        version=version,
                        ecosystem=Ecosystem.GO,
                        source_file=str(path),
                    )
                    packages.append(pkg)

        return packages


class CargoTomlParser:
    """Parser for Cargo.toml files."""

    def parse(self, path: Path) -> list[Package]:
        """Parse Cargo.toml file."""
        packages = []
        in_dependencies = False
        in_dev_dependencies = False
        in_build_dependencies = False

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        for line in content.splitlines():
            line = line.strip()

            # Detect section headers
            if line == "[dependencies]":
                in_dependencies = True
                in_dev_dependencies = False
                in_build_dependencies = False
                continue
            elif line == "[dev-dependencies]":
                in_dependencies = False
                in_dev_dependencies = True
                continue
            elif line == "[build-dependencies]":
                in_dependencies = False
                in_dev_dependencies = False
                in_build_dependencies = True
                continue
            elif line.startswith("["):
                in_dependencies = False
                in_dev_dependencies = False
                in_build_dependencies = False
                continue

            if not (in_dependencies or in_dev_dependencies or in_build_dependencies):
                continue

            if not line or line.startswith("#"):
                continue

            # Parse dependency
            # Format: package_name = "version" or package_name = { version = "...", ... }
            match = re.match(r"^([a-zA-Z0-9_\-]+)\s*=\s*(.+)$", line)
            if match:
                name = match.group(1)
                value = match.group(2).strip()

                version = None
                if value.startswith('"'):
                    # Simple version string
                    version_match = re.match(r'"([^"]+)"', value)
                    if version_match:
                        version = version_match.group(1)
                else:
                    # Table format
                    version_match = re.search(r'version\s*=\s*"([^"]+)"', value)
                    if version_match:
                        version = version_match.group(1)

                pkg = Package(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.CARGO,
                    source_file=str(path),
                    dev_dependency=in_dev_dependencies,
                )
                packages.append(pkg)

        return packages


class GemfileParser:
    """Parser for Gemfile (Ruby)."""

    def parse(self, path: Path) -> list[Package]:
        """Parse Gemfile."""
        packages = []

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        in_group = None

        for line in content.splitlines():
            line = line.strip()

            # Group declarations
            group_match = re.match(r"^group\s+:([^\s,]+)", line)
            if group_match:
                in_group = group_match.group(1)
                continue

            # End of group
            if line == "end" and in_group:
                in_group = None
                continue

            # Gem declarations
            gem_match = re.match(r"^gem\s+['\"]([^'\"]+)['\"](?:,\s*(.+))?", line)
            if gem_match:
                name = gem_match.group(1)
                rest = gem_match.group(2) or ""

                version = None
                version_match = re.search(r"['\"]~>?\s*([0-9.]+)", rest)
                if version_match:
                    version = version_match.group(1)
                else:
                    version_match = re.search(r"['\"]([0-9.]+)['\"]", rest)
                    if version_match:
                        version = version_match.group(1)

                pkg = Package(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.RUBY,
                    source_file=str(path),
                    dev_dependency=in_group in ("development", "test"),
                )
                packages.append(pkg)

        return packages


class ComposerJsonParser:
    """Parser for composer.json (PHP)."""

    def parse(self, path: Path) -> list[Package]:
        """Parse composer.json."""
        packages = []

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Parse require
        for name, version in data.get("require", {}).items():
            if name == "php":
                continue
            if isinstance(version, str):
                pkg = Package(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.COMPOSER,
                    source_file=str(path),
                )
                packages.append(pkg)

        # Parse require-dev
        for name, version in data.get("require-dev", {}).items():
            if isinstance(version, str):
                pkg = Package(
                    name=name,
                    version=version,
                    ecosystem=Ecosystem.COMPOSER,
                    source_file=str(path),
                    dev_dependency=True,
                )
                packages.append(pkg)

        return packages


class CsprojParser:
    """Parser for .NET .csproj files."""

    def parse(self, path: Path) -> list[Package]:
        """Parse .csproj or PackageReference elements."""
        packages = []

        tree = ET.parse(path)
        root = tree.getroot()

        # Get namespaces
        ns = root.tag.split("}")[1] if "}" in root.tag else ""
        ns_map = {"": ns} if ns else {}

        # Find PackageReference elements
        for ref in root.iter():
            if ref.tag.endswith("PackageReference"):
                name = ref.get("Include")
                version = ref.get("Version")

                # Handle Version property as child element
                if not version:
                    for child in ref:
                        if child.tag.endswith("Version"):
                            version = child.text
                            break

                if name:
                    pkg = Package(
                        name=name,
                        version=version,
                        ecosystem=Ecosystem.DOTNET,
                        source_file=str(path),
                        dev_dependency=ref.get("PrivateAssets") == "all",
                    )
                    packages.append(pkg)

        return packages


class PackageRegistry:
    """Registry for all supported package parsers."""

    def __init__(self) -> None:
        self._parsers: dict[str, PackageLockParser] = {}
        self._file_parsers: dict[str, type] = {
            "requirements.txt": RequirementsTxtParser,
            "Pipfile": PipfileParser,
            "Pipfile.lock": PipfileParser,
            "package-lock.json": NpmLockParser,
            "yarn.lock": YarnLockParser,
            "pnpm-lock.yaml": PnpmLockParser,
            "pom.xml": PomXmlParser,
            "go.mod": GoModParser,
            "Cargo.toml": CargoTomlParser,
            "Gemfile": GemfileParser,
            "composer.json": ComposerJsonParser,
        }

    def register_parser(self, filename: str, parser: PackageLockParser) -> None:
        """Register a custom parser for a specific file."""
        self._parsers[filename] = parser

    def get_parser(self, path: Path) -> PackageLockParser | None:
        """Get a parser for a specific file."""
        if path.name in self._parsers:
            return self._parsers[path.name]

        parser_class = self._file_parsers.get(path.name)
        if parser_class:
            return parser_class()

        return None

    def parse_file(self, path: Path) -> list[Package]:
        """Parse a package file."""
        parser = self.get_parser(path)
        if parser is None:
            return []

        return parser.parse(path)

    def detect_ecosystem(self, path: Path) -> Ecosystem | None:
        """Detect the ecosystem from a file."""
        name = path.name.lower()

        ecosystem_map = {
            "requirements.txt": Ecosystem.PYTHON,
            "pyproject.toml": Ecosystem.PYTHON,
            "setup.py": Ecosystem.PYTHON,
            "pipfile": Ecosystem.PYTHON,
            "pipfile.lock": Ecosystem.PYTHON,
            "package.json": Ecosystem.NPM,
            "package-lock.json": Ecosystem.NPM,
            "yarn.lock": Ecosystem.YARN,
            "pnpm-lock.yaml": Ecosystem.PNPM,
            "pom.xml": Ecosystem.MAVEN,
            "build.gradle": Ecosystem.GRADLE,
            "build.gradle.kts": Ecosystem.GRADLE,
            "go.mod": Ecosystem.GO,
            "go.sum": Ecosystem.GO,
            "cargo.toml": Ecosystem.CARGO,
            "cargo.lock": Ecosystem.CARGO,
            "gemfile": Ecosystem.RUBY,
            "gemfile.lock": Ecosystem.RUBY,
            "composer.json": Ecosystem.COMPOSER,
            "composer.lock": Ecosystem.COMPOSER,
            ".csproj": Ecosystem.DOTNET,
            "packages.config": Ecosystem.DOTNET,
        }

        return ecosystem_map.get(name)

    def discover_files(self, root: Path) -> dict[Ecosystem, list[Path]]:
        """Discover all package files in a directory tree."""
        results: dict[Ecosystem, list[Path]] = {}

        for path in root.rglob("*"):
            if not path.is_file():
                continue

            ecosystem = self.detect_ecosystem(path)
            if ecosystem:
                if ecosystem not in results:
                    results[ecosystem] = []
                results[ecosystem].append(path)

        return results

    def parse_directory(
        self,
        root: Path,
        ecosystems: list[Ecosystem] | None = None,
    ) -> dict[Ecosystem, list[Package]]:
        """Parse all package files in a directory."""
        results: dict[Ecosystem, list[Package]] = {}

        discovered = self.discover_files(root)

        for ecosystem, paths in discovered.items():
            if ecosystems and ecosystem not in ecosystems:
                continue

            results[ecosystem] = []
            for path in paths:
                packages = self.parse_file(path)
                results[ecosystem].extend(packages)

        return results


# Global registry instance
_registry: PackageRegistry | None = None


def get_registry() -> PackageRegistry:
    """Get the global package registry."""
    global _registry
    if _registry is None:
        _registry = PackageRegistry()
    return _registry


def parse_lockfile(path: Path) -> list[Package]:
    """Convenience function to parse a lockfile."""
    return get_registry().parse_file(path)


def detect_ecosystem(path: Path) -> Ecosystem | None:
    """Convenience function to detect ecosystem."""
    return get_registry().detect_ecosystem(path)