"""deptrack - Validators for dependency specifications."""

import re
from typing import Optional, List, Tuple, Dict, Any
from dataclasses import dataclass
from urllib.parse import urlparse


@dataclass
class ValidationError:
    """Represents a validation error."""
    field: str
    message: str
    code: str


@dataclass
class ValidationResult:
    """Result of a validation operation."""
    is_valid: bool
    errors: List[ValidationError]

    @classmethod
    def success(cls) -> "ValidationResult":
        """Create a successful validation result."""
        return cls(is_valid=True, errors=[])

    @classmethod
    def failure(cls, errors: List[ValidationError]) -> "ValidationResult":
        """Create a failed validation result."""
        return cls(is_valid=False, errors=errors)

    def add_error(self, field: str, message: str, code: str = "INVALID") -> None:
        """Add an error to the result."""
        self.errors.append(ValidationError(field, message, code))
        self.is_valid = False


class VersionValidator:
    """Validates package version specifications."""

    # PEP 440 version pattern
    PEP440_PATTERN = re.compile(
        r'^'  # Start
        r'v?'  # Optional 'v' prefix
        r'(?:(0|[1-9]\d*)\.(?:(0|[1-9]\d*)\.(?:(0|[1-9]\d*)'
        r'(?:\.(?:(0|[1-9]\d*)))?)?)?)'  # Version core
        r'(?:-([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*))?'  # Pre-release
        r'(?:\+([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*))?'  # Build
        r'$'  # End
    )

    # Semantic versioning pattern
    SEMVER_PATTERN = re.compile(
        r'^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)'
        r'(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)'
        r'(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?'
        r'(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$'
    )

    # Version constraint patterns
    CONSTRAINT_PATTERNS = {
        "exact": re.compile(r'^==(.+)$'),
        "greater_than": re.compile(r'^>(.+)$'),
        "less_than": re.compile(r'^<(.+)$'),
        "greater_equal": re.compile(r'^>=(.+)$'),
        "less_equal": re.compile(r'^<=(.+)$'),
        "not_equal": re.compile(r'^!=(.+)$'),
        "compatible": re.compile(r'^~=(.+)$'),
        "wildcard": re.compile(r'^(\d+\.?\d*|\*)$'),
    }

    @classmethod
    def is_valid_version(cls, version: str, strict: bool = True) -> bool:
        """Check if a version string is valid."""
        if not version or not isinstance(version, str):
            return False

        # Check for invalid characters
        if not strict and "*" in version:
            return True

        # Check PEP 440 format
        if cls.PEP440_PATTERN.match(version):
            return True

        # Check semantic versioning
        if cls.SEMVER_PATTERN.match(version):
            return True

        return False

    @classmethod
    def parse_constraint(cls, constraint: str) -> Tuple[Optional[str], str]:
        """Parse a version constraint and return (operator, version)."""
        if not constraint:
            return None, ""

        constraint = constraint.strip()

        for op_name, pattern in cls.CONSTRAINT_PATTERNS.items():
            match = pattern.match(constraint)
            if match:
                if op_name == "wildcard":
                    return "*", match.group(1)
                return op_name, match.group(1)

        # If no operator, assume exact match
        return "==", constraint

    @classmethod
    def validate_constraint(cls, constraint: str) -> ValidationResult:
        """Validate a version constraint."""
        result = ValidationResult.success()

        if not constraint:
            result.add_error("constraint", "Constraint cannot be empty", "EMPTY")
            return result

        operator, version = cls.parse_constraint(constraint)

        if not operator:
            result.add_error("constraint", "Invalid constraint format", "INVALID_FORMAT")
            return result

        if operator != "*" and not cls.is_valid_version(version):
            result.add_error("version", f"Invalid version: {version}", "INVALID_VERSION")

        return result

    @classmethod
    def normalize_version(cls, version: str) -> str:
        """Normalize a version string."""
        # Remove leading 'v'
        if version.startswith('v'):
            version = version[1:]

        return version


class PackageNameValidator:
    """Validates package names."""

    # Python package name pattern (PEP 508)
    PYTHON_PATTERN = re.compile(
        r'^[A-Z0-9]([A-Z0-9._-]*[A-Z0-9])?$',
        re.IGNORECASE
    )

    # npm package name pattern
    NPM_PATTERN = re.compile(
        r'^(?:@[a-z0-9-*~][a-z0-9-*._~]*/)?'
        r'[a-z0-9-~][a-z0-9-._~]*$',
        re.IGNORECASE
    )

    # Maven package name pattern
    MAVEN_PATTERN = re.compile(
        r'^[a-z][a-z0-9-]*(\.[a-z][a-z0-9-]*)+$',
        re.IGNORECASE
    )

    # Go module name pattern
    GO_PATTERN = re.compile(
        r'^(?:[a-zA-Z0-9]+[a-zA-Z0-9._-]*)+$'
    )

    @classmethod
    def is_valid_python_name(cls, name: str) -> bool:
        """Check if a name is a valid Python package name."""
        if not name or len(name) > 214:
            return False

        # Reserved names
        if name.lower() in ("n", "c", "o", "l", "i"):
            return False

        return bool(cls.PYTHON_PATTERN.match(name))

    @classmethod
    def is_valid_npm_name(cls, name: str) -> bool:
        """Check if a name is a valid npm package name."""
        if not name:
            return False

        if len(name) > 214:
            return False

        # Scoped packages
        if name.startswith('@'):
            parts = name[1:].split('/')
            if len(parts) != 2:
                return False
            return (cls.NPM_PATTERN.match(f"@{parts[0]}") and
                    cls.NPM_PATTERN.match(parts[1]))

        return bool(cls.NPM_PATTERN.match(name))

    @classmethod
    def is_valid_maven_name(cls, name: str) -> bool:
        """Check if a name is a valid Maven artifact ID."""
        if not name:
            return False

        return bool(cls.MAVEN_PATTERN.match(name))

    @classmethod
    def is_valid_go_name(cls, name: str) -> bool:
        """Check if a name is a valid Go module name."""
        if not name:
            return False

        # Cannot start with dot or dash
        if name.startswith('.') or name.startswith('-'):
            return False

        # Cannot contain __
        if '__' in name:
            return False

        return bool(cls.GO_PATTERN.match(name))

    @classmethod
    def validate(cls, name: str, ecosystem: str = "python") -> ValidationResult:
        """Validate a package name for a specific ecosystem."""
        result = ValidationResult.success()

        if not name:
            result.add_error("name", "Package name cannot be empty", "EMPTY")
            return result

        validators = {
            "python": cls.is_valid_python_name,
            "npm": cls.is_valid_npm_name,
            "maven": cls.is_valid_maven_name,
            "go": cls.is_valid_go_name,
        }

        validator = validators.get(ecosystem.lower())
        if validator and not validator(name):
            result.add_error("name", f"Invalid {ecosystem} package name", "INVALID_NAME")

        return result


class URLValidator:
    """Validates URLs."""

    ALLOWED_SCHEMES = {"http", "https", "ftp", "ftps"}

    @classmethod
    def is_valid_url(cls, url: str, require_scheme: bool = True) -> bool:
        """Check if a URL is valid."""
        if not url:
            return False

        try:
            parsed = urlparse(url)

            if require_scheme and not parsed.scheme:
                return False

            if parsed.scheme.lower() not in cls.ALLOWED_SCHEMES:
                return False

            if not parsed.netloc:
                return False

            return True
        except Exception:
            return False

    @classmethod
    def validate(cls, url: str, require_scheme: bool = True) -> ValidationResult:
        """Validate a URL."""
        result = ValidationResult.success()

        if not url:
            result.add_error("url", "URL cannot be empty", "EMPTY")
            return result

        if not cls.is_valid_url(url, require_scheme):
            result.add_error("url", f"Invalid URL: {url}", "INVALID_URL")

        return result


class LicenseValidator:
    """Validates license identifiers."""

    # Common SPDX license identifiers
    COMMON_LICENSES = {
        "MIT", "Apache-2.0", "Apache 2.0", "BSD-2-Clause", "BSD-3-Clause",
        "GPL-2.0", "GPL-3.0", "LGPL-2.1", "LGPL-3.0", "MPL-2.0",
        "ISC", "Unlicense", "WTFPL", "CC0-1.0", "CC-BY-4.0",
        "Python-2.0", "Zlib", "PostgreSQL", " Artistic-2.0",
    }

    # SPDX license pattern
    SPDX_PATTERN = re.compile(r'^[A-Za-z0-9\-\.]{3,}$')

    # License expression operators
    EXPRESSION_PATTERN = re.compile(r'^\s*(AND|OR|WITH)\s+')

    @classmethod
    def is_valid_spdx(cls, license_id: str) -> bool:
        """Check if a license ID is a valid SPDX identifier."""
        if not license_id:
            return False

        # Check for common licenses (case-insensitive)
        if license_id.upper() in [l.upper() for l in cls.COMMON_LICENSES]:
            return True

        return bool(cls.SPDX_PATTERN.match(license_id))

    @classmethod
    def normalize(cls, license_str: str) -> str:
        """Normalize a license string."""
        if not license_str:
            return ""

        # Remove extra whitespace
        license_str = " ".join(license_str.split())

        # Common normalizations
        normalizations = {
            "Apache 2.0": "Apache-2.0",
            "Apache License 2.0": "Apache-2.0",
            "GPLv3": "GPL-3.0",
            "GPL3": "GPL-3.0",
            "BSD": "BSD-3-Clause",
            "BSD License": "BSD-3-Clause",
        }

        return normalizations.get(license_str, license_str)

    @classmethod
    def validate(cls, license_str: str) -> ValidationResult:
        """Validate a license string."""
        result = ValidationResult.success()

        if not license_str:
            result.add_error("license", "License cannot be empty", "EMPTY")
            return result

        # Check for compound expressions
        parts = license_str.replace("(", " ").replace(")", " ").split()
        for part in parts:
            part = part.strip()
            if part in ("AND", "OR", "WITH"):
                continue
            if not cls.is_valid_spdx(part):
                result.add_error("license", f"Invalid license: {part}", "INVALID_LICENSE")

        return result


class EnvironmentValidator:
    """Validates environment configuration."""

    @classmethod
    def is_valid_env_name(cls, name: str) -> bool:
        """Check if an environment variable name is valid."""
        if not name:
            return False

        # Must start with letter or underscore
        if not name[0].isalpha() and name[0] != '_':
            return False

        # Only alphanumeric and underscore
        return all(c.isalnum() or c == '_' for c in name)

    @classmethod
    def validate_key_value(cls, key: str, value: str) -> ValidationResult:
        """Validate an environment variable key-value pair."""
        result = ValidationResult.success()

        if not cls.is_valid_env_name(key):
            result.add_error("key", f"Invalid environment variable name: {key}", "INVALID_NAME")

        return result


class DependencyValidator:
    """Validates dependency specifications."""

    def __init__(
        self,
        validate_versions: bool = True,
        validate_names: bool = True,
        strict: bool = False
    ):
        self.validate_versions = validate_versions
        self.validate_names = validate_names
        self.strict = strict

    def validate(self, dependency: Dict[str, Any], ecosystem: str = "python") -> ValidationResult:
        """Validate a dependency specification."""
        result = ValidationResult.success()

        # Validate name
        if self.validate_names and "name" in dependency:
            name_result = PackageNameValidator.validate(dependency["name"], ecosystem)
            if not name_result.is_valid:
                result.errors.extend(name_result.errors)

        # Validate version
        if self.validate_versions and "version" in dependency:
            version = dependency["version"]
            if version:
                if version.startswith(("==", ">=", "<=", "~=", "!=", "> ", "< ")):
                    constraint_result = VersionValidator.validate_constraint(version)
                    if not constraint_result.is_valid:
                        result.errors.extend(constraint_result.errors)
                else:
                    if not VersionValidator.is_valid_version(version, self.strict):
                        result.add_error("version", f"Invalid version: {version}", "INVALID_VERSION")

        return result

    def validate_batch(
        self,
        dependencies: List[Dict[str, Any]],
        ecosystem: str = "python"
    ) -> Dict[str, ValidationResult]:
        """Validate multiple dependencies."""
        results = {}
        for dep in dependencies:
            name = dep.get("name", "unknown")
            results[name] = self.validate(dep, ecosystem)
        return results


class ConfigValidator:
    """Validates configuration files."""

    REQUIRED_FIELDS = ["version"]
    VERSION_PATTERN = re.compile(r'^\d+\.\d+$')

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> ValidationResult:
        """Validate a configuration dictionary."""
        result = ValidationResult.success()

        # Check required fields
        for field in cls.REQUIRED_FIELDS:
            if field not in config:
                result.add_error(field, f"Required field missing: {field}", "MISSING_FIELD")

        # Validate version format
        if "version" in config:
            version = config["version"]
            if not cls.VERSION_PATTERN.match(str(version)):
                result.add_error("version", f"Invalid version format: {version}", "INVALID_VERSION")

        return result


# Factory function
def get_validator(validator_type: str) -> Any:
    """Get a validator instance by type."""
    validators = {
        "version": VersionValidator(),
        "package_name": PackageNameValidator(),
        "url": URLValidator(),
        "license": LicenseValidator(),
        "environment": EnvironmentValidator(),
        "dependency": DependencyValidator(),
        "config": ConfigValidator(),
    }
    return validators.get(validator_type)