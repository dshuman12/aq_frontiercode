import { ORE_TYPES, type OreType } from '../../../game/engine'
import aluminumoreAsset from '../../../assets/aluminumore.png'
import coaloreAsset from '../../../assets/coalore.png'
import copperoreAsset from '../../../assets/copperore.png'
import lithiumoreAsset from '../../../assets/lithiumore.png'
import silicaoreAsset from '../../../assets/silicaore.png'
import silveroreAsset from '../../../assets/silverore.png'
import thoriumoreAsset from '../../../assets/thoriumore.png'
import titaniumoreAsset from '../../../assets/titaniumore.png'
import tungstenoreAsset from '../../../assets/tungstenore.png'
import {
  closeBitmapList,
  loadBitmapList,
  pickVariantIndexByPosition,
} from './spriteUtils'

export type OreSpriteDefinition = Record<OreType, string[]>

export type OreSpriteBitmaps = Record<OreType, ImageBitmap[]>

export const ORE_SPRITE_DEFINITION: OreSpriteDefinition = {
  iron: [silveroreAsset],
  copper: [copperoreAsset],
  coal: [coaloreAsset],
  silica: [silicaoreAsset],
  aluminum: [aluminumoreAsset],
  titanium: [titaniumoreAsset],
  lithium: [lithiumoreAsset],
  tungsten: [tungstenoreAsset],
  thorium: [thoriumoreAsset],
}

export async function loadOreSpriteBitmaps(
  definition: OreSpriteDefinition = ORE_SPRITE_DEFINITION,
): Promise<OreSpriteBitmaps | null> {
  const bitmaps = {} as OreSpriteBitmaps
  let loadedCount = 0

  for (const ore of ORE_TYPES) {
    const variants = await loadBitmapList(definition[ore] ?? [])
    bitmaps[ore] = variants
    loadedCount += variants.length
  }

  if (loadedCount === 0) return null
  return bitmaps
}

export function closeOreSpriteBitmaps(bitmaps: OreSpriteBitmaps | null): void {
  if (!bitmaps) return
  for (const ore of ORE_TYPES) {
    closeBitmapList(bitmaps[ore] ?? [])
  }
}

export function pickOreSpriteVariant(
  bitmaps: OreSpriteBitmaps | null,
  ore: OreType,
  x: number,
  y: number,
): ImageBitmap | null {
  if (!bitmaps) return null
  const variants = bitmaps[ore]
  if (!variants || variants.length === 0) return null
  return variants[pickVariantIndexByPosition(x, y, variants.length)] ?? null
}
